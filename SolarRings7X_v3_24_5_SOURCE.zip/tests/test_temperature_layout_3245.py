"""Watch-face layout regression checks for the weather lower panel.
These are static/layout checks, not Garmin emulator pixel snapshots.
"""
import re
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
PROPS=ET.parse(ROOT/'resources/settings/properties.xml').getroot()

class TemperatureLayout3245(unittest.TestCase):
    def test_badge_geometry_allows_the_temperature_to_fit(self):
        # drawSized x is the text center and width its maximum measured width.
        m=re.search(r'var tempX = hasMarkers \? (\d+) : (\d+);\s*var tempWidth = hasMarkers \? (\d+) : (\d+);', FACE)
        self.assertIsNotNone(m)
        center,old_center,width,old_width=map(int,m.groups())
        self.assertEqual((old_center,old_width),(174,105))
        self.assertGreaterEqual(center-width/2,162)
        self.assertLessEqual(center+width/2,230)
        self.assertLessEqual(center,200)  # no shift back to old rightmost x=211
        self.assertGreaterEqual(width,64) # readable 2-digit temperatures
    def test_icons_still_use_original_spots_and_partial_refresh(self):
        self.assertIn('temperatureMarker(dc, weather, warning != 0 ? 130 : 150, 227)',FACE)
        self.assertIn('drawGarminWarningIcon(dc, 150, 227, warning)',FACE)
        self.assertIn('drawGarminWarningIcon(dc, 150, 227, nextKind)',FACE)
        self.assertIn('dc.setClip(140, 216, 20, 22)',FACE)
        self.assertIn('var hasMarkers = hasThermometer || warning != 0;',FACE)
    def test_feels_like_description_does_not_shift_when_icons_present(self):
        self.assertIn('drawSized(dc, lowerLabel, 174, 234, 105, 16, lowerColor, false,', FACE)
        self.assertNotIn('hasMarkers ? 219 : 174', FACE)
    def test_temperature_alerts_remain_strict_with_saved_thresholds(self):
        self.assertIn('var hot = srSetting("tempHotV312", 30);',FACE)
        self.assertIn('var cold = srSetting("tempColdV312", 0);',FACE)
        self.assertIn('temp > hot',FACE)
        self.assertIn('temp < cold',FACE)
        defaults={p.attrib['id']:p.text for p in PROPS}
        self.assertEqual(defaults['tempHotV312'],'30')
        self.assertEqual(defaults['tempColdV312'],'0')
    def test_font_is_measured_and_scaled_to_slot(self):
        self.assertIn('var dim = dc.getTextDimensions(str, font);',FACE)
        self.assertIn('if (dim[0] <= width && dim[1] <= height)',FACE)
        self.assertIn('fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale)',FACE)
    def test_weather_warning_controls_are_preserved(self):
        for setting in ['gwPreviewV324','gwOnV324','gwIntervalV324','gwHorizonV324','showFeelsLikeV319']:
            self.assertIsNotNone(PROPS.find(".//property[@id='%s']" % setting))

if __name__ == '__main__': unittest.main()
