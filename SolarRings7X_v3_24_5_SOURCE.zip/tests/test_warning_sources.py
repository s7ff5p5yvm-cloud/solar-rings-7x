"""Static integration contracts for the source-aware warning engine.

These checks validate source code and settings, not firmware execution. Real
Monkey C compilation and Garmin Weather I/O happen in GitHub Actions/device.
"""
import re
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
ENGINE=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
UI=(ROOT/'resources/settings/settings.xml').read_text()
LABELS=ET.parse(ROOT/'resources/strings.xml').getroot()

class WarningSourceIntegration(unittest.TestCase):
    def test_current_forecast_tag_encoding_is_used(self):
        self.assertIn('function baseKind(tag)', ENGINE)
        self.assertIn('if (tag > 16) { return tag - 16; }', ENGINE)
        self.assertIn('if (isForecast) { tag += 16; }', ENGINE)
        self.assertIn('false);', ENGINE)
        self.assertIn('null, h.uvIndex, true), true);', ENGINE)

    def test_same_hazard_current_overrides_forecast(self):
        self.assertIn('if (baseKind(items[i]) == kind)', ENGINE)
        self.assertIn('if (items[i] > 16 && tag <= 16) { items[i] = tag; }', ENGINE)
        self.assertIn('addAlert(_lastKinds, 20); // forecast storm', ENGINE)
        self.assertIn('addAlert(_lastKinds, 4);  // currently observed storm wins', ENGINE)

    def test_warning_colors_come_only_from_source(self):
        self.assertIn('var color = Gfx.COLOR_RED;', FACE)
        self.assertIn('if (alertTag > 16)', FACE)
        self.assertIn('color = 0x00FFFF;', FACE)
        self.assertNotIn('var color = 0xFFFF00;', FACE)
        self.assertIn('var kind = alertTag;', FACE)
        self.assertIn('kind = alertTag - 16;', FACE)

    def test_one_icon_cell_and_five_second_stepping(self):
        self.assertIn('Time.now().value() / 5', ENGINE)
        self.assertIn('_lastKinds[phase % count]', ENGINE)
        self.assertIn('if (count == 1) { return _lastKinds[0]; }', ENGINE)
        self.assertIn('drawGarminWarningIcon(dc, 150, 227, warning)', FACE)
        self.assertIn('drawGarminWarningIcon(dc, 150, 227, nextKind)', FACE)
        self.assertIn('dc.setClip(140, 216, 20, 22)', FACE)
        self.assertIn('if (nextKind == _lastDrawnWeatherWarning)', FACE)
        self.assertIn('temperatureMarker(dc, weather, warning != 0 ? 130 : 150, 227)', FACE)

    def test_data_api_actual_and_hourly_sources(self):
        self.assertIn('Weather.getCurrentConditions()', FACE)
        self.assertIn('Weather.getHourlyForecast()', ENGINE)
        self.assertIn('current.observationTime.value()', ENGINE)
        self.assertIn('h.forecastTime.value() - now', ENGINE)
        self.assertIn('secondsOld <= 2700', ENGINE)
        self.assertIn('if (hourly == null)', ENGINE)
        self.assertIn('if (dt <= -3600 || dt > horizon * 3600)', ENGINE)

    def test_chance_only_current_categories_are_not_red(self):
        self.assertIn('if ((!isForecast && !stormOnlyChance) ||', ENGINE)
        self.assertIn('if ((!isForecast && !chanceOnlyRain) ||', ENGINE)
        self.assertIn('if ((!isForecast && !chanceOnlySnow) ||', ENGINE)
        for threshold in ('gwRainChanceV324', 'gwSnowChanceV324', 'gwStormChanceV324'):
            self.assertIn(threshold, ENGINE)

    def test_test_modes_preserved_and_expanded(self):
        for n in range(14):
            self.assertIn(f'value="{n}"', UI)
        self.assertIn('if (preview == 10)', ENGINE)
        self.assertIn('if (preview == 11)', ENGINE)
        self.assertIn('if (preview == 12)', ENGINE)
        self.assertIn('if (preview == 13)', ENGINE)
        names={x.attrib['id']:x.text for x in LABELS}
        self.assertIn('czerwona', names['gw_gwPreviewV324_10'])
        self.assertIn('niebieski', names['gw_gwPreviewV324_10'])

    def test_same_application_id_and_property_compatibility(self):
        manifest=ET.parse(ROOT/'manifest.xml').getroot()
        app=manifest.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['id'], 'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(app.attrib['version'], '3.24.5')
        props={v.attrib['id'] for v in ET.parse(ROOT/'resources/settings/properties.xml').getroot()}
        for key in ('gwOnV324','gwForecastV324','gwHorizonV324','gwPreviewV324',
                    'gwRainHeavyV324','gwSnowHeavyV324','showFeelsLikeV319'):
            self.assertIn(key,props)

if __name__=='__main__': unittest.main()
