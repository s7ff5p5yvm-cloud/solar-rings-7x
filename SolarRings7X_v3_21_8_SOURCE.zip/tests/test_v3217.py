from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
s=(p/'source/SolarRings7X.mc').read_text()
w=s.split('function drawWeather(dc, monitor, weather) {',1)[1].split('function drawBattery',1)[0]
class TestV3217(unittest.TestCase):
 def test_stage4_is_always_production_label(self):
  assert 'var diag = isTemp ? imgwDiagnosticLine(imgwSnapshot) : null;' in w
  gate='if (srSetting("imgwTestStageV3194", 0) == 4) {\n            diag = null;\n        }'
  assert gate in w
  assert w.index(gate) < w.index('if (diag != null) {')
  assert w.index(gate) < w.index('if (iconPreview) {\n            diag = null;')
 def test_stage1_and_11_diagnostics_stay_accessible(self):
  assert 'if (stage == 1) { return imgwLocationTestLine(); }' in s
  assert 'if (stage == 4 || stage == 11)' in s
  assert 'imgwDiagnosticsV3193' in s
 def test_label_still_has_feelslike_and_preview_test(self):
  assert 'lowerLabel = "ODCZ. " + weather.feelsLikeTemperature.format("%.0f") + "°C";' in w
  assert 'lowerLabel = "TEST: " + previewImgwName(previewKind);' in w
  assert 'if (hasImgw) {' in w
 def test_manifest_settings(self):
  ET.parse(p/'manifest.xml')
  assert 'version="3.21.8"' in (p/'manifest.xml').read_text()
  st=(p/'resources/strings.xml').read_text()
  assert '4 - IMGW normalne' in st
if __name__=='__main__': unittest.main()
