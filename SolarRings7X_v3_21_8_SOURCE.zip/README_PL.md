# Solar Rings 7X v3.21.8

## Poprawka kompilacji Connect IQ

Błąd `Cannot find symbol ':toNumber' on type 'Position.Quality'` został poprawiony przez jawne porównania ze stałymi `Position.QUALITY_*` i zapis liczbowej jakości w zakresie 0–4.

Zachowano wszystkie zmiany v3.21.7 (m.in. bezstatusowy widok produkcyjny Test 4, ikony IMGW, kontrastowe kolory, termometr, diagnostyka GPS).

Wgraj `SolarRings7X_v3_21_8_SOURCE.zip` do katalogu głównego repozytorium oraz `SolarRings7X_v3_21_8_BUILD.yml` do `.github/workflows/`, uruchom nowy workflow, potem pobierz wynikowy PRG lub IQ. Kompilacja Garmin SDK jest weryfikowana dopiero przez GitHub Actions, a nie testy lokalne.
