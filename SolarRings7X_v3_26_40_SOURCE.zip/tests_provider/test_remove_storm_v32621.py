import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
UI=(ROOT/'source/SolarRings7X.mc').read_text()
STR=(ROOT/'resources/strings.xml').read_text()
P=(ROOT/'resources/settings/properties.xml').read_text()
S=(ROOT/'resources/settings/settings.xml').read_text()
G=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
O=(ROOT/'source/SolarOpenWarnings.mc').read_text()
N=(ROOT/'source/SolarOpenNetwork.mc').read_text()
class StormGuardRemoval32621(unittest.TestCase):
    def test_no_heuristic_or_warnings_settings(self):
        self.assertFalse((ROOT/'source/StormGuard.mc').exists())
        for name in ('stormOnV3','stormDropV3','stormFastV310','stormFastDropV310','stormAltitudeV3'):
            for text in (UI,P,S,STR): self.assertNotIn(name,text)
        self.assertNotIn('_storm',UI)
        self.assertNotIn('SensorHistory',UI)
    def test_three_original_weather_cells_and_rotation(self):
        self.assertIn('var centers = [68, 91, 114];',UI)
        self.assertIn('if (fixedCount > 3) { fixedCount = 2; }',UI)
        self.assertIn('if (count > 3)',UI)
        self.assertIn('for (var k = 2; k < count; k++)',UI)
        self.assertIn('dc.setClip(103, 217, 22, 26)',UI)
        self.assertIn('drawAlertGlyph(dc, 114, kind)',UI)
    def test_sources_keep_real_storm_alerts(self):
        self.assertIn('gwStormOnV332',G)
        self.assertIn('gwStormOnV332',O)
        self.assertIn('code >= 200 && code <= 232',O)
        self.assertIn('if (kind == 4)',UI)
    def test_ordinary_pressure_field_remains(self):
        f=(ROOT/'source/FieldData.mc').read_text()
        self.assertIn('History.getPressureHistory',f)
        self.assertIn('id="data_22"',STR)
    def test_no_change_to_network_count(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),2)
    def test_xml_and_version(self):
        for f in ROOT.rglob('*.xml'):ET.parse(f)
        m=ET.parse(ROOT/'manifest.xml').getroot()
        app=m.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('version'),'3.26.40')
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
