"""Static regression: diagnostic WMO mapping must not index a nested empty array.
These tests do not replace Garmin Monkey C compilation on actual Connect IQ SDK.
"""
from pathlib import Path
import re
import unittest
SRC=(Path(__file__).resolve().parents[1]/'source/SolarOpenNetwork.mc').read_text()
class TestMeteoForecastCompile(unittest.TestCase):
    def test_no_dynamic_array_double_literal_index(self):
        self.assertNotRegex(SRC, r'\bmini\s*\[\s*0\s*\]\s*\[\s*1\s*\]')
        meteo=SRC[SRC.index('    function receiveMeteo('):SRC.index('    function onReceive(')]
        self.assertNotIn('if (mini[z][1] != null)', meteo)
    def test_first_recognized_pair_is_aligned(self):
        self.assertIn('var rawWmo = meteoSeries(series, "weather_code", i);', SRC)
        self.assertIn('var code = meteoId(rawWmo);', SRC)
        self.assertIn('if (code != null && firstRecognizedId == null)', SRC)
        self.assertIn('firstRecognizedWmo = rawWmo;', SRC)
        self.assertIn('firstRecognizedId = code;', SRC)
        self.assertIn('var recognized = firstRecognizedId != null;', SRC)
        self.assertIn('[_now, firstRecognizedWmo, firstRecognizedId]',SRC)
    def test_no_extra_network_request(self):
        self.assertEqual(SRC.count('Comm.makeWebRequest('),2)
    def test_forecast_storage_unchanged(self):
        self.assertIn('mini.add([stamp.toNumber(), code,',SRC)
        self.assertIn('[_loc[0], _loc[1], _now, mini]',SRC)
if __name__=='__main__': unittest.main()
