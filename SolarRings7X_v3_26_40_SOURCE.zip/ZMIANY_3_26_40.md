# Solar Rings 7X v3.26.40 — poprawka kompilacji v3.26.39

Baza: **wersja testowa 3.26.39** (Photon TEST 21 + Open-Meteo), oparta na stabilnej **3.26.37**. Stabilnej paczki nie zmieniono.

## Naprawa błędu kompilatora Connect IQ
- `source/SolarOpenNetwork.mc`, prognoza Open-Meteo: usunięto `mini[0][1]`, które kompilator odrzucał jako `Array index is out of bounds for type Toybox.Lang.Array[]`.
- Zamiast indeksowania zagnieżdżonej tablicy zapisujemy WMO i przetłumaczony identyfikator pierwszego rozpoznanego wiersza w dwóch prostych zmiennych.
- Naprawia to również niedopasowanie diagnostyki, gdy pierwszy wiersz ma nieobsługiwany kod, a kolejny prawidłowy.
- Bez zmian w formacie zapisywanych prognoz, w interwałach, Photon, ostrzeżeniach lub UI.
- Dodano regresyjny test źródłowy wykrywający powrót ryzykownego indeksowania.

**Ważne:** bez lokalnego Garmin Connect IQ SDK nie można potwierdzić kompilacji Monkey C; testy Pythona i XML nie są substytutem kompilatora.
