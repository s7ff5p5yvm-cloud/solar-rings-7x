# Solar Rings 7X v3.26.36 — obsługa ustawień / provider / pamięć

**Podstawa:** CIQ_LOG[1](7).YML i IQ v3.26.35: `Unexpected Type Error` w trakcie `Properties.getValue()` po zmianie ustawień (obręcz / odczuwalna).

1. `Config.mc`: w `srSetting()` odczyt jest ujednolicany do typu `fallback` (liczba, Boolean, String) **przed** wpisaniem do cache. Niepoprawna wartość wraca do domyślnej; błędny String nie jest używany w porównaniach. `String.toNumber()` chroniony `try/catch`. Nie ma obietnicy naprawy natywnego błędu w samym `Props.getValue()`.
2. `Config.mc`: `srResetSettingsCache()` przy zapisie ustawień jedynie odłącza stary cache (`null`). Nowy Dictionary powstaje dopiero przy faktycznym odczycie; nie jest tworzony w `onSettingsChanged()`.
3. `SolarOpenNetwork.mc`: normalizacja ustawień w procesie background również, niezależnie od foreground.
4. `WeatherGeocode.mc`: obsługa null/nietypowanych providerów i ścisła selekcja `1 || 2` we wszystkich trzech zdarzeniach, w tym migracji OWM do Open-Meteo.
5. `SolarRings7X.mc`: zmiana samego wyglądu nie usuwa i nie tworzy od nowa czasowego eventu pogodowego. Przełączenie dostawcy nadal to robi.
6. **Nie zmieniono progu 60 KB -> 30 KB**, ponieważ bez pomiaru wolnej pamięci na zegarku obniżenie progu może wywołać kolejne OOM. Nie zmieniono bieżących progów ostrzeżeń, silnika modeli Open-Meteo, zapytań, geometrii kapsuł, baterii ani ustawienia temperatury odczuwalnej.
7. Jutrzejszy wschód słońca to osobna poprawka funkcjonalna; celowo poza tym wydaniem naprawczym.

**Testy offline nie są testami uruchomienia na zegarku.** Dokładne sprawdzenie wymagają kompilacji Garmin SDK i testu na Fenix 7X Pro, szczególnie ustawień `outerRingV31=0`, `showFeelsLikeV319=true`, `srProviderV326=2`, zarówno osobno, jak i razem.
