"""Static integration regression tests for observed settings crash: these
verify code paths and types, not monkeyc runtime on a real watch."""
from pathlib import Path
import re, unittest, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1]
C=(P/'source/Config.mc').read_text()
G=(P/'source/WeatherGeocode.mc').read_text()
S=(P/'source/SolarOpenNetwork.mc').read_text()
U=(P/'source/SolarRings7X.mc').read_text()
R=ET.parse(P/'resources/settings/properties.xml').getroot()
SET=ET.parse(P/'resources/settings/settings.xml').getroot()

class SettingsCrashRegressions32636(unittest.TestCase):
    def test_every_direct_static_property_key_is_declared(self):
        known={p.attrib['id'] for p in R}
        used=set()
        for f in (P/'source').glob('*.mc'):
            txt=f.read_text()
            used.update(re.findall(r'(?:srSetting|Props\.getValue|App\.Properties\.getValue)\(\s*"([^"]+)"',txt))
        self.assertFalse(used-known)
    def test_settings_resource_types_agree(self):
        props={p.get('id'):p.get('type') for p in R}
        for s in SET.findall('setting'):
            key=s.get('propertyKey','').removeprefix('@Properties.')
            cfg=s.find('settingConfig')
            self.assertIn(key,props)
            if cfg is not None and cfg.get('type') == 'boolean':
                self.assertEqual(props[key],'boolean')
            if cfg is not None and cfg.get('type') == 'list':
                self.assertEqual(props[key],'number')
                for ent in cfg.findall('listEntry'):
                    self.assertRegex(ent.get('value',''), r'^-?\d+$')
    def test_type_conversion_before_main_cache(self):
        self.assertIn('function srSettingTyped(value, fallback)',C)
        self.assertIn('value = srSettingTyped(value, fallback);',C)
        self.assertIn('value.toNumber()',C)
        self.assertIn('value.equals("true")',C)
        self.assertIn('value.equals("false")',C)
        self.assertLess(C.index('value = srSettingTyped(value, fallback);'),C.index('_srSettingCache[key] = value;'))
        self.assertIn('if (_srSettingCache == null) { _srSettingCache = {}; }',C)
        self.assertIn('_srSettingCache = null;',C)
    def test_background_types_are_not_relayed_raw(self):
        self.assertIn('var n = v.toNumber()',S)
        self.assertIn('return v instanceof Lang.String ? v : fallback;',S)
        self.assertIn('return n instanceof Lang.Number ? n : fallback;',S)
    def test_background_provider_is_explicit_and_null_safe(self):
        self.assertIn('function selectedProvider()',G)
        self.assertIn('return 0;',G)
        self.assertEqual(G.count('if (provider == 1 || provider == 2)'),3)
        self.assertNotIn('if (provider != 0)',G)
        self.assertEqual(G.count('var provider = selectedProvider();'),3)
    def test_appearance_does_not_reschedule_background_service(self):
        f=U.split('function refreshChangedSettings()',1)[1].split('function rebuildWeatherWarnings()',1)[0]
        self.assertIn('if (modeChanged && mode != 0)',f)
        self.assertIn('else if (modeChanged)',f)
        self.assertIn('var modeChanged = mode != _srSelectedProvider;',f)
    def test_memory_reserve_not_dropped_without_evidence(self):
        self.assertIn('stats.freeMemory < 60000',U)
        self.assertNotIn('stats.freeMemory < 30000',U)
    def test_valid_user_requested_settings_exist(self):
        d={x.attrib['id']:x for x in R}
        self.assertEqual(d['showFeelsLikeV319'].attrib['type'],'boolean')
        self.assertEqual(d['outerRingV31'].attrib['type'],'number')
        self.assertEqual(d['srProviderV326'].attrib['type'],'number')

if __name__=='__main__':unittest.main()
