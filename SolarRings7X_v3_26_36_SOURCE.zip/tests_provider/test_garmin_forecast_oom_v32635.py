"""Regression contracts for symbolized real-watch OOM. Source-level only.

The supplied v32634 debug.xml maps 0x10007d7c to Config.mc:37,
called by GarminWeatherWarnings.evaluate line 420 after getHourlyForecast.
"""
import re
import unittest
from pathlib import Path

R=Path(__file__).resolve().parents[1]
G=(R/'source/GarminWeatherWarnings.mc').read_text()
F=(R/'source/SolarRings7X.mc').read_text()

class GarminForecastOOM(unittest.TestCase):
    def test_forecast_rule_snapshot_all_22_original_settings(self):
        prepare=G.split('function prepareRules()',1)[1].split('function rule(',1)[0]
        options=re.findall(r'srSetting\("([^"\n]+)",\s*([^)]*?)\)',prepare)
        self.assertEqual(len(options),22)
        self.assertEqual(len(set(k for k,d in options)),22)
        self.assertEqual(options[5],('gwWindV332','10'))
        self.assertEqual(options[7],('gwFogMetersV332','500'))
        self.assertEqual(options[-2],('gwForecastV332','true'))
        self.assertEqual(options[-1],('gwHorizonV332','1'))

    def test_forecast_evaluation_never_calls_native_properties_while_hourlies_live(self):
        warning=G.split('function warning(current)',1)[1].split('function allWarnings(',1)[0]
        self.assertLess(warning.index('prepareRules();'),warning.index('evaluate(current, now)'))
        self.assertLess(warning.index('evaluate(current, now)'),warning.index('_ruleValues = null;',warning.index('evaluate(current, now)')))
        for method,nextmethod in [('forecastChanceMatches','iceChanceMatches'),('iceChanceMatches','classify'),('classify','evaluate')]:
            body=G.split('function '+method+'(',1)[1].split('function '+nextmethod+'(',1)[0]
            self.assertNotIn('srSetting(',body)
        evaluate=G.split('function evaluate(current, now)',1)[1]
        self.assertNotIn('srSetting(',evaluate)
        self.assertIn('var horizon = rule(21);',evaluate)

    def test_memory_guard_precedes_full_hourly_forecast(self):
        evaluate=G.split('function evaluate(current, now)',1)[1]
        self.assertLess(evaluate.index('if (freeBeforeHourly < 73728)'),evaluate.index('Weather.getHourlyForecast()'))
        self.assertIn('return orderAlerts(matched)',evaluate)

    def test_evaluate_before_dynamic_face_drawing(self):
        update=F.split('function onUpdate(dc)',1)[1]
        self.assertLess(update.index('_weatherWarnings.allWarnings(w)'),update.index('outerProgressRing(dc'))
        draw=F.split('function drawAlertCenter(dc, weather)',1)[1].split('function drawBattery(',1)[0]
        self.assertIn('warnings = _weatherWarnings.cachedWarnings()',draw)
        self.assertIn('warnings = _weatherWarnings.allWarnings(weather)',draw)

    def test_open_meteo_unchanged_and_capsules_stay_clear(self):
        self.assertIn('var top = 171;',F)
        self.assertIn('rule(dc, 164);',F)
        self.assertIn('srOwmVisibleCurrent()',F)
        self.assertIn('version="3.26.36"',(R/'manifest.xml').read_text())

if __name__=='__main__':unittest.main()
