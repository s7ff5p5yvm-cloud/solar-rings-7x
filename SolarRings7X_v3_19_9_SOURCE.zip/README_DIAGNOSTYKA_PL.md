# Solar Rings 7X v3.19.9 — test odpowiedzi GUGiK

Poprzedni wynik na zegarku: **T3 F5** (odpowiedź HTTP 200, ale pierwszy wiersz ULDK nie miał statusu powodzenia `0`).

W tej wersji:
- zapytanie GetCountyByXY ma jawny adres URL zgodny z dokumentacją ULDK;
- parser toleruje spacje/CR wokół statusu, ale nigdy nie uznaje błędnego statusu za sukces;
- jeśli pierwszy wiersz jest niepoprawny, tarcza pokaże krótki fragment tego wiersza (`T3 F5-1`, `T3 F5--1`, `T3 F5-html` itp.);
- nie zmieniono pobierania GPS ani interwału IMGW.

## Test na zegarku
1. Zainstaluj nową wersję.
2. IMGW włączone, diagnostyka włączona, **Test 3 – GUGiK**, odświeżanie co 5 minut.
3. Poczekaj na wynik i odczytaj dokładny napis.
4. `T3 #### OK`: GUGiK poprawnie ustalił 4-cyfrowy kod powiatu. Dopiero wtedy test 4.
5. `T3 F5-X`: serwer zwraca status inny niż `0`. Przepisz X. Nie interpretuj tego jako braku ostrzeżeń.

`T3 F5-X` to kod diagnostyczny, nie kod powiatu. Kompilacja Garmin SDK i działanie na zegarku muszą zostać potwierdzone osobno.
