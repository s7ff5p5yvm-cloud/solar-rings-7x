from pathlib import Path
import xml.etree.ElementTree as ET
p = Path(__file__).resolve().parent
m = ET.parse(p/'manifest.xml').getroot()
a = m.find('{http://www.garmin.com/xml/connectiq}application')
assert a is not None and a.attrib.get('version') == '3.23.0'
print('OK: 3.23.0')
