# Solar Rings 7X — wydanie końcowe 3.23.0 (bez IMGW)

Wersja opracowana na bazie v3.21.9, ze sprawdzonym układem tarczy i kolorami.
Cały moduł IMGW został usunięty, nie tylko wyłączony: brak usług w tle,
HTTP do IMGW/GUGiK, obsługi ostrzeżeń, testów IMGW i ustawień lokalizacji IMGW.

## Co pozostaje
- Zegar, data, 3 pierścienie, 8 pól konfigurowalnych, tarcza księżyca,
  zwykła pogoda Garmin, pogoda odczuwalna i ikony warunków pogodowych.
- Termometr ostrzegawczy (temperatura poniżej ustawionego progu / powyżej
  górnego), z własnym ustawieniem w Connect IQ.
- Body Battery: kolor żółty przy niskim poziomie, czerwony przy 10% lub mniej.
- Bateria zegarka: żółty przy niskim poziomie, czerwony przy poziomie krytycznym.
- Kolory pierścieni, stresu, minut intensywnych i innych istniejących pól;
  ochrona przed awarią podczas rysowania pogody.
- Zachowane identyfikatory ustawień innych niż IMGW oraz identyfikator
  aplikacji w manifest.xml (dla zgodności preferencji).

## Ważne
Pozostaje uprawnienie Positioning wyłącznie dla zapasowego ustalania
wschodu i zachodu słońca, gdy zwykła pogoda Garmina nie poda lokalizacji.
Nie ma własnego odświeżania GPS ani sieciowego mechanizmu ostrzeżeń IMGW.
Możliwe jest, że w pamięci zegarka pozostało stare zarejestrowane zadanie
w tle po poprzednich wydaniach: przed instalacją tej końcowej wersji
zalecana jest deinstalacja poprzedniej tarczy (może skasować preferencje)
i ponowna instalacja. Przed usunięciem zanotuj swoje ustawienia.

## Instalacja przez GitHub Actions
1. Wgraj `SolarRings7X_v3_23_0_SOURCE.zip` do głównego katalogu repozytorium.
2. Wgraj `SolarRings7X_v3_23_0_BUILD.yml` do `.github/workflows/`.
3. W GitHub Actions uruchom `Build Solar Rings 7X - final bez IMGW`.
4. Pobierz artefakt z plikami PRG i IQ.

Weryfikacja: testy statyczne oraz test integracji zasobów wykonywane w Actions.
Niezbędna jest kompilacja Garmin SDK i próba uruchomienia na zegarku.
