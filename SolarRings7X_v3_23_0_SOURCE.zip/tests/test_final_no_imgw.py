import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
MC=(ROOT/'source/SolarRings7X.mc').read_text()
FC=(ROOT/'source/FieldData.mc').read_text()
P=ET.parse(ROOT/'resources/settings/properties.xml').getroot()
S=ET.parse(ROOT/'resources/settings/settings.xml').getroot()
STR=ET.parse(ROOT/'resources/strings.xml').getroot()
MAN=ET.parse(ROOT/'manifest.xml').getroot()
APP=MAN.find('{http://www.garmin.com/xml/connectiq}application')

class FinalWithoutImgw(unittest.TestCase):
    def test_manifest_version(self):
        self.assertEqual(APP.attrib['version'],'3.23.0')
    def test_no_service(self):
        self.assertFalse((ROOT/'source/ImgwService.mc').exists())
        self.assertNotIn('getServiceDelegate',MC)
        self.assertNotIn('onBackgroundData',MC)
        self.assertNotIn('registerForTemporalEvent',MC)
    def test_no_http_or_background_permission(self):
        self.assertNotIn('Communications',ET.tostring(MAN,encoding='unicode'))
        self.assertNotIn('Background',ET.tostring(MAN,encoding='unicode'))
    def test_no_imgw_in_source(self):
        for file in (ROOT/'source').glob('*.mc'):
            self.assertNotIn('imgw',file.read_text().lower(),file.name)
    def test_no_imgw_resources(self):
        for file in (ROOT/'resources').rglob('*.xml'):
            self.assertNotIn('imgw',file.read_text().lower(),file.name)
    def test_settings_resolve(self):
        property_ids={x.attrib['id'] for x in P}
        string_ids={x.attrib['id'] for x in STR}
        for setting in S:
            self.assertIn(setting.attrib['propertyKey'].split('.')[-1],property_ids)
            self.assertIn(setting.attrib['title'].split('.')[-1],string_ids)
            for x in setting.iter('listEntry'):
                self.assertIn(x.text.split('.')[-1],string_ids)
    def test_cached_weather_remains(self):
        self.assertIn('Weather.getCurrentConditions()',MC)
        self.assertIn('conditionText(weather)',MC)
    def test_feels_like_preserved(self):
        self.assertIn('showFeelsLikeV319',MC)
        self.assertIn('weather.feelsLikeTemperature',MC)
        self.assertIn('ODCZ. ',MC)
    def test_temp_warning(self):
        self.assertIn('temperatureMarker',MC)
        self.assertIn('tempColdV312',MC)
        self.assertIn('tempHotV312',MC)
    def test_body_battery_colors(self):
        self.assertIn('if (percent <= 10) { return Gfx.COLOR_RED; }',MC)
        self.assertIn('if (percent <= bodyLow) { return Gfx.COLOR_YELLOW; }',MC)
    def test_render_layout(self):
        for code in ('drawMoonPanel(dc)','capsule(dc, 32','capsule(dc, 99',
                     'capsule(dc, 185','drawBattery(dc, monitor, w)',
                     'drawWeather(dc, monitor, w)'):
            self.assertIn(code,MC)
    def test_sunrise_sunset(self):
        self.assertIn('Weather.getSunrise',FC)
        self.assertIn('Weather.getSunset',FC)
    def test_sources_have_balanced_braces(self):
        # A fast structural check; real Monkey C syntax is checked by Garmin SDK.
        for p in (ROOT/'source').glob('*.mc'):
            text=p.read_text()
            self.assertEqual(text.count('{'),text.count('}'),p.name)

if __name__=='__main__':unittest.main()
