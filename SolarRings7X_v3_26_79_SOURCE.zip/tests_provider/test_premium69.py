import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile

P = Path(__file__).resolve().parent.parent
S = (P / 'source/SolarRings7X.mc').read_text(encoding='utf-8')
F = (P / 'source/FieldData.mc').read_text(encoding='utf-8')
SERVICE = (P / 'source/SolarRingsGarminService.mc').read_text(encoding='utf-8')


def function_body(name):
    m = re.search(r'function\s+' + re.escape(name) + r'\s*\([^)]*\)\s*\{', S)
    if not m:
        raise AssertionError('Missing method: ' + name)
    start = m.end()
    depth = 1
    i = start
    while i < len(S):
        if S[i] == '{': depth += 1
        elif S[i] == '}':
            depth -= 1
            if depth == 0: return S[start:i]
        i += 1
    raise AssertionError('Unclosed method: ' + name)


class Premium69(unittest.TestCase):
    def test_all_35_available_and_individually_mapped(self):
        root = ET.parse(P / 'resources/settings/settings.xml').getroot()
        options = []
        for item in root.findall('setting'):
            if 'slot' in item.attrib.get('propertyKey', ''):
                options.append({int(x.attrib['value']) for x in item.findall('./settingConfig/listEntry')})
        self.assertEqual(len(options), 8)
        self.assertTrue(all(opts == set(range(36)) for opts in options))
        dispatcher = function_body('drawIcon')
        specialized = function_body('premiumSmallIcon')
        known = {int(x) for x in re.findall(r'\bid\s*==\s*(\d+)', dispatcher + specialized)}
        self.assertEqual(known, set(range(36)), f'Uncovered icons: {set(range(36))-known}')
        for field in ('premiumSmallIcon', 'premiumSmallSun', 'premiumSmallCloud',
                      'premiumSmallThermometer', 'premiumSmallClock', 'premiumSmallTimer'):
            self.assertIn('function ' + field + '(', S)

    def test_special_glyphs_are_different(self):
        small = function_body('premiumSmallIcon')
        for x in ['Floors up / down', 'Recovery', 'Stress', 'SpO2',
                  'Breathing', 'Barometer', 'Altitude', 'UV index',
                  'Rain probability', 'Calendar', 'Cloud cover',
                  'Daily steps goal', 'Weekly minutes goal']:
            self.assertIn(x, small)
        self.assertIn('id == 24', small)
        self.assertIn('id == 25', small)
        self.assertIn('id == 26 || id == 27', small)
        self.assertIn('id == 8 || id == 9', small)

    def test_all_small_icon_methods_are_lightweight(self):
        for method in ['premiumSmallIcon', 'premiumSmallSun', 'premiumSmallCloud',
                       'premiumSmallThermometer', 'premiumSmallClock', 'premiumSmallTimer']:
            body = function_body(method)
            for forbidden in ['Time.now(', 'Weather.', 'Activity.', 'Monitor.',
                              'App.Storage', 'new ', 'registerForTemporalEvent(',
                              'getTextDimensions(', 'drawText(']:
                self.assertNotIn(forbidden, body, (method, forbidden))
        self.assertIn('if (y == 30)', function_body('drawIcon'))

    def test_live_hr_not_buffered(self):
        self.assertIn('var hr = activity.currentHeartRate;', F)
        self.assertIn('x = recentHeartRate();', F)
        self.assertIn('_frameEpoch += 1;', S)
        self.assertNotIn('sampleValue(1)', F)

    def test_weather_and_photon_unchanged(self):
        self.assertIn('Weather.getCurrentConditions()', S)
        self.assertNotIn('Weather.getHourlyForecast(', S + F + SERVICE)
        self.assertIn('srPhotonScheduleIfNeeded()', S)
        self.assertNotIn('registerForTemporalEvent(', S)
        self.assertIn('now - _cachedWeatherAt < 55', S)
        self.assertIn('function drawCurrentWeatherIcon(', S)
        self.assertIn('function bodyBatteryIcon(', S)

    def test_manifest_settings_and_xml(self):
        m = (P / 'manifest.xml').read_text()
        self.assertIn('version="3.26.79"', m)
        self.assertIn('id="D1F8E1A4B7FC45BD91E8F0A0959041BF"', m)
        for permission in ['Communications','Positioning','Background','SensorHistory']:
            self.assertIn('id="'+permission+'"', m)
        for file in P.rglob('*.xml'):
            ET.parse(file)

    def test_monkeyc_delimiter_balance(self):
        # Parse delimiter structure with strings, line and block comments removed.
        for src in (P / 'source').glob('*.mc'):
            data = src.read_text(encoding='utf-8')
            cleaned = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"', '', data, flags=re.S)
            pair = {')': '(', ']': '[', '}': '{'}
            stack = []
            for ch in cleaned:
                if ch in '([{': stack.append(ch)
                elif ch in ')]}':
                    self.assertTrue(stack and stack.pop() == pair[ch], (src.name, ch))
            self.assertFalse(stack, src.name)

if __name__ == '__main__': unittest.main()
