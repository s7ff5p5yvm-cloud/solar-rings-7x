import unittest,re,xml.etree.ElementTree as ET
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text()
F=(P/'source/FieldData.mc').read_text()
B=(P/'source/SolarRingsGarminService.mc').read_text()
class Premium68(unittest.TestCase):
 def test_realtime_heart_rate_unchanged(self):
  self.assertIn('var hr = activity.currentHeartRate;',F)
  self.assertIn('x = recentHeartRate();',F)
  self.assertIn('_frameEpoch += 1;',S)
  self.assertNotIn('sampleValue(1)',F)
  self.assertNotIn('onPartialUpdate(',S)
 def test_battery_static_field_optimization(self):
  self.assertIn('_cachedCalendar = Gregorian.info(Time.now(), Time.FORMAT_SHORT);',S)
  self.assertIn('_calendarMinuteKey != minuteKey',S)
  self.assertIn('var monitor = Monitor.getInfo();',S)
  self.assertIn('var stats = null;',S)
 def test_icon_family(self):
  for f in ('sunIcon','heart','footprints','batteryIcon','bodyBatteryIcon','intensityTimerIcon','currentWeatherCloud','currentWeatherSun','currentWeatherIce'):
   self.assertIn('function '+f+'(',S)
  self.assertIn('Raised arms',S)
  self.assertIn('0x55AAFF',S)
  self.assertIn('0xAAFFFF',S)
 def test_no_weather_alert_polling(self):
  self.assertNotIn('Weather.getHourlyForecast(',S+B+F)
  self.assertNotIn('onPartialUpdate(',S)
  self.assertNotIn('registerForTemporalEvent(',S)
  self.assertIn('Weather.getCurrentConditions()',S)
  self.assertIn('srPhotonScheduleIfNeeded()',S)
 def test_identifiers_and_permissions(self):
  M=(P/'manifest.xml').read_text()
  self.assertIn('version="3.26.72"',M)
  for permission in ('Positioning','Communications','Background','SensorHistory'):
   self.assertIn('id="'+permission+'"',M)
  props=ET.parse(P/'resources/settings/properties.xml').getroot()
  keys=[x.attrib['id'] for x in props]
  self.assertEqual(len(keys),len(set(keys)))
 def test_no_extra_user_timers(self):
  self.assertEqual(S.count('function getCachedConditions()'),1)
  self.assertIn('now - _cachedWeatherAt < 55',S)
  self.assertNotIn('lang" => "pl"',B)
if __name__=='__main__':unittest.main()
