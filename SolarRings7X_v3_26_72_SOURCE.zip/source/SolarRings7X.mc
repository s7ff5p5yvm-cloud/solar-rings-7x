using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;
using Toybox.Math as Math;

// Immutable labels: avoid two new arrays on every high-power redraw.
var _srDays = ["ND", "PN", "WT", "SR", "CZ", "PT", "SB"];
var _srMonths = ["STY", "LUT", "MAR", "KWI", "MAJ", "CZE",
                 "LIP", "SIE", "WRZ", "PAZ", "LIS", "GRU"];

var _srMoonExtents7 = [0.000000000000000, 3.605551275463989, 4.898979485566356, 5.744562646538029, 6.324555320336759, 6.708203932499369, 6.928203230275509, 7.000000000000000, 6.928203230275509, 6.708203932499369, 6.324555320336759, 5.744562646538029, 4.898979485566356, 3.605551275463989, 0.000000000000000];
// v3.24.24: 28px lunar disk uses a precomputed row geometry table.
var _srMoonExtents14 = [0.00000000000000, 5.19615242270663, 7.21110255092798, 8.66025403784439, 9.79795897113271, 10.72380529476361, 11.48912529307606, 12.12435565298214, 12.64911064067352, 13.07669683062202, 13.41640786499874, 13.67479433117734, 13.85640646055102, 13.96424004376894, 14.00000000000000, 13.96424004376894, 13.85640646055102, 13.67479433117734, 13.41640786499874, 13.07669683062202, 12.64911064067352, 12.12435565298214, 11.48912529307606, 10.72380529476361, 9.79795897113271, 8.66025403784439, 7.21110255092798, 5.19615242270663, 0.00000000000000];

var _srMoonExtents12 = [0.000000000000000, 4.795831523312719, 6.633249580710800, 7.937253933193772, 8.944271909999159, 9.746794344808963, 10.392304845413264, 10.908712114635714, 11.313708498984761, 11.618950038622250, 11.832159566199232, 11.958260743101398, 12.000000000000000, 11.958260743101398, 11.832159566199232, 11.618950038622250, 11.313708498984761, 10.908712114635714, 10.392304845413264, 9.746794344808963, 8.944271909999159, 7.937253933193772, 6.633249580710800, 4.795831523312719, 0.000000000000000];

// Solar Rings v3.26.71: MIP-64 palette tuning of complete premium icon family and low-power static-field caching, Photon for
// reverse-geocoding on changed coordinates. No OpenWeather/WeatherGuard.
(:background)
class SolarRings7XApp extends App.AppBase {
    var _face;
    function initialize() { AppBase.initialize(); _face = null; }

    function getInitialView() {
        _face = new SolarRingsFaceV3();
        // Stop the old 5-minute forecast loop after updating from v3.26.65.
        // Only one-shot Photon lookups for a new city may be scheduled.
        try {
            var event = Bg.getTemporalEventRegisteredTime();
            if (event instanceof Time.Duration) { Bg.deleteTemporalEvent(); }
            srPhotonScheduleIfNeeded();
        } catch (e) { }
        return [_face];
    }

    function getServiceDelegate() { return [new SolarRingsGarminService()]; }

    function onBackgroundData(data) {
        if (data == 2 && _face != null) { _face.invalidatePhotonDisplay(); }
        // The one-off task finished. Re-arm only if Photon needs another
        // attempt for the same unresolved/new location; never loop forever.
        if (data != null) { srPhotonScheduleIfNeeded(); }
    }

    function onSettingsChanged() {
        // Retain the safe, deferred settings refresh from v3.26.65.
        if (_face != null) { _face.markSettingsChanged(); }
    }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _srSettingsDirty;
    var _fontCache;
    var _fontCacheCount;
    var _lowMemory;
    var _sizedFitCache;
    var _sizedFitCacheSize;
    var _clockFitCache;
    var _tempFitCache;
    var _cachedWeather;
    var _cachedWeatherAt;
    var _moonCosCache;
    var _frameFieldResults;
    var _frameEpoch;
    var _dateTextCache;
    var _cachedCalendar;
    var _calendarMinuteKey;
    var _ageTextCache;
    var _clockTextCache;
    var _clockLayoutCache;
    var _locationCache;
    var _photonTargetCache;
    var _photonTargetCheckAt;

    function initialize() {
        WatchFace.initialize();
        _srSettingsDirty = false;
        _fontCache = {};
        _fontCacheCount = 0;
        _lowMemory = false;
        resetPerformanceCaches();
    }

    // The next normal update completes the settings transition. This is
    // NEVER a holding screen; failures preserve the clock and retry only
    // on the next explicit settings change, not on every frame.
    function markSettingsChanged() {
        _srSettingsDirty = true;
    }

    function refreshChangedSettings() {
        if (!_srSettingsDirty) { return; }
        _srSettingsDirty = false;
        // This executes on a regular frame, NEVER in onSettingsChanged().
        srResetSettingsCache();
        _cachedWeatherAt = 0;
    }


    function resetPerformanceCaches() {
        _sizedFitCache = {};
        _sizedFitCacheSize = 0;
        _clockFitCache = null;
        _tempFitCache = null;
        _cachedWeather = null;
        _cachedWeatherAt = 0;
        _moonCosCache = null;
        _frameFieldResults = {};
        _frameEpoch = 0;
        _dateTextCache = null;
        _cachedCalendar = null;
        _calendarMinuteKey = -1;
        _ageTextCache = null;
        _clockTextCache = null;
        _clockLayoutCache = null;
        _locationCache = null;
        _photonTargetCache = null;
        _photonTargetCheckAt = 0;
        _srFullMoonDayCache = null;
    }

    // Read a selected field at most once per render. The generation number
    // changes for EVERY full update (even in 1 Hz high-power mode): HR, steps,
    // battery and goals are not cached between redraws. Reuse small storage
    // instead of building a new Dictionary on each wrist gesture.
    function frameField(id, monitor, weather) {
        var entry = _frameFieldResults[id];
        if (entry != null && entry[0] == _frameEpoch) { return entry[1]; }
        var result = readField(id, monitor, weather);
        if (entry == null) {
            _frameFieldResults[id] = [_frameEpoch, result];
        } else {
            entry[0] = _frameEpoch;
            entry[1] = result;
        }
        return result;
    }

    // The weather object is the last observation already held by Garmin,
    // not a direct network download. 55s caching prevents repeated system
    // reads during high-power redraws while refreshing on the next minute.
    function getCachedConditions() {
        var now = Time.now().value();
        if (_cachedWeatherAt != 0 && now >= _cachedWeatherAt &&
            now - _cachedWeatherAt < 55) { return _cachedWeather; }
        _cachedWeatherAt = now;
        try { _cachedWeather = Weather.getCurrentConditions(); }
        catch (e) { _cachedWeather = null; }
        return _cachedWeather;
    }


    // Detect changed Garmin weather coordinates during a normal minute frame.
    // An unresolved new location schedules ONE Photon background event.
    // We never persist coordinates on every redraw; movement > ~0.8 km is
    // needed to ask Photon to resolve a new town. No periodic weather task.
    function updatePhotonTarget(weather) {
        if (!srSetting("moonPanelV38", true) || weather == null) { return; }
        var now = Time.now().value();
        if (_photonTargetCheckAt > 0 && now >= _photonTargetCheckAt &&
            now - _photonTargetCheckAt < 55) { return; }
        _photonTargetCheckAt = now;
        try {
            var pos = weather.observationLocationPosition;
            if (pos == null) { return; }
            var ll = pos.toDegrees();
            if (!(ll instanceof Toybox.Lang.Array) || ll.size() < 2) { return; }
            var lat = ll[0];
            var lon = ll[1];
            if (lat == null || lon == null || lat < -90 || lat > 90 ||
                lon < -180 || lon > 180) { return; }
            if (_photonTargetCache != null &&
                srPhotonSameRegion(_photonTargetCache, ll)) {
                srPhotonScheduleIfNeeded();
                return;
            }
            _photonTargetCache = [lat, lon];
            var previous = App.Storage.getValue("srPhotonTargetV32664");
            if (!srPhotonSameRegion(previous, ll)) {
                App.Storage.setValue("srPhotonTargetV32664", [lat, lon]);
                _locationCache = null;
            }
            srPhotonScheduleIfNeeded();
        } catch (e) { /* Garmin's weather position can be unavailable. */ }
    }

    function invalidatePhotonDisplay() { _locationCache = null; }



    // Select genuinely different font sizes for SMALL / NORMAL / LARGE.
    // Always fit the selected font to a reserved box; never draw outside it.
    // IMPORTANT: using a single dynamic largest-fit list made small and
    // large look identical in v3.1. This implementation uses distinct caps.
    // 3.5: native Garmin text throughout. Earlier versions drew clock and
    // ring numbers one bitmap rectangle at a time and sometimes showed NO
    // values on the real MIP screen. One Dc.drawText per value avoids it.
    // This renderer NEVER changes the clip region and always has a fallback.
    function fitScaled(dc, value, x, top, width, height, color, numeric, scale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        var numberOnly = numeric;
        if (numberOnly) {
            for (var i = 0; i < str.length(); i++) {
                var c = str.substring(i, i + 1);
                if ("0123456789:".find(c) == null) {
                    numberOnly = false;
                    break;
                }
            }
        }
        var fonts;
        if (numberOnly) {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_LARGE, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }
        var chosen = Gfx.FONT_XTINY;
        var textH = dc.getFontHeight(chosen);
        for (var j = 0; j < fonts.size(); j++) {
            var dim = dc.getTextDimensions(str, fonts[j]);
            if (dim[0] <= width && dim[1] <= height) {
                chosen = fonts[j];
                textH = dim[1];
                break;
            }
        }
        // No pixel rectangles and NO setClip(): every field is visible.
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        var yy = top + ((height - textH) / 2).toNumber();
        dc.drawText(x, yy, chosen, str, Gfx.TEXT_JUSTIFY_CENTER);
    }

    // NEW v3.6: scalable fonts available on Fenix 7X Pro (Connect IQ 4.2.2+).
    // RobotoCondensedBold is an installed system face, NOT a bundled font file.
    // The optional style and increase settings affect every visible data field.
    function desiredPixels(settingKey, normalSize, increment) {
        var level = srSetting(settingKey, 2);
        if (level < 0) { level = 0; }
        if (level > 2) { level = 2; }
        return normalSize + (level - 1) * increment +
               (srSetting("fontExtraV36", 1) * 2);
    }

    // v3.7: Independent field size controls, with backwards-compatible group
    // settings as defaults. -1 means inherit the existing group setting.
    // 0..4 map to XS / Small / Medium / Large / XL.
    function fieldPixels(fieldKey, groupKey, normalSize, step) {
        var chosen = srSetting(fieldKey, -1);
        if (chosen == -1) {
            var groupLevel = srSetting(groupKey, 2);
            if (groupLevel < 0) { groupLevel = 0; }
            if (groupLevel > 2) { groupLevel = 2; }
            chosen = groupLevel * 2;
        }
        if (chosen < 0) { chosen = 0; }
        if (chosen > 4) { chosen = 4; }
        return normalSize + (chosen - 2) * step +
               (srSetting("fontExtraV36", 1) * 2);
    }

    function fieldScale(fieldKey, groupKey) {
        var level = srSetting(fieldKey, -1);
        if (level < 0) { return srSetting(groupKey, 2); }
        if (level <= 1) { return 0; }
        if (level == 2) { return 1; }
        return 2;
    }

    function vectorFontFor(pixels, digits) {
        var style = srSetting("fontFaceV36", 0);
        if (style == 4) { return null; } // Garmin native-only fallback
        var face = "RobotoCondensedBold";
        if (style == 1) { face = "RobotoCondensedRegular"; }
        else if (style == 2) { face = "ExoSemiBold"; }
        else if (style == 3 && digits) { face = "BionicBold"; }
        var key = face + ":" + pixels.toString();
        var cached = _fontCache[key];
        if (cached != null) { return cached; }
        var found = null;
        try { found = Gfx.getVectorFont({:face => face, :size => pixels}); }
        catch (e) { }
        // Avoid retaining an unbounded number of vector font handles.
        // Garmin watch faces have a strict memory budget.
        if (found != null && _fontCacheCount < 20) {
            _fontCache[key] = found;
            _fontCacheCount += 1;
        }
        return found;
    }

    // v3.24.20: test the requested font first (fast path), then binary-search
    // the largest size that actually fits. Previously we constructed/measured
    // every intermediate 1px font on long values and on each wrist gesture.
    // Rendering, bounds, fonts and the smallest 10px fallback are unchanged.
    function drawSized(dc, value, x, top, width, height, color, digits, sizePixels, fallbackScale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        if (_lowMemory) {
            fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale);
            return;
        }
        // x and top are 0..279 in this 280px design; numeric keys avoid
        // creating temporary concatenated strings on every screen redraw.
        var slotKey = x * 512 + top;
        var cached = _sizedFitCache[slotKey];
        var selected = null;
        var selectedDimensions = null;
        var canReuse = cached != null && cached[0] == str &&
                       cached[1] == sizePixels && cached[2] == digits &&
                       cached[6] == width && cached[7] == height;
        if (canReuse) {
            selected = cached[4];
            selectedDimensions = cached[5];
        }
        if (!canReuse) { try {
            var requestedFont = vectorFontFor(sizePixels, digits);
            if (requestedFont != null) {
                var dim = dc.getTextDimensions(str, requestedFont);
                if (dim[0] <= width && dim[1] <= height) {
                    selected = requestedFont;
                    selectedDimensions = dim;
                } else {
                    var low = 10;
                    var high = sizePixels - 1;
                    while (low <= high) {
                        var mid = ((low + high) / 2).toNumber();
                        var font = vectorFontFor(mid, digits);
                        if (font == null) { break; }
                        dim = dc.getTextDimensions(str, font);
                        if (dim[0] <= width && dim[1] <= height) {
                            selected = font;
                            selectedDimensions = dim;
                            low = mid + 1;
                        } else {
                            high = mid - 1;
                        }
                    }
                }
            }
        } catch (e) {
            selected = null;
        }
            // Cache the fit (including a failed fit) for the exact slot/value.
            // Later value changes and font settings automatically invalidate it.
            if (selected != null && (cached != null || _sizedFitCacheSize < 16)) {
                if (cached == null) { _sizedFitCacheSize += 1; }
                _sizedFitCache[slotKey] = [str, sizePixels, digits,
                                         0, selected, selectedDimensions,
                                         width, height];
            } else if (cached != null && selected == null) {
                _sizedFitCache.remove(slotKey);
                _sizedFitCacheSize -= 1;
            }
        }
        if (selected != null) {
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            var yy = top + ((height - selectedDimensions[1]) / 2).toNumber();
            dc.drawText(x, yy, selected, str, Gfx.TEXT_JUSTIFY_CENTER);
            return;
        }
        fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale);
    }

    function fit(dc, value, x, top, width, height, color, numeric) {
        fitScaled(dc, value, x, top, width, height, color, numeric, 1);
    }


    // v3.26.28: compact, measured HH:MM typography, no fixed pair centers.
    // Each real text width is measured once per minute (cached); clock group
    // is centered in x=25..175 with two 3px gaps around the colon. The font
    // choice uses the worst-case 88:88, so 11:11 and 08:59 cannot overlap
    // the date lane. No weather/network/background logic is touched.
    function clockBoldFont(pixels) {
        var key = "CLOCKB:" + pixels.toString();
        var cached = _fontCache[key];
        if (cached != null) { return cached; }
        var font = Gfx.getVectorFont({:face => "RobotoCondensedBold", :size => pixels});
        if (font != null && _fontCacheCount < 20) {
            _fontCache[key] = font;
            _fontCacheCount += 1;
        }
        return font;
    }

    function drawClock(dc, clock) {
        var minuteOfDay = clock.hour * 60 + clock.min;
        var value = null;
        if (_clockTextCache != null && _clockTextCache[0] == minuteOfDay) {
            value = _clockTextCache[1];
        } else {
            value = twoDigits(clock.hour) + ":" + twoDigits(clock.min);
            _clockTextCache = [minuteOfDay, value];
        }
        var hourText = value.substring(0, 2);
        var minuteText = value.substring(3, 5);
        var pref = srSetting("fontClockV31", 2);
        var requested = 94;
        if (pref <= 0) { requested = 58; }
        else if (pref == 1) { requested = 75; }
        requested += srSetting("fontExtraV36", 1) * 2;

        var top = 73;
        var slotH = 60;
        var gap = 3;
        // Leave room for a 1px bold outline, rounding and the date lane.
        var maxGroupW = 146;
        var font = null;
        var dimensions = null;
        if (!_lowMemory) {
            var saved = _clockFitCache;
            if (saved != null && saved[0] == requested) {
                font = saved[1];
                dimensions = saved[2];
            } else {
                try {
                    var probe = clockBoldFont(requested);
                    if (probe != null) {
                        var pairDim = dc.getTextDimensions("88", probe);
                        var colonDim = dc.getTextDimensions(":", probe);
                        if (pairDim[0] * 2 + colonDim[0] + gap * 2 <= maxGroupW &&
                            pairDim[1] <= slotH && colonDim[1] <= slotH) {
                            font = probe;
                            dimensions = pairDim;
                        } else {
                            var low = 32;
                            var high = requested - 1;
                            while (low <= high) {
                                var mid = ((low + high) / 2).toNumber();
                                probe = clockBoldFont(mid);
                                if (probe == null) { break; }
                                pairDim = dc.getTextDimensions("88", probe);
                                colonDim = dc.getTextDimensions(":", probe);
                                if (pairDim[0] * 2 + colonDim[0] + gap * 2 <= maxGroupW &&
                                    pairDim[1] <= slotH && colonDim[1] <= slotH) {
                                    font = probe;
                                    dimensions = pairDim;
                                    low = mid + 1;
                                } else {
                                    high = mid - 1;
                                }
                            }
                        }
                    }
                } catch (e) { font = null; }
                _clockFitCache = font == null ? null : [requested, font, dimensions];
                _clockLayoutCache = null;
            }
        }
        // If vector fonts are unavailable, use the largest fitting built-in
        // numeric font and the SAME measured compact geometry.
        if (font == null) {
            try {
                var nativeFonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                                   Gfx.FONT_NUMBER_MILD, Gfx.FONT_MEDIUM,
                                   Gfx.FONT_SMALL, Gfx.FONT_TINY];
                for (var n = 0; n < nativeFonts.size(); n++) {
                    var nativeFont = nativeFonts[n];
                    var p = dc.getTextDimensions("88", nativeFont);
                    var c = dc.getTextDimensions(":", nativeFont);
                    if (p[0] * 2 + c[0] + gap * 2 <= maxGroupW &&
                        p[1] <= slotH && c[1] <= slotH) {
                        font = nativeFont;
                        dimensions = p;
                        break;
                    }
                }
            } catch (e) { font = null; }
        }
        if (font == null) {
            // Emergency native fallback never suppresses the main clock.
            fitScaled(dc, value, 99, top, 146, slotH,
                      Gfx.COLOR_WHITE, true, 2);
            return;
        }

        var layout = _clockLayoutCache;
        if (layout == null || layout[0] != minuteOfDay ||
            layout[1] != font || layout[2] != requested) {
            try {
                var hourDim = dc.getTextDimensions(hourText, font);
                var colonDim = dc.getTextDimensions(":", font);
                var minuteDim = dc.getTextDimensions(minuteText, font);
                var groupW = hourDim[0] + colonDim[0] + minuteDim[0] + gap * 2;
                // Worst-case font fit above guarantees room even for '88:88'.
                var left = 9 + ((148 - groupW) / 2).toNumber();
                var hourX = left + (hourDim[0] / 2).toNumber();
                var colonX = left + hourDim[0] + gap + (colonDim[0] / 2).toNumber();
                var minuteX = left + hourDim[0] + gap + colonDim[0] + gap +
                              (minuteDim[0] / 2).toNumber();
                var y = top + ((slotH - dimensions[1]) / 2).toNumber();
                layout = [minuteOfDay, font, requested, hourX, colonX, minuteX, y];
                _clockLayoutCache = layout;
            } catch (e) {
                fitScaled(dc, value, 99, top, 146, slotH,
                          Gfx.COLOR_WHITE, true, 2);
                return;
            }
        }
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        // RobotoCondensedBold + +/-1px gives visibly stronger hour and minute
        // weight, without allocating other font sizes or shifting their group.
        dc.drawText(layout[3] - 1, layout[6], font, hourText, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(layout[3], layout[6], font, hourText, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(layout[3] + 1, layout[6], font, hourText, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(layout[4], layout[6], font, ":", Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(layout[5] - 1, layout[6], font, minuteText, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(layout[5], layout[6], font, minuteText, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(layout[5] + 1, layout[6], font, minuteText, Gfx.TEXT_JUSTIFY_CENTER);
    }

    // Mini digits for compact times and symbols are kept below.


    // Fixed-width 3x7 glyphs. All writes are confined to the intended
    // region; use only filled rectangles so this works without font assets.

    function onlyDigits(str) {
        if (str == null || str.length() == 0) { return false; }
        for (var i = 0; i < str.length(); i++) {
            if ("0123456789".find(str.substring(i, i + 1)) == null) {
                return false;
            }
        }
        return true;
    }
    // Sunrise and sunset times use a larger measured Garmin font.
    function drawTopClock(dc, value, center, sizeKey, slotWidth) {
        drawSized(dc, value, center, 44, slotWidth, 23,
                  0xECF4FF, true,
                  fieldPixels(sizeKey, "fontTopV31", 21, 2),
                  fieldScale(sizeKey, "fontTopV31"));
    }

    // v3.26.29: TOP right row contains ONLY Bluetooth and observation age.
    // Weekday is immediately BEFORE the full date in the LOWER right row:
    // "CZ 19 LIS". Separate measured text boxes avoid overlap on 280px MIP.
    function drawDate(dc, dayLabel, dateLabel) {
        var settingSize = srSetting("fontDateV31", 2);
        // Clock is in x=9..157. Day x=158..182 and date x=184..266.
        // Both date elements stay above the y=135 horizontal separator.
        drawSized(dc, dayLabel, 170, 100, 24, 29,
                  0x55AAFF, false,
                  desiredPixels("fontDateV31", 26, 2), settingSize);
        drawSized(dc, dateLabel, 225, 97, 82, 34,
                  0xAAFFFF, false,
                  desiredPixels("fontDateV31", 39, 4), settingSize);
    }

    // Connection status as reported by the Garmin device (not internet reachability).
    // True: green Bluetooth; false: red Bluetooth with an oblique strike.
    // No network calls, no new permissions, no separate settings required.
    function drawPhoneBluetooth(dc) {
        var connected = false;
        try {
            connected = System.getDeviceSettings().phoneConnected;
        } catch (e) { connected = false; }
        var btColor = connected ? 0x00DD77 : 0xFF5555;
        dc.setColor(btColor, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        // Bluetooth is the only icon in the TOP right row; the age is next.
        // Icon bounds x=190..200 and y=77..91; age starts at x=207.
        dc.drawLine(195, 77, 195, 91);
        dc.drawLine(195, 77, 200, 80);
        dc.drawLine(200, 80, 190, 87);
        dc.drawLine(190, 80, 200, 87);
        dc.drawLine(200, 87, 195, 91);
        if (!connected) {
            dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(3);
            dc.drawLine(190, 91, 200, 77);
            dc.setColor(btColor, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(1);
            dc.drawLine(190, 91, 200, 77);
        }
        dc.setPenWidth(1);
    }

    // Observation age supplied by Garmin Weather. This does not trigger
    // any additional network requests or change the current-weather icon.
    function drawWeatherAge(dc, current) {
        var ageLabel = "--";
        var ageColor = 0xFF5555;
        try {
            if (current != null && current.observationTime != null) {
                var seconds = Time.now().value() - current.observationTime.value();
                if (seconds >= 0) {
                    var minutes = (seconds / 60).toNumber();
                    if (_ageTextCache != null && _ageTextCache[0] == minutes) {
                        ageLabel = _ageTextCache[1];
                        ageColor = _ageTextCache[2];
                    } else {
                        if (minutes < 50) {
                            ageLabel = minutes.toString() + "m";
                        } else if (minutes < 60) {
                            // User preference: switch to 1h at 50 minutes.
                            ageLabel = "1h";
                        } else {
                            var hours = (minutes / 60).toNumber();
                            var remainingMinutes = minutes - (hours * 60);
                            if (remainingMinutes == 0 || hours >= 10) {
                                // Abbreviate extremely old observations to stay readable.
                                ageLabel = hours.toString() + "h";
                            } else {
                                ageLabel = hours.toString() + "h" + remainingMinutes.toString() + "m";
                            }
                        }
                        if (minutes <= 30) { ageColor = 0x00DD77; }
                        else if (minutes <= 60) { ageColor = 0xFFCC33; }
                        _ageTextCache = [minutes, ageLabel, ageColor];
                    }
                }
            }
        } catch (e) { ageLabel = "--"; ageColor = 0xFF5555; }

        // TOP row is Bluetooth x=190..200 followed by age x=207..263.
        // The full 56px age field shrinks for values such as 10h11m.
        drawPhoneBluetooth(dc);
        drawSized(dc, ageLabel, 235, 75, 56, 20,
                  ageColor, false, 19, 0);
    }

    // Native 1px separators, including the two vertical ones requested
    // between the sunrise / moon / sunset fields.
    function rule(dc, y) {
        dc.setColor(0x57677B, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        if (y == 250) {
            dc.drawLine(100, y, 190, y);
        } else {
            // Full-width horizontal rules; moon clearance is handled by
            // the separate 134/164px rule coordinates and lunar center y=149.
            dc.drawLine(28, y, 252, y);
        }
    }

    function topDividers(dc) {
        dc.setColor(0x75869A, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(107, 23, 107, 64);
        dc.drawLine(163, 23, 163, 64);
    }

    function weatherDivider(dc) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(133, 219, 133, 245);
    }

    // Different shapes for sunrise and sunset, not just different colors.
    // Both icons fit within x-12..x+15, y-9..y+8 on the 280px face.
    // Sunrise: arrow UP. Sunset: arrow DOWN.
    // Premium MIP duotone sunrise/sunset: bright horizon, a half-disc and
    // a compact direction arrow. Bounds x-12..x+15, y-10..y+9.
    // No arrays, fonts or allocations; same 27x20 safe icon envelope.
    function sunIcon(dc, x, y, isRise) {
        var primary = isRise ? 0xFFAA55 : 0xAA55FF;
        dc.setColor(primary, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y + 3, 6);
        // Mask lower half to create a clean sunrise/sunset silhouette.
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillRectangle(x - 11, y + 5, 16, 6);
        dc.setColor(0xDCEAFF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawLine(x - 12, y + 5, x + 5, y + 5);
        dc.setColor(primary, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x - 4, y - 7, x - 4, y - 5);
        dc.drawLine(x - 11, y - 2, x - 9, y - 1);
        dc.drawLine(x + 2, y - 2, x + 4, y - 1);
        // Direction arrow has separate reserved lane on the right.
        dc.setPenWidth(2);
        dc.drawLine(x + 12, y - 7, x + 12, y + 7);
        if (isRise) {
            dc.drawLine(x + 9, y - 4, x + 12, y - 7);
            dc.drawLine(x + 12, y - 7, x + 15, y - 4);
        } else {
            dc.drawLine(x + 9, y + 4, x + 12, y + 7);
            dc.drawLine(x + 12, y + 7, x + 15, y + 4);
        }
        dc.setPenWidth(1);
    }

    // Solid, symmetrical heart similar to the clear heart from Garmin Connect.
    // Pixel-width fill makes it readable even at the MIP capsule's icon size.
    // Extents x-8..x+8, y-8..y+8.
    // Premium solid heart with tiny pale specular accent.
    // Bounds x-8..x+8 and y-8..y+8, safe in every capsule.
    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 4, 4);
        dc.fillCircle(x + 4, y - 4, 4);
        dc.fillRectangle(x - 8, y - 4, 16, 4);
        for (var row = 0; row <= 8; row++) {
            var halfWidth = 8 - row;
            dc.drawLine(x - halfWidth, y + row, x + halfWidth, y + row);
        }
        dc.setColor(0xFFE6F2, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 5, 2);
    }

    // Premium footprints: 2 distinct steps, dual highlight, no bitmap.
    // Bounds x-9..x+9, y-9..y+9.
    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(x - 9, y - 1, 6, 9, 3);
        dc.fillRoundedRectangle(x + 2, y - 7, 6, 9, 3);
        dc.setColor(0xD1F2FF, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 6, 3);
        dc.fillCircle(x + 6, y + 5, 3);
    }

    // Watch battery: horizontal rectangular pack, never confused with BB.
    function batteryIcon(dc, x, y, color) {
        dc.setColor(0xD6E9F3, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRoundedRectangle(x - 9, y - 6, 17, 12, 2);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRoundedRectangle(x - 6, y - 3, 9, 6, 1);
        dc.setPenWidth(1);
    }

    // v3.24.19: use a bolt inside the existing 17x12 battery outline
    // when connected to a USB charger. Same bounds as batteryIcon();
    // no extra space and no changes to the percent display or other fields.
    function chargingBatteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        // Bright bolt instead of the normal battery fill, readable on MIP.
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x + 2, y - 4, x - 4, y + 1);
        dc.drawLine(x - 4, y + 1, x + 1, y + 1);
        dc.drawLine(x + 1, y + 1, x - 2, y + 5);
        dc.setPenWidth(1);
    }

    // Body Battery Premium — intentionally based on the supplied Garmin reference:
    // solid raised-arm person, circular head and segmented energy halo.
    // Unlike the watch battery this icon has no rectangular cell or bolt.
    // Pixel geometry x-11..x+9, y-10..y+9; fits the capsule icon lane.
    // All coordinates are static; no bitmap, heap allocation or extra refresh.
    function bodyBatteryIcon(dc, x, y, color) {
        // Three visually separated halo segments, open at lower right.
        // A darker ring leaves the figure clearly distinguishable on MIP.
        dc.setColor(0x5555FF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        // Lower-left energy segment.
        dc.drawLine(x - 8, y + 5, x - 10, y + 3);
        // Left energy segment.
        dc.drawLine(x - 10, y + 1, x - 10, y - 2);
        // Upper-left energy segment.
        dc.drawLine(x - 9, y - 4, x - 7, y - 7);
        dc.drawLine(x - 7, y - 7, x - 5, y - 8);
        // Upper energy crescent, interrupted from the left section.
        dc.setPenWidth(3);
        dc.drawLine(x - 3, y - 9, x + 2, y - 9);
        dc.drawLine(x + 2, y - 9, x + 5, y - 8);
        dc.drawLine(x + 5, y - 8, x + 7, y - 6);

        // Solid human figure: Raised arms in a V and a clear wide torso.
        // The primary color remains the user-configured/status capsule color.
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x - 2, y + 2, x - 5, y - 1);
        dc.drawLine(x - 5, y - 1, x - 6, y - 3);
        dc.drawLine(x + 2, y + 2, x + 5, y - 1);
        dc.drawLine(x + 5, y - 1, x + 6, y - 3);
        dc.fillRoundedRectangle(x - 3, y + 1, 7, 8, 1);
        dc.fillCircle(x, y - 3, 2);
        // Subtle glint on the head for premium duotone definition.
        dc.setColor(0xAAFFFF, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x - 1, y - 4, x, y - 4);
        dc.setPenWidth(1);
    }

    // Intensywne minuty: a fast stopwatch with three speed lines, clearly
    // distinct from the simple top-row stopwatch icon.
    // Bounds x-14..x+10, y-11..y+10.
    // Premium sport stopwatch: bold dial and three short speed streaks.
    // Bounds x-14..x+10, y-11..y+10.
    function intensityTimerIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x + 1, y + 1, 8);
        dc.drawLine(x + 1, y - 8, x + 1, y - 11);
        dc.drawLine(x - 2, y - 11, x + 4, y - 11);
        dc.setColor(0xD5EDFF, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x + 1, y + 1, x + 5, y + 4);
        dc.drawLine(x + 1, y + 1, x + 1, y - 3);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x - 14, y - 4, x - 10, y - 4);
        dc.drawLine(x - 14, y, x - 10, y);
        dc.drawLine(x - 14, y + 4, x - 10, y + 4);
        dc.setPenWidth(1);
    }


    function moon(dc, x, y) {
        drawLunarDisk(dc, x, y, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // a simple clock, they describe present weather.


    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    // Only the existing pictogram changes color when an optional threshold is
    // crossed. This adds no icons/lines and preserves the approved geometry.
    // d[2] is a 0..1 ratio, not a percent; null means no dependable data.
    function statusIconColor(id, ratio, normalColor) {
        if (!srSetting("statusColorsV315", true) || ratio == null) {
            return normalColor;
        }
        var percent = ratio.toFloat() * 100.0;
        if (id == 17) {
            if (percent <= srSetting("batteryCriticalV315", 10)) { return Gfx.COLOR_RED; }
            if (percent <= srSetting("batteryLowV315", 20)) { return Gfx.COLOR_YELLOW; }
        }
        // Body Battery: a bright yellow warning and red critical icon are
        // easier to distinguish than orange/red on the Fenix 7X MIP.
        if (id == 3) {
            var bodyLow = srSetting("bodyLowV315", 20);
            if (percent <= 10) { return Gfx.COLOR_RED; }
            if (percent <= bodyLow) { return Gfx.COLOR_YELLOW; }
        }
        if (id == 10 && percent >= srSetting("stressHighV315", 80)) {
            return Gfx.COLOR_ORANGE;
        }
        return normalColor;
    }

    // Compact Premium Duotone glyphs for all 35 selectable data fields.
    // Every small glyph stays within x +/-9 and y +/-9, except the existing
    // Body Battery (10px) and the 27px SOLAR symbols in the dedicated top row.
    // No font calls, collections, timers, sensor reads, or cached graphics.
    // Status / user-selected capsule color always remains the PRIMARY hue.
    // Shared secondary accent is bright and readable on 64-colour MIP.
    function premiumSmallSun(dc, x, y, rise) {
        dc.setColor(rise ? 0xFFAA55 : 0xAA55FF, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 3, y + 1, 5);
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillRectangle(x - 9, y + 3, 13, 6);
        dc.setColor(0xDCEAFF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawLine(x - 9, y + 3, x + 3, y + 3);
        dc.setColor(rise ? 0xFFAA55 : 0xAA55FF, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x + 7, y - 6, x + 7, y + 6);
        if (rise) {
            dc.drawLine(x + 4, y - 3, x + 7, y - 6);
            dc.drawLine(x + 7, y - 6, x + 9, y - 3);
        } else {
            dc.drawLine(x + 4, y + 3, x + 7, y + 6);
            dc.drawLine(x + 7, y + 6, x + 9, y + 3);
        }
        dc.setPenWidth(1);
    }

    function premiumSmallCloud(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y + 1, 4);
        dc.fillCircle(x + 1, y - 2, 6);
        dc.fillCircle(x + 6, y + 2, 3);
        dc.fillRectangle(x - 8, y + 1, 17, 5);
        dc.setColor(0xB5D5E9, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x - 6, y + 6, x + 6, y + 6);
    }

    function premiumSmallThermometer(dc, x, y, color) {
        dc.setColor(0xDCEEFF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawLine(x - 1, y - 8, x - 1, y + 2);
        dc.drawLine(x + 3, y - 8, x + 3, y + 2);
        dc.drawLine(x - 1, y - 8, x + 3, y - 8);
        dc.drawCircle(x + 1, y + 5, 4);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x + 1, y + 5, 3);
        dc.drawLine(x + 1, y - 4, x + 1, y + 4);
        dc.setPenWidth(1);
    }

    function premiumSmallClock(dc, x, y, color) {
        dc.setColor(0xDCEEFF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 8);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x, y, x, y - 5);
        dc.drawLine(x, y, x + 4, y + 2);
        dc.setPenWidth(1);
    }

    function premiumSmallTimer(dc, x, y, color, weekly) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 1, 7);
        dc.drawLine(x, y - 8, x, y - 6);
        dc.drawLine(x - 3, y - 9, x + 3, y - 9);
        dc.setColor(0xE4F5FF, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x, y + 1, x + 3, y - 2);
        dc.drawLine(x, y + 1, x, y - 3);
        if (weekly) {
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 8, y - 4, 1);
            dc.fillCircle(x - 8, y + 4, 1);
        }
        dc.setPenWidth(1);
    }

    function premiumSmallIcon(dc, x, y, id, color) {
        // x +/-9 and y +/-9. The two-colour MIP palette never masks the
        // numeric value, which starts at left+30 in 64px capsules.
        dc.setPenWidth(1);
        if (id == 6) { // KCAL: upward flame with a white inner core.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x, y + 3, 6);
            dc.drawLine(x - 5, y, x - 2, y - 6);
            dc.drawLine(x - 2, y - 6, x + 1, y - 3);
            dc.drawLine(x + 1, y - 3, x + 3, y - 9);
            dc.drawLine(x + 3, y - 9, x + 6, y + 2);
            dc.setColor(0xFFEED3, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x, y + 4, 3);
        } else if (id == 7) { // DISTANCE: point-to-point route.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 6, y + 6, x - 1, y + 2);
            dc.drawLine(x - 1, y + 2, x + 3, y + 2);
            dc.drawLine(x + 3, y + 2, x + 6, y - 5);
            dc.setColor(0xE0F5FF, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 7, y + 7, 2);
            dc.drawCircle(x + 6, y - 6, 3);
        } else if (id == 8 || id == 9) { // Floors up / down.
            dc.setColor(0xC9E3F4, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 9, y + 7, x - 4, y + 7);
            dc.drawLine(x - 4, y + 7, x - 4, y + 2);
            dc.drawLine(x - 4, y + 2, x + 1, y + 2);
            dc.drawLine(x + 1, y + 2, x + 1, y - 3);
            dc.drawLine(x + 1, y - 3, x + 5, y - 3);
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x + 7, y - 7, x + 7, y + 6);
            if (id == 8) {
                dc.drawLine(x + 4, y - 4, x + 7, y - 7);
                dc.drawLine(x + 7, y - 7, x + 9, y - 4);
            } else {
                dc.drawLine(x + 4, y + 3, x + 7, y + 6);
                dc.drawLine(x + 7, y + 6, x + 9, y + 3);
            }
        } else if (id == 10) { // Stress: compact waveform in a calm circle.
            dc.setColor(0xCDE4F0, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x - 6, y + 1, x - 3, y + 1);
            dc.drawLine(x - 3, y + 1, x - 1, y - 4);
            dc.drawLine(x - 1, y - 4, x + 2, y + 5);
            dc.drawLine(x + 2, y + 5, x + 4, y);
            dc.drawLine(x + 4, y, x + 6, y);
        } else if (id == 11) { // SpO2: oxygen drop with central highlight.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x, y - 9, x - 6, y);
            dc.drawLine(x - 6, y, x - 5, y + 5);
            dc.drawLine(x - 5, y + 5, x, y + 8);
            dc.drawLine(x, y + 8, x + 5, y + 5);
            dc.drawLine(x + 5, y + 5, x + 6, y);
            dc.drawLine(x + 6, y, x, y - 9);
            dc.setColor(0xDFF8FF, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x, y + 3, 3);
        } else if (id == 12) { // Breathing: lungs and windpipe.
            dc.setColor(0xDBF0FF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x, y - 8, x, y - 2);
            dc.drawLine(x, y - 2, x - 4, y);
            dc.drawLine(x, y - 2, x + 4, y);
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 5, y + 3, 4);
            dc.fillCircle(x + 5, y + 3, 4);
            dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x, y + 1, x, y + 8);
        } else if (id == 13) { // Recovery: circular arrow and rest dot.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawArc(x, y, 8, Gfx.ARC_CLOCKWISE, 45, 300);
            dc.drawLine(x + 6, y - 6, x + 8, y - 2);
            dc.drawLine(x + 8, y - 2, x + 3, y - 3);
            dc.setColor(0xE2F4FF, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x, y, 3);
        } else if (id == 16) { // Weather: small sun behind cloud.
            dc.setColor(0xFFCC61, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 4, y - 4, 5);
            premiumSmallCloud(dc, x + 1, y + 1, 0xDDEAF6);
        } else if (id == 18) { // Air temperature.
            premiumSmallThermometer(dc, x, y, color);
        } else if (id == 19) { // Feels like: therm + moving air.
            premiumSmallThermometer(dc, x - 3, y, color);
            dc.setColor(0xDCEEFF, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x + 3, y - 4, x + 9, y - 4);
            dc.drawLine(x + 5, y + 1, x + 9, y + 1);
        } else if (id == 20) { // Relative humidity: filled droplet.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x, y - 9, x - 7, y + 1);
            dc.drawLine(x, y - 9, x + 7, y + 1);
            dc.fillCircle(x, y + 2, 7);
            dc.setColor(0xD6F3FF, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 2, y + 1, 2);
        } else if (id == 21) { // Wind.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 9, y - 5, x + 4, y - 5);
            dc.drawLine(x + 4, y - 5, x + 7, y - 7);
            dc.drawLine(x - 8, y + 1, x + 9, y + 1);
            dc.drawLine(x + 9, y + 1, x + 6, y + 4);
            dc.setColor(0xD6F3FF, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x - 7, y + 7, x + 5, y + 7);
        } else if (id == 22) { // Barometer / atmospheric pressure.
            dc.setColor(0xD5EAF7, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x - 5, y + 5, x, y);
            dc.drawLine(x, y, x + 5, y - 4);
            dc.fillCircle(x, y, 2);
        } else if (id == 23) { // Altitude: clean mountain peaks.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 9, y + 7, x - 2, y - 7);
            dc.drawLine(x - 2, y - 7, x + 3, y + 1);
            dc.drawLine(x + 1, y - 2, x + 4, y - 5);
            dc.drawLine(x + 4, y - 5, x + 9, y + 7);
            dc.setColor(0xE3F7FF, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x - 4, y - 3, x - 2, y - 7);
            dc.drawLine(x - 2, y - 7, x, y - 3);
        } else if (id == 24) { // Daily steps goal: target framing two footsteps.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.setColor(0xE6F6FF, Gfx.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(x - 5, y, 3, 5, 1);
            dc.fillRoundedRectangle(x + 2, y - 4, 3, 5, 1);
            dc.fillCircle(x - 4, y - 3, 2);
            dc.fillCircle(x + 4, y + 3, 2);
        } else if (id == 25) { // Weekly minutes goal: target with clock hands.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.setColor(0xE6F6FF, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x, y, x, y - 5);
            dc.drawLine(x, y, x + 4, y + 2);
            dc.fillCircle(x, y, 2);
        } else if (id == 26 || id == 27) { // High / low temperature.
            premiumSmallThermometer(dc, x - 3, y, color);
            dc.setColor(0xDDEEFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x + 7, y - 7, x + 7, y + 7);
            if (id == 26) {
                dc.drawLine(x + 4, y - 4, x + 7, y - 7);
                dc.drawLine(x + 7, y - 7, x + 9, y - 4);
            } else {
                dc.drawLine(x + 4, y + 4, x + 7, y + 7);
                dc.drawLine(x + 7, y + 7, x + 9, y + 4);
            }
        } else if (id == 28) { // Move bar: walking dynamic arrow.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 2, y - 7, 3);
            dc.setPenWidth(2);
            dc.drawLine(x - 2, y - 3, x + 1, y + 1);
            dc.drawLine(x + 1, y + 1, x - 4, y + 8);
            dc.drawLine(x + 1, y + 1, x + 7, y + 6);
            dc.drawLine(x - 1, y - 1, x - 7, y + 2);
            dc.setColor(0xDBF0FF, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x + 4, y - 6, x + 9, y - 6);
        } else if (id == 29) { // UV index: solar circle / short rays.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x, y, 5);
            dc.setPenWidth(2);
            dc.drawLine(x, y - 9, x, y - 7);
            dc.drawLine(x, y + 7, x, y + 9);
            dc.drawLine(x - 9, y, x - 7, y);
            dc.drawLine(x + 7, y, x + 9, y);
            dc.setColor(0xFFF4D4, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 1, y - 1, 2);
        } else if (id == 30) { // Rain probability: cloud + two drops.
            premiumSmallCloud(dc, x, y - 3, 0xDEEAF5);
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 4, y + 5, x - 5, y + 9);
            dc.drawLine(x + 4, y + 5, x + 3, y + 9);
        } else if (id == 31) { // Clock.
            premiumSmallClock(dc, x, y, color);
        } else if (id == 32) { // Calendar.
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawRoundedRectangle(x - 8, y - 7, 16, 15, 2);
            dc.drawLine(x - 8, y - 3, x + 8, y - 3);
            dc.drawLine(x - 4, y - 9, x - 4, y - 5);
            dc.drawLine(x + 4, y - 9, x + 4, y - 5);
            dc.setColor(0xDCEEFF, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x - 3, y + 2, 1);
            dc.fillCircle(x + 3, y + 2, 1);
            dc.fillCircle(x, y + 5, 1);
        } else if (id == 33) { // Cloud cover.
            premiumSmallCloud(dc, x, y - 1, 0xD6E4F2);
            dc.setColor(color, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x - 6, y + 8, x + 6, y + 8);
        } else {
            // Never expected for 0..35; unknown future field remains safe.
            genericIcon(dc, x, y, color);
        }
        dc.setPenWidth(1);
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15 || id == 35) {
            var isRise = (id == 14);
            if (id == 35) {
                var event = nextSunEvent(getCachedConditions());
                if (event == null) { genericIcon(dc, x, y, Gfx.COLOR_LT_GRAY); return; }
                isRise = event[0];
            }
            // The top slots allow a wide sunrise/sunset arrow. Other slots
            // reserve only a 20px pictogram lane, protecting long values.
            if (y == 30) { sunIcon(dc, x, y, isRise); }
            else { premiumSmallSun(dc, x, y, isRise); }
        } else if (id == 34) { moon(dc, x, y); }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3) { bodyBatteryIcon(dc, x, y, color); }
        else if (id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { premiumSmallTimer(dc, x, y, color, id == 4); }
        else { premiumSmallIcon(dc, x, y, id, color); }
    }


    // Lunar phase illustration: illuminated fraction changes as the synodic
    // cycle progresses. It is intentionally simple for low-color MIP displays.
    function drawLunarDisk(dc, x, y, r) {
        var state = srMoonDayInfo();
        var phase = state[0];
        dc.setColor(0x182238, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, r);
        dc.setColor(0xF2F6FF, Gfx.COLOR_TRANSPARENT);
        var cosPhase = null;
        var dayKey = _srFullMoonDayCache[0];
        if (_moonCosCache != null && _moonCosCache[0] == dayKey) {
            cosPhase = _moonCosCache[1];
        } else {
            cosPhase = Math.cos(2.0 * Math.PI * phase);
            _moonCosCache = [dayKey, cosPhase];
        }
        for (var row = -r; row <= r; row++) {
            // 14px main moon (plus small top icons) uses constant geometry.
            var extent = r == 14 ? _srMoonExtents14[row + 14]
                       : r == 12 ? _srMoonExtents12[row + 12]
                       : r == 7 ? _srMoonExtents7[row + 7]
                                : Math.sqrt((r * r - row * row).toFloat());
            var leftEdge = x - extent.toNumber();
            var rightEdge = x + extent.toNumber();
            if (phase < 0.5) {
                var startX = x + (extent * cosPhase).toNumber();
                if (startX <= rightEdge) {
                    dc.drawLine(startX, y + row, rightEdge, y + row);
                }
            } else {
                var endX = x - (extent * cosPhase).toNumber();
                if (leftEdge <= endX) {
                    dc.drawLine(leftEdge, y + row, endX, y + row);
                }
            }
        }
        dc.setColor(0xA5B9D7, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawCircle(x, y, r);
    }

    // Moon/day-to-full/local weather observation source share a 28px band.
    // Layout: 24px disk @ x52; day counter x=78..114; separator x=119;
    // location x=125..251. No pressure indicator in this band any more.
    function drawMoonPanel(dc, weather) {
        if (!srSetting("moonPanelV38", true)) { return; }
        drawLunarDisk(dc, 52, 149, 12);
        var moon = srMoonDayInfo();
        drawSized(dc, moon[1], 96, 136, 36, 25,
                  0xE6F5FF, false, 19, 1);
        dc.setColor(0x888888, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(119, 138, 119, 159);
        var location = "BRAK LOK.";
        try {
            var pos = weather == null ? null : weather.observationLocationPosition;
            if (pos != null) {
                var ll = pos.toDegrees();
                if (ll != null && ll.size() >= 2) {
                    var keyLat = (ll[0] * 100.0d).toNumber();
                    var keyLon = (ll[1] * 100.0d).toNumber();
                    var now = Time.now().value();
                    // High-power frames do not reread flash/storage per second.
                    if (_locationCache != null && _locationCache[0] == keyLat &&
                        _locationCache[1] == keyLon && now >= _locationCache[3] &&
                        now - _locationCache[3] < 55) {
                        location = _locationCache[2];
                    } else {
                        var answer = App.Storage.getValue("srPhotonResultV32664");
                        if (answer instanceof Toybox.Lang.Array && answer.size() == 3 &&
                            srPhotonSameRegion(answer, ll) &&
                            answer[2] instanceof Toybox.Lang.String) {
                            location = answer[2];
                        } else if (weather.observationLocationName != null &&
                                   weather.observationLocationName.length() > 0) {
                            location = weather.observationLocationName.toUpper();
                        } else {
                            // Offline fallback is approximate, Photon is the
                            // preferred name when the server resolves it.
                            location = "~" + srWeatherCityFromDegrees(ll[0], ll[1]);
                        }
                        _locationCache = [keyLat, keyLon, location, now];
                    }
                }
            } else if (weather != null && weather.observationLocationName != null &&
                       weather.observationLocationName.length() > 0) {
                location = weather.observationLocationName.toUpper();
            }
        } catch (e) { location = "BRAK LOK."; }
        drawSized(dc, location, 188, 136, 126, 25,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("moonFontV38", "fontWeatherV31", 27, 2),
                  fieldScale("moonFontV38", "fontWeatherV31"));
    }

    function topSlot(dc, x, id, sizeKey, monitor, weather) {
        if (id == 0) { return; }
        var d = frameField(id, monitor, weather);
        if (id == 35) {
            // readField() has already resolved the next event for this frame.
            if (!d[1].equals("--:--")) { sunIcon(dc, x, 30, d[0].equals("WSCHOD")); }
            else { genericIcon(dc, x, 30, Gfx.COLOR_LT_GRAY); }
        } else {
            drawIcon(dc, x, 30, id, 0x00CCFF);
        }
        var v = d[1];
        var boxWidth = x == 134 ? 45 : 66;
        if (id == 14 || id == 15 || id == 35) {
            drawTopClock(dc, v, x, sizeKey, boxWidth);
        } else {
            drawSized(dc, v, x, 43, boxWidth, 24,
                      Gfx.COLOR_WHITE, false,
                      fieldPixels(sizeKey, "fontTopV31", 19, 2),
                      fieldScale(sizeKey, "fontTopV31"));
        }
    }

    // v3.12: Three capsules with independent safe lanes for icon, number and
    // progress. Works for any selectable metric with or without a ratio.
    // FIX v3.26.32: border y=171..210, stroke width 3. The top outline
    // starts at least 5 full pixels below the y=164 separator (including
    // the thick stroke), and ends above the y=215 lower separator.
    // Icon center y=184; primary text box y=175..194; track y=198..202.
    // All three capsules use this one geometry; no font or metric changes.
    function capsuleTrack(dc, left, top, width, ratio, color, stepsReached, showDone) {
        if (ratio == null) { return; }
        var p = ratio.toFloat();
        if (p < 0.0) { p = 0.0; }
        if (p > 1.0) { p = 1.0; }
        var bx = left + 10;
        // Align track within the shortened capsule, below text and icons.
        var by = top + 27;
        var barH = 4;
        var barWidth = width - 20;
        // At 100% steps the check has its OWN 12px lane at track's right;
        // no check mark is ever painted on top of a filled progress bar.
        if (showDone) { barWidth -= 12; }
        dc.setColor(0x283144, Gfx.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(bx, by, barWidth, barH, 2);
        var fill = (p * barWidth.toFloat()).toNumber();
        if (fill >= 2) {
            dc.setColor(stepsReached ? Gfx.COLOR_GREEN : color, Gfx.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(bx, by, fill, barH, 2);
        }
        if (showDone) {
            // An outlined green DONE circle occupies x=right-20..right-10.
            // Text ends above y=195; this marker stays in y=195..205.
            dc.setColor(Gfx.COLOR_GREEN, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(1);
            var cx = left + width - 15;
            var cy = by + 2;
            dc.drawCircle(cx, cy, 5);
            dc.drawLine(cx - 3, cy, cx - 1, cy + 2);
            dc.drawLine(cx - 1, cy + 2, cx + 3, cy - 2);
        }
    }

    function capsule(dc, left, width, id, colorCode, sizeKey, monitor, weather, isCenter) {
        if (id == 0) { return; }
        var d = frameField(id, monitor, weather);
        var col = srColor(colorCode);
        var top = 171;
        dc.setPenWidth(3);
        dc.setColor(col, Gfx.COLOR_TRANSPARENT);
        dc.drawRoundedRectangle(left, top, width, 39, 18);
        dc.setPenWidth(1);
        // Icon occupies x=left+6..+28, number starts at x=left+30.
        // Icons stay fully inside the outline and above the track.
        var iconX = left + 17;
        // Alert only recolors the existing icon; capsule border stays themed.
        drawIcon(dc, iconX, 184, id, statusIconColor(id, d[2], col));
        var value = d[1];
        var stepsReached = false;
        if (id == 2) {
            if (monitor.steps != null && monitor.stepGoal != null &&
                monitor.stepGoal > 0 && monitor.steps >= monitor.stepGoal) {
                stepsReached = true;
            }
            if (monitor.steps != null) {
                var steps = monitor.steps;
                if (isCenter && srSetting("capsuleStepsModeV39", 0) == 1 &&
                    monitor.stepGoal != null && monitor.stepGoal > 0) {
                    steps = monitor.stepGoal - steps;
                    if (steps < 0) { steps = 0; }
                }
                value = steps < 1000000 ? steps.toString() : compact(steps);
            }
        }
        // Optional dual-line steps display in the CENTER capsule only.
        // Modes 0 and 1 retain their original rendering path unchanged.
        if (id == 2 && isCenter && srSetting("capsuleStepsModeV39", 0) == 2 &&
            monitor.steps != null && monitor.stepGoal != null && monitor.stepGoal > 0) {
            var doneSteps = monitor.steps;
            var remainingSteps = monitor.stepGoal - doneSteps;
            // Signed difference: positive before goal, zero at goal, negative above goal.
            // Keep the exact number (including the minus sign), never compact it.
            // drawSized measures the text and reduces font size to fit its slot.
            var doneText = doneSteps < 1000000 ? doneSteps.toString() : compact(doneSteps);
            var remainingText = remainingSteps.toString();
            var dualWidth = width - 35;
            var dualCenter = left + 30 + (dualWidth / 2).toNumber();
            // Two separate measured text slots inside the 39px capsule.
            // No progress track or DONE badge is rendered in this mode.
            drawSized(dc, doneText, dualCenter, 174, dualWidth, 16,
                      Gfx.COLOR_WHITE, onlyDigits(doneText),
                      fieldPixels(sizeKey, "fontRingV31", 19, 1),
                      fieldScale(sizeKey, "fontRingV31"));
            drawSized(dc, remainingText, dualCenter, 192, dualWidth, 15,
                      Gfx.COLOR_WHITE, onlyDigits(remainingText),
                      fieldPixels(sizeKey, "fontRingV31", 15, 1),
                      fieldScale(sizeKey, "fontRingV31"));
            return;
        }
        var valueW = width - 35;
        var valueCenter = left + 30 + (valueW / 2).toNumber();
        drawSized(dc, value, valueCenter, 175, valueW, 19,
                  Gfx.COLOR_WHITE, onlyDigits(value),
                  fieldPixels(sizeKey, "fontRingV31", isCenter ? 23 : 21, 2),
                  fieldScale(sizeKey, "fontRingV31"));
        var showDone = stepsReached && srSetting("stepDoneV314", true);
        capsuleTrack(dc, left, top, width, d[2], col, stepsReached, showDone);
    }

    // v3.24.11: left-anchored temperature in a fixed, protected lane.
    // Returns the actual text centre so the feels-like line can follow it.
    function drawWeatherTemperature(dc, value, left, right) {
        var str = value == null ? "--" : value.toString();
        var width = right - left;
        var pixels = fieldPixels("sizeWeatherValueV37", "fontWeatherV31", 27, 2);
        var scale = fieldScale("sizeWeatherValueV37", "fontWeatherV31");
        if (!_lowMemory) {
            var cached = _tempFitCache;
            var match = cached != null && cached[0] == str &&
                        cached[1] == pixels && cached[2] == width;
            var selected = match ? cached[3] : null;
            var chosenDim = match ? cached[4] : null;
            if (!match) {
                try {
                    var requested = vectorFontFor(pixels, false);
                    if (requested != null) {
                        var dim = dc.getTextDimensions(str, requested);
                        if (dim[0] <= width && dim[1] <= 22) {
                            selected = requested;
                            chosenDim = dim;
                        } else {
                            var low = 10;
                            var high = pixels - 1;
                            while (low <= high) {
                                var mid = ((low + high) / 2).toNumber();
                                var probe = vectorFontFor(mid, false);
                                if (probe == null) { break; }
                                dim = dc.getTextDimensions(str, probe);
                                if (dim[0] <= width && dim[1] <= 22) {
                                    selected = probe;
                                    chosenDim = dim;
                                    low = mid + 1;
                                } else { high = mid - 1; }
                            }
                        }
                    }
                } catch (e) { selected = null; }
                _tempFitCache = selected == null ? null :
                                [str, pixels, width, selected, chosenDim];
            }
            if (selected != null) {
                var center = left + (chosenDim[0] / 2).toNumber();
                dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
                dc.drawText(center, 215 + ((22 - chosenDim[1]) / 2).toNumber(),
                            selected, str, Gfx.TEXT_JUSTIFY_CENTER);
                return center;
            }
        }
        // Native font fallback: measure before drawing and keep the same
        // left alignment. The existing fit routine handles the final fallback.
        var fonts = [Gfx.FONT_LARGE, Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                     Gfx.FONT_TINY, Gfx.FONT_XTINY];
        for (var i = 0; i < fonts.size(); i++) {
            try {
                var dim2 = dc.getTextDimensions(str, fonts[i]);
                if (dim2[0] <= width && dim2[1] <= 22) {
                    var center2 = left + (dim2[0] / 2).toNumber();
                    dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
                    dc.drawText(center2, 215 + ((22 - dim2[1]) / 2).toNumber(),
                                fonts[i], str, Gfx.TEXT_JUSTIFY_CENTER);
                    return center2;
                }
            } catch (e) { }
        }
        drawSized(dc, str, left + width / 2, 215, width, 22,
                  Gfx.COLOR_WHITE, false, pixels, scale);
        return left + width / 2;
    }

    // v3.26.70: temperature-only marker retained independently of the
    // removed weather-warning engine. Duotone 9x19px glyph: pale outline,
    // vivid red/cyan mercury and tiny white glint. No timers or forecasts.
    // At x=142,y=224 all drawn pixels stay in x=138..146,y=215..233,
    // between the divider at x=133 and temperature text starting x=148.
    function premiumWarningThermometer(dc, x, y, color) {
        dc.setColor(0xD7E9F7, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawRoundedRectangle(x - 3, y - 9, 6, 13, 2);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(x - 1, y - 5, 2, 10, 1);
        dc.fillCircle(x, y + 5, 4);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 1, y + 4, 1);
        dc.setPenWidth(1);
    }

    // Keep original Connect IQ identifiers from v3.26.65 so users retain
    // temperature warning preferences after updating from older versions.
    // Temperature alert only, never a storm/rain/snow hourly forecast.
    function temperatureMarker(dc, w, x, y, diagnosticTemp) {
        var testCold = (diagnosticTemp == 1 || diagnosticTemp == 2);
        var testHot = diagnosticTemp == 3;
        var isTest = testCold || testHot;
        if (!isTest && !srSetting("tempAlertsV312", true)) { return; }
        var color = 0xFF5F55;
        if (isTest) {
            color = testCold ? 0x32C8FF : 0xFF5F55;
        } else {
            if (w == null || w.temperature == null) { return; }
            var temp = w.temperature;
            if (temp > srSetting("tempHotV312", 30)) { color = 0xFF5F55; }
            else if (temp < srSetting("tempColdV312", 0)) { color = 0x32C8FF; }
            else { return; }
            // Do not show fresh-looking heat/frost markers on stale data.
            if (w.observationTime != null) {
                var age = Time.now().value() - w.observationTime.value();
                if (age < -300 || age > 5400) { return; }
                if (age > 2700) { color = Gfx.COLOR_LT_GRAY; }
            }
        }
        premiumWarningThermometer(dc, x, y, color);
    }

    // Footer right field retains temperature and feels-like. The left side
    // now draws the current Garmin condition pictogram without alerts.
    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = frameField(id, monitor, weather);
        var isTemp = (id == 16 || id == 18 || id == 19);
        var diagnosticTemp = srSetting("tempLayoutTestV32412", 0);
        var shownTemp = d[1];
        if (isTemp && diagnosticTemp == 1) { shownTemp = "-35°C"; }
        if (isTemp && diagnosticTemp == 2) { shownTemp = "-99°C"; }
        if (isTemp && diagnosticTemp == 3) { shownTemp = "45°C"; }
        var actualTempCenter = drawWeatherTemperature(dc, shownTemp, 148, 227);
        if (isTemp) { temperatureMarker(dc, weather, 142, 224, diagnosticTemp); }
        var lowerLabel = id == 16 ? conditionText(weather) : d[0];
        var lowerColor = id == 16 ? Gfx.COLOR_WHITE : Gfx.COLOR_LT_GRAY;
        if (isTemp && srSetting("showFeelsLikeV319", false) && weather != null &&
            weather.feelsLikeTemperature != null) {
            lowerLabel = "ODCZ. " + weather.feelsLikeTemperature.format("%.0f") + "°C";
            lowerColor = Gfx.COLOR_WHITE;
        }
        if (isTemp && diagnosticTemp == 1) {
            lowerLabel = "ODCZ. -45°C";
            lowerColor = Gfx.COLOR_WHITE;
        } else if (isTemp && diagnosticTemp == 2) {
            lowerLabel = "ODCZ. -99°C";
            lowerColor = Gfx.COLOR_WHITE;
        } else if (isTemp && diagnosticTemp == 3) {
            lowerLabel = "ODCZ. 50°C";
            lowerColor = Gfx.COLOR_WHITE;
        }
        // Follow the upper temperature's measured centre, within a safe
        // range for the long ODCZ. -18°C label and the curved screen edge.
        // No change to the lower font, line height, or weather icon positions.
        var lowerCenter = actualTempCenter;
        if (lowerCenter < 166) { lowerCenter = 166; }
        if (lowerCenter > 174) { lowerCenter = 174; }
        // Wider feels-like labels need a little more room to the right of
        // the separator. Keep the entire fitted string inside the safe 280px
        // footer instead of letting 10/-10 degrees touch the vertical rule.
        var labelWidth = 105;
        if (isTemp && lowerLabel.find("ODCZ.") != null) {
            lowerCenter = 179;
            labelWidth = 102;
        }
        var lowerPixels = fieldPixels("sizeWeatherLabelV37", "fontWeatherV31", 17, 2);
        if (lowerLabel.equals("BRAK DANYCH")) {
            // A temporary API error should never visually outrank the clock.
            lowerColor = Gfx.COLOR_LT_GRAY;
            if (lowerPixels > 14) { lowerPixels = 14; }
        }
        drawSized(dc, lowerLabel, lowerCenter, 234, labelWidth, 16, lowerColor, false,
                  lowerPixels,
                  fieldScale("sizeWeatherLabelV37", "fontWeatherV31"));
    }

    // v3.26.67: large, colourful CURRENT-WEATHER pictograms.
    // The entire left weather lane is used: approximately x=46..117,
    // y=216..248 on the 280x280 MIP face. The right temperature lane
    // begins at x=134; neither separator nor text is overwritten.
    // No bitmaps, arrays, timers, API calls or heap objects are created.
    function currentWeatherCloud(dc, x, y, color) {
        // Wide, softly layered silhouette; a full-width filled icon instead
        // of the tiny outline used in v3.26.66. Bounds: x-30..x+29,
        // y-14..y+11 (for the usual y=230).
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x-21, y+2, 9);
        dc.fillCircle(x-3, y-4, 10);
        dc.fillCircle(x+20, y+2, 9);
        dc.fillRectangle(x-30, y+1, 59, 10);
        dc.setColor(0xAAFFFF, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x-7, y-8, 3);
    }

    function currentWeatherSun(dc, x, y, small) {
        // Large sun fills the height of the footer without touching rules.
        // Full sun: x +/- 24, y +/- 15. Small sun: x +/- 13, y +/- 11.
        var r = small ? 7 : 11;
        var sx = small ? 13 : 24;
        var sy = small ? 10 : 15;
        var d = small ? 11 : 15;
        var e = small ? 8 : 12;
        dc.setColor(0xFFFF55, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawLine(x-sx, y, x-r-3, y);
        dc.drawLine(x+r+3, y, x+sx, y);
        dc.drawLine(x, y-sy, x, y-r-3);
        dc.drawLine(x, y+r+3, x, y+sy);
        dc.drawLine(x-d, y-d, x-e, y-e);
        dc.drawLine(x+d, y-d, x+e, y-e);
        dc.drawLine(x-d, y+d, x-e, y+e);
        dc.drawLine(x+d, y+d, x+e, y+e);
        dc.setColor(0xFFAA00, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, r);
        dc.setColor(0xFFFFAA, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x-2, y-2, small ? 3 : 6);
    }

    function currentWeatherRain(dc, x, y, heavy) {
        // Three unmistakable cyan rain streaks, not a warning marker.
        dc.setColor(0x32C8FF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(heavy ? 3 : 2);
        dc.drawLine(x-18, y+9, x-22, y+17);
        dc.drawLine(x-1, y+9, x-5, y+17);
        dc.drawLine(x+16, y+9, x+12, y+17);
    }

    function currentWeatherSnow(dc, x, y, hail) {
        dc.setColor(hail ? 0xB4EDFF : Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        if (hail) {
            dc.fillCircle(x-17, y+14, 3);
            dc.fillCircle(x-1, y+15, 3);
            dc.fillCircle(x+16, y+14, 3);
        } else {
            dc.setPenWidth(2);
            // Tiny snow crystals rather than confusing them with raindrops.
            dc.drawLine(x-18, y+11, x-18, y+17);
            dc.drawLine(x-21, y+14, x-15, y+14);
            dc.drawLine(x-1, y+11, x-1, y+17);
            dc.drawLine(x-4, y+14, x+2, y+14);
            dc.drawLine(x+16, y+11, x+16, y+17);
            dc.drawLine(x+13, y+14, x+19, y+14);
        }
    }

    function currentWeatherIce(dc, x, y) {
        // Distinct large crystalline snowflake for ice/black-ice conditions.
        // Bounds x +/- 22, y +/- 15.
        dc.setColor(0x82E5FF, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x-22, y, x+22, y);
        dc.drawLine(x, y-15, x, y+15);
        dc.drawLine(x-14, y-13, x+14, y+13);
        dc.drawLine(x-14, y+13, x+14, y-13);
        dc.setPenWidth(2);
        dc.drawLine(x-18,y-4,x-18,y+4);
        dc.drawLine(x+18,y-4,x+18,y+4);
        dc.drawLine(x-4,y-12,x+4,y-12);
        dc.drawLine(x-4,y+12,x+4,y+12);
    }

    function currentWeatherFog(dc, x, y) {
        // Layered horizontal bands occupy most of the lane's width.
        dc.setPenWidth(3);
        dc.setColor(0xDBE5F1, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x-31,y-11,x+24,y-11);
        dc.drawLine(x-22,y-3,x+31,y-3);
        dc.setColor(0xA8B9CE, Gfx.COLOR_TRANSPARENT);
        dc.drawLine(x-33,y+5,x+19,y+5);
        dc.drawLine(x-17,y+13,x+28,y+13);
    }

    function currentWeatherWind(dc, x, y) {
        // Three long gusts with curved-looking ends, no alert colours.
        dc.setColor(0xA9E5FA, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x-30,y-10,x+19,y-10);
        dc.drawLine(x+19,y-10,x+24,y-13);
        dc.drawLine(x+24,y-13,x+21,y-15);
        dc.drawLine(x-33,y,x+28,y);
        dc.drawLine(x+28,y,x+30,y+4);
        dc.drawLine(x+30,y+4,x+24,y+7);
        dc.drawLine(x-27,y+11,x+13,y+11);
        dc.drawLine(x+13,y+11,x+17,y+14);
        dc.drawLine(x+17,y+14,x+12,y+15);
    }

    function currentWeatherDust(dc, x, y) {
        // Dust / sand / smoke, visibly different from cool grey fog.
        dc.setColor(0xE9AE60, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x-30,y-11,x+15,y-11);
        dc.drawLine(x-17,y-2,x+30,y-2);
        dc.drawLine(x-32,y+8,x+18,y+8);
        dc.fillCircle(x+24,y-12,2);
        dc.fillCircle(x-25,y+16,2);
        dc.fillCircle(x+29,y+13,2);
    }

    function currentWeatherStorm(dc, x, y) {
        // Bold warm lightning bolt distinctly below the cloud.
        dc.setColor(0xFFD43B, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x+6,y+7,x-3,y+14);
        dc.drawLine(x-3,y+14,x+4,y+14);
        dc.drawLine(x+4,y+14,x-2,y+18);
    }

    function currentWeatherExtreme(dc, x, y) {
        // Tropical cyclone / tornado: a broad-to-narrow spiral funnel.
        dc.setColor(0xFF9478, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x-29,y-12,x+28,y-12);
        dc.drawLine(x-24,y-7,x+22,y-7);
        dc.drawLine(x-19,y-2,x+19,y-2);
        dc.drawLine(x-12,y+4,x+13,y+4);
        dc.drawLine(x-6,y+10,x+7,y+10);
        dc.drawLine(x-2,y+15,x+2,y+15);
    }

    function drawCurrentWeatherIcon(dc, weather) {
        // The very same CURRENT Garmin observation is shared with the
        // temperature. Rendering requires no hourly forecasts or polling.
        var group = -1;
        if (weather != null && weather.condition != null) {
            group = srGarminDisplayGroup(weather.condition);
        }
        var x = 80;
        var y = 232;
        dc.setPenWidth(2);
        if (group == 0) { // Clear sky
            currentWeatherSun(dc, x, y, false);
        } else if (group == 1) { // Sun peeking out from behind a cloud
            currentWeatherSun(dc, x-19, y-3, true);
            currentWeatherCloud(dc, x+9, 235, 0xE1EBF5);
        } else if (group == 2) { // Cloudy
            currentWeatherCloud(dc, x, 230, 0xDCE6F1);
        } else if (group == 3) { // Rain, including drizzle/showers
            currentWeatherCloud(dc, x, 230, 0xDCE6F1);
            currentWeatherRain(dc, x, 230, false);
        } else if (group == 4) { // Snow / flurries
            currentWeatherCloud(dc, x, 230, Gfx.COLOR_WHITE);
            currentWeatherSnow(dc, x, 230, false);
        } else if (group == 5) { // Wintry mix
            currentWeatherCloud(dc, x, 230, 0xDCE6F1);
            dc.setColor(0x32C8FF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x-20, 240, x-23, 247);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.drawLine(x+2, 241, x+2, 247);
            dc.drawLine(x-1, 244, x+5, 244);
            dc.drawLine(x+18, 241, x+18, 247);
            dc.drawLine(x+15, 244, x+21, 244);
        } else if (group == 6) { // Thunderstorm
            currentWeatherCloud(dc, x, 230, 0xBEC9D7);
            currentWeatherStorm(dc, x, 230);
        } else if (group == 7) { // Fog/mist/haze
            currentWeatherFog(dc, x, y);
        } else if (group == 8) { // Wind, squall
            currentWeatherWind(dc, x, y);
        } else if (group == 9) { // Tornado, hurricane, tropical storm
            currentWeatherExtreme(dc, x, y);
        } else if (group == 10) { // Dust, smoke, sand, ash
            currentWeatherDust(dc, x, y);
        } else if (group == 11) { // Ice, icy conditions
            currentWeatherIce(dc, x, y);
        } else if (group == 12) { // Hail
            currentWeatherCloud(dc, x, 230, 0xDCE6F1);
            currentWeatherSnow(dc, x, 230, true);
        } else if (group == 13) { // Freezing rain, distinct from ice
            currentWeatherCloud(dc, x, 230, 0xDCE6F1);
            dc.setColor(0x32C8FF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(3);
            dc.drawLine(x-17, 239, x-21, 247);
            dc.drawLine(x+15, 239, x+11, 247);
            dc.setColor(0xD6F7FF, Gfx.COLOR_TRANSPARENT);
            dc.fillCircle(x, 245, 3);
        } else { // Unknown/missing weather: do not falsely show sunshine.
            dc.setColor(0x9DA9B9, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(3);
            dc.drawCircle(x, y, 13);
            dc.drawText(x, y-10, Gfx.FONT_SMALL, "?", Gfx.TEXT_JUSTIFY_CENTER);
        }
        dc.setPenWidth(1);
    }

    // Battery footer occupies y=251..267. Move icon 7px right and number
    // 2px right to reduce apparent separation while freeing the left edge.
    // At maximum fitted value width=60: text starts x=137 and icon ends
    // x=135, maintaining a guaranteed >=2px gap. No footer clipping.
    // This does not change the separate weather glyph at y=216..248.
    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = frameField(id, monitor, weather);
        var footerColor = statusIconColor(id, d[2], Gfx.COLOR_GREEN);
        var charging = false;
        if (id == 17) { // Footer displays the watch battery.
            // Connect IQ System.Stats.charging is TRUE while USB is plugged in,
            // including after reaching 100%. Safe fallback: normal icon.
            try { charging = srSystemStatsForFrame().charging; }
            catch (e) { charging = false; }
        }
        if (id == 17 && charging) {
            chargingBatteryIcon(dc, 124, 261, Gfx.COLOR_GREEN);
        } else {
            // All other footer selections and unplugged battery unchanged.
            drawIcon(dc, 124, 261, id, footerColor);
        }
        drawSized(dc, d[1], 167, 251, 60, 20,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("sizeFooterV37", "fontWeatherV31", 22, 2),
                  fieldScale("sizeFooterV37", "fontWeatherV31"));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = frameField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 131;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function drawGarminLocationDiag(dc) {
        var wx = getCachedConditions();
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_BLACK);
        dc.drawText(140, 30, Gfx.FONT_SMALL, "TEST 21: GARMIN + PHOTON", Gfx.TEXT_JUSTIFY_CENTER);
        var name = "BRAK NAZWY";
        if (wx != null) {
            try {
                if (wx.observationLocationName != null) {
                    name = wx.observationLocationName;
                }
            } catch (e) { }
        }
        dc.drawText(140, 100, Gfx.FONT_XTINY, name, Gfx.TEXT_JUSTIFY_CENTER);
        var diag = null;
        try { diag = App.Storage.getValue("srPhotonDiagV32664"); } catch (e) { }
        var status = "PHOTON: JESZCZE BRAK TESTU";
        if (diag instanceof Toybox.Lang.Array && diag.size() >= 3) {
            status = "PHOTON ST " + diag[1].toString() + " HTTP " + diag[2].toString();
        }
        dc.drawText(140, 158, Gfx.FONT_XTINY,
                    status, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(140, 205, Gfx.FONT_XTINY,
                    "~ = NAZWA PRZYBLIZONA", Gfx.TEXT_JUSTIFY_CENTER);
    }

    function drawGarminMemoryDiag(dc) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_BLACK);
        dc.drawText(140, 32, Gfx.FONT_SMALL, "TEST 22: GARMIN RAM", Gfx.TEXT_JUSTIFY_CENTER);
        var st = System.getSystemStats();
        dc.drawText(140, 84, Gfx.FONT_XTINY,
                    "WOLNA RAM: " + st.freeMemory.toString(), Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(140, 138, Gfx.FONT_XTINY,
                    "POGODA: TYLKO TERAZ", Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(140, 190, Gfx.FONT_XTINY,
                    "BRAK PROGNOZY / ALERTOW", Gfx.TEXT_JUSTIFY_CENTER);
    }

    function onUpdate(dc) {
        // Only after the previous Settings transaction has completed.
        refreshChangedSettings();
        // One snapshot for memory, battery percentage and charging status.
        // Obtained anew on EVERY onUpdate, never reused on a later frame.
        var stats = null;
        try { stats = System.getSystemStats(); } catch (e) { }
        _srFrameSystemStats = stats;
        _frameEpoch += 1;
        // One-way low-memory fallback avoids repeated vector font allocations.
        if (!_lowMemory && stats != null) {
            try {
                if (stats.freeMemory < 18000) {
                    _lowMemory = true;
                    _fontCache = {};
                    _fontCacheCount = 0;
                    _sizedFitCache = {};
                    _sizedFitCacheSize = 0;
                    _clockFitCache = null;
                    _clockLayoutCache = null;
                    _tempFitCache = null;
                    _moonCosCache = null;
                }
            } catch (e) { }
        }
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var diagMode = srSetting("gwPreviewV332", 0);
        if (diagMode == 21 || diagMode == 22) {
            if (diagMode == 21) {
                try { drawGarminLocationDiag(dc); } catch (e) { }
            } else {
                try { drawGarminMemoryDiag(dc); } catch (e) { }
            }
            _srFrameSystemStats = null;
            return;
        }
        var clock = System.getClockTime();
        // Calendar is static within the current minute, unlike LIVE heart
        // rate, steps or the battery. Avoid Gregorian.info per 1Hz redraw.
        var minuteKey = (Time.now().value() / 60).toNumber();
        if (_cachedCalendar == null || _calendarMinuteKey != minuteKey) {
            _cachedCalendar = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
            _calendarMinuteKey = minuteKey;
        }
        var date = _cachedCalendar;
        // ActivityMonitor and live Activity.currentHeartRate stay uncached.
        var monitor = Monitor.getInfo();
        var w = getCachedConditions();
        // Only a changed Garmin-weather coordinate is persisted to the
        // background queue; never invoke Photon from the render path.
        updatePhotonTarget(w);

        outerProgressRing(dc, monitor, w, clock);
        topSlot(dc, 73, srSetting("slotTop1V3", 14), "sizeTopLeftV37", monitor, w);
        topSlot(dc, 134, srSetting("slotTop2V3", 34), "sizeTopMidV37", monitor, w);
        topSlot(dc, 195, srSetting("slotTop3V3", 15), "sizeTopRightV37", monitor, w);
        topDividers(dc);
        rule(dc, 70);

        drawClock(dc, clock);
        // Calendar values still come from Gregorian on every full update;
        // only the identical day/month label is memoized until it changes.
        var dayMonthKey = date.month * 32 + date.day;
        var dayMonthText = null;
        if (_dateTextCache != null && _dateTextCache[0] == dayMonthKey) {
            dayMonthText = _dateTextCache[1];
        } else {
            dayMonthText = date.day.toString() + " " + _srMonths[date.month - 1];
            _dateTextCache = [dayMonthKey, dayMonthText];
        }
        drawDate(dc, _srDays[date.day_of_week - 1], dayMonthText);
        drawWeatherAge(dc, w);
        rule(dc, 134);

        try { drawMoonPanel(dc, w); } catch (e) { /* Keep main time alive. */ }
        rule(dc, 164);

        capsule(dc, 32, 64, srSetting("slotRing1V3", 1),
                srSetting("colorRing1V3", 0), "sizeRingLeftV37", monitor, w, false);
        capsule(dc, 99, 83, srSetting("slotRing2V3", 2),
                srSetting("colorRing2V3", 2), "sizeRingMidV37", monitor, w, true);
        capsule(dc, 185, 64, srSetting("slotRing3V3", 3),
                srSetting("colorRing3V3", 6), "sizeRingRightV37", monitor, w, false);
        rule(dc, 215);

        // Weather API failures must not interrupt the time and other fields.
        try { drawWeather(dc, monitor, w); } catch (e) { }
        // Only a pictogram of the current Garmin observation; no forecast
        // fetch, warnings, thresholds, rotations or extra timer.
        try { drawCurrentWeatherIcon(dc, w); } catch (e) { }
        weatherDivider(dc);
        rule(dc, 250);
        drawBattery(dc, monitor, w);

        // No stale System.Stats can survive a successfully completed render.
        _srFrameSystemStats = null;
    }

    
}
