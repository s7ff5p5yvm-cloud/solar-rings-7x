# Solar Rings 7X 3.20.3 — dalsza diagnostyka po awarii trybu 4

- W trybie 4 zadanie w tle emituje ten sam wynik (`stage=11`) co sprawdzony test 5C. Warstwa ekranowa interpretuje go jako bieżący IMGW tylko po weryfikacji lokalizacji GPS i wieku wyniku.
- Dodano ustawienie **IMGW: pokaz ikony ostrzezen (eksperymentalnie)**. Domyślnie wyłączone, aby odseparować komunikację od rysowania. Włączenie diagnostyki również wyłącza rysowanie ikony.
- Po zmianie ustawień czyszczony jest wynik IMGW i pomocniczy cache powiatu.
- Wszystkie stare testy 0–13 pozostają dostępne w tej samej tarczy.

**Instrukcja:** Zbuduj na GitHubie z nowego ZIP i BUILD, zainstaluj i wybierz IMGW włączone, etap 4, diagnostyka włączona, ikony wyłączone, odświeżanie 5 minut. Potwierdź, czy ekran pokazuje `T4 OK0`, `T4 ALERT` czy tarcza się wyłącza. Nie interpretuj "CZEKA" jako braku ostrzeżeń. Po pozytywnym teście wyłącz diagnostykę, ale na początek pozostaw ikony wyłączone. Dopiero na końcu włącz ikony.

**Uwaga:** To test różnic między trybem 4 a 5C, a nie potwierdzona naprawa awarii pamięci. Sam Garmin SDK ani fizyczny zegarek nie został przetestowany lokalnie.
