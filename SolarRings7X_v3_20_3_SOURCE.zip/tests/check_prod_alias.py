from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
s=(p/'source/ImgwService.mc').read_text()
f=(p/'source/SolarRings7X.mc').read_text()
assert '_stage = stage == 4 ? 11 : stage;' in s
assert 'beginUnifiedImgwRequest(_stage);' in s
assert 'result[7] != (stage == 4 ? 11 : stage)' in f
assert 'd[7] != (stage == 4 ? 11 : stage)' in f
assert 'imgwIconsV3203' in f
p2=ET.parse(p/'resources/settings/properties.xml').getroot()
icons=[x for x in p2 if x.get('id')=='imgwIconsV3203']
assert len(icons)==1 and icons[0].text=='false'
assert 'verifiedImgwResult(4, true)' in f
print('PASS stage4 service aliased to 5C; icon output opt-in and GPS validation retained')
