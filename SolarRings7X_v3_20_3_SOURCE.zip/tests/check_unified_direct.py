from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
s=(p/'source/ImgwService.mc').read_text()
f=(p/'source/SolarRings7X.mc').read_text()
xml=ET.parse(p/'resources/settings/settings.xml').getroot()
strs=ET.parse(p/'resources/strings.xml').getroot()
values={e.attrib['value'] for e in xml.findall('.//setting[@propertyKey="@Properties.imgwTestStageV3194"]/settingConfig/listEntry')}
assert values=={str(i) for i in range(14)},values
assert all(any(x.attrib.get('id')=='imgwStage_'+str(i) for x in strs) for i in range(14))
assert 'if (stage == 4) { _phase = 44; stop(10); return; }' not in s
assert 'if (_county != null) { beginUnifiedImgwRequest(4); return; }' not in s
assert 'if (_stage == 9 || _stage == 10 || _stage == 11)' in s
assert 'beginUnifiedImgwRequest(_stage)' in s
assert '_stage = stage == 4 ? 11 : stage;' in s
assert 'processOfficialWarnings(payload)' in s
assert 'since.substring(0, 19).compareTo(stamp) <= 0' in s
assert 'ids[n].equals(_county)' in s
assert 'Bg.exit([_county, bestLevel, bestKind' in s
assert 'if (probe.size() < 8 || probe[7] != stage)' not in f # condition is in compound statement
assert 'probe[7] != stage' in f
assert 'data[7] != stage' in f
assert 'if (dStage >= 9 && dStage <= 13)' in f
assert 'https://danepubliczne.imgw.pl/api/data/warningsmeteo' in s
assert 'https://raw.githubusercontent.com/' in s # legacy optional probe only
assert 'version="3.20.3"' in (p/'manifest.xml').read_text()
print('PASS unified direct IMGW modes 0-13; stage-tagged diagnostics, no GitHub in full mode')
