# Solar Rings 7X v3.21.5 — IMGW i temperatura odczuwalna

## Co się zmieniło
- Przestaliśmy zastępować odczuwalną temperaturę wielkim napisem „RĘCZNY 1205 ALERT!” lub „OSTATNI...”. Przy wyłączonej diagnostyce wyświetlana jest sama ikona IMGW.
- Termometr dla mrozu (temperatura poniżej ustawionego progu, standardowo 0°C) i ikona IMGW mają odrębne pola i mogą być wyświetlane równocześnie.
- Dodano kontrolę zgodności kodu oraz współrzędnych ostatniego powiatu zwróconego przez GUGiK. Jeżeli Garmin po zapytaniu zgubi współrzędne GPS, ważny alert może zostać pokazany jako ostatni znany powiat zamiast zniknąć z powodu D7/D8; to nie jest dowód aktualnej lokalizacji.
- Odczyt lokalizacji korzysta z już pobranej pogody Garmin, aby nie robić dwóch zapytań Weather w tym samym odświeżeniu.
- Dokładniejsza diagnostyka: G8 = pozycja Garmin Weather bez czasu pomiaru; G9 = pogoda za stara; G10 = wyjątek odczytu Weather. Kod G3 nadal może wystąpić, gdy Garmin nie udostępnia żadnej pozycji.

## Wgrywanie
1. Wgraj `SolarRings7X_v3_21_5_SOURCE.zip` do głównego katalogu repozytorium GitHub.
2. Wgraj `SolarRings7X_v3_21_5_BUILD.yml` do `.github/workflows/`.
3. W GitHub Actions wybierz `Build Solar Rings 7X v3.21.5` → Run workflow.
4. Zainstaluj plik .iq z artefaktów.

## Ustawienia do normalnego korzystania
- IMGW: włączone, test 4.
- IMGW: ikony ostrzeżeń: włączone.
- IMGW: podgląd ikony TEST: Wyłącz.
- IMGW: diagnostyka: Wyłącz (inaczej diagnostyka celowo zajmie linię temperatury odczuwalnej).
- IMGW: TERYT awaryjny: 0 dla automatycznego ustalania; konkretny numer powiatu tylko do testów.
- Temperatura odczuwalna: Włącz, aby była pokazana pod temperaturą bieżącą.

**Uwaga:** tarcza typu WatchFace nie może uruchomić GPS samodzielnie. Pełna automatyka nadal zależy od udostępnienia pozycji przez Garmin. Rozwiązanie nie jest zweryfikowane na fizycznym Fenixie ani kompilatorem Garmin SDK.
