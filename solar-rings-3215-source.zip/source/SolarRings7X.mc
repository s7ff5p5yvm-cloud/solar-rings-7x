using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;
using Toybox.Math as Math;
using Toybox.Background as Bg;
using Toybox.Application.Storage as Storage;
using Toybox.Activity as Activity;
using Toybox.Lang as Lang;

// App class is also available to the small IMGW background service.
(:background)
class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    // Register background events only from the foreground watch-face view.
    // AppBase.onStart() also runs inside the background worker; scheduling
    // from there can recursively restart the service on some firmware.
    function getInitialView() {
        updateImgwScheduler();
        return [new SolarRingsFaceV3()];
    }

    function getServiceDelegate() { return [new ImgwServiceV318()]; }

    function onStart(state) {
        AppBase.onStart(state);
    }

    function onSettingsChanged() {
        updateImgwScheduler();
        try {
            if (App.Properties.getValue("imgwTestStageV3194") >= 2) {
                Storage.deleteValue("imgwResultV318");
            }
        } catch (e) { }
        try { Ui.requestUpdate(); } catch (e) { }
    }

    function updateImgwScheduler() {
        try {
            // Staged test modes 0=UI, 1=GPS, 2=background,
            // 3=GUGiK, 4=full IMGW, 5=GitHub text probe, 6=GitHub JSON probe.
            // No background service in 0 or 1.
            var diagnosticStage = App.Properties.getValue("imgwTestStageV3194");
            if (diagnosticStage == null) { diagnosticStage = 0; }
            var isRealStage = diagnosticStage == 2 || diagnosticStage == 3 ||
                diagnosticStage == 4 || (diagnosticStage >= 7 && diagnosticStage <= 13);
            if (App.Properties.getValue("imgwOnV317") == true && isRealStage) {
                var interval = App.Properties.getValue("imgwMinutesV317");
                if (interval == null || interval < 5) { interval = 30; }
                // Re-register on settings change and startup, if supported.
                Bg.registerForTemporalEvent(new Time.Duration(interval * 60));
            } else {
                if (Bg.getTemporalEventRegisteredTime() != null) {
                    Bg.deleteTemporalEvent();
                }
                // Test 0/1 isolates the renderer and GPS without disk writes.
            }
        } catch (e) { }
    }

    function onBackgroundData(data) {
        try {
            if (data != null && data instanceof Lang.Array && data.size() >= 8) {
                // Always write the diagnostic result first. Previously a
                // failure writing the county cache could suppress this result
                // entirely and leave the UI stuck on an old status.
                Storage.setValue("imgwResultV318", data);
            }
        } catch (e) { }
        // Never let an IMGW callback terminate the watch-face renderer.
        try { Ui.requestUpdate(); } catch (e) { }
    }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;
    var _fontCache;
    var _fontCacheCount;
    var _lowMemory;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
        _fontCache = {};
        _fontCacheCount = 0;
        _lowMemory = false;
    }

    // Select genuinely different font sizes for SMALL / NORMAL / LARGE.
    // Always fit the selected font to a reserved box; never draw outside it.
    // IMPORTANT: using a single dynamic largest-fit list made small and
    // large look identical in v3.1. This implementation uses distinct caps.
    // 3.5: native Garmin text throughout. Earlier versions drew clock and
    // ring numbers one bitmap rectangle at a time and sometimes showed NO
    // values on the real MIP screen. One Dc.drawText per value avoids it.
    // This renderer NEVER changes the clip region and always has a fallback.
    function fitScaled(dc, value, x, top, width, height, color, numeric, scale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        var numberOnly = numeric;
        if (numberOnly) {
            for (var i = 0; i < str.length(); i++) {
                var c = str.substring(i, i + 1);
                if ("0123456789:".find(c) == null) {
                    numberOnly = false;
                    break;
                }
            }
        }
        var fonts;
        if (numberOnly) {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_LARGE, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }
        var chosen = Gfx.FONT_XTINY;
        var textH = dc.getFontHeight(chosen);
        for (var j = 0; j < fonts.size(); j++) {
            var dim = dc.getTextDimensions(str, fonts[j]);
            if (dim[0] <= width && dim[1] <= height) {
                chosen = fonts[j];
                textH = dim[1];
                break;
            }
        }
        // No pixel rectangles and NO setClip(): every field is visible.
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        var yy = top + ((height - textH) / 2).toNumber();
        dc.drawText(x, yy, chosen, str, Gfx.TEXT_JUSTIFY_CENTER);
    }

    // NEW v3.6: scalable fonts available on Fenix 7X Pro (Connect IQ 4.2.2+).
    // RobotoCondensedBold is an installed system face, NOT a bundled font file.
    // The optional style and increase settings affect every visible data field.
    function desiredPixels(settingKey, normalSize, increment) {
        var level = srSetting(settingKey, 2);
        if (level < 0) { level = 0; }
        if (level > 2) { level = 2; }
        return normalSize + (level - 1) * increment +
               (srSetting("fontExtraV36", 1) * 2);
    }

    // v3.7: Independent field size controls, with backwards-compatible group
    // settings as defaults. -1 means inherit the existing group setting.
    // 0..4 map to XS / Small / Medium / Large / XL.
    function fieldPixels(fieldKey, groupKey, normalSize, step) {
        var chosen = srSetting(fieldKey, -1);
        if (chosen == -1) {
            var groupLevel = srSetting(groupKey, 2);
            if (groupLevel < 0) { groupLevel = 0; }
            if (groupLevel > 2) { groupLevel = 2; }
            chosen = groupLevel * 2;
        }
        if (chosen < 0) { chosen = 0; }
        if (chosen > 4) { chosen = 4; }
        return normalSize + (chosen - 2) * step +
               (srSetting("fontExtraV36", 1) * 2);
    }

    function fieldScale(fieldKey, groupKey) {
        var level = srSetting(fieldKey, -1);
        if (level < 0) { return srSetting(groupKey, 2); }
        if (level <= 1) { return 0; }
        if (level == 2) { return 1; }
        return 2;
    }

    function vectorFontFor(pixels, digits) {
        var style = srSetting("fontFaceV36", 0);
        if (style == 4) { return null; } // Garmin native-only fallback
        var face = "RobotoCondensedBold";
        if (style == 1) { face = "RobotoCondensedRegular"; }
        else if (style == 2) { face = "ExoSemiBold"; }
        else if (style == 3 && digits) { face = "BionicBold"; }
        var key = face + ":" + pixels.toString();
        var cached = _fontCache[key];
        if (cached != null) { return cached; }
        var found = null;
        try { found = Gfx.getVectorFont({:face => face, :size => pixels}); }
        catch (e) { }
        // Avoid retaining an unbounded number of vector font handles.
        // Garmin watch faces have a strict memory budget.
        if (found != null && _fontCacheCount < 20) {
            _fontCache[key] = found;
            _fontCacheCount += 1;
        }
        return found;
    }

    function drawSized(dc, value, x, top, width, height, color, digits, sizePixels, fallbackScale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        // When RAM is low, use stable Garmin bitmap fonts instead of vectors.
        if (_lowMemory) {
            fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale);
            return;
        }
        // Fit the *measured* glyphs into the allotted section.
        // For long values reduce font size rather than truncating steps.
        var smallest = 10;
        for (var px = sizePixels; px >= smallest; px -= 1) {
            var font = vectorFontFor(px, digits);
            if (font == null) { break; }
            try {
                var dim = dc.getTextDimensions(str, font);
                if (dim[0] <= width && dim[1] <= height) {
                    dc.setColor(color, Gfx.COLOR_TRANSPARENT);
                    var yy = top + ((height - dim[1]) / 2).toNumber();
                    dc.drawText(x, yy, font, str, Gfx.TEXT_JUSTIFY_CENTER);
                    return;
                }
            } catch (e) {
                // If Garmin rejects a glyph, try the native bitmap fallback.
                break;
            }
        }
        // Never leave a field blank if a face is unsupported.
        fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale);
    }

    function fit(dc, value, x, top, width, height, color, numeric) {
        fitScaled(dc, value, x, top, width, height, color, numeric, 1);
    }


    // Truly visible large clock. Font sizes are measured on the actual device,
    // so changing small/medium/large in the iPhone app changes the candidate
    // set and still fits the reserved 145 x 53 px area.
    // v3.12: wider 164px bold clock, still separate from the unchanged date.
    // Distinct target sizes (small/medium/large) avoid prior settings collapsing
    // to one size. Actual glyph bounds are measured before drawing.
    function drawClock(dc, clock) {
        var value = twoDigits(clock.hour) + ":" + twoDigits(clock.min);
        var pref = srSetting("fontClockV31", 2);
        var requested = 62;
        if (pref <= 0) { requested = 46; }
        else if (pref == 1) { requested = 54; }
        requested += srSetting("fontExtraV36", 1) * 2;
        // Horizontal position is deliberately separated from the date box.
        // 77..129 is the full vertical band between the rules at 76 and 130.
        var cx = 97;
        var top = 77;
        var slotW = 164;
        var slotH = 52;
        if (_lowMemory) {
            fitScaled(dc, value, cx, top, slotW, slotH,
                      Gfx.COLOR_WHITE, true, pref);
            return;
        }
        for (var px = requested; px >= 32; px--) {
            var boldFont = null;
            try {
                var clockFontKey = "CLOCKB:" + px.toString();
                boldFont = _fontCache[clockFontKey];
                if (boldFont == null) {
                    boldFont = Gfx.getVectorFont({:face => "RobotoCondensedBold", :size => px});
                    if (boldFont != null && _fontCacheCount < 20) {
                        _fontCache[clockFontKey] = boldFont;
                        _fontCacheCount += 1;
                    }
                }
                if (boldFont != null) {
                    var dim = dc.getTextDimensions(value, boldFont);
                    if (dim[0] + 3 <= slotW && dim[1] <= slotH) {
                        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
                        var yy = top + ((slotH - dim[1]) / 2).toNumber();
                        dc.drawText(cx, yy, boldFont, value, Gfx.TEXT_JUSTIFY_CENTER);
                        // One pixel of additional weight for high contrast MIP.
                        dc.drawText(cx + 1, yy, boldFont, value, Gfx.TEXT_JUSTIFY_CENTER);
                        return;
                    }
                }
            } catch (e) { break; }
        }
        // Fallback on devices that cannot render the vector typeface.
        drawSized(dc, value, cx, top, slotW, slotH, Gfx.COLOR_WHITE, true,
                  requested, pref);
    }

    // Mini digits for compact times and symbols are kept below.

    function miniGlyph(ch) {
        if (ch == "0") { return ["111","101","101","101","101","101","111"]; }
        if (ch == "1") { return ["010","110","010","010","010","010","111"]; }
        if (ch == "2") { return ["111","001","001","111","100","100","111"]; }
        if (ch == "3") { return ["111","001","001","111","001","001","111"]; }
        if (ch == "4") { return ["101","101","101","111","001","001","001"]; }
        if (ch == "5") { return ["111","100","100","111","001","001","111"]; }
        if (ch == "6") { return ["111","100","100","111","101","101","111"]; }
        if (ch == "7") { return ["111","001","001","010","010","010","010"]; }
        if (ch == "8") { return ["111","101","101","111","101","101","111"]; }
        if (ch == "9") { return ["111","101","101","111","001","001","111"]; }
        if (ch == ":") { return ["0","1","1","0","1","1","0"]; }
        return ["000","000","000","000","000","000","000"];
    }

    // Fixed-width 3x7 glyphs. All writes are confined to the intended
    // region; use only filled rectangles so this works without font assets.
    function drawPixelDigits(dc, value, centerX, top, pixel, color) {
        if (value == null || value.length() == 0) { return; }
        var units = 0;
        for (var i = 0; i < value.length(); i++) {
            var g = miniGlyph(value.substring(i, i + 1));
            units += g[0].length() + 1;
        }
        units -= 1;
        var x = (centerX - (units * pixel) / 2).toNumber();
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        for (var k = 0; k < value.length(); k++) {
            var glyph = miniGlyph(value.substring(k, k + 1));
            for (var row = 0; row < 7; row++) {
                var bits = glyph[row];
                for (var col = 0; col < bits.length(); col++) {
                    if (bits.substring(col, col + 1) == "1") {
                        dc.fillRectangle(x + col * pixel, top + row * pixel,
                                         pixel, pixel);
                    }
                }
            }
            x += (glyph[0].length() + 1) * pixel;
        }
    }

    function onlyDigits(str) {
        if (str == null || str.length() == 0) { return false; }
        for (var i = 0; i < str.length(); i++) {
            if ("0123456789".find(str.substring(i, i + 1)) == null) {
                return false;
            }
        }
        return true;
    }
    // Sunrise and sunset times use a larger measured Garmin font.
    function drawTopClock(dc, value, center, sizeKey, slotWidth) {
        drawSized(dc, value, center, 50, slotWidth, 23,
                  Gfx.COLOR_WHITE, true,
                  fieldPixels(sizeKey, "fontTopV31", 21, 2),
                  fieldScale(sizeKey, "fontTopV31"));
    }

    // Date is on the right of the clock; the two lines are individually
    // fitted to 72px. No clips which can hide the clock or ring values.
    function drawDate(dc, dayLabel, dateLabel) {
        var settingSize = srSetting("fontDateV31", 2);
        drawSized(dc, dayLabel, 219, 80, 65, 23,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontDateV31", 27, 3), settingSize);
        drawSized(dc, dateLabel, 219, 104, 77, 25,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontDateV31", 24, 3), settingSize);
    }

    // Native 1px separators, including the two vertical ones requested
    // between the sunrise / moon / sunset fields.
    function rule(dc, y) {
        dc.setColor(0x696969, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        if (y == 250) {
            dc.drawLine(100, y, 190, y);
        } else if (y == 163) {
            // Short separator leaves the moon symbol and the outer rim clear.
            dc.drawLine(99, y, 242, y);
        } else {
            dc.drawLine(28, y, 252, y);
        }
    }

    function topDividers(dc) {
        dc.setColor(0x888888, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(107, 29, 107, 70);
        dc.drawLine(163, 29, 163, 70);
    }

    function weatherDivider(dc) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(109, 220, 109, 245);
    }

    // Different shapes for sunrise and sunset, not just different colors.
    // Both icons fit within x-12..x+15, y-9..y+8 on the 280px face.
    // Sunrise: arrow UP. Sunset: arrow DOWN.
    function sunIcon(dc, x, y, isRise) {
        dc.setColor(isRise ? 0xFFE8A0 : 0xFF7799, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 2, y + 6, 6, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 12, y + 7, x + 9, y + 7);
        dc.setPenWidth(1);
        dc.drawLine(x - 2, y - 4, x - 2, y - 6);
        dc.drawLine(x - 10, y, x - 8, y + 1);
        dc.drawLine(x + 5, y, x + 7, y + 1);
        // The arrow is separate from the sun, so its direction is obvious.
        dc.setPenWidth(2);
        dc.drawLine(x + 13, y - 8, x + 13, y + 1);
        if (isRise) {
            dc.drawLine(x + 10, y - 5, x + 13, y - 8);
            dc.drawLine(x + 13, y - 8, x + 16, y - 5);
        } else {
            dc.drawLine(x + 10, y - 2, x + 13, y + 1);
            dc.drawLine(x + 13, y + 1, x + 16, y - 2);
        }
        dc.setPenWidth(1);
    }

    // Solid, symmetrical heart similar to the clear heart from Garmin Connect.
    // Pixel-width fill makes it readable even at the MIP capsule's icon size.
    // Extents x-8..x+8, y-8..y+8.
    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 4, 4);
        dc.fillCircle(x + 4, y - 4, 4);
        dc.fillRectangle(x - 8, y - 4, 16, 4);
        for (var row = 0; row <= 8; row++) {
            var halfWidth = 8 - row;
            dc.drawLine(x - halfWidth, y + row, x + halfWidth, y + row);
        }
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    // Garmin Connect inspired Body Battery pictogram. Three segmented energy
    // arcs and one central circular node; vector geometry, no external assets.
    // Bounds x +/-10, y +/-10: safe even in the 64px side capsules.
    function bodyBatteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 10, Gfx.ARC_CLOCKWISE, 35, 142);
        dc.drawArc(x, y, 10, Gfx.ARC_CLOCKWISE, 158, 252);
        dc.drawArc(x, y, 10, Gfx.ARC_CLOCKWISE, 269, 342);
        dc.setPenWidth(1);
        dc.drawCircle(x, y - 2, 3);
        dc.fillCircle(x, y - 2, 2);
        dc.setPenWidth(2);
        dc.drawLine(x, y + 2, x, y + 7);
        dc.drawLine(x - 4, y + 2, x, y + 5);
        dc.drawLine(x + 4, y + 2, x, y + 5);
        dc.setPenWidth(1);
    }

    // Intensywne minuty: a fast stopwatch with three speed lines, clearly
    // distinct from the simple top-row stopwatch icon.
    // Bounds x-14..x+10, y-11..y+10.
    function intensityTimerIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x + 1, y + 1, 8);
        dc.drawLine(x + 1, y - 8, x + 1, y - 11);
        dc.drawLine(x - 2, y - 11, x + 4, y - 11);
        dc.drawLine(x + 1, y + 1, x + 4, y + 4);
        dc.drawLine(x + 1, y + 1, x + 1, y - 3);
        dc.drawLine(x - 14, y - 4, x - 9, y - 4);
        dc.drawLine(x - 14, y, x - 10, y);
        dc.drawLine(x - 14, y + 4, x - 9, y + 4);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        drawLunarDisk(dc, x, y, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // independent pressure-warning bolt, they describe present weather.
    function weatherSymbol(dc, x, y, weather) {
        if (weather == null || weather.condition == null) {
            // Missing weather: neutral outline, no invented condition.
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.drawLine(x, y - 4, x, y + 1);
            dc.drawCircle(x, y + 5, 1);
            dc.setPenWidth(1);
            return;
        }
        var c = weather.condition;
        // Pure sunshine.
        if (c == Weather.CONDITION_CLEAR || c == Weather.CONDITION_FAIR ||
            c == Weather.CONDITION_MOSTLY_CLEAR) {
            dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y - 2, 10);
            dc.drawLine(x, y - 19, x, y - 15);
            dc.drawLine(x, y + 11, x, y + 16);
            dc.drawLine(x - 18, y - 2, x - 14, y - 2);
            dc.drawLine(x + 14, y - 2, x + 18, y - 2);
            dc.drawLine(x - 13, y - 15, x - 10, y - 12);
            dc.drawLine(x + 10, y + 8, x + 13, y + 11);
            dc.drawLine(x + 12, y - 15, x + 9, y - 12);
            dc.drawLine(x - 9, y + 8, x - 12, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Cloud with some sun.
        if (c == Weather.CONDITION_PARTLY_CLOUDY ||
            c == Weather.CONDITION_PARTLY_CLEAR ||
            c == Weather.CONDITION_THIN_CLOUDS) {
            cloud(dc, x, y);
            return;
        }
        // Cloud and precipitation.
        if (c == Weather.CONDITION_RAIN || c == Weather.CONDITION_LIGHT_RAIN ||
            c == Weather.CONDITION_HEAVY_RAIN || c == Weather.CONDITION_DRIZZLE ||
            c == Weather.CONDITION_SCATTERED_SHOWERS || c == Weather.CONDITION_SHOWERS ||
            c == Weather.CONDITION_LIGHT_SHOWERS || c == Weather.CONDITION_HEAVY_SHOWERS ||
            c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN ||
            c == Weather.CONDITION_UNKNOWN_PRECIPITATION) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(0x00AAFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 12, x - 13, y + 18);
            dc.drawLine(x, y + 12, x - 3, y + 18);
            dc.drawLine(x + 10, y + 12, x + 7, y + 18);
            dc.setPenWidth(1);
            return;
        }
        // Snow / wintry conditions.
        if (c == Weather.CONDITION_SNOW || c == Weather.CONDITION_LIGHT_SNOW ||
            c == Weather.CONDITION_HEAVY_SNOW || c == Weather.CONDITION_FLURRIES ||
            c == Weather.CONDITION_CHANCE_OF_SNOW || c == Weather.CONDITION_WINTRY_MIX ||
            c == Weather.CONDITION_RAIN_SNOW || c == Weather.CONDITION_ICE_SNOW ||
            c == Weather.CONDITION_LIGHT_RAIN_SNOW || c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
            c == Weather.CONDITION_FREEZING_RAIN || c == Weather.CONDITION_SLEET ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 11, x - 10, y + 19);
            dc.drawLine(x - 14, y + 15, x - 6, y + 15);
            dc.drawLine(x + 7, y + 11, x + 7, y + 19);
            dc.drawLine(x + 3, y + 15, x + 11, y + 15);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_THUNDERSTORMS ||
            c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
            c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS ||
            c == Weather.CONDITION_TROPICAL_STORM) {
            simpleCloud(dc, x, y - 6);
            stormBolt(dc, x + 2, y + 13);
            return;
        }
        if (c == Weather.CONDITION_FOG || c == Weather.CONDITION_MIST ||
            c == Weather.CONDITION_HAZY || c == Weather.CONDITION_HAZE) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 20, y - 9, x + 16, y - 9);
            dc.drawLine(x - 16, y - 2, x + 20, y - 2);
            dc.drawLine(x - 20, y + 5, x + 15, y + 5);
            dc.drawLine(x - 13, y + 12, x + 20, y + 12);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_WINDY || c == Weather.CONDITION_SQUALL) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 22, y - 5, x + 12, y - 5);
            dc.drawLine(x - 12, y + 3, x + 19, y + 3);
            dc.drawLine(x - 19, y + 11, x + 10, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Overcast / unclassified present weather.
        simpleCloud(dc, x, y);
    }

    function simpleCloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 11, y + 2, 8);
        dc.fillCircle(x + 1, y - 4, 11);
        dc.fillCircle(x + 14, y + 3, 8);
        dc.fillRectangle(x - 17, y + 3, 38, 9);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    // Only the existing pictogram changes color when an optional threshold is
    // crossed. This adds no icons/lines and preserves the approved geometry.
    // d[2] is a 0..1 ratio, not a percent; null means no dependable data.
    function statusIconColor(id, ratio, normalColor) {
        if (!srSetting("statusColorsV315", true) || ratio == null) {
            return normalColor;
        }
        var percent = ratio.toFloat() * 100.0;
        if (id == 17) {
            if (percent <= srSetting("batteryCriticalV315", 10)) { return Gfx.COLOR_RED; }
            if (percent <= srSetting("batteryLowV315", 20)) { return Gfx.COLOR_YELLOW; }
        }
        if (id == 3 && percent <= srSetting("bodyLowV315", 20)) {
            return Gfx.COLOR_ORANGE;
        }
        if (id == 10 && percent >= srSetting("stressHighV315", 80)) {
            return Gfx.COLOR_ORANGE;
        }
        return normalColor;
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 35) {
            var currentWeather = null;
            try { currentWeather = Weather.getCurrentConditions(); } catch (e) { }
            var event = nextSunEvent(currentWeather);
            if (event != null) { sunIcon(dc, x, y, event[0]); }
            else { genericIcon(dc, x, y, Gfx.COLOR_LT_GRAY); }
        }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3) { bodyBatteryIcon(dc, x, y, color); }
        else if (id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { intensityTimerIcon(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }


    // Lunar phase illustration: illuminated fraction changes as the synodic
    // cycle progresses. It is intentionally simple for low-color MIP displays.
    function drawLunarDisk(dc, x, y, r) {
        var phase = moonFraction();
        if (phase < 0.0) { phase += 1.0; }
        dc.setColor(0x303044, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, r);
        dc.setColor(0xEEEEFF, Gfx.COLOR_TRANSPARENT);
        var cosPhase = Math.cos(2.0 * Math.PI * phase);
        for (var row = -r; row <= r; row++) {
            var extent = Math.sqrt((r * r - row * row).toFloat());
            var leftEdge = x - extent.toNumber();
            var rightEdge = x + extent.toNumber();
            if (phase < 0.5) {
                var startX = x + (extent * cosPhase).toNumber();
                if (startX <= rightEdge) {
                    dc.drawLine(startX, y + row, rightEdge, y + row);
                }
            } else {
                var endX = x - (extent * cosPhase).toNumber();
                if (leftEdge <= endX) {
                    dc.drawLine(leftEdge, y + row, endX, y + row);
                }
            }
        }
        dc.setColor(0x9999BB, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawCircle(x, y, r);
    }

    // Independent, optional lunar panel with its own mobile font control.
    // Short labels are deliberately preferred to unreadably small long names.
    function drawMoonPanel(dc) {
        if (!srSetting("moonPanelV38", true)) { return; }
        // Warning appears ONLY after a qualified pressure trend.
        // Dedicated left gutter ensures it cannot collide with lunar graphic.
        if (_storm.warning()) { stormBolt(dc, 46, 147); }
        drawLunarDisk(dc, 76, 147, 12);
        dc.setColor(0x999999, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(101, 135, 101, 158);
        var mode = srSetting("moonLabelV38", 0);
        var value = mode == 0 ? moonPhaseCompactLabel() : moonPhaseExtendedLabel();
        drawSized(dc, value, 182, 135, 136, 24,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("moonFontV38", "fontWeatherV31", 19, 2),
                  fieldScale("moonFontV38", "fontWeatherV31"));
    }

    function topSlot(dc, x, id, sizeKey, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        if (id == 35) {
            var event = nextSunEvent(weather);
            if (event != null) { sunIcon(dc, x, 36, event[0]); }
            else { genericIcon(dc, x, 36, Gfx.COLOR_LT_GRAY); }
        } else {
            drawIcon(dc, x, 36, id, 0x00CCFF);
        }
        var v = d[1];
        var boxWidth = x == 134 ? 45 : 66;
        if (id == 14 || id == 15 || id == 35) {
            drawTopClock(dc, v, x, sizeKey, boxWidth);
        } else {
            drawSized(dc, v, x, 49, boxWidth, 24,
                      Gfx.COLOR_WHITE, false,
                      fieldPixels(sizeKey, "fontTopV31", 19, 2),
                      fieldScale(sizeKey, "fontTopV31"));
        }
    }

    // v3.12: Three capsules with independent safe lanes for icon, number and
    // progress. Works for any selectable metric with or without a ratio.
    // Border y=167..211; icon center y=182; text y=171..191;
    // progress track y=196..199. The separator is below at y=215.
    function capsuleTrack(dc, left, top, width, ratio, color, stepsReached, showDone) {
        if (ratio == null) { return; }
        var p = ratio.toFloat();
        if (p < 0.0) { p = 0.0; }
        if (p > 1.0) { p = 1.0; }
        var bx = left + 10;
        // Raised a little and made thicker for better visibility.
        var by = top + 29;
        var barH = 4;
        var barWidth = width - 20;
        // At 100% steps the check has its OWN 12px lane at track's right;
        // no check mark is ever painted on top of a filled progress bar.
        if (showDone) { barWidth -= 12; }
        dc.setColor(0x283144, Gfx.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(bx, by, barWidth, barH, 2);
        var fill = (p * barWidth.toFloat()).toNumber();
        if (fill >= 2) {
            dc.setColor(stepsReached ? Gfx.COLOR_GREEN : color, Gfx.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(bx, by, fill, barH, 2);
        }
        if (showDone) {
            // An outlined green DONE circle occupies x=right-20..right-10.
            // Text is in y=171..191; this icon is in y=193..203.
            dc.setColor(Gfx.COLOR_GREEN, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(1);
            var cx = left + width - 15;
            var cy = by + 2;
            dc.drawCircle(cx, cy, 5);
            dc.drawLine(cx - 3, cy, cx - 1, cy + 2);
            dc.drawLine(cx - 1, cy + 2, cx + 3, cy - 2);
        }
    }

    function capsule(dc, left, width, id, colorCode, sizeKey, monitor, weather, isCenter) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var col = srColor(colorCode);
        var top = 167;
        dc.setPenWidth(3);
        dc.setColor(col, Gfx.COLOR_TRANSPARENT);
        dc.drawRoundedRectangle(left, top, width, 44, 19);
        dc.setPenWidth(1);
        // Icon occupies x=left+6..+28, number starts at x=left+30.
        // Lowest icon point at y=192, below top border and above track.
        var iconX = left + 17;
        // Alert only recolors the existing icon; capsule border stays themed.
        drawIcon(dc, iconX, 182, id, statusIconColor(id, d[2], col));
        var value = d[1];
        var stepsReached = false;
        if (id == 2) {
            if (monitor.steps != null && monitor.stepGoal != null &&
                monitor.stepGoal > 0 && monitor.steps >= monitor.stepGoal) {
                stepsReached = true;
            }
            if (monitor.steps != null) {
                var steps = monitor.steps;
                if (isCenter && srSetting("capsuleStepsModeV39", 0) == 1 &&
                    monitor.stepGoal != null && monitor.stepGoal > 0) {
                    steps = monitor.stepGoal - steps;
                    if (steps < 0) { steps = 0; }
                }
                value = steps < 1000000 ? steps.toString() : compact(steps);
            }
        }
        var valueW = width - 35;
        var valueCenter = left + 30 + (valueW / 2).toNumber();
        drawSized(dc, value, valueCenter, 171, valueW, 20,
                  Gfx.COLOR_WHITE, onlyDigits(value),
                  fieldPixels(sizeKey, "fontRingV31", isCenter ? 23 : 21, 2),
                  fieldScale(sizeKey, "fontRingV31"));
        var showDone = stepsReached && srSetting("stepDoneV314", true);
        capsuleTrack(dc, left, top, width, d[2], col, stepsReached, showDone);
    }

    // A single thermometer glyph for both temperature warnings. The narrow
    // 14x17px icon fits between the weather divider and temperature text on
    // the 280x280 MIP display, without touching the captions underneath.
    // The entire symbol changes color rather than adding extra UI elements.
    function warningThermometer(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        // Outline, mercury column and filled round bulb.
        // Bounds x-4..x+4, y-8..y+9.
        dc.drawRoundedRectangle(x - 3, y - 8, 6, 13, 2);
        dc.fillRectangle(x - 1, y - 5, 2, 10);
        dc.fillCircle(x, y + 5, 4);
        dc.setPenWidth(1);
    }

    // Displays ONLY when weather temperature crosses a configured threshold.
    // We deliberately reuse v3.12 property IDs so current iPhone settings and
    // saved threshold preferences stay compatible across updates.
    function temperatureMarker(dc, w, x, y) {
        if (!srSetting("tempAlertsV312", true) || w == null ||
            w.temperature == null) { return; }
        var temp = w.temperature;
        var hot = srSetting("tempHotV312", 30);
        var cold = srSetting("tempColdV312", 0);
        if (temp > hot) {
            // Orange/red tone: over the hot threshold (e.g. >30C).
            warningThermometer(dc, x, y, Gfx.COLOR_ORANGE);
        } else if (temp < cold) {
            // Bright cold blue: below the cold threshold (e.g. <0C).
            warningThermometer(dc, x, y, 0x00CCFF);
        }
    }

    // Polish IMGW weather warning: a symbol per phenomenon and official
    // severity color. Local simplified vector icons are drawn in Monkey C.
    // Event categories: 1 storm, 2 wind, 3 rain, 4 snow, 5 ice,
    //                   6 heat, 7 fog, 8 cold, 9 other.
    function previewImgwName(kind) {
        if (kind == 1) { return "BURZA"; }
        if (kind == 2) { return "WIATR"; }
        if (kind == 3) { return "DESZCZ"; }
        if (kind == 4) { return "SNIEG"; }
        if (kind == 5) { return "OBLODZENIE"; }
        if (kind == 6) { return "MARZNACE"; }
        if (kind == 7) { return "UPAL"; }
        if (kind == 8) { return "MROZ"; }
        if (kind == 9) { return "PRZYMROZEK"; }
        if (kind == 10) { return "MGLA"; }
        if (kind == 11) { return "ZAMIEC"; }
        if (kind == 12) { return "ROZTOPY"; }
        return "INNE";
    }

    function imgwAlert(dc, x, y, category, level) {
        var color = Gfx.COLOR_YELLOW;
        if (level == 2) { color = Gfx.COLOR_ORANGE; }
        else if (level >= 3) { color = Gfx.COLOR_RED; }
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        if (category == 1) { // Thunderstorm
            dc.drawLine(x + 2, y - 8, x - 3, y + 1);
            dc.drawLine(x - 3, y + 1, x + 2, y + 1);
            dc.drawLine(x + 2, y + 1, x - 2, y + 8);
        } else if (category == 2) { // Wind
            dc.drawLine(x - 7, y - 4, x + 4, y - 4);
            dc.drawArc(x + 3, y - 7, 3, Gfx.ARC_CLOCKWISE, 180, 360);
            dc.drawLine(x - 8, y + 1, x + 7, y + 1);
            dc.drawLine(x - 6, y + 6, x + 3, y + 6);
        } else if (category == 3) { // Heavy rain
            dc.drawArc(x - 1, y - 3, 6, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
            dc.drawLine(x - 7, y - 2, x + 6, y - 2);
            dc.drawLine(x - 5, y + 1, x - 7, y + 6);
            dc.drawLine(x, y + 1, x - 2, y + 6);
            dc.drawLine(x + 5, y + 1, x + 3, y + 6);
        } else if (category == 4) { // Heavy snowfall: cloud + two snowflakes
            // Cloud silhouette occupies y-9..y, snowflakes y+2..y+7.
            // Deliberately different from freezing-rain drops over icy ground.
            dc.fillCircle(x - 4, y - 4, 3);
            dc.fillCircle(x + 1, y - 5, 4);
            dc.fillCircle(x + 5, y - 3, 3);
            dc.fillRectangle(x - 7, y - 4, 14, 4);
            dc.setPenWidth(1);
            dc.drawLine(x - 4, y + 2, x - 4, y + 7);
            dc.drawLine(x - 6, y + 4, x - 2, y + 4);
            dc.drawLine(x + 4, y + 2, x + 4, y + 7);
            dc.drawLine(x + 2, y + 4, x + 6, y + 4);
            dc.setPenWidth(2);
        } else if (category == 5) { // Ice
            dc.drawLine(x - 7, y, x + 7, y);
            dc.drawLine(x, y - 7, x, y + 7);
            dc.drawCircle(x, y, 3);
        } else if (category == 7) { // Heat
            dc.drawCircle(x, y, 4);
            dc.drawLine(x, y - 8, x, y - 6);
            dc.drawLine(x, y + 6, x, y + 8);
            dc.drawLine(x - 8, y, x - 6, y);
            dc.drawLine(x + 6, y, x + 8, y);
        } else if (category == 10) { // Fog
            dc.drawLine(x - 7, y - 5, x + 7, y - 5);
            dc.drawLine(x - 8, y, x + 5, y);
            dc.drawLine(x - 5, y + 5, x + 8, y + 5);
        } else if (category == 6) { // Freezing rain: two drops + ice sheet
            // Strong triangular drops; double horizontal line = frozen surface.
            // No snowflake and no cloud: unmistakable at just 18x18 pixels.
            dc.drawLine(x - 4, y - 8, x - 7, y - 2);
            dc.drawLine(x - 7, y - 2, x - 1, y - 2);
            dc.drawLine(x - 1, y - 2, x - 4, y - 8);
            dc.drawLine(x + 4, y - 8, x + 1, y - 2);
            dc.drawLine(x + 1, y - 2, x + 7, y - 2);
            dc.drawLine(x + 7, y - 2, x + 4, y - 8);
            dc.setPenWidth(1);
            dc.drawLine(x - 8, y + 4, x + 8, y + 4);
            dc.drawLine(x - 6, y + 7, x + 6, y + 7);
            dc.setPenWidth(2);
        } else if (category == 8) { // Strong frost: thermometer outline
            dc.drawRoundedRectangle(x - 3, y - 7, 6, 11, 2);
            dc.fillCircle(x, y + 5, 4);
            dc.drawLine(x - 1, y - 3, x - 1, y + 4);
        } else if (category == 9) { // Ground frost: short grass and ice
            dc.drawLine(x - 7, y + 6, x + 7, y + 6);
            dc.drawLine(x - 3, y + 6, x - 5, y - 3);
            dc.drawLine(x + 3, y + 6, x + 5, y - 3);
            dc.drawLine(x - 6, y - 6, x + 6, y + 1);
        } else if (category == 11) { // Snowdrift / blizzard
            dc.drawLine(x - 8, y - 5, x + 6, y - 5);
            dc.drawLine(x - 7, y, x + 8, y);
            dc.drawLine(x - 5, y + 5, x + 6, y + 5);
            dc.fillCircle(x - 2, y - 7, 1);
            dc.fillCircle(x + 5, y + 3, 1);
        } else if (category == 12) { // Thaw: melting ice droplet
            dc.drawLine(x - 7, y - 4, x + 7, y - 4);
            dc.drawLine(x, y - 8, x, y);
            dc.drawCircle(x, y + 4, 4);
        } else { // Unknown alert: triangle + exclamation
            dc.drawLine(x, y - 7, x + 7, y + 6);
            dc.drawLine(x + 7, y + 6, x - 7, y + 6);
            dc.drawLine(x - 7, y + 6, x, y - 7);
            dc.drawLine(x, y - 2, x, y + 2);
            dc.fillCircle(x, y + 4, 1);
        }
        dc.setPenWidth(1);
    }

    // Location source diagnostic (not an instruction to enable GPS):
    // 1=device GPS; 2=missing Activity.Info; 3=no GPS or Weather position;
    // 4=out of Poland; 5=watch-face location exception;
    // 6=approximate weather station; 7=cached GPS still valid;
    // 8=Weather location exists but its observation time is absent;
    // 9=Weather observation is too old; 10=Weather access error.
    function imgwGpsReport(code) {
        try {
            var old = Storage.getValue("imgwGpsReasonV3213");
            if (old != code) { Storage.setValue("imgwGpsReasonV3213", code); }
        } catch (e) { }
    }

    function saveImgwLocation(lat, lon, source) {
        if (lat < 49.0 || lat > 55.1 || lon < 14.0 || lon > 24.3) {
            imgwGpsReport(4); return false;
        }
        var now = Time.now().value();
        var old = Storage.getValue("imgwLocV318");
        var update = true;
        if (old != null && old instanceof Lang.Array && old.size() >= 3 &&
            (old[0] instanceof Lang.Number || old[0] instanceof Lang.Float) &&
            (old[1] instanceof Lang.Number || old[1] instanceof Lang.Float) &&
            old[2] instanceof Lang.Number) {
            var oldSource = old.size() >= 4 ? old[3] : 0;
            update = oldSource != source || now < old[2] ||
                now - old[2] >= 900 ||
                Math.abs(old[0] - lat) > 0.002 ||
                Math.abs(old[1] - lon) > 0.002;
        }
        if (update) { Storage.setValue("imgwLocV318", [lat, lon, now, source]); }
        imgwGpsReport(source == 3 ? 6 : 1);
        return true;
    }

    function captureImgwLocation(weatherData) {
        if (!srSetting("imgwOnV317", false) ||
            srSetting("imgwTestStageV3194", 0) == 0) { return; }
        try {
            var info = Activity.getActivityInfo();
            if (info != null && info.currentLocation != null) {
                var gps = info.currentLocation.toDegrees();
                if (gps != null && gps.size() >= 2) {
                    saveImgwLocation(gps[0].toFloat(), gps[1].toFloat(), 0);
                    return;
                }
            }
            // Reuse a real GPS position for at most 6 hours without silently
            // extending the time of the fix when currentLocation is null.
            var old = Storage.getValue("imgwLocV318");
            if (old != null && old instanceof Lang.Array && old.size() >= 3 &&
                (old.size() < 4 || old[3] == 0) &&
                old[2] instanceof Lang.Number) {
                var age = Time.now().value() - old[2];
                if (age >= 0 && age <= 21600) { imgwGpsReport(7); return; }
            }
            // Garmin Weather may provide a WEATHER STATION location. It is
            // approximate, not the watch's exact GPS and must be so labeled.
            // Diagnose the difference between absent coordinates, missing
            // observation time and stale data. Previously these all became G3.
            var fallbackReason = info == null ? 2 : 3;
            try {
                var wx = weatherData;
                if (wx == null) { wx = Weather.getCurrentConditions(); }
                if (wx != null && wx.observationLocationPosition != null) {
                    if (wx.observationTime == null) {
                        fallbackReason = 8;
                    } else {
                        var ageWx = Time.now().value() - wx.observationTime.value();
                        if (ageWx < 0 || ageWx > 7200) {
                            fallbackReason = 9;
                        } else {
                            var approximate = wx.observationLocationPosition.toDegrees();
                            if (approximate != null && approximate.size() >= 2) {
                                if (saveImgwLocation(approximate[0].toFloat(),
                                                     approximate[1].toFloat(), 3)) { return; }
                                fallbackReason = 4;
                            }
                        }
                    }
                }
            } catch (wxErr) { fallbackReason = 10; }
            imgwGpsReport(fallbackReason);
        } catch (e) { imgwGpsReport(5); }
    }

    // Take another look immediately when returning from a GPS activity,
    // rather than waiting for a later minute-by-minute render.
    function onShow() { captureImgwLocation(null); }

    // Results from the background must be checked before they can influence
    // the foreground. Never use status, coordinates or an icon without a valid
    // stage tag, age, types, and current GPS position.
    // Stage 11 and stage 4 share the same validators and GPS freshness check.
    // Shared single source of truth for the two full-analysis modes.
    // 0 = verified; 1 = missing/incomplete; 2 = other diagnostic stage;
    // 3 = corrupt age; 4 = expired response; 5 = invalid response status;
    // 6 = invalid county/coordinates; 7 = absent location;
    // 8 = expired observed location; 9 = position changed;
    // 10 = invalid warning fields. None of these is an all-clear.
    function imgwValidationProblem(stage, requireLiveLocation, d) {
        try {
            if (d == null || !(d instanceof Lang.Array) || d.size() < 8) {
                return 1;
            }
            if (!(d[7] instanceof Lang.Number) ||
                d[7] != (stage == 4 ? 11 : stage)) { return 2; }
            if (!(d[3] instanceof Lang.Number)) { return 3; }
            var age = Time.now().value() - d[3];
            if (age < 0 || age > 7200) { return 4; }
            if (d[6] != 1 && d[6] != 2) { return 5; }
            if (!(d[0] instanceof Lang.String) || d[0].length() != 4 ||
                !(d[4] instanceof Lang.Float || d[4] instanceof Lang.Number) ||
                !(d[5] instanceof Lang.Float || d[5] instanceof Lang.Number)) {
                return 6;
            }
            if (requireLiveLocation) {
                var loc = Storage.getValue("imgwLocV318");
                if (loc == null || !(loc instanceof Lang.Array) || loc.size() < 3 ||
                    !(loc[0] instanceof Lang.Float || loc[0] instanceof Lang.Number) ||
                    !(loc[1] instanceof Lang.Float || loc[1] instanceof Lang.Number) ||
                    !(loc[2] instanceof Lang.Number)) { return 7; }
                var observedAge = Time.now().value() - loc[2];
                if (observedAge < 0 || observedAge > 21600) { return 8; }
                var resultSource = d.size() >= 9 ? d[8] : 0;
                var observationSource = loc.size() >= 4 ? loc[3] : 0;
                if (resultSource != observationSource) { return 9; }
                // Treat movement as a reason to RECHECK the county. Never
                // display a verified all-clear for an older GPS location.
                if (Math.abs(d[4] - loc[0]) > 0.002 ||
                    Math.abs(d[5] - loc[1]) > 0.002) { return 9; }
            }
            if (d[6] == 1 &&
                (!(d[1] instanceof Lang.Number) ||
                 !(d[2] instanceof Lang.Number) ||
                 d[1] < 1 || d[1] > 3 ||
                 d[2] < 1 || d[2] > 13)) { return 10; }
            return 0;
        } catch (e) { return 11; }
    }

    function verifiedImgwResult(stage, requireLiveLocation, d) {
        return imgwValidationProblem(stage, requireLiveLocation, d) == 0 ? d : null;
    }

    // A successful ULDK lookup writes its confirmed county separately from
    // the transient GPS position. If Garmin clears Activity.currentLocation
    // after the request, accept the same verified county as LAST KNOWN ONLY.
    // Keep this proof tied to the lookup coordinates and a short TTL; it is
    // never a fresh/current GPS fix and never a general-purpose location.
    function imgwMatchesLastCounty(d) {
        try {
            if (d == null || !(d instanceof Lang.Array) || d.size() < 9 ||
                !(d[0] instanceof Lang.String) ||
                !(d[4] instanceof Lang.Number || d[4] instanceof Lang.Float) ||
                !(d[5] instanceof Lang.Number || d[5] instanceof Lang.Float)) {
                return false;
            }
            var cached = Storage.getValue("imgwLastCountyV3213");
            if (cached == null || !(cached instanceof Lang.Array) ||
                cached.size() < 4 || !(cached[0] instanceof Lang.String) ||
                !(cached[1] instanceof Lang.Number || cached[1] instanceof Lang.Float) ||
                !(cached[2] instanceof Lang.Number || cached[2] instanceof Lang.Float) ||
                !(cached[3] instanceof Lang.Number) ||
                !cached[0].equals(d[0])) { return false; }
            var age = Time.now().value() - cached[3];
            return age >= 0 && age <= 86400 &&
                Math.abs(cached[1] - d[4]) <= 0.002 &&
                Math.abs(cached[2] - d[5]) <= 0.002;
        } catch (e) { return false; }
    }

    // To keep the live diagnostic comparable to successful mode 5C, suppress
    // the *additional* live icon overlay while diagnostic text is enabled.
    // The diagnostic shows the actual alert status; disabling diagnostic
    // text restores the normal icon for a verified active warning.
    function activeImgwAlert(snapshot) {
        if (!srSetting("imgwOnV317", false) ||
            srSetting("imgwTestStageV3194", 0) != 4 ||
            srSetting("imgwDiagnosticsV3193", false) ||
            !srSetting("imgwIconsV3203", false)) { return null; }
        var source = 0;
        if (snapshot != null && snapshot instanceof Lang.Array && snapshot.size() >= 9) {
            source = snapshot[8];
        }
        // Source 2 (manual) and 1 (last county) have no live coordinates.
        var requirePosition = source == 0 || source == 3;
        var d = verifiedImgwResult(4, requirePosition, snapshot);
        if (d == null && source == 0 && imgwMatchesLastCounty(snapshot)) {
            // GPS can disappear between the background callback and redraw.
            // Downgrade this result to the LAST KNOWN county; never call it GPS.
            d = verifiedImgwResult(4, false, snapshot);
            source = 1;
        }
        if (d == null || d[6] != 1) { return null; }
        if (source == 2) {
            var manual = srSetting("imgwFallbackCountyV3213", 0);
            if (!(manual instanceof Lang.Number) ||
                !manual.format("%04d").equals(d[0])) { return null; }
        }
        if (source == 1 && !imgwMatchesLastCounty(d)) { return null; }
        return d;
    }

    // Opt-in live diagnostics. Only status=1 or 2 is a verified response from
    // BOTH GUGiK and IMGW; never mistake no data for no warnings.
    function imgwDiagnosticLine(snapshot) {
        if (!srSetting("imgwOnV317", false) ||
            !srSetting("imgwDiagnosticsV3193", false)) { return null; }
        try {
            // Display diagnostic stages before checking the GPS/response.
            // Test 0 NEVER starts GPS or a background worker.
            var stage = srSetting("imgwTestStageV3194", 0);
            // Results from another test are not current results; the stage
            // identifier travels in the eighth Bg.exit array element.
            if (stage == 0) { return "TEST 0: EKRAN OK"; }
            // Background-only test must not depend on GPS being available.
            if (stage == 2) {
                var taskData = snapshot;
                if (taskData == null || !(taskData instanceof Lang.Array) ||
                    taskData.size() < 7) { return "TEST 2: CZEKA"; }
                return taskData[6] == 11 ? "TEST 2: TLO OK" : "TEST 2: BLAD";
            }
            // Direct IMGW probes are GPS-independent and DO NOT evaluate
            // warnings. A green result means only that the GET completed.
            if (stage == 7 || stage == 8) {
                var directResult = snapshot;
                var which = stage == 7 ? "4C" : "4D";
                if (directResult == null || !(directResult instanceof Lang.Array) ||
                    directResult.size() < 7) { return "TEST " + which + ": CZEKA"; }
                if ((stage == 7 && directResult[6] == 17) ||
                    (stage == 8 && directResult[6] == 18)) {
                    return "TEST " + which + ": OK";
                }
                if (directResult[6] == 8) {
                    return "TEST " + which + ": HTTP " + directResult[1];
                }
                if (directResult[6] == 10) {
                    return "TEST " + which + ": E" + directResult[1];
                }
                return "TEST " + which + ": BLAD";
            }
            // Standalone 4A/4B diagnostics MUST NOT depend on GPS, GUGiK,
            // nor treat a successful test as an actual IMGW weather result.
            if (stage == 5 || stage == 6) {
                var probe = snapshot;
                var marker = stage == 5 ? "4A" : "4B";
                if (probe == null || !(probe instanceof Lang.Array) || probe.size() < 7) {
                    return "TEST " + marker + ": CZEKA";
                }
                var resultCode = probe[6];
                if ((stage == 5 && resultCode == 14) ||
                    (stage == 6 && resultCode == 15)) {
                    return "TEST " + marker + ": OK";
                }
                if (resultCode == 8) { return "TEST " + marker + ": HTTP " + probe[1]; }
                if (resultCode == 9) { return "TEST " + marker + ": FORMAT"; }
                if (resultCode == 13) { return "TEST " + marker + ": STARE DANE"; }
                return "TEST " + marker + ": BLAD";
            }
            // Production mode 4 now shares the same status decoder as the
            // proven full-analysis 5C test (internal stage 11). The extra
            // production check is only location freshness; a stale/missing
            // result never becomes a false all-clear.
            if (stage == 4 || stage == 11) {
                var result = snapshot;
                var prefix = stage == 4 ? "IMGW" : "TRYB 11";
                if (result == null || !(result instanceof Lang.Array) ||
                    result.size() < 8 || result[7] != (stage == 4 ? 11 : stage)) {
                    return prefix + ": CZEKA";
                }
                if (result[6] == 1 || result[6] == 2) {
                    // A last-confirmed or manual county is NOT verified as
                    // the user's current location. Mark it on-screen explicitly.
                    if (stage == 4 && result.size() >= 9 &&
                        (result[8] == 1 || result[8] == 2 || result[8] == 3)) {
                        var pfx = result[8] == 1 ? "OST" : (result[8] == 2 ? "RECZ" : "PRZYBL");
                        if (result[0] instanceof Lang.String) {
                            return prefix + ": " + pfx + " " + result[0] +
                                (result[6] == 1 ? " ALERT" : " BRAK? ");
                        }
                        return prefix + ": D6";
                    }
                    var reason = imgwValidationProblem(stage, true, snapshot);
                    // D7/D8: Garmin no longer exposes position, but ULDK
                    // has just confirmed this county at identical coords.
                    if ((reason == 7 || reason == 8) &&
                        stage == 4 && imgwMatchesLastCounty(result) &&
                        imgwValidationProblem(stage, false, result) == 0) {
                        return prefix + ": OST " + result[0] +
                            (result[6] == 1 ? " ALERT" : " BRAK?");
                    }
                    if (reason != 0) { return prefix + ": D" + reason.toString(); }
                    if (result[6] == 1) { return prefix + " " + result[0] + ": ALERT"; }
                    return prefix + " " + result[0] + ": OK 0";
                }
                if (result[6] == 10) { return prefix + ": E" + result[1]; }
                if (result[6] == 6 || result[6] == 8) {
                    return prefix + ": HTTP" + result[1];
                }
                if (result[6] == 7 || result[6] == 9) {
                    return prefix + ": FORMAT";
                }
                if (result[6] == 3 || result[6] == 4) {
                    // If a new position was captured AFTER the background
                    // job failed, await the next event instead of claiming
                    // the current GPS fix is unavailable.
                    var latest = Storage.getValue("imgwLocV318");
                    if (latest != null && latest instanceof Lang.Array &&
                        latest.size() >= 3 && latest[2] instanceof Lang.Number &&
                        result[3] instanceof Lang.Number && latest[2] > result[3]) {
                        return prefix + ": PONOW";
                    }
                    return result[6] == 3 ? prefix + ": BRAK GPS" :
                        prefix + ": GPS STARY";
                }
                return prefix + ": BLAD";
            }
            // Independent diagnostic probes; 13 uses a fixed county only
            // for testing and is never treated as live device location.
            if (stage == 9 || stage == 10 || stage == 12 || stage == 13) {
                var probe = snapshot;
                if (probe == null || !(probe instanceof Lang.Array) ||
                    probe.size() < 8 || probe[7] != stage) {
                    return "TRYB " + stage + ": CZEKA";
                }
                if (probe[6] == 19 || probe[6] == 20 || probe[6] == 21) {
                    return "TRYB " + stage + ": OK";
                }
                if (probe[6] == 1) { return "TRYB " + stage + ": ALERT"; }
                if (probe[6] == 2) { return "TRYB " + stage + ": OK 0"; }
                if (probe[6] == 10) {
                    return "TRYB " + stage + ": E" + probe[1];
                }
                if (probe[6] == 8 || probe[6] == 6) {
                    return "TRYB " + stage + ": HTTP" + probe[1];
                }
                if (probe[6] == 7 || probe[6] == 9) {
                    return "TRYB " + stage + ": FORMAT";
                }
                return "TRYB " + stage + ": BLAD";
            }
            var loc = Storage.getValue("imgwLocV318");
            if (loc == null || !(loc instanceof Lang.Array) || loc.size() < 3) {
                return "TEST " + stage + ": BRAK GPS";
            }
            var locAge = Time.now().value() - loc[2];
            if (locAge < 0 || locAge > 21600) { return "TEST " + stage + ": GPS STARY"; }
            if (stage == 1) { return "TEST 1: GPS OK"; }
            var data = snapshot;
            if (data == null || !(data instanceof Lang.Array) || data.size() < 7) {
                return "TEST " + stage + ": CZEKA";
            }
            if (data.size() < 8 || data[7] != stage) {
                return "TEST " + stage + ": CZEKA";
            }
            var status = data[6];
            if (stage == 3) {
                if (status == 12) { return "GUGIK " + data[0] + ": OK"; }
                if (status == 6) { return "GUGIK: HTTP " + data[1]; }
                if (status == 7) { return "GUGIK: FORMAT"; }
                return "GUGIK: BLAD";
            }
            var age = Time.now().value() - data[3];
            if (age < 0 || age > 7200) { return "IMGW: WYGASLO"; }

            if (status == 16) {
                // County is known; actual warnings will arrive next cycle.
                return "IMGW " + data[0] + ": CZEKA";
            }
            if (status == 10) {
                // Exact local exception checkpoint, not a guess about HTTP.
                return "IMGW: KROK " + data[1];
            }
            // Old results from tests 2, 3, 4A, 4B are never IMGW errors.
            if (status == 11 || status == 12 || status == 14 || status == 15) {
                return "IMGW: CZEKA";
            }
            if (status == 3) { return "IMGW: BRAK GPS"; }
            if (status == 4) { return "IMGW: GPS STARY"; }
            if (status == 5) { return "IMGW: POZA PL"; }
            if (status == 13) { return "IMGW: STARE DANE"; }
            if (status == 6) { return "GUGIK: HTTP " + data[1]; }
            if (status == 8) { return "IMGW: HTTP " + data[1]; }
            if (status == 7 || status == 9) { return "IMGW: FORMAT API"; }
            return "IMGW: BLAD";
        } catch (e) { return "IMGW: BLAD DANYCH"; }
    }

    // Dedicated 43px weather area. Same visual composition as the reference:
    // pictogram LEFT, large temperature RIGHT, short condition BELOW.
    // Weather zone Y=207..249, deliberately independent from the rings
    // and footer. The icon changes with the actual Garmin weather condition.
    // Weather is composed like the reference: large dynamic icon LEFT,
    // divider, large temperature RIGHT, condition directly underneath.
    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var isTemp = (id == 16 || id == 18);
        var hasThermometer = false;
        if (isTemp && srSetting("tempAlertsV312", true) && weather != null &&
            weather.temperature != null) {
            var hot = srSetting("tempHotV312", 30);
            var cold = srSetting("tempColdV312", 0);
            hasThermometer = weather.temperature > hot || weather.temperature < cold;
        }
        // Fetch the background result ONCE per frame, reusing the same
        // snapshot for the diagnostic and optional icon. Previous versions
        // performed several storage deserializations during every redraw.
        var imgwSnapshot = null;
        if (isTemp && srSetting("imgwOnV317", false)) {
            try { imgwSnapshot = Storage.getValue("imgwResultV318"); }
            catch (e) { }
        }
        var previewKind = srSetting("imgwIconPreviewV3214", 0);
        var iconPreview = isTemp && previewKind instanceof Lang.Number &&
                          previewKind >= 1 && previewKind <= 13;
        var imgw = isTemp ? activeImgwAlert(imgwSnapshot) : null;
        if (iconPreview) {
            var previewLevel = srSetting("imgwIconPreviewLevelV3214", 1);
            if (!(previewLevel instanceof Lang.Number) || previewLevel < 1 ||
                previewLevel > 3) { previewLevel = 1; }
            imgw = ["TEST", previewLevel, previewKind];
        }
        var hasImgw = (imgw != null) && isTemp;
        if (id == 16) {
            weatherSymbol(dc, 74, 235, weather);
        } else {
            drawIcon(dc, 74, 235, id, 0x00CCFF);
        }
        // Two independent warning slots to the left of the actual temperature.
        // Both appear simultaneously; numeric field always stays to their right.
        if (hasThermometer) { temperatureMarker(dc, weather, 124, 224); }
        if (hasImgw) {
            try { imgwAlert(dc, hasThermometer ? 144 : 124, 224, imgw[2], imgw[1]); }
            catch (e) { }
        }
        var textX = 174;
        var textWidth = 105;
        if (hasImgw && hasThermometer) {
            textX = 198;
            textWidth = 78;
        } else if (hasImgw || hasThermometer) {
            textX = 183;
            textWidth = 91;
        }
        drawSized(dc, d[1], textX, 215, textWidth, 22,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("sizeWeatherValueV37", "fontWeatherV31", 27, 2),
                  fieldScale("sizeWeatherValueV37", "fontWeatherV31"));
        // Optional second temperature in the existing label lane, without
        // shrinking the main number or colliding with two warning icons.
        // When off, the original weather description is unchanged.
        var lowerLabel = id == 16 ? conditionText(weather) : d[0];
        var lowerColor = id == 16 ? Gfx.COLOR_WHITE : Gfx.COLOR_LT_GRAY;
        if (isTemp && srSetting("showFeelsLikeV319", false) && weather != null &&
            weather.feelsLikeTemperature != null) {
            lowerLabel = "ODCZ. " + weather.feelsLikeTemperature.format("%.0f") + "°C";
            lowerColor = Gfx.COLOR_WHITE;
        }
        // In test mode use the label lane for live IMGW pipeline status.
        // A successful download with zero warnings is shown as OK 0.
        var diag = isTemp ? imgwDiagnosticLine(imgwSnapshot) : null;
        // A county selected by the user is already explicit in Connect IQ.
        // Do not overwrite "ODCZ." / weather condition with county and ALERT.
        // The warning itself is shown only by its pictogram. Diagnostics
        // remain opt-in and are intentionally allowed to use this label lane.
        if (diag != null) {
            lowerLabel = diag;
            lowerColor = Gfx.COLOR_YELLOW;
            if (diag.find(": OK") != null || diag.find(": ALERT") != null ||
                diag.find("EKRAN OK") != null || diag.find("GPS OK") != null ||
                diag.find("TLO OK") != null) {
                lowerColor = Gfx.COLOR_GREEN;
            }
        }
        // Preview is DRAW ONLY. Always label it TEST, even if diagnostics
        // are enabled; it never represents a real meteorological warning.
        if (iconPreview) {
            diag = null;
            lowerLabel = "TEST: " + previewImgwName(previewKind);
            lowerColor = Gfx.COLOR_YELLOW;
        }
        if (diag != null) {
            // Fixed-size native font: avoid extra scalable-font allocations.
            // Show current free RAM in KiB next to the diagnostic stage.
            var mem = "?";
            try {
                mem = ((System.getSystemStats().freeMemory / 1024).toNumber()).toString();
            } catch (e) { }
            var shortStatus = "T" + srSetting("imgwTestStageV3194", 0).toString() + " R" + mem + "K";
            if (diag.find("BRAK GPS") != null || diag.find("GPS STARY") != null) {
                shortStatus = "T" + srSetting("imgwTestStageV3194", 0).toString() + " GPS? R" + mem + "K";
                if (srSetting("imgwTestStageV3194", 0) == 4) {
                    try {
                        var gpsDetail = Storage.getValue("imgwGpsReasonV3213");
                        if (gpsDetail instanceof Lang.Number) {
                            shortStatus = "T4 GPS? G" + gpsDetail.toString();
                        }
                    } catch (e) { }
                }
            }
            else if (diag.find("CZEKA") != null) { shortStatus = "T" + srSetting("imgwTestStageV3194", 0).toString() + " CZEKA R" + mem + "K"; }
            else if (diag.find("OK") != null) { shortStatus = "T" + srSetting("imgwTestStageV3194", 0).toString() + " OK R" + mem + "K"; }
            else if (diag.find("BLAD") != null) { shortStatus = "T" + srSetting("imgwTestStageV3194", 0).toString() + " BLAD R" + mem + "K"; }
            // v3.19.7: never hide network/format errors behind generic T3 RnnK.
            // A 4-digit county is shown only if GUGiK returned a valid TERYT code.
            var dStage = srSetting("imgwTestStageV3194", 0);
            if (dStage == 3 || dStage == 4) {
                var response = null;
                response = imgwSnapshot;
                if (dStage == 4 && response != null && response instanceof Lang.Array &&
                    response.size() >= 9 && (response[8] == 1 || response[8] == 2 ||
                     response[8] == 3) &&
                    (response[6] == 1 || response[6] == 2)) {
                    shortStatus = response[8] == 1 ? "T4 O" : (response[8] == 2 ? "T4 M" : "T4 P");
                    shortStatus = shortStatus + response[0].toString() +
                        (response[6] == 1 ? "!" : "?");
                } else if (dStage == 4 && response != null &&
                    response instanceof Lang.Array && response.size() >= 7 &&
                    response[6] == 10) {
                    shortStatus = "T4 E" + response[1].toString();
                } else if (diag.find("HTTP") != null && response != null &&
                    response instanceof Lang.Array && response.size() >= 7 &&
                    response[1] != null) {
                    shortStatus = "T" + dStage.toString() + " HTTP" + response[1].toString();
                } else if (diag.find("FORMAT") != null) {
                    // Small, explicit parser reason; never show success.
                    // E.g. T3 F5 = unexpected GUGiK response status line.
                    shortStatus = "T" + dStage.toString() + " FORMAT";
                    if (dStage == 3 && response != null &&
                        response instanceof Lang.Array && response.size() >= 7 &&
                        response[1] != null && response[1] != 0) {
                        var reason = response[1].toString();
                        // Hxx.xx is the leading Unicode codepoints of the actual ULDK
                        // header. Status is never treated as success.
                        shortStatus = "T3 " + (reason.find("H") == 0 || reason.find("F5-") == 0 ? reason : "F" + reason);
                    }
                } else if (dStage == 3 && diag.find(": OK") != null &&
                           response != null && response instanceof Lang.Array &&
                           response.size() >= 7 && response[0] != null) {
                    shortStatus = "T3 " + response[0].toString() + " OK";
                } else if (dStage == 4 && diag.find(": OST ") != null &&
                           response != null && response instanceof Lang.Array &&
                           response.size() >= 7 && response[0] != null) {
                    shortStatus = "T4 O" + response[0].toString() +
                        (response[6] == 1 ? "!" : "?");
                } else if (dStage == 4 && response != null &&
                           response instanceof Lang.Array && response.size() >= 7 &&
                           response[6] == 16 && response[0] != null) {
                    shortStatus = "T4 POW " + response[0].toString();
                } else if (dStage == 4 && diag.find(": ALERT") != null &&
                           response != null && response instanceof Lang.Array &&
                           response.size() >= 7 && response[0] != null) {
                    shortStatus = "T4 ALERT " + response[0].toString();
                } else if (dStage == 4 && diag.find(": OK 0") != null &&
                           response != null && response instanceof Lang.Array &&
                           response.size() >= 7 && response[0] != null) {
                    shortStatus = "T4 OK0 " + response[0].toString();
                } else if (dStage == 4 && diag.find(": D") != null) {
                    var dCode = diag.find(": D");
                    shortStatus = "T4 " + diag.substring(dCode + 2, diag.length());
                } else if (dStage == 4 && diag.find("PONOW") != null) {
                    shortStatus = "T4 PONOW";
                } else if (dStage == 4 && diag.find(": HTTP") != null) {
                    shortStatus = "T4 HTTP";
                } else if (dStage == 4 && diag.find("STARE DANE") != null) {
                    shortStatus = "T4 STARE";
                } else if (dStage == 4 && diag.find("FORMAT") != null) {
                    shortStatus = "T4 FORMAT";
                } else if (diag.find("BLAD") != null) {
                    shortStatus = "T" + dStage.toString() + " BLAD";
                }
            }
            // New standalone transport probes: never report T4 OK or ALERT.
            // The code 4A/4B is shown exactly to make testing unambiguous.
            if (dStage == 5 || dStage == 6) {
                var pfx = dStage == 5 ? "T4A" : "T4B";
                shortStatus = pfx + " R" + mem + "K";
                if (diag.find("CZEKA") != null) { shortStatus = pfx + " CZEKA R" + mem + "K"; }
                else if (diag.find(": OK") != null) { shortStatus = pfx + " OK R" + mem + "K"; }
                else if (diag.find("HTTP") != null) {
                    var probeResult = imgwSnapshot;
                    if (probeResult != null && probeResult instanceof Lang.Array &&
                        probeResult.size() >= 7) {
                        shortStatus = pfx + " HTTP" + probeResult[1].toString();
                    } else { shortStatus = pfx + " HTTP"; }
                }
                else if (diag.find("FORMAT") != null) { shortStatus = pfx + " FORMAT"; }
                else if (diag.find("STARE") != null) { shortStatus = pfx + " STARE"; }
                else if (diag.find("BLAD") != null) { shortStatus = pfx + " BLAD"; }
            }
            if (dStage == 7 || dStage == 8) {
                var pfx = dStage == 7 ? "T4C" : "T4D";
                shortStatus = pfx + " R" + mem + "K";
                if (diag.find("CZEKA") != null) {
                    shortStatus = pfx + " CZEKA";
                } else if (diag.find(": OK") != null) {
                    shortStatus = pfx + " OK R" + mem + "K";
                } else if (diag.find("HTTP") != null) {
                    var directHttpResult = imgwSnapshot;
                    if (directHttpResult != null && directHttpResult instanceof Lang.Array && directHttpResult.size() >= 7) {
                        shortStatus = pfx + " HTTP" + directHttpResult[1].toString();
                    } else { shortStatus = pfx + " HTTP"; }
                } else if (diag.find(": E") != null) {
                    var directExceptionResult = imgwSnapshot;
                    if (directExceptionResult != null && directExceptionResult instanceof Lang.Array && directExceptionResult.size() >= 7) {
                        shortStatus = pfx + " E" + directExceptionResult[1].toString();
                    } else { shortStatus = pfx + " BLAD"; }
                } else {
                    shortStatus = pfx + " BLAD";
                }
            }
            if (dStage >= 9 && dStage <= 13) {
                var code = dStage.toString();
                shortStatus = "T" + code + " CZEKA";
                if (diag.find(": OK 0") != null) { shortStatus = "T" + code + " OK0"; }
                else if (diag.find(": OK") != null) { shortStatus = "T" + code + " OK"; }
                else if (diag.find(": ALERT") != null) { shortStatus = "T" + code + " ALERT"; }
                else if (diag.find(": E") != null) {
                    var ex = imgwSnapshot;
                    if (ex != null && ex instanceof Lang.Array && ex.size() >= 8) {
                        shortStatus = "T" + code + " E" + ex[1].toString();
                    }
                }
                else if (diag.find(": HTTP") != null) {
                    var http = imgwSnapshot;
                    if (http != null && http instanceof Lang.Array && http.size() >= 8) {
                        shortStatus = "T" + code + " HTTP" + http[1].toString();
                    }
                }
                else if (diag.find("FORMAT") != null) { shortStatus = "T" + code + " FORMAT"; }
            }
            var diagnosticColor = lowerColor;
            if (diag.find("CZEKA") != null || diag.find("BLAD") != null ||
                diag.find(": E") != null || diag.find("SIEC") != null || diag.find("BRAK") != null ||
                diag.find("HTTP") != null || diag.find("FORMAT") != null ||
                diag.find("NIEWAZNE") != null ||
                diag.find(": D") != null ||
                diag.find("PONOW") != null ||
                diag.find("CZEKA") != null) {
                diagnosticColor = Gfx.COLOR_RED;
            }
            dc.setColor(diagnosticColor, Gfx.COLOR_TRANSPARENT);
            dc.drawText(174, 235, Gfx.FONT_XTINY, shortStatus,
                        Gfx.TEXT_JUSTIFY_CENTER);
        } else {
            drawSized(dc, lowerLabel, 174, 234, 105, 16,
                      lowerColor, false,
                      fieldPixels("sizeWeatherLabelV37", "fontWeatherV31", 17, 2),
                      fieldScale("sizeWeatherLabelV37", "fontWeatherV31"));
        }
    }

    // Battery footer resides inside the circle at Y=251..267 and cannot
    // touch the outer progress ring. All contents stay in a 76px box.
    // Battery is separate from the outer ring and weather description.
    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 117, 261, id,
                 statusIconColor(id, d[2], Gfx.COLOR_GREEN));
        drawSized(dc, d[1], 165, 251, 60, 20,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("sizeFooterV37", "fontWeatherV31", 22, 2),
                  fieldScale("sizeFooterV37", "fontWeatherV31"));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = readField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 131;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function onUpdate(dc) {
        // One-way low-memory fallback avoids repeated vector font allocations.
        // Never use this flag to interpret IMGW status or suppress warnings.
        if (!_lowMemory) {
            try {
                if (System.getSystemStats().freeMemory < 18000) {
                    _lowMemory = true;
                    _fontCache = {};
                    _fontCacheCount = 0;
                }
            } catch (e) { }
        }
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var clock = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND", "PN", "WT", "SR", "CZ", "PT", "SB"];
        var months = ["STY", "LUT", "MAR", "KWI", "MAJ", "CZE",
                      "LIP", "SIE", "WRZ", "PAZ", "LIS", "GRU"];
        var monitor = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }
        captureImgwLocation(w);

        outerProgressRing(dc, monitor, w, clock);
        topSlot(dc, 73, srSetting("slotTop1V3", 14), "sizeTopLeftV37", monitor, w);
        topSlot(dc, 134, srSetting("slotTop2V3", 34), "sizeTopMidV37", monitor, w);
        topSlot(dc, 195, srSetting("slotTop3V3", 15), "sizeTopRightV37", monitor, w);
        topDividers(dc);
        rule(dc, 76);

        drawClock(dc, clock);
        drawDate(dc, days[date.day_of_week - 1],
                 date.day.toString() + " " + months[date.month - 1]);
        rule(dc, 130);

        drawMoonPanel(dc);
        rule(dc, 163);

        capsule(dc, 32, 64, srSetting("slotRing1V3", 1),
                srSetting("colorRing1V3", 0), "sizeRingLeftV37", monitor, w, false);
        capsule(dc, 99, 83, srSetting("slotRing2V3", 2),
                srSetting("colorRing2V3", 2), "sizeRingMidV37", monitor, w, true);
        capsule(dc, 185, 64, srSetting("slotRing3V3", 3),
                srSetting("colorRing3V3", 6), "sizeRingRightV37", monitor, w, false);
        rule(dc, 215);

        try {
            drawWeather(dc, monitor, w);
        } catch (e) {
            // Weather/IMGW UI must never take down clock, date, or other fields.
            // Fail closed: do not show an OK indicator if display fails.
            try {
                dc.setColor(Gfx.COLOR_RED, Gfx.COLOR_TRANSPARENT);
                dc.drawText(174, 234, Gfx.FONT_XTINY, "IMGW UI ERR", Gfx.TEXT_JUSTIFY_CENTER);
            } catch (displayError) { }

        }
        weatherDivider(dc);
        rule(dc, 250);
        drawBattery(dc, monitor, w);

        if (!srSetting("moonPanelV38", true) && _storm.warning()) { stormBolt(dc, 46, 147); }
    }

    
}
