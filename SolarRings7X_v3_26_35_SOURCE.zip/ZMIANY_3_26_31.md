# Solar Rings 7X 3.26.31 — Open-Meteo + wspólny geokoder + bateria

Baza: działająca 3.26.30. Wizualny układ zegara, fazy księżyca, linie, paski, trzy sloty ikon oraz warstwa Garmin Weather i OWM zostały zachowane.

## Nowy trzeci dostawca
- Wybór w Connect IQ: 0 Garmin Weather, 1 OpenWeatherMap, 2 Open-Meteo.
- Open-Meteo `https://api.open-meteo.com/v1/forecast` bez klucza dla osobistego niekomercyjnego testu. Domyślny automatyczny dobór modeli `best_match`.
- Aktualne warunki: temperatura, odczuwalna, wilgotność, wiatr, porywy, kod WMO, widzialność, UV, ciśnienie, zachmurzenie; wschód i zachód słońca.
- Prognoza 15-minutowa (do 12 rekordów) oraz godzinowa awaryjna. Godzinowe prawdopodobieństwo opadów i UV dołączane w tym samym zapytaniu, bez osobnego wybudzenia.
- Dzienna temperatura min/max oraz osobne zapytanie AQI (European AQI); jedno żądanie HTTP na wybudzenie.
- Logika trzech kolorowanych ikon, aktualne/forecast, podkreślenie turkusowe i ustawienia progów są współdzielone z OWM.
- Mapowanie WMO wszystkich standardowych kodów 0,1,2,3,45,48,51,53,55,56,57,61,63,65,66,67,71,73,75,77,80,81,82,85,86,95,96,99. Brak rozpoznanego kodu nie tworzy fałszywego ostrzeżenia. 96/99 to grad towarzyszący burzy; gołoledź to tylko ocena ryzyka.
- W trybie Open-Meteo (jak w OWM) bieżąca pogoda jest wynikiem modelu, a NIE potwierdzoną obserwacją ani oficjalnym ostrzeżeniem IMGW.

## Lokalizacja i bateria
- Geokoder Photon służy wszystkim trzem dostawcom przy lokalizacji nieobecnej na liście offline, z cache, globalnym limitem 30 min, jednym wspólnym zadaniem czasowym. Zapytanie o nazwę nie wyprzedza bieżących alertów; może zająć termin prognozy.
- GPS jest tylko odczytywany, nie aktywowany. Pogoda z wybranego dostawcy jest pobierana dla współrzędnych zegarka/Garmin Weather, nie dla odległej nazwy stacji.
- Bateria wyświetla rzeczywiste dziesiąte części procenta, jeśli firmware je udostępnia. Gdy podaje całkowite procenty, pozostaje np. 99%, bez sztucznego 99,0%.
- Zachowano czasowe wstrzymanie zadań pogodowych na zaplanowany sen i powrót po pobudce.
- Limit zapytań bez zmian (maksymalnie 700 zapytań na dobę w tej instalacji), obecny harmonogram OWM/Open-Meteo i zabezpieczenia przerw w Bluetooth.

## Znane ograniczenia i testy
- Testy skryptowe sprawdzają umowy kodu i ustawienia, ale nie wykonują Monkey C. Kompilację, RAM i zużycie baterii trzeba potwierdzić na Fenixie.
- Dziesiętne baterii zależą od firmware i nie są gwarantowane.
- 15-minutowy krok prognozy nie oznacza nowej publikacji modelu co 15 minut, a część pól w Polsce może być interpolowana.
- Jakość prognoz i alertów nie jest gwarantowana: burze/grad/marznące opady zależą od dostępnego modelu.
- Darmowy Open-Meteo dotyczy zastosowań niekomercyjnych; przed płatną dystrybucją Premium wymagana jest odrębna weryfikacja warunków licencji i odpowiednia subskrypcja/rozwiązanie.
