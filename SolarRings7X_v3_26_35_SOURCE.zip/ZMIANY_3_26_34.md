# Solar Rings 7X v3.26.34 — poprawka obciążenia pamięci na starcie

**Wejście:** pełne źródła v3.26.33 i rzeczywisty `CIQ_LOG` z 19.11.2026 (Store-Version 98), błąd `Out Of Memory Error`, Fenix 7X Pro, firmware 27.18, Connect IQ 6.0.4.

**Ograniczenie diagnozy:** adresy PC ze stosu nie dają się jednoznacznie przypisać do źródeł bez `debug.xml` z dokładnie tej kompilacji. Poprawka jest uzasadnioną redukcją presji pamięciowej, nie potwierdzoną eliminacją pierwotnego źródła OOM.

1. Pierwszy pełny rysunek po upgrade z zachowanym OWM/Open-Meteo nie wykonuje pobrania i migracji lokalizacji zewnętrznej (`_srExternalBootstrapDeferred`). Było to obsłużone tylko na zmianę ustawień; obecnie również na start.
2. Zapewniono wczesne przejście na bezpieczne natywne fonty Garmin, gdy na początku odrysowania pozostaje mniej niż 60 KB wolnej pamięci. Poprzedni próg 18 KB nie pozostawiał rezerwy.
3. Pamięć trwałego cache ustawień: limit 64 zamiast 96 rekordów. Pozostałe odczyty nadal działają z Properties, bez zmiany ustawień użytkownika.
4. Pamięć cache fontów wariantowych: limit 8 zamiast 20; kolejne niedostępne warianty korzystają z natywnego fallbacku zamiast bez końca generować niezapamiętane fonty.
5. W `clockBoldFont()` nie są już zatrzymywane testowe rozmiary; wybrany font wciąż jest przechowywany w `_clockFitCache`.
6. Workflow kopiuje wygenerowane przez SDK pliki `*.debug.xml` (jeżeli są obecne) do artefaktu; pakiet `.iq` nadal jest generowany dla ewentualnego odzyskania symboli.

**Bez zmian:** źródła pogodowe Garmin/OWM/Open-Meteo, best_match, progi, ostrzeżenia i ich ikony, AQI, harmonogram odświeżania, bateria, geometria kapsuł. Jedynie przy bardzo małym budżecie pamięci wygląd czcionek może przejść na natywne Garmin.

**Walidacja:** testy źródłowe Python, spójność wersji, XML i archiwa. Brak lokalnego Garmin Connect IQ SDK; kompilację oraz test na urządzeniu trzeba wykonać w udostępnionym workflow. W razie kolejnej awarii potrzebne są wynikowe `.iq`/`.debug.xml` i nowy `CIQ_LOG` do symbolizacji adresów.
