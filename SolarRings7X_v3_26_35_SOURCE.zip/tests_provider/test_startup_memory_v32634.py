"""Static regression contracts for OOM-risk mitigation. No Garmin simulator."""
import unittest
from pathlib import Path
R = Path(__file__).resolve().parents[1]
F = (R/'source/SolarRings7X.mc').read_text(encoding='utf-8')
C = (R/'source/Config.mc').read_text(encoding='utf-8')
N = (R/'source/SolarOpenNetwork.mc').read_text(encoding='utf-8')
class StartupMemoryContract(unittest.TestCase):
    def test_first_frame_with_persisted_external_provider_defers_location(self):
        init = F.split('function initialize() {\n        WatchFace.initialize();',1)[1].split('function markSettingsChanged()',1)[0]
        self.assertIn('_srExternalBootstrapDeferred = _srSelectedProvider != 0;', init)
        self.assertIn('if (_srExternalBootstrapDeferred) {', F)
        self.assertIn('return null;',F)
    def test_native_fallback_has_reserve(self):
        self.assertIn('if (stats.freeMemory < 60000)', F)
        self.assertIn('if (_lowMemory) {\n            fitScaled(',F)
    def test_font_cache_limits_and_probe_cleanup(self):
        self.assertIn('if (_fontCacheCount >= 8) { return null; }',F)
        clock = F.split('function clockBoldFont(pixels)',1)[1].split('function drawClock(',1)[0]
        self.assertNotIn('_fontCache[key]', clock)
        self.assertIn('Gfx.getVectorFont', clock)
        self.assertIn('_clockFitCache = font == null ? null',F)
    def test_properties_and_weather_unchanged(self):
        self.assertIn('_srSettingCacheSize < 64',C)
        self.assertIn('srOwmVisibleCurrent()',F)
        self.assertIn('q["minutely_15"] = fields;',N)
        self.assertIn('return _interval == 5 ? 10 * 60',N)
        self.assertIn('rule(dc, 164);',F)
        self.assertIn('var top = 171;',F)
