"""Stroke-aware regression of three metric capsules for 280px MIP face."""
from pathlib import Path
import re
import unittest
S=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()

class CapsuleClearanceTests(unittest.TestCase):
    def test_stroke_clearance_between_rules_and_capsules(self):
        face=S.split('function capsule(dc,',1)[1].split('function warningThermometer',1)[0]
        top=int(re.search(r'var top = (\d+);',face).group(1))
        dims=re.search(r'dc\.drawRoundedRectangle\(left, top, width, (\d+), (\d+)\)',face)
        self.assertIsNotNone(dims)
        height,radius=map(int,dims.groups())
        self.assertIn('dc.setPenWidth(3);',face)
        self.assertEqual((top,height,radius),(171,39,18))
        # 3px stroke can extend ~2px from path; require visible black lanes.
        self.assertGreaterEqual(top-2-164,5)
        self.assertGreaterEqual(215-(top+height+2),3)
        self.assertIn('rule(dc, 164);',S)
        self.assertIn('rule(dc, 215);',S)
    def test_all_three_use_same_capsule_function(self):
        self.assertEqual(len(re.findall(r'^        capsule\(dc, (32|99|185),',S,re.M)),3)
        self.assertIn('drawIcon(dc, iconX, 184, id,',S)
        self.assertIn('drawSized(dc, value, valueCenter, 175, valueW, 19,',S)
    def test_track_and_both_steps_modes_inside(self):
        block=S.split('function capsuleTrack(dc,',1)[1].split('function warningThermometer',1)[0]
        self.assertIn('var by = top + 27;',block)
        self.assertIn('var barH = 4;',block)
        # 198..202 track doesn't touch lower border at 210.
        self.assertGreaterEqual(210-(171+27+4),8)
        self.assertIn('drawSized(dc, doneText, dualCenter, 174, dualWidth, 16,',block)
        self.assertIn('drawSized(dc, remainingText, dualCenter, 192, dualWidth, 15,',block)

if __name__=='__main__': unittest.main()
