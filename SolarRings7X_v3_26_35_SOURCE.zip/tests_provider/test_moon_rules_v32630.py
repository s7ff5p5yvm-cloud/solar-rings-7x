"""Layout regression: full-width lunar band rules with safe clearances."""
from pathlib import Path
import unittest
S=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
class LunarRulesTests(unittest.TestCase):
    def test_full_width_both_rules(self):
        rule=S.split('function rule(dc, y) {',1)[1].split('function topDividers',1)[0]
        self.assertIn('dc.drawLine(28, y, 252, y);',rule)
        self.assertNotIn('dc.drawLine(99, y, 242, y)',rule)
        self.assertNotIn('y == 163',rule)
        self.assertIn('rule(dc, 134);',S)
        self.assertIn('rule(dc, 164);',S)
    def test_moon_vertical_spacing_and_capsules(self):
        self.assertIn('drawLunarDisk(dc, 52, 149, 12);',S)
        top,bottom=149-12,149+12
        self.assertGreaterEqual(top-134,3)
        self.assertGreaterEqual(164-bottom,3)
        # Date and city fields have a gap from the horizontal bars.
        self.assertGreaterEqual(134-(97+34),3)
        self.assertGreaterEqual(164-(136+25),3)
        # Stroke-aware clearance: outline moved down; lower rule stays visible.
        self.assertGreaterEqual(171-2-164,5)
        self.assertGreaterEqual(215-(171+39+2),3)
        self.assertIn('var top = 171;',S)
    def test_no_extra_sensors_or_requests(self):
        rule=S.split('function rule(dc, y) {',1)[1].split('function topDividers',1)[0]
        for word in ('getValue','getCurrent','makeWebRequest','requestUpdate'):
            self.assertNotIn(word,rule)
if __name__=='__main__': unittest.main()
