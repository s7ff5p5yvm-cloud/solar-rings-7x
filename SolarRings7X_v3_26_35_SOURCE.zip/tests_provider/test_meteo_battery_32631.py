from pathlib import Path
import unittest
R = Path(__file__).resolve().parents[1]
class MeteoBatteryAudit(unittest.TestCase):
    def test_precise_battery_only_when_reported(self):
        s = (R/'source/FieldData.mc').read_text()
        self.assertIn('function srBatteryPercentText(x)', s)
        self.assertIn('srBatteryPercentText(x)',s)
        self.assertNotIn('numeric(x) + "%", x.toFloat() / 100.0',s)
        self.assertIn('var tenths = (v * 10.0 + 0.00001).toNumber()',s)
    def test_15minute_api_hourly_supplement_without_extra_call(self):
        s=(R/'source/SolarOpenNetwork.mc').read_text()
        self.assertIn('q["minutely_15"] = fields;',s)
        self.assertIn('q["hourly"] = "precipitation_probability,uv_index";',s)
        self.assertIn('function meteoHourlyAt(hourly, key, stamp)',s)
        self.assertIn('meteoHourlyAt(hourlyExtra, "precipitation_probability", stamp)',s)
        self.assertNotIn('q["minutely_15"] = "weather_code,temperature_2m,precipitation_probability',s)
    def test_photon_cannot_starve_with_5min_wake_slots(self):
        s=(R/'source/SolarOpenNetwork.mc').read_text()
        self.assertIn('var geoDue = geoDeadline();',s)
        self.assertIn('kindIs("forecast") && _now - geoDue >= 15 * 60',s)
        self.assertIn('if (!Sys.getDeviceSettings().phoneConnected)',s)
    def test_three_providers_and_alert_codes(self):
        c=(R/'source/SolarMeteoCodes.mc').read_text()
        for code in (45,48,51,53,55,56,57,61,63,65,66,67,71,73,75,77,80,81,82,85,86,95,96,99):
            self.assertIn('wmo == '+str(code), c)
        s=(R/'resources/settings/settings.xml').read_text()
        self.assertIn('<listEntry value="2">@Strings.sr_source_meteo</listEntry>',s)
if __name__=='__main__': unittest.main()
