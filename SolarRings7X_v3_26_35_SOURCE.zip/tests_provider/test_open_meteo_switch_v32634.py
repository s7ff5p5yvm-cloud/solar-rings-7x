"""Static regression contracts for deferred Open-Meteo initialization. No SDK runtime."""
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[1]
F=(R/'source/SolarRings7X.mc').read_text()
D=(R/'source/SolarOpenData.mc').read_text()
N=(R/'source/SolarOpenNetwork.mc').read_text()
W=(R/'source/SolarOpenWarnings.mc').read_text()
class SwitchSafety(unittest.TestCase):
 def test_no_heavy_migration_in_foreground(self):
  init=F.split('function getInitialView()',1)[1].split('function onStart(',1)[0]
  changed=F.split('function refreshChangedSettings()',1)[1].split('function rebuildWeatherWarnings()',1)[0]
  self.assertNotIn('srOwmProviderChanged()',init)
  self.assertNotIn('srOwmProviderChanged()',changed)
  self.assertIn('Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)))',changed)
  start=N.split('function start()',1)[1].split('function reserveQuota()',1)[0] if False else N.split('function start()',1)[1].split('function onReceive(',1)[0]
  self.assertIn('srOwmProviderChanged();',start)
 def test_provider_id_not_boolean_and_first_frame_deferred(self):
  self.assertIn('_srSelectedProvider = srSetting("srProviderV326", 0)',F)
  self.assertIn('var modeChanged = mode != _srSelectedProvider;',F)
  self.assertIn('_srExternalBootstrapDeferred = mode != 0;',F)
  self.assertIn('if (_srExternalBootstrapDeferred) {',F)
  self.assertIn('try { srOwmUpdateLocation(locationMetadata); }',F)
 def test_no_cross_provider_data(self):
  for f in ('srOwmCurrentSnapshot','srOwmForecastSnapshot','srOwmDailySnapshot'):
   sect=D.split('function '+f+'(',1)[1].split('function ',1)[0]
   self.assertIn('srOLastModeV326',sect)
  self.assertIn('srOLastModeV326',W)
  self.assertIn('status(-309);',N)
 def test_look_and_weather_policy_unchanged(self):
  self.assertIn('var top = 171;',F)
  self.assertIn('rule(dc, 164);',F)
  self.assertIn('q["minutely_15"] = fields;',N)
  self.assertIn('"https://api.open-meteo.com/v1/forecast"',N)
  self.assertIn('return _interval == 5 ? 10 * 60',N)
