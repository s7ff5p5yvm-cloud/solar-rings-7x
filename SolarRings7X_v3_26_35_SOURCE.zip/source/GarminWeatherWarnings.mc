using Toybox.Weather as Weather;
using Toybox.Time as Time;
using Toybox.System as System;

// Read-only Garmin Weather rule engine. This deliberately does NOT call
// network, GPS, background tasks or persistent storage.
// The watch controls when weather is updated; our interval only throttles
// re-evaluation of the already-cached values.
class GarminWeatherWarnings {
    var _lastCheck;
    // Packed warning tags: kind 1..11, +16 forecast-only,
    // +32 fresh observation and forecast, +64 old observation (45..90m),
    // +96 old observation and forecast. No new weather reads or timers.
    // A phenomenon always occupies a single alert-center slot.
    var _lastKinds;
    // Only alive while a warning evaluation is running. No native Properties
    // calls while Garmin hourly forecast objects are in memory.
    var _ruleValues;

    function initialize() {
        _lastCheck = 0;
        _lastKinds = [];
        _ruleValues = null;
    }

    // Fetch settings before asking Garmin for its entire hourly forecast.
    // Keeping the hourly array resident and calling Properties.getValue()
    // caused the verified OOM stack in v3.26.33/34 (Config.mc line 37).
    function prepareRules() {
        _ruleValues = [
            srSetting("srPrecipModeV3263", 1),
            srSetting("gwIceChanceV332", 50),
            srSetting("gwRainOnV332", true),
            srSetting("gwSnowOnV332", true),
            srSetting("gwWindOnV332", true),
            srSetting("gwWindV332", 10),
            srSetting("gwFogOnV332", true),
            srSetting("gwFogMetersV332", 500),
            srSetting("gwUvOnV332", false),
            srSetting("gwUvV332", 7),
            srSetting("gwStormOnV332", true),
            srSetting("gwRainChanceV332", 30),
            srSetting("gwSnowChanceV332", 40),
            srSetting("gwRainHeavyV332", false),
            srSetting("gwSnowHeavyV332", false),
            srSetting("gwFreezeOnV332", true),
            srSetting("gwHailOnV332", true),
            srSetting("gwAirOnV332", true),
            srSetting("gwIceOnV332", true),
            srSetting("gwIceTempV332", 1),
            srSetting("gwForecastV332", true),
            srSetting("gwHorizonV332", 1)
        ];
    }

    function rule(index) {
        return _ruleValues[index];
    }

    // Alert positions read the prepared results without re-evaluation.
    function cachedWarnings() {
        return _lastKinds;
    }

    // Kinds: 1 wind, 2 rain, 3 snow, 4 thunder, 5 freezing rain,
    // 6 fog, 7 ice risk, 8 hail, 9 UV, 10 atmospheric dust/smoke,
    // 11 mixed winter precipitation, 13 explicit extreme wind event.
    // A list keeps ALL active warnings.
    // Forecast data stays cached: only the displayed icon rotates every 5 s.
    function warning(current) {
        // Run demonstration modes before the master weather-alert switch.
        // A TEST is always visible, even with real alerts OFF and without
        // current Garmin weather data or hourly forecast availability.
        var preview = srSetting("gwPreviewV332", 0);
        if (preview > 0 && preview <= 9) {
            _lastKinds = [preview];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 10) {
            // RED thunderstorm NOW and CYAN forecast wind: two adjacent cells.
            _lastKinds = [4, 17];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 11) {
            // Same thunderstorm now and later: ONE red icon with cyan bar.
            _lastKinds = [];
            addAlert(_lastKinds, 20); // forecast storm
            addAlert(_lastKinds, 4);  // combined into tag 36
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 12) {
            // One forecast-only thunderstorm: BLUE icon never rotates.
            _lastKinds = [20];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 13) {
            // Two current + one forecast condition, all visible simultaneously.
            _lastKinds = [5, 4, 17];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 14) {
            // Three distinct phenomena, each NOW + FORECAST: 3 icons.
            // All warning slots are reserved for provider alerts.
            _lastKinds = [36, 34, 33]; // thunder, rain, wind
            _lastCheck = 0;
            return rotatingWarning();
        }
        // The main switch controls only real-weather warning evaluation.
        // TEST 1..14 above deliberately bypasses it.
        if (!srSetting("gwOnV332", true)) {
            reset();
            return 0;
        }
        var now = Time.now().value();
        var interval = srSetting("gwIntervalV332", 15);
        if (interval < 5) { interval = 5; }
        if (interval > 60) { interval = 60; }
        if (_lastCheck == 0 || now < _lastCheck ||
            now - _lastCheck >= interval * 60) {
            _lastCheck = now;
            _lastKinds = [];
            try {
                prepareRules();
                _lastKinds = evaluate(current, now);
            } catch (e) {
                _lastKinds = [];
            }
            // Release small temporary snapshot immediately after the forecast
            // data is gone. No permanent heap growth every refresh.
            _ruleValues = null;
        }
        return rotatingWarning();
    }

    // Same rules and throttle as warning(), but expose every active icon.
    // Returns a read-only-by-convention short cached list; caller must not
    // mutate it. Same phenomenon merges both sources into one tag.
    function allWarnings(current) {
        warning(current);
        return _lastKinds;
    }

    // Does NOT touch Garmin Weather or settings. Safe for onPartialUpdate().
    // Every five seconds it selects the next warning in priority order.
    function rotatingWarning() {
        var count = _lastKinds.size();
        if (count == 0) { return 0; }
        if (count == 1) { return _lastKinds[0]; }
        var phase = (Time.now().value() / 5).toNumber();
        return _lastKinds[phase % count];
    }

    function reset() {
        _lastCheck = 0;
        _lastKinds = [];
        _ruleValues = null;
    }

    function priority(tag) {
        var k = baseKind(tag);
        if (k == 13) { return 110; } // tornado/hurricane/squall category
        if (k == 5) { return 90; } // freezing rain
        if (k == 8) { return 85; } // hail
        if (k == 11) { return 82; } // sleet/wintry mix
        if (k == 4) { return 80; } // thunder
        if (k == 7) { return 75; } // black ice risk
        if (k == 1) { return 65; } // high wind
        if (k == 3) { return 60; } // snow
        if (k == 2) { return 55; } // rain
        if (k == 6) { return 50; } // fog
        if (k == 10) { return 55; } // dust/smoke/ash/sandstorm
        if (k == 9) { return 40; } // UV
        return 0;
    }

    function baseKind(tag) {
        if (tag > 96) { return tag - 96; }
        if (tag > 64) { return tag - 64; }
        if (tag > 32) { return tag - 32; }
        if (tag > 16) { return tag - 16; }
        return tag;
    }

    function isNow(tag) {
        return tag <= 16 || tag > 32;
    }

    function isFuture(tag) {
        return (tag > 16 && tag <= 48) || tag > 96;
    }

    function isOld(tag) {
        return (tag > 64 && tag <= 80) || tag > 96;
    }

    // Merge same weather phenomenon without dropping forecast information.
    // Fresh observation wins over a stale observation for a single kind.
    function addAlert(items, tag) {
        var kind = baseKind(tag);
        for (var i = 0; i < items.size(); i++) {
            if (baseKind(items[i]) == kind) {
                var before = items[i];
                var hasNow = isNow(before) || isNow(tag);
                var hasFuture = isFuture(before) || isFuture(tag);
                var fresh = (isNow(before) && !isOld(before)) ||
                            (isNow(tag) && !isOld(tag));
                if (hasNow && hasFuture) {
                    items[i] = fresh ? kind + 32 : kind + 96;
                } else if (hasNow) {
                    items[i] = fresh ? kind : kind + 64;
                } else { items[i] = kind + 16; }
                return items;
            }
        }
        items.add(tag);
        return items;
    }

    function mergeAlerts(items, other, isForecast) {
        for (var i = 0; i < other.size(); i++) {
            var tag = other[i];
            if (isForecast) { tag += 16; }
            addAlert(items, tag);
        }
        return items;
    }

    // Priority only controls the cycle order; never drops other hazards.
    function orderAlerts(items) {
        for (var i = 0; i < items.size(); i++) {
            for (var j = i + 1; j < items.size(); j++) {
                if (priority(items[j]) > priority(items[i])) {
                    var tmp = items[i];
                    items[i] = items[j];
                    items[j] = tmp;
                }
            }
        }
        return items;
    }

    // Pop is the chance of ANY precipitation, not the probability of a
    // particular thunderstorm, lightning strike, hail or freezing rain.
    // For predicted RAIN/SNOW/MIX ONLY, apply the same rule to Garmin and OWM:
    //   * code + valid 0..100%: use selected sensitivity threshold;
    //   * code + null: keep forecast as "probability unavailable";
    //   * code + invalid probability: reject, never confuse it with null;
    //   * probability without a recognized phenomenon: no alert.
    // Current observations are NEVER filtered by a forecast probability.
    function validMeasure(v, low, high) {
        return v != null && (v instanceof Toybox.Lang.Number ||
            v instanceof Toybox.Lang.Long || v instanceof Toybox.Lang.Float ||
            v instanceof Toybox.Lang.Double) && v >= low && v <= high;
    }

    function forecastChanceMatches(chance, customMinimum) {
        if (chance == null) { return true; }
        if (!validMeasure(chance, 0, 100)) { return false; }
        var sensitivity = rule(0);
        if (sensitivity == 0) { return true; }  // Czuly: any valid %
        if (sensitivity == 1) { return chance >= 40; } // Standard: 40%
        // Custom: keep the user's existing Garmin rain/snow thresholds.
        if (!validMeasure(customMinimum, 0, 100)) { return false; }
        return chance >= customMinimum;
    }

    // Separate estimated ice-risk threshold. Unlike rain/snow sensitivity,
    // this setting always means precisely what the Connect IQ menu says.
    // Unknown probability is not zero. Invalid input is rejected.
    function iceChanceMatches(chance) {
        if (chance == null) { return true; }
        if (!validMeasure(chance, 0, 100)) { return false; }
        var iceMinimum = rule(1);
        return validMeasure(iceMinimum, 0, 100) && chance >= iceMinimum;
    }

    // One weather condition is classified into action-oriented categories.
    // Ordinary clouds, fair weather and UNKNOWN are intentionally ignored.
    // Mixed precipitation is represented by ONE icon, not rain + snow clones.
    // No allocation of weather arrays other than the short warning list.
    function classify(c, chance, wind, temp, visibility, uv, isForecast) {
        if (c == null && wind == null && uv == null && visibility == null) {
            return [];
        }
        var k = [];
        var rainEnabled = rule(2);
        var snowEnabled = rule(3);
        // When an explicit severe wind phenomenon exists, its separate icon
        // supersedes the ordinary numerical wind icon (avoid duplicates).
        var extremeWind = c == Weather.CONDITION_SQUALL ||
                          c == Weather.CONDITION_TORNADO ||
                          c == Weather.CONDITION_HURRICANE ||
                          c == Weather.CONDITION_TROPICAL_STORM;
        // The user-selected threshold is absolute for the ordinary wind icon.
        // Never turn a category code into a claimed numeric threshold hit.
        if (rule(4) && !extremeWind &&
            (validMeasure(wind, 0, 120) && wind >= rule(5) ||
             (wind == null && c == Weather.CONDITION_WINDY))) {
            addAlert(k, 1);
        }
        // All 54 official Garmin condition values are known to the display
        // classifier. Unknown future constants do not trigger vague alerts.
        if (c != null && srGarminDisplayGroup(c) < 0) { c = null; }
        if (c == null) {
            // A valid low-visibility reading is actionable even without code.
            if (rule(6) &&
                validMeasure(visibility, 0, 100000) &&
                visibility <= rule(7)) {
                addAlert(k, 6);
            }
            if (rule(8) && validMeasure(uv, 0, 30) &&
                uv >= rule(9)) { addAlert(k, 9); }
            return k;
        }

        // Explicit extreme weather codes are a SEPARATE phenomenon from
        // the measured speed threshold; do not manufacture a 15 m/s reading.
        if (rule(4) && extremeWind) {
            addAlert(k, 13);
        }

        // A general precipitation probability is NOT a probability of thunder.
        // Explicit storm = current or forecast; chance-of-storm = forecast only.
        var stormUncertain = c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS;
        if (rule(10) &&
            (c == Weather.CONDITION_THUNDERSTORMS ||
             c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
             (isForecast && stormUncertain))) { addAlert(k, 4); }

        // Mixed precipitation (wintry mix, rain/snow, sleet, ice/snow) is
        // distinct from freezing rain. Forecast probability is filtered separately.
        var mixedUncertain = c == Weather.CONDITION_CHANCE_OF_RAIN_SNOW ||
                             c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW;
        var mixedExplicit = c == Weather.CONDITION_WINTRY_MIX ||
                            c == Weather.CONDITION_LIGHT_RAIN_SNOW ||
                            c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
                            c == Weather.CONDITION_RAIN_SNOW ||
                            c == Weather.CONDITION_SLEET ||
                            c == Weather.CONDITION_ICE_SNOW;
        if ((rainEnabled || snowEnabled) && (mixedExplicit || mixedUncertain)) {
            var mixedLimit = 100;
            if (rainEnabled) { mixedLimit = rule(11); }
            if (snowEnabled) {
                var snowLimit = rule(12);
                if (snowLimit < mixedLimit) { mixedLimit = snowLimit; }
            }
            // "Only heavy" mode skips light/mild mixed precipitation.
            var heavyMixed = c == Weather.CONDITION_HEAVY_RAIN_SNOW;
            var mixAllowed = (rainEnabled && !rule(13)) ||
                             (snowEnabled && !rule(14)) ||
                             heavyMixed;
            if (mixAllowed && (mixedExplicit || isForecast) &&
                (!isForecast || forecastChanceMatches(chance, mixedLimit))) {
                addAlert(k, 11);
            }
        }

        if (rule(15) &&
            c == Weather.CONDITION_FREEZING_RAIN) { addAlert(k, 5); }
        if (rule(16) &&
            c == Weather.CONDITION_HAIL) { addAlert(k, 8); }

        var rainUncertain = c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
                            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN;
        var rainExplicit = c == Weather.CONDITION_RAIN ||
                           c == Weather.CONDITION_LIGHT_RAIN ||
                           c == Weather.CONDITION_HEAVY_RAIN ||
                           c == Weather.CONDITION_SHOWERS ||
                           c == Weather.CONDITION_LIGHT_SHOWERS ||
                           c == Weather.CONDITION_HEAVY_SHOWERS ||
                           c == Weather.CONDITION_SCATTERED_SHOWERS ||
                           c == Weather.CONDITION_DRIZZLE;
        if (rainEnabled && (rainExplicit || rainUncertain)) {
            var heavyRain = c == Weather.CONDITION_HEAVY_RAIN ||
                            c == Weather.CONDITION_HEAVY_SHOWERS;
            if ((!rule(13) || heavyRain) &&
                (rainExplicit || isForecast) &&
                (!isForecast || forecastChanceMatches(chance,
                  rule(11)))) {
                addAlert(k, 2);
            }
        }
        var snowUncertain = c == Weather.CONDITION_CHANCE_OF_SNOW ||
                            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW;
        var snowExplicit = c == Weather.CONDITION_SNOW ||
                           c == Weather.CONDITION_LIGHT_SNOW ||
                           c == Weather.CONDITION_HEAVY_SNOW ||
                           c == Weather.CONDITION_FLURRIES;
        if (snowEnabled && (snowExplicit || snowUncertain)) {
            if ((!rule(14) ||
                  c == Weather.CONDITION_HEAVY_SNOW) &&
                (snowExplicit || isForecast) &&
                (!isForecast || forecastChanceMatches(chance,
                  rule(12)))) {
                addAlert(k, 3);
            }
        }

        // FOG is explicit even if numerical visibility is slightly inconsistent.
        // Other weather types only qualify by validated measured visibility.
        // The shared glyph means fog OR dangerous reduced visibility.
        var lowVisibility = validMeasure(visibility, 0, 100000) &&
                            visibility <= rule(7);
        if (rule(6) &&
            (lowVisibility || c == Weather.CONDITION_FOG)) {
            addAlert(k, 6);
        }
        // Atmospheric hazards distinct from meteorological fog. No claim
        // that these are road-visibility measurements or an air quality index.
        if (rule(17) &&
            (c == Weather.CONDITION_DUST || c == Weather.CONDITION_SMOKE ||
             c == Weather.CONDITION_SAND || c == Weather.CONDITION_SANDSTORM ||
             c == Weather.CONDITION_VOLCANIC_ASH)) {
            addAlert(k, 10);
        }
        if (rule(18)) {
            var icyWeather = c == Weather.CONDITION_ICE;
            var wetWeather = rainExplicit || snowExplicit || mixedExplicit;
            // This is an estimate of SLIPPERY CONDITIONS, not a road sensor.
            // A freezing-rain alert already describes the hazard: no duplicate.
            if (icyWeather || (wetWeather && validMeasure(temp, -100, 80) &&
                 temp <= rule(19) &&
                 (!isForecast || iceChanceMatches(chance)))) {
                addAlert(k, 7);
            } else if (isForecast && mixedUncertain &&
                       validMeasure(temp, -100, 80) &&
                       temp <= rule(19) &&
                       iceChanceMatches(chance)) {
                addAlert(k, 7);
            }
        }
        if (rule(8) && validMeasure(uv, 0, 30) &&
            uv >= rule(9)) { addAlert(k, 9); }
        return k;
    }

    function evaluate(current, now) {
        var matched = [];
        if (current != null && current.observationTime != null) {
            var secondsOld = now - current.observationTime.value();
            // <=45 min: fresh RED. 45..90 min: faded observation glyph.
            // >90 min: no "now" claim. Forecast source stays independent.
            if (secondsOld >= -300 && secondsOld <= 5400) {
                var observed = classify(current.condition,
                        current.precipitationChance, current.windSpeed,
                        current.temperature, current.visibility,
                        current.uvIndex, false);
                if (secondsOld <= 2700) {
                    matched = mergeAlerts(matched, observed, false);
                } else {
                    for (var o = 0; o < observed.size(); o++) {
                        addAlert(matched, observed[o] + 64);
                    }
                }
            }
        }
        if (!rule(20)) { return orderAlerts(matched); }
        // On constrained watch-face heaps a Garmin hourly Array can create
        // a large temporary native allocation. Do not risk killing the clock:
        // retain the observed alerts, and skip forecast if reserve is too low.
        // 72 KiB is a conservative minimum before the native array allocation.
        var freeBeforeHourly = 0;
        try { freeBeforeHourly = System.getSystemStats().freeMemory; } catch (e) { }
        if (freeBeforeHourly < 73728) { return orderAlerts(matched); }
        var hourly = null;
        try { hourly = Weather.getHourlyForecast(); } catch (e) { return orderAlerts(matched); }
        if (hourly == null) { return orderAlerts(matched); }
        // HourlyForecast.forecastTime is the time a prediction is valid.
        // Include at most the current hour and only the requested future
        // horizon. A forecast for the current hour is still a prediction
        // (CYAN), never an observed condition (RED).
        // Never retain the array on the watch face between refresh checks.
        var horizon = rule(21);
        if (horizon < 1) { horizon = 1; }
        if (horizon > 3) { horizon = 3; }
        var count = hourly.size();
        if (count > 8) { count = 8; }
        for (var i = 0; i < count; i++) {
            try {
                var h = hourly[i];
                if (h == null || h.forecastTime == null) { continue; }
                var dt = h.forecastTime.value() - now;
                if (dt <= -3600 || dt > horizon * 3600) { continue; }
                matched = mergeAlerts(matched, classify(h.condition,
                        h.precipitationChance, h.windSpeed, h.temperature,
                        null, h.uvIndex, true), true);
            } catch (e) { /* Broken record must not crash the watch face. */ }
        }
        return orderAlerts(matched);
    }
}
