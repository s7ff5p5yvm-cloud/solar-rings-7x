// Open-Meteo WMO interpretation codes (0,1,2,3,45,48,51-57,61-67,
// 71-77,80-82,85-86,95-99) mapped to known Solar Rings weather IDs.
// Never compare these numeric codes directly with OWM's IDs.
// 233 is an INTERNAL thunderstorm-with-hail marker, not an OWM code.
function srMeteoToWeatherId(wmo) {
    if (!srOwmNumber(wmo)) { return null; }
    if (wmo == 0) { return 800; }
    if (wmo == 1) { return 801; }
    if (wmo == 2) { return 803; }
    if (wmo == 3) { return 804; }
    if (wmo == 45 || wmo == 48) { return 741; }
    if (wmo == 51) { return 300; }
    if (wmo == 53) { return 301; }
    if (wmo == 55) { return 302; }
    if (wmo == 56 || wmo == 57 || wmo == 66 || wmo == 67) { return 511; }
    if (wmo == 61) { return 500; }
    if (wmo == 63) { return 501; }
    if (wmo == 65) { return 502; }
    if (wmo == 71) { return 600; }
    if (wmo == 73) { return 601; }
    if (wmo == 75) { return 602; }
    if (wmo == 77) { return 620; }
    if (wmo == 80) { return 520; }
    if (wmo == 81) { return 521; }
    if (wmo == 82) { return 522; }
    if (wmo == 85) { return 620; }
    if (wmo == 86) { return 622; }
    if (wmo == 95) { return 211; }
    if (wmo == 96 || wmo == 99) { return 233; }
    return null;  // Unknown: fail closed rather than show misleading alerts.
}
