using Toybox.Weather as Weather;

// Official Garmin Condition enum 0..53, all values explicitly covered.
// Group is for the general weather pictogram and description only.
// Warning thresholds and alert switches are evaluated separately.
// 0 clear, 1 partly cloudy, 2 cloudy, 3 rain, 4 snow, 5 mixed,
// 6 thunder, 7 fog/haze, 8 wind, 9 extreme weather, 10 dust/smoke,
// 11 ice/freezing rain, 12 hail; -1 unknown.
function srGarminDisplayGroup(code) {
    if (code == null) { return -1; }
    if (code == Weather.CONDITION_UNKNOWN) { return -1; }
    if (code == Weather.CONDITION_CLEAR ||
        code == Weather.CONDITION_MOSTLY_CLEAR ||
        code == Weather.CONDITION_FAIR) { return 0; }
    if (code == Weather.CONDITION_PARTLY_CLOUDY ||
        code == Weather.CONDITION_PARTLY_CLEAR ||
        code == Weather.CONDITION_THIN_CLOUDS) { return 1; }
    if (code == Weather.CONDITION_MOSTLY_CLOUDY ||
        code == Weather.CONDITION_CLOUDY) { return 2; }
    if (code == Weather.CONDITION_RAIN ||
        code == Weather.CONDITION_SCATTERED_SHOWERS ||
        code == Weather.CONDITION_UNKNOWN_PRECIPITATION ||
        code == Weather.CONDITION_LIGHT_RAIN ||
        code == Weather.CONDITION_HEAVY_RAIN ||
        code == Weather.CONDITION_LIGHT_SHOWERS ||
        code == Weather.CONDITION_SHOWERS ||
        code == Weather.CONDITION_HEAVY_SHOWERS ||
        code == Weather.CONDITION_CHANCE_OF_SHOWERS ||
        code == Weather.CONDITION_DRIZZLE ||
        code == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN) { return 3; }
    if (code == Weather.CONDITION_SNOW ||
        code == Weather.CONDITION_LIGHT_SNOW ||
        code == Weather.CONDITION_HEAVY_SNOW ||
        code == Weather.CONDITION_CHANCE_OF_SNOW ||
        code == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
        code == Weather.CONDITION_FLURRIES) { return 4; }
    if (code == Weather.CONDITION_WINTRY_MIX ||
        code == Weather.CONDITION_LIGHT_RAIN_SNOW ||
        code == Weather.CONDITION_HEAVY_RAIN_SNOW ||
        code == Weather.CONDITION_RAIN_SNOW ||
        code == Weather.CONDITION_CHANCE_OF_RAIN_SNOW ||
        code == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW ||
        code == Weather.CONDITION_SLEET ||
        code == Weather.CONDITION_ICE_SNOW) { return 5; }
    if (code == Weather.CONDITION_THUNDERSTORMS ||
        code == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
        code == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS) { return 6; }
    if (code == Weather.CONDITION_FOG ||
        code == Weather.CONDITION_HAZY ||
        code == Weather.CONDITION_MIST ||
        code == Weather.CONDITION_HAZE) { return 7; }
    if (code == Weather.CONDITION_WINDY ||
        code == Weather.CONDITION_SQUALL) { return 8; }
    if (code == Weather.CONDITION_TORNADO ||
        code == Weather.CONDITION_HURRICANE ||
        code == Weather.CONDITION_TROPICAL_STORM) { return 9; }
    if (code == Weather.CONDITION_DUST ||
        code == Weather.CONDITION_SMOKE ||
        code == Weather.CONDITION_SAND ||
        code == Weather.CONDITION_SANDSTORM ||
        code == Weather.CONDITION_VOLCANIC_ASH) { return 10; }
    if (code == Weather.CONDITION_ICE ||
        code == Weather.CONDITION_FREEZING_RAIN) { return 11; }
    if (code == Weather.CONDITION_HAIL) { return 12; }
    return -1; // Unknown/future Garmin values: neutral, no invented alert.
}

// Complete OWM standard weather IDs. Return null for unsupported IDs.
// Weather presentation maps to Garmin symbols; warnings use RAW OWM IDs.
function srOwmMappedCondition(code) {
    if (!srOwmNumber(code)) { return null; }
    if (code == 233) { return Weather.CONDITION_THUNDERSTORMS; }
    if (code == 200 || code == 201 || code == 202 || code == 210 || code == 211 || code == 212 || code == 221 || code == 230 || code == 231 || code == 232) { return Weather.CONDITION_THUNDERSTORMS; }
    if (code == 300 || code == 301 || code == 302 || code == 310 || code == 311 || code == 312 || code == 313 || code == 314 || code == 321) { return Weather.CONDITION_DRIZZLE; }
    if (code == 500) { return Weather.CONDITION_LIGHT_RAIN; }
    if (code == 501) { return Weather.CONDITION_RAIN; }
    if (code == 502 || code == 503 || code == 504) { return Weather.CONDITION_HEAVY_RAIN; }
    if (code == 511) { return Weather.CONDITION_FREEZING_RAIN; }
    if (code == 520) { return Weather.CONDITION_LIGHT_SHOWERS; }
    if (code == 521 || code == 531) { return Weather.CONDITION_SHOWERS; }
    if (code == 522) { return Weather.CONDITION_HEAVY_SHOWERS; }
    if (code == 600) { return Weather.CONDITION_LIGHT_SNOW; }
    if (code == 601 || code == 621) { return Weather.CONDITION_SNOW; }
    if (code == 602 || code == 622) { return Weather.CONDITION_HEAVY_SNOW; }
    if (code == 611 || code == 612 || code == 613) { return Weather.CONDITION_SLEET; }
    if (code == 615) { return Weather.CONDITION_LIGHT_RAIN_SNOW; }
    if (code == 616) { return Weather.CONDITION_RAIN_SNOW; }
    if (code == 620) { return Weather.CONDITION_FLURRIES; }
    if (code == 701) { return Weather.CONDITION_MIST; }
    if (code == 711) { return Weather.CONDITION_SMOKE; }
    if (code == 721) { return Weather.CONDITION_HAZE; }
    if (code == 731 || code == 761) { return Weather.CONDITION_DUST; }
    if (code == 741) { return Weather.CONDITION_FOG; }
    if (code == 751) { return Weather.CONDITION_SAND; }
    if (code == 762) { return Weather.CONDITION_VOLCANIC_ASH; }
    if (code == 771) { return Weather.CONDITION_SQUALL; }
    if (code == 781) { return Weather.CONDITION_TORNADO; }
    if (code == 800) { return Weather.CONDITION_CLEAR; }
    if (code == 801 || code == 802) { return Weather.CONDITION_PARTLY_CLOUDY; }
    if (code == 803) { return Weather.CONDITION_MOSTLY_CLOUDY; }
    if (code == 804) { return Weather.CONDITION_CLOUDY; }
    return null; // Reject undocumented IDs; never invent conditions.
}

