using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;
using Toybox.System as Sys;
using Toybox.Time as Time;

// Solar Rings 7X v3.24.29: bounded, persistent geocoding state machine.
// Single pending timer for ALL locations; no network calls in the render loop.
// Photon public endpoint: low-volume personal testing only. No GPS acquisition.
(:background)
class SolarRingsGeoService extends Sys.ServiceDelegate {
    var _requestedLat;
    var _requestedLon;
    var _openService;

    function initialize() {
        ServiceDelegate.initialize();
        _openService = null;
        _requestedLat = null;
        _requestedLon = null;
    }

    function storedNumber(key, fallback) {
        try {
            var value = App.Storage.getValue(key);
            if (value != null) { return value; }
        } catch (e) { }
        return fallback;
    }

    function saveNumber(key, value) {
        try { App.Storage.setValue(key, value); } catch (e) { }
    }

    function sameRegion(aLat, aLon, bLat, bLon) {
        return aLat < bLat + 0.025d && aLat > bLat - 0.025d &&
               aLon < bLon + 0.035d && aLon > bLon - 0.035d;
    }

    // Always use a single non-periodic Moment event; at least five minutes away.
    function armTimer(targetEpoch) {
        var now = Time.now().value();
        var delay = targetEpoch - now;
        if (delay < 5 * 60) { delay = 5 * 60; }
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(delay)));
            saveNumber("srGEventDue", now + delay);
        } catch (e) {
            saveNumber("srGEventDue", 0);
        }
    }

    function stopTimer() {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        saveNumber("srGEventDue", 0);
    }

    // Only server responses and malformed Photon content use exponential
    // backoff: 3h -> 6h -> 12h -> 24h. An unavailable phone or network
    // transport error is not a reason to accumulate 24-hour server failures.
    // A location change does not bypass an active server cooldown.
    function retryLater() {
        saveNumber("srGInFlight", 0);
        var failures = storedNumber("srGFail", 0) + 1;
        if (failures > 4) { failures = 4; }
        saveNumber("srGFail", failures);
        var hours = 3;
        if (failures == 2) { hours = 6; }
        else if (failures == 3) { hours = 12; }
        else if (failures >= 4) { hours = 24; }
        var next = Time.now().value() + hours * 60 * 60;
        saveNumber("srGNextAt", next);
        armTimer(next);
        Bg.exit(null);
    }

    // No phone means no HTTP call. Wait conservatively (one wake/hour) and
    // record the disconnect so the visible face can accelerate on reconnection.
    function retryPhoneMissing() {
        saveNumber("srGInFlight", 0);
        saveNumber("srGPhoneMissingV32624", 1);
        armTimer(Time.now().value() + 60 * 60);
        Bg.exit(null);
    }

    // Network transport errors and lost asynchronous callbacks are transient;
    // retry hourly without raising the long-lived server failure counter.
    function retryTransport() {
        saveNumber("srGInFlight", 0);
        var next = Time.now().value() + 60 * 60;
        // Never override an already-active server cooldown with a shorter one.
        var serverNext = storedNumber("srGNextAt", 0);
        if (serverNext > next) { next = serverNext; }
        armTimer(next);
        Bg.exit(null);
    }

    // Events follow Garmin's configured sleep/wake schedule rather than a
    // hard-coded clock window. Neither event represents a manual sleep toggle.
    function onSleepTime() as Void {
        try {
            var now = Time.now().value();
            App.Storage.setValue("srOSleepStateV32624", [1, now]);
            // Do not replace geocoding's timer if Garmin is the provider.
            // A wake event may override the OWM watchdog at the configured time.
            var provider = App.Properties.getValue("srProviderV326");
            if (provider != 0) {
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(2 * 3600)));
            }
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }

    function onWakeTime() as Void {
        try {
            var now = Time.now().value();
            App.Storage.setValue("srOSleepStateV32624", [0, now]);
            var provider = App.Properties.getValue("srProviderV326");
            if (provider != 0) {
                // Recover expired current weather and 15min forecasts first.
                // Keep daily/AQI cadence unchanged; one endpoint per wake.
                App.Storage.setValue("srONextCV326", 0);
                App.Storage.setValue("srONextFV326", 0);
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
            }
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }

    function onTemporalEvent() {
        // The same OS background slot serves either city geocoding for
        // Garmin mode OR OpenWeather fetches. They never run together.
        var provider = 0;
        try { provider = App.Properties.getValue("srProviderV326"); } catch (e) { }
        if (provider != 0) {
            try {
                _openService = new SolarOpenNetwork();
                _openService.runSafely();
            } catch (e) {
                // Even an exception constructing the network service must
                // not disappear before the diagnostic breadcrumbs are saved.
                try {
                    var stamp = Time.now().value();
                    App.Storage.setValue("srODGateV3269", [stamp, 91, 0, -1, -1]);
                    App.Storage.setValue("srODiagV3266", [stamp, 0, -231]);
                    Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(10 * 60)));
                } catch (e2) { }
                Bg.exit(["OWM", 0]);
            }
            return;
        }
        saveNumber("srGEventDue", 0);
        var request = null;
        try { request = App.Storage.getValue("srGRequest"); } catch (e) { }
        if (request == null || request.size() < 2 ||
            request[0] == null || request[1] == null) {
            stopTimer();
            Bg.exit(null);
            return;
        }
        _requestedLat = request[0];
        _requestedLon = request[1];
        try {
            var answer = App.Storage.getValue("srGResult");
            if (answer != null && answer.size() == 3 &&
                sameRegion(_requestedLat, _requestedLon, answer[0], answer[1])) {
                stopTimer();
                Bg.exit(null);
                return;
            }
            // Check Bluetooth BEFORE the HTTP watchdog or server cooldown.
            // A disconnect must never count as a Photon server failure.
            if (!Sys.getDeviceSettings().phoneConnected) {
                retryPhoneMissing();
                return;
            }
            // A lost async callback is a transport failure, not HTTP 429.
            if (storedNumber("srGInFlight", 0) == 1) {
                retryTransport();
                return;
            }
            if (storedNumber("srGPhoneMissingV32624", 0) == 1) {
                saveNumber("srGPhoneMissingV32624", 0);
            }
            var now = Time.now().value();
            var next = storedNumber("srGNextAt", 0);
            var fromLastRequest = storedNumber("srGLastTry", 0) + 30 * 60;
            if (fromLastRequest > next) { next = fromLastRequest; }
            if (now < next) {
                armTimer(next);
                Bg.exit(null);
                return;
            }
            // A global 30-minute network rate limit across all destinations.
            saveNumber("srGLastTry", now);
            saveNumber("srGInFlight", 1);
            // If response callback never fires, a watchdog detects this.
            armTimer(now + 3 * 60 * 60);
            var query = {
                "lat" => _requestedLat.format("%.3f"),
                "lon" => _requestedLon.format("%.3f"),
                "lang" => "pl",
                "osm_tag" => "place",
                "limit" => "1"
            };
            var options = {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            };
            Comm.makeWebRequest("https://photon.komoot.io/reverse",
                                query, options, method(:onReceive));
        } catch (e) {
            retryLater();
        }
    }

    // Explicit callback signature required by the Connect IQ 9.3 typechecker.
    // Match the full makeWebRequest() response union, even though JSON
    // should arrive as a Dictionary. Never index other response types.
    function onReceive(code as Lang.Number,
                       data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        // Negative HTTP callback status indicates a transport problem,
        // not a reply from Photon. Keep the normal rate limit but avoid the
        // growing 24-hour retry lockout during a trip without internet.
        if (code < 0) { retryTransport(); return; }
        if (code != 200 || !(data instanceof Lang.Dictionary)) { retryLater(); return; }
        var city = null;
        try {
            var features = data["features"];
            if (features != null && features.size() > 0) {
                var props = features[0]["properties"];
                if (props != null && (props["osm_key"] instanceof Lang.String && props["osm_key"].equals("place"))) {
                    city = props["name"];
                }
            }
            if (city == null || !(city instanceof String) ||
                city.length() < 2 || city.length() > 42) {
                retryLater();
                return;
            }
            city = city.toUpper();
        } catch (e) { retryLater(); return; }

        var now = Time.now().value();
        saveNumber("srGInFlight", 0);
        saveNumber("srGFail", 0);
        saveNumber("srGNextAt", now + 30 * 60);
        // Newer coordinates may have arrived while the network was busy.
        // Never clear the timer for the newer location or display stale data.
        var latest = null;
        try { latest = App.Storage.getValue("srGRequest"); } catch (e) { }
        if (latest == null || latest.size() < 2 ||
            !sameRegion(_requestedLat, _requestedLon, latest[0], latest[1])) {
            armTimer(now + 30 * 60);
            Bg.exit(null);
            return;
        }
        stopTimer();
        Bg.exit([_requestedLat, _requestedLon, city]);
    }
}
