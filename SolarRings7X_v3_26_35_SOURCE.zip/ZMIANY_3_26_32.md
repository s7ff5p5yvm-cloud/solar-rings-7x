# Solar Rings 7X v3.26.32 — poprawka nachodzących kapsuł

Baza: pełne źródła **3.26.31 z Open-Meteo, OWM, Garmin Weather, AQI, geokoderem i baterią dziesiętną**. Zmiana dotyczy wyłącznie geometrii trzech kapsuł i numeru wydania.

- Górny separator księżyca/miasta **y=164** pozostaje bez zmian.
- Trzy kapsuły (tętno, kroki, Body Battery lub inne konfigurowalne pola): obrys y=171..210 (wcześniej 167..211), wysokość 39 (wcześniej 44), zaokrąglenie 18 (wcześniej 19), grubość obrysu 3 bez zmian.
- Wolna przerwa między separatorem y=164 a obrysem wzrasta do co najmniej ~5 px po uwzględnieniu połowy grubości linii. Dolny separator y=215 nadal ma odstęp od kapsuł.
- Ikony wewnątrz kapsuł: środek y=184 zamiast 182. Liczba: y=175, wysokość pola 19. Pasek postępu: y=198..201. Tryb dwóch wartości kroków został dopasowany do nowej wysokości.
- **Bez zmian** w częstotliwości i implementacji odświeżania, źródłach pogody, ostrzeżeniach, API, cache, lokalizacji, harmonogramie snu, rysowaniu zegara, księżyca, dolnej pogody, danych i ich ustawieniach.

Kontrola Python i XML nie zastępuje kompilacji Monkey C i sprawdzenia po instalacji na ekranie zegarka.
