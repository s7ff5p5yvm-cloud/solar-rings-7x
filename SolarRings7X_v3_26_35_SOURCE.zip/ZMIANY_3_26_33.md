# Solar Rings 7X v3.26.33 — ochrona przed awarią przy zmianie na Open-Meteo

Bazą jest pełna paczka v3.26.32. Zmiany wykonane po zgłoszeniu natychmiastowego znikania tarczy po wybraniu Open-Meteo. **Nie dysponujemy Garmin `CIQ_LOG.txt` ani pełnym kodem błędu; zatem przyczyna jest hipotezą, a nie potwierdzoną diagnozą.**

1. `getInitialView` nie uruchamia już wieloetapowej migracji ustawień, kilkudziesięciu zapisów Storage ani operacji timerów. Przeniesiono ją do odpornego na błędy serwisu w tle (`runSafely`/`start`).
2. `refreshChangedSettings` resetuje wyłącznie obiekty odczytu i ostrzeżeń, przełącza timer na najbliższą dozwoloną chwilę (5 min). Pierwsza klatka po zmianie na zewnętrznego dostawcę nie wywołuje inicjalizacji lokalizacji; dopiero kolejny onUpdate aktualizuje metadane GPS / Garmin Weather.
3. Rozróżnienie trzech wartości dostawcy (0/1/2), nie tylko boolean external; poprawne czyszczenie stanu ostrzeżeń również przy 1 -> 2.
4. Wszystkie odczyty przechowywanej pogody, prognozy i AQI mają blokadę przełączenia między dostawcami aż do synchronizacji w tle. Nie mieszamy starych danych OWM i Open-Meteo.
5. Odczyt położenia i obiektów pogody jest odizolowany `try/catch`; brak pobrania powoduje puste dane, nigdy zamierzone zatrzymanie zegara. Asynchroniczna odpowiedź z poprzedniego dostawcy jest ignorowana.

**Zachowane:** Open-Meteo best_match, OWM, Garmin Weather, mapowanie zjawisk, kolorowane ostrzeżenia, brak klucza Open-Meteo, progi, 5-min okna harmonogramu / 10-min świeżość warunków w profilu, AQI, oszczędzanie baterii w porze snu, geokoder, procent baterii, geometria trzech kapsuł 3.26.32.

Testy Python zapewniają tylko kontrolę kontraktów źródłowych, XML, archiwum i workflow. **Ostateczne potwierdzenie wymaga Garmin CIQ SDK i instalacji na zegarku.** Jeśli nadal jest IQ!, potrzebny `CIQ_LOG.txt` (Connect IQ); nie zakładaj dalszych zmian w ciemno.
