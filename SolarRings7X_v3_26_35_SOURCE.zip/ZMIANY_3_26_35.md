# Solar Rings 7X v3.26.35 — naprawa z logu i mapy symboli Garmin

Weryfikacja na rzeczywistych `SolarRings7X_v32634.iq` oraz `CIQ_LOG[1](6).YML`:
- `0x10007d7c` → `Config.mc:37` (Props.getValue w srSetting)
- `0x1000a353` → `GarminWeatherWarnings.mc:420` (ustawienie horyzontu po pobraniu Weather.getHourlyForecast)
- `0x1000a182` → `GarminWeatherWarnings.warning` (evaluate)
- `0x10009e9b` → `GarminWeatherWarnings.allWarnings`
- `0x1000bfc4` → `SolarRings7X.drawAlertCenter`
- `0x10010aa7` → `SolarRings7X.onUpdate`

**Zmiana przyczyny, nie kosmetyczna redukcja cache**:
1. Wszystkie 22 parametry progów Garmin wymagane przez `evaluate` / `classify` są odczytywane przed wywołaniem `Weather.getHourlyForecast`, jako krótkotrwała tablica liczb i flag; po wywołaniu nie wykonują `Props.getValue` aż do zwolnienia tablicy prognozy.
2. Prognoza Garmin jest obliczana przed dynamicznym rysowaniem, gdy dostępna pamięć jest większa, a następnie centrum ostrzeżeń wyświetla tylko obliczoną listę.
3. Gdy wolna pamięć przed kosztownym wywołaniem prognozy wynosi mniej niż 72 KiB, prognoza godzinowa Garmin jest bezpiecznie pomijana w danym cyklu. Bieżące alerty Garmin pozostają. Pozostałe źródła nie są ograniczane.
4. Nowa diagnostyka źródłowa testuje brak Props.getValue w krytycznej ścieżce oraz niezmieniony układ grafiki.

**Ważne**: przy małej pamięci może nie pojawić się niebieska ikonka prognozy Garmin. Jest to świadome zabezpieczenie przed wyłączaniem tarczy. Nie zmieniono silnika Open-Meteo, OWM, bieżących ostrzeżeń, geometrii kapsuł, częstotliwości API ani interwału baterii.

Walidacja offline nie zastępuje uruchomienia na urządzeniu. Jeżeli OOM wystąpi nadal, potrzebny nowy plik `.iq` i log do symbolizacji adresów z tej samej wersji.
