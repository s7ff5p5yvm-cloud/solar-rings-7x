using Toybox.WatchUi as Ui;
using Toybox.Graphics as G;
using Toybox.Sensor as Sensor;
using Toybox.Activity as Activity;
using Toybox.Timer as Timer;
using Toybox.System as Sys;
using Toybox.Math as M;

class CompassScreen extends Ui.View {
    // 0 compass, 1 guidance, 2 menu, 3 saved, 4 save slot,
    // 5 manual bearing, 6 settings, 7 manual declination, 8 help
    var _page = 0;
    var _selection = 0;
    var _returnPage = 0;
    var _timer;
    var _timerActive = false;
    var _shown = false;
    var _heading = null;
    var _filtered = null;
    var _source = "BRAK";
    var _lastValid = 0;
    var _target = null; // Always TRUE north
    var _edit = 0.0; // Display-referenced desired heading
    var _decEdit = 0; // Tenths of a degree
    var _decl10 = 0;
    var _magnetic = false;
    var _mils = false;
    var _eco = false;
    var _toast = null;
    var _tickSin;
    var _tickCos;
    var _lastDrawnHeading = null;
    var _lastDrawValid = false;
    var _lastDrawSource = "";
    var _lastDrawMs = 0;

    function initialize() {
        View.initialize();
        _timer = new Timer.Timer();
        // Static angles are computed once. The rotating rose uses only
        // a single sin/cos pair per frame instead of 144+ trig calls.
        _tickSin = [];
        _tickCos = [];
        for (var angle = 0; angle < 360; angle += 10) {
            var rad = CompassMath.radians(angle);
            _tickSin.add(M.sin(rad));
            _tickCos.add(M.cos(rad));
        }
        _target = CompassStore.read("target_true", null);
        _magnetic = CompassStore.read("magnetic", false);
        _decl10 = CompassStore.read("decl10", 0);
        _mils = CompassStore.read("mils", false);
        _eco = CompassStore.read("eco", false);
    }

    function isCompassPage() { return _page == 0 || _page == 1; }

    function onShow() {
        _shown = true;
        _readHeading();
        _refreshTimer();
    }

    function onHide() {
        _shown = false;
        _stopTimer();
    }

    function _stopTimer() {
        if (_timerActive) {
            _timer.stop();
            _timerActive = false;
        }
    }

    function _refreshTimer() {
        _stopTimer();
        _lastDrawnHeading = null;
        if (_shown && isCompassPage()) {
            // Smooth ~5.5 Hz, Eco ~1.3 Hz. No GPS/network/background work.
            _timer.start(method(:_tick), _eco ? 750 : 180, true);
            _timerActive = true;
        }
        Ui.requestUpdate();
    }

    function _tick() {
        _readHeading();
        // Redraw immediately on rotation/status changes, but avoid continuously
        // repainting the entire MIP screen when the wrist is stationary.
        var now = Sys.getTimer();
        var validNow = _valid();
        var changed = false;
        if (validNow && _filtered != null) {
            if (_lastDrawnHeading == null) {
                changed = true;
            } else {
                var delta = CompassMath.shortest(_lastDrawnHeading, _filtered);
                if (delta < 0.0) { delta = -delta; }
                changed = delta >= 0.65;
            }
        }
        var mustDraw = changed || (validNow != _lastDrawValid) ||
            (_source != _lastDrawSource) || (now - _lastDrawMs >= 1400);
        if (mustDraw) {
            _lastDrawnHeading = validNow ? _filtered : null;
            _lastDrawValid = validNow;
            _lastDrawSource = _source;
            _lastDrawMs = now;
            Ui.requestUpdate();
        }
    }

    function _readHeading() {
        var reading = null;
        var source = "BRAK";
        try {
            var info = Sensor.getInfo();
            if (info != null && info.heading != null) {
                reading = info.heading * 180.0 / M.PI;
                source = "SENSOR";
            }
        } catch (e) { }

        // Fallback supplied by Garmin, not interpreted as a calibrated
        // standstill magnetometer. The UI identifies this fallback explicitly.
        if (reading == null) {
            try {
                var activityInfo = Activity.getActivityInfo();
                if (activityInfo != null && activityInfo.currentHeading != null) {
                    reading = activityInfo.currentHeading * 180.0 / M.PI;
                    source = "SYSTEM";
                }
            } catch (e) { }
        }

        if (reading != null && reading >= -360.0 && reading <= 720.0) {
            _heading = CompassMath.wrap(reading);
            if (_filtered == null) {
                _filtered = _heading;
            } else {
                // Faster, wrap-safe response. The previous 0.48 filter at
                // 350 ms gave visible lag during wrist rotations.
                var delta = CompassMath.shortest(_filtered, _heading);
                var alpha = _eco ? 0.72 : 0.85;
                _filtered = CompassMath.wrap(_filtered + delta * alpha);
            }
            _source = source;
            _lastValid = Sys.getTimer();
        } else {
            _source = "BRAK";
        }
    }

    function _valid() {
        if (_filtered == null || _source == "BRAK") { return false; }
        var age = Sys.getTimer() - _lastValid;
        return age >= 0 && age < 3500;
    }

    function _display(deg) {
        return CompassMath.toDisplay(deg, _magnetic, _decl10 / 10.0);
    }

    function _goto(page) {
        _page = page;
        _selection = 0;
        _refreshTimer();
    }

    function _rememberTarget(value) {
        _target = CompassMath.wrap(value);
        CompassStore.write("target_true", _target);
    }

    function select() {
        _toast = null;
        if (_page == 0) {
            if (_valid()) {
                _rememberTarget(_filtered);
                _goto(1);
            } else {
                _edit = 0.0;
                _goto(5);
            }
        } else if (_page == 1) {
            _goto(2);
        } else if (_page == 2) {
            _chooseMenu();
        } else if (_page == 3) {
            var s = CompassStore.slot(_selection);
            if (s != null) {
                _rememberTarget(s);
                _goto(1);
            } else {
                _toast = "PUSTY SLOT";
                Ui.requestUpdate();
            }
        } else if (_page == 4) {
            if (_target != null && CompassStore.write(CompassStore.slotKey(_selection), _target)) {
                _toast = "ZAPISANO #" + (_selection + 1).toString();
                _goto(1);
            } else {
                _toast = "BRAK CELU / PAMIECI";
                _goto(2);
            }
        } else if (_page == 5) {
            _rememberTarget(CompassMath.toTrue(_edit, _magnetic, _decl10 / 10.0));
            _goto(1);
        } else if (_page == 6) {
            _chooseSettings();
        } else if (_page == 7) {
            _decl10 = _decEdit;
            CompassStore.write("decl10", _decl10);
            _goto(6);
        }
    }

    function _chooseMenu() {
        if (_selection == 0) {
            if (_target == null && _valid()) { _rememberTarget(_filtered); }
            if (_target == null) {
                _edit = 0.0;
                _goto(5);
            } else {
                _goto(4);
            }
        } else if (_selection == 1) {
            _edit = _target != null ? _display(_target) : (_valid() ? _display(_filtered) : 0.0);
            _goto(5);
        } else if (_selection == 2) {
            _goto(3);
        } else if (_selection == 3) {
            _target = null;
            CompassStore.write("target_true", null);
            _goto(0);
        } else if (_selection == 4) {
            _goto(6);
        } else if (_selection == 5) {
            _goto(8);
        } else {
            _goto(_target != null ? 1 : 0);
        }
    }

    function _chooseSettings() {
        if (_selection == 0) {
            _magnetic = !_magnetic;
            CompassStore.write("magnetic", _magnetic);
        } else if (_selection == 1) {
            _decEdit = _decl10;
            _goto(7);
            return;
        } else if (_selection == 2) {
            _mils = !_mils;
            CompassStore.write("mils", _mils);
        } else if (_selection == 3) {
            _eco = !_eco;
            CompassStore.write("eco", _eco);
            _refreshTimer();
            return;
        } else {
            _goto(2);
            return;
        }
        Ui.requestUpdate();
    }

    function up() { _navigate(-1); }
    function down() { _navigate(1); }

    function _navigate(direction) {
        _toast = null;
        if (_page == 0) {
            _goto(direction < 0 ? 3 : 2);
            return;
        }
        if (_page == 1) {
            if (_target != null) {
                _rememberTarget(_target + direction);
            }
        } else if (_page == 2) {
            _selection = (_selection + direction + 7) % 7;
        } else if (_page == 3 || _page == 4) {
            _selection = (_selection + direction + 5) % 5;
        } else if (_page == 5) {
            _edit = CompassMath.wrap(_edit + direction * (_mils ? 0.5625 : 5.0));
        } else if (_page == 6) {
            _selection = (_selection + direction + 5) % 5;
        } else if (_page == 7) {
            _decEdit += direction * 5;
            if (_decEdit > 300) { _decEdit = 300; }
            if (_decEdit < -300) { _decEdit = -300; }
        }
        Ui.requestUpdate();
    }

    function menu() {
        _goto(2);
    }

    function back() {
        _toast = null;
        if (_page == 0) {
            _stopTimer();
            Sys.exit();
        } else if (_page == 1) {
            _goto(0);
        } else if (_page == 2) {
            _goto(_target != null ? 1 : 0);
        } else if (_page == 3 || _page == 4 || _page == 5 || _page == 6 || _page == 8) {
            _goto(2);
        } else if (_page == 7) {
            _goto(6);
        }
    }

    function onUpdate(dc) {
        dc.setColor(G.COLOR_BLACK, G.COLOR_BLACK);
        dc.clear();
        if (isCompassPage()) {
            _drawCompass(dc);
        } else {
            _drawPanel(dc);
        }
    }

    function _pointX(cx, r, deg) { return cx + (M.sin(CompassMath.radians(deg)) * r).toNumber(); }
    function _pointY(cy, r, deg) { return cy - (M.cos(CompassMath.radians(deg)) * r).toNumber(); }

    // Sized for 280px round MIP; all important copy is kept inside the
    // visible circular region and OUTSIDE the rotating compass rose.
    function _drawCompass(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();
        var cx = w / 2;
        var cy = (h * 0.405).toNumber();
        var rad = ((w < h ? w : h) / 2) - 61;
        var heading = _valid() ? _display(_filtered) : null;
        var active = heading != null;
        var targetMode = (_page == 1 && _target != null);

        // Short headline: long words were clipped by the circular MIP bezel.
        dc.setColor(0xAFC3CC, G.COLOR_TRANSPARENT);
        dc.drawText(cx, 8, G.FONT_XTINY, targetMode ? "AZYMUT" : "KOMPAS", G.TEXT_JUSTIFY_CENTER);

        dc.setPenWidth(1);
        dc.setColor(0x536675, G.COLOR_TRANSPARENT);
        dc.drawCircle(cx, cy, rad);
        dc.drawCircle(cx, cy, rad - 12);

        if (active) {
            // Rotate cached tick unit vectors against the current heading.
            var headingRad = CompassMath.radians(heading);
            var sinH = M.sin(headingRad);
            var cosH = M.cos(headingRad);
            for (var i = 0; i < 36; i++) {
                var isMajor = (i % 3) == 0;
                var r1 = rad - (isMajor ? 11 : 7);
                var r2 = rad - 2;
                var ux = _tickSin[i] * cosH - _tickCos[i] * sinH;
                var uy = _tickCos[i] * cosH + _tickSin[i] * sinH;
                dc.setColor(isMajor ? 0xE1E8EA : 0x607785, G.COLOR_TRANSPARENT);
                dc.drawLine(cx + (ux * r1).toNumber(), cy - (uy * r1).toNumber(),
                            cx + (ux * r2).toNumber(), cy - (uy * r2).toNumber());
            }
            var names = ["N", "E", "S", "W"];
            for (var k = 0; k < 4; k++) {
                var cardAngle = CompassMath.wrap(k * 90.0 - heading);
                dc.setColor(k == 0 ? 0xFF4545 : 0xD7E2E5, G.COLOR_TRANSPARENT);
                dc.drawText(_pointX(cx, rad - 23, cardAngle),
                            _pointY(cy, rad - 23, cardAngle) - 8,
                            G.FONT_TINY, names[k], G.TEXT_JUSTIFY_CENTER);
            }
        }

        // Fixed sight at 12 o'clock. It stays put while the card rotates.
        dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
        dc.fillPolygon([[cx, cy-rad+4], [cx-7, cy-rad-10], [cx+7, cy-rad-10]]);

        if (active) {
            var northAngle = CompassMath.wrap(-heading);
            dc.setColor(0xF04444, G.COLOR_TRANSPARENT);
            dc.setPenWidth(3);
            dc.drawLine(_pointX(cx, 25, northAngle), _pointY(cy, 25, northAngle),
                        _pointX(cx, rad - 21, northAngle), _pointY(cy, rad - 21, northAngle));
            dc.setPenWidth(1);
        }

        var delta = 0.0;
        if (targetMode && active) {
            delta = CompassMath.shortest(heading, _display(_target));
            var aim = CompassMath.wrap(delta);
            dc.setColor(0x19E1B2, G.COLOR_TRANSPARENT);
            dc.fillCircle(_pointX(cx, rad - 5, aim), _pointY(cy, rad - 5, aim), 5);
        }

        // A compact solid number plate protects digit legibility from the
        // moving cardinal letters while keeping the peripheral rose visible.
        var bigNumber = "---";
        if (active) {
            bigNumber = (_mils ? CompassMath.degreesToMils(heading) % 6400
                               : (heading + 0.5).toNumber() % 360).toString();
        }
        var font = _mils ? G.FONT_LARGE : G.FONT_NUMBER_MEDIUM;
        var fontHeight = dc.getFontHeight(font);
        var numY = cy - (fontHeight / 2).toNumber() - 12;
        var textWidth = dc.getTextWidthInPixels(bigNumber, font);
        var plateWidth = textWidth + 14;
        dc.setColor(G.COLOR_BLACK, G.COLOR_BLACK);
        dc.fillRoundedRectangle(cx - plateWidth / 2, numY - 3,
                                plateWidth, fontHeight + 19, 6);
        dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
        dc.drawText(cx, numY, font, bigNumber, G.TEXT_JUSTIFY_CENTER);
        dc.setColor(0xA6CBD1, G.COLOR_TRANSPARENT);
        dc.drawText(cx, numY + fontHeight - 2, G.FONT_XTINY,
            active ? ((_mils ? "MIL" : "STOPNIE") + " / " + (_magnetic ? "MAG*" : "TRUE"))
                   : "BRAK ODCZYTU", G.TEXT_JUSTIFY_CENTER);

        // The footer starts beneath the ring. Three independent rows:
        // target, deviation, and sensor/refresh status. No shared y values.
        dc.setColor(0x536675, G.COLOR_TRANSPARENT);
        dc.drawLine(cx - 57, h - 80, cx + 57, h - 80);
        if (targetMode) {
            dc.setColor(0xDCEAF0, G.COLOR_TRANSPARENT);
            dc.drawText(cx, h - 76, G.FONT_TINY,
                        "CEL " + CompassMath.text(_display(_target), _mils),
                        G.TEXT_JUSTIFY_CENTER);
            if (active) {
                var signText = delta > 2.0 ? "PRAWO " : (delta < -2.0 ? "LEWO " : "NA KIERUNKU");
                var magnitude = delta < 0 ? -delta : delta;
                dc.setColor(0x2DE4C0, G.COLOR_TRANSPARENT);
                dc.drawText(cx, h - 54, G.FONT_SMALL,
                            (signText == "NA KIERUNKU" ? signText : signText + CompassMath.text(magnitude, _mils)),
                            G.TEXT_JUSTIFY_CENTER);
            } else {
                dc.setColor(0xFFDA63, G.COLOR_TRANSPARENT);
                dc.drawText(cx, h - 54, G.FONT_TINY, "CZUJNIK NIEDOSTEPNY", G.TEXT_JUSTIFY_CENTER);
            }
        } else {
            dc.setColor(0xE3EDF1, G.COLOR_TRANSPARENT);
            dc.drawText(cx, h - 76, G.FONT_TINY, "START: ZAPISZ", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, h - 54, G.FONT_TINY, "DOWN: MENU", G.TEXT_JUSTIFY_CENTER);
        }
        dc.setColor(0x8EA5B0, G.COLOR_TRANSPARENT);
        dc.drawText(cx, h - 30, G.FONT_XTINY,
                    active ? (_source + " / " + (_eco ? "ECO" : "SMOOTH")) : "BRAK KIERUNKU",
                    G.TEXT_JUSTIFY_CENTER);
        if (_toast != null) {
            dc.setColor(0xFFDF62, G.COLOR_TRANSPARENT);
            dc.drawText(cx, h - 94, G.FONT_XTINY, _toast, G.TEXT_JUSTIFY_CENTER);
        }
    }

    function _drawPanel(dc) {
        var cx = dc.getWidth() / 2;
        var items = [];
        var title = "";
        if (_page == 2) {
            title = "MENU";
            items = ["ZAPISZ CEL", "USTAW AZYMUT", "ZAPISANE", "USUN CEL", "USTAWIENIA", "POMOC / KAL.", "WROC"];
        } else if (_page == 3 || _page == 4) {
            title = _page == 3 ? "ZAPISANE AZYMUTY" : "ZAPISZ DO SLOTU";
            for (var i = 0; i < 5; i++) {
                var value = CompassStore.slot(i);
                items.add((i + 1).toString() + "   " + (value == null ? "PUSTY" : CompassMath.text(_display(value), _mils)));
            }
        } else if (_page == 6) {
            title = "USTAWIENIA";
            items = ["POLNOC: " + (_magnetic ? "MAG*" : "TRUE"),
                     "DEKLINACJA: " + (_decl10 / 10.0).toString(),
                     "JEDNOSTKI: " + (_mils ? "MIL" : "STOPNIE"),
                     "ODSWIEZANIE: " + (_eco ? "ECO" : "SMOOTH"), "WROC"];
        }
        dc.setColor(0x18CAB6, G.COLOR_TRANSPARENT);
        dc.drawText(cx, 22, G.FONT_MEDIUM, title, G.TEXT_JUSTIFY_CENTER);

        if (_page == 8) {
            dc.setColor(0x18CAB6, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 22, G.FONT_MEDIUM, "POMOC / KALIBRACJA", G.TEXT_JUSTIFY_CENTER);
            dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 71, G.FONT_TINY, "TRZYMAJ ZEGAREK POZIOMO", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 103, G.FONT_TINY, "ODDAL OD METALU I MAGNESOW", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 135, G.FONT_TINY, "KALIBRUJ W MENU GARMINA", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 166, G.FONT_XTINY, "BRAK ODCZYTU = BRAK KOMPASU", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 199, G.FONT_XTINY, "MAG* WYMAGA RECZNEJ DEKLINACJI", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 235, G.FONT_XTINY, "BACK: MENU", G.TEXT_JUSTIFY_CENTER);
            return;
        }

        if (_page == 5 || _page == 7) {
            dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 50, G.FONT_SMALL, _page == 5 ? "USTAW CEL" : "DEKLINACJA (E+ / W-)", G.TEXT_JUSTIFY_CENTER);
            var val = _page == 5 ? CompassMath.text(_edit, _mils) : (_decEdit / 10.0).toString() + "°";
            dc.drawText(cx, 102, G.FONT_LARGE, val, G.TEXT_JUSTIFY_CENTER);
            dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 189, G.FONT_SMALL, _page == 5 ? (_mils ? "UP/DOWN: +/-10 mil" : "UP/DOWN: +/-5°") : "UP/DOWN: +/-0.5°", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 216, G.FONT_TINY, "START: ZATWIERDZ", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 240, G.FONT_XTINY, "BACK: ANULUJ", G.TEXT_JUSTIFY_CENTER);
            return;
        }

        for (var j = 0; j < items.size(); j++) {
            var y = 60 + j * 27;
            if (j == _selection) {
                dc.setColor(0x1C3639, G.COLOR_BLACK);
                dc.fillRoundedRectangle(26, y - 2, dc.getWidth() - 52, 28, 7);
                dc.setColor(0x48F0D1, G.COLOR_TRANSPARENT);
            } else {
                dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
            }
            dc.drawText(38, y, G.FONT_TINY, (j == _selection ? "> " : "  ") + items[j], G.TEXT_JUSTIFY_LEFT);
        }
        dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
        dc.drawText(cx, dc.getHeight() - 30, G.FONT_XTINY, "UP/DOWN: WYBOR  START: OK", G.TEXT_JUSTIFY_CENTER);
        if (_toast != null) {
            dc.setColor(0xFFDF62, G.COLOR_TRANSPARENT);
            dc.drawText(cx, dc.getHeight() - 48, G.FONT_XTINY, _toast, G.TEXT_JUSTIFY_CENTER);
        }
    }
}
