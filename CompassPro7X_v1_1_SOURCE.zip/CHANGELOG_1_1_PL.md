# Compass Pro 7X v1.1.0 — poprawka czytelności i płynności

## Zgłoszenie z Fenix 7X Pro
- Teksty prowadzenia (`PRAWO`, `CEL`) nakładały się na różę kompasu i dolny status.
- Obracająca się róża wyraźnie lagowała po obrocie zegarka.

## Zmiany
- Tarcza kompasu pomniejszona i przesunięta w górę; dane wyprowadzone do osobnego dolnego panelu.
- Nagłówek skrócony, by nie przycinał go okrągły ekran MIP.
- Dane: `CEL`, `LEWO/PRAWO`, stan sensora w osobnych wierszach.
- Liczba azymutu ma czarne tło chroniące czytelność przed obracającymi się oznaczeniami.
- Odświeżanie `SMOOTH` co 180 ms (wczesniej 350 ms), `ECO` co 750 ms (wczesniej 1000 ms).
- Filtr zmiany kąta: SMOOTH 0.85 / ECO 0.72 (wczesniej 0.48 / 0.55).
- Geometryczne dane 36 kresek wyliczane raz przy uruchomieniu (w trakcie rysowania obliczane są tylko sin/cos azymutu).
- Niepotrzebny redraw przy bezruchu pomijany (progi 0,65 stopnia i maks. 1,4 s miedzy przerysowaniami).
- Przełączenie ECO/SMOOTH od razu restartuje timer z nowym interwałem.

## Co zostało bez zmian
- Identyfikator aplikacji, klucz storage, zapisane azymuty i target.
- 360 stopni / 6400 mils, MAG/TRUE, deklinacja, kierowanie do celu, przyciski, ikona i uprawnienia.
- Brak GPS, komunikacji i usługi działającej w tle.

## Testy i ograniczenia
Testy jednostkowe/statyczne uruchomione lokalnie. Kompilacja SDK i działanie na Fenixie wymagają potwierdzenia. `Sensor.getInfo()` może samo powodować krótkie blokowanie; szczegółowa płynność zależy od firmware i częstotliwości aktualizacji czujnika. Wzrost próbkowania w trybie SMOOTH może zwiększyć pobór energii podczas otwartej aplikacji (nie wpływa na Solar Rings po wyjściu).
