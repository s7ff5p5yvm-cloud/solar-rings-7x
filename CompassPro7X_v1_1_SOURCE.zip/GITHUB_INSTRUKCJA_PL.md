# Compass Pro 7X v1.1.0 — instalacja przez GitHub Actions

1. Wgraj plik `CompassPro7X_v1_1_SOURCE.zip` do katalogu głównego repozytorium Compass Pro 7X.
2. Wgraj `CompassPro7X_v1_1_BUILD.yml` do `.github/workflows` w tym samym repozytorium.
3. Przejdź do `Actions` i odczytaj wynik zadania `Compass Pro 7X v1.1 - layout and responsiveness fix`.
4. Pobierz artefakt `CompassPro7X_v1_1_build` i użyj `CompassPro7X_fenix7xpro.prg` do testów na Twoim zegarku.
5. Jeśli istnieje trwały klucz podpisywania w `CONNECTIQ_DEVELOPER_KEY_BASE64`, GitHub zbuduje też plik .iq do późniejszej publikacji.
6. Najpierw sprawdź czy ekran, cel i odchyłka nie nachodzą na siebie, a następnie obracaj zegarek przez kilkanaście sekund w trybie SMOOTH i sprawdź płynność.

Nie zmieniaj w projekcie `manifest.xml` identyfikatora aplikacji. Dzięki temu zachowasz zapisane azymuty po aktualizacji, o ile instalacja zachowa dane aplikacji. Przed aktualizacją warto dodatkowo zanotować ważne wartości.

Aplikacja jest niezależna od tarczy Solar Rings. Wersja v1.1.0 nie została jeszcze skompilowana w Garmin SDK ani sprawdzona na urządzeniu.
