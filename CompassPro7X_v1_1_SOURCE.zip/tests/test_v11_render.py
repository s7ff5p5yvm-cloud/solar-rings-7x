import re
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
SCR=(ROOT/'source/CompassScreen.mc').read_text(encoding='utf-8')

class LayoutAndMotionTests(unittest.TestCase):
    def test_new_version_same_app_id(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('id'),'93F847268B3845A49991C28B7E590E2A')
        self.assertEqual(app.get('version'),'1.1.0')
        self.assertEqual(app.get('type'),'watch-app')

    def test_footer_outside_dial_in_280_mip(self):
        # 280px fēnix 7X Pro: dial [34..192], footer divider 200.
        h=280
        cy=int(h*0.405)
        rad=h//2 - 61
        self.assertLessEqual(cy+rad,h-80)
        self.assertLess(h-76,h-54)
        self.assertLess(h-54,h-30)
        self.assertIn('h - 76',SCR)
        self.assertIn('h - 54',SCR)
        self.assertIn('h - 30',SCR)

    def test_no_long_title_or_compass_center_guidance(self):
        drawing=SCR.split('function _drawCompass(dc)',1)[1].split('function _drawPanel(dc)',1)[0]
        self.assertNotIn('NAWIGUJ DO AZYMUTU',drawing)
        self.assertNotIn('cy + 46',drawing)
        self.assertNotIn('h - 15',drawing)
        self.assertIn('"AZYMUT" : "KOMPAS"',drawing)
        self.assertIn('"CEL "',drawing)
        self.assertIn('"PRAWO "',drawing)
        self.assertIn('"LEWO "',drawing)

    def test_draw_uses_cached_ticks(self):
        self.assertIn('_tickSin.add(M.sin(rad))',SCR)
        self.assertIn('_tickCos.add(M.cos(rad))',SCR)
        self.assertIn('var ux = _tickSin[i] * cosH - _tickCos[i] * sinH',SCR)
        self.assertIn('var uy = _tickCos[i] * cosH + _tickSin[i] * sinH',SCR)
        self.assertEqual(SCR.count('_tickSin.add(M.sin(rad))'),1)

    def test_updates_and_skip_idle_redraws(self):
        self.assertIn('_eco ? 750 : 180',SCR)
        self.assertIn('_eco ? 0.72 : 0.85',SCR)
        self.assertIn('changed = delta >= 0.65',SCR)
        self.assertIn('now - _lastDrawMs >= 1400',SCR)
        self.assertIn('if (mustDraw)',SCR)

    def test_no_extra_gps_or_background(self):
        manifest=(ROOT/'manifest.xml').read_text()
        self.assertNotIn('Positioning',manifest)
        self.assertNotIn('Communications',manifest)
        self.assertNotIn('Background',manifest)
        self.assertIn('_stopTimer();',SCR)
        self.assertIn('Sensor.getInfo()',SCR)

    def test_eco_toggle_reschedules(self):
        settings=SCR.split('function _chooseSettings()',1)[1].split('function up()',1)[0]
        self.assertRegex(settings,r'_eco = !_eco;[\s\S]*?_refreshTimer\(\);')

    def test_smoothness_preserves_bearing_data_model(self):
        self.assertIn('CompassStore.write("target_true", _target)',SCR)
        self.assertIn('CompassStore.slotKey(_selection)',SCR)
        self.assertIn('CompassMath.shortest(heading, _display(_target))',SCR)

if __name__=='__main__':
    unittest.main()
