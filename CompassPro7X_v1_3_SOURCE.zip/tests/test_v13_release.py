import unittest
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
UI=(ROOT/'source/CompassScreen.mc').read_text()
ST=(ROOT/'source/CompassStore.mc').read_text()
M=(ROOT/'manifest.xml').read_text()

class CompassPro13Tests(unittest.TestCase):
    def test_watchapp_identity_and_update(self):
        self.assertIn('type="watch-app"',M)
        self.assertIn('version="1.3.0"',M)
        self.assertIn('id="93F847268B3845A49991C28B7E590E2A"',M)
    def test_three_profiles(self):
        self.assertIn('return 700;',UI)
        self.assertIn('return _speedMode == 2 ? 80 : 100;',UI)
        self.assertIn('SMOOTH',UI)
        self.assertIn('TURBO',UI)
        self.assertIn('ECO',UI)
    def test_adaptive_fast_turn(self):
        self.assertIn('magnitude >= 12.0',UI)
        self.assertIn('gain = 1.0;',UI)
        self.assertIn('difference * gain',UI)
    def test_timer_only_visible_compass(self):
        self.assertIn('_shown && isCompassPage()',UI)
        self.assertIn('function onHide()',UI)
        self.assertIn('_stopTimer();',UI)
        self.assertNotIn('Position.enableLocationEvents(',UI)
    def test_persistent_target_delete(self):
        self.assertIn('Store.deleteValue(key)',ST)
        self.assertIn('CompassStore.remove("target_true")',UI)
        self.assertNotIn('CompassStore.write("target_true", null)',UI)
    def test_wmm_stale_location_handling(self):
        self.assertIn('pos.when.value()',UI)
        self.assertIn('gpsAge > 604800',UI)
        self.assertIn('Position.QUALITY_NOT_AVAILABLE',UI)
        self.assertIn('AUTO BRAK: TRYB TRUE',UI)
    def test_true_bearing_storage_and_manual(self):
        self.assertIn('CompassMath.toTrue',UI)
        self.assertIn('CompassMath.toDisplay',UI)
        self.assertIn('target_true',UI)
        self.assertIn('0.05625',UI)
    def test_circular_safe_menu(self):
        self.assertIn('var visible = items.size() > 5 ? 5 : items.size()',UI)
        self.assertIn('first = _selection - 2;',UI)
        self.assertIn('row<visible;',UI)
    def test_tick_cache(self):
        self.assertIn('i < 48',UI)
        self.assertIn('_ticksSin[i]*ch-_ticksCos[i]*sh',UI)
        self.assertIn('changed || ok != _lastDrawValid',UI)
    def test_preserves_five_slots(self):
        self.assertIn('CompassStore.slot(_selection)',UI)
        self.assertIn('CompassStore.slotKey(_selection)',UI)
        self.assertIn('(_selection + direction + 5) % 5',UI)
    def test_no_gps_or_net_background(self):
        joined='\n'.join(q.read_text() for q in (ROOT/'source').glob('*.mc'))
        for forbidden in ('Communications.makeWebRequest(', 'Position.enableLocationEvents(', 'registerForTemporalEvent('):
            self.assertNotIn(forbidden,joined)
    def test_power_status(self):
        self.assertIn('_lastDrawMs',UI)
        self.assertIn('if (_shown && isCompassPage())',UI)

if __name__=='__main__': unittest.main()
