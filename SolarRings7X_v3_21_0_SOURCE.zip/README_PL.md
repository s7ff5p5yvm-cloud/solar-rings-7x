# Solar Rings 7X v3.21.0 — stabilizacja IMGW

**Cel:** ograniczenie przydziału pamięci i liczby odczytów, przy zachowaniu
bezpośrednich zapytań GUGiK -> IMGW, bez gałęzi `imgw-feed`.

## Co zmieniono

- Usunięto nieużywane funkcje GitHub-feed i pamięć podręczną powiatu z zadania w tle.
- Tryb 4 i 5C uruchamiają identyczne zapytania i parser; rezultat ma ten sam identyfikator 11.
- Callback IMGW akceptuje rzeczywistą tablicę JSON bez błędnej deklaracji typu Dictionary.
- Wynik zadania jest odczytywany z pamięci tylko raz na odrysowanie; walidacja i ikona
  korzystają z tego samego obiektu, bez zbędnych deserializacji.
- Lokalizacja GPS nadal pochodzi z zegarka; nie ma zastępczego miasta.
- Nieprawidłowe, obce lub stare dane nie są traktowane jako brak alertów.
- Dostępne diagnostyki: 0/1/2/3/4/4C/4D/5A/5B/5C/6A/6B.
- Wyłączono przestarzałe diagnostyki 4A/4B wymagające GitHuba.

## Instalacja

1. Umieść `SolarRings7X_v3_21_0_SOURCE.zip` w katalogu głównym GitHub.
2. Umieść `SolarRings7X_v3_21_0_BUILD.yml` w `.github/workflows/`.
3. Uruchom `Build Solar Rings 7X v3.21.0` w Actions.
4. Po udanej kompilacji wgraj wygenerowany `.iq` przez dotychczasową metodę.
5. Włącz IMGW, diagnostykę, wybierz `4 – pełny IMGW`, odświeżanie 5 minut;
   ikony pozostaw **wyłączone** do sprawdzenia stabilności.

## Co sprawdzić na urządzeniu

- Najpierw poprawny wynik bez awarii, np. `T4 OK0 1261` lub `T4 ALERT 1261`.
- Następnie pozostaw tarczę na **co najmniej trzy pełne cykle** (w praktyce
  około 20–30 minut ze względu na opóźnienia systemu).
- Jeżeli stabilna, włącz ikony IMGW i powtórz obserwację.
- Jeśli Garmin zamknie tarczę, testy lokalne nie ujawniają przyczyny; potrzebny
  jest log Connect IQ lub test w symulatorze. Nie traktuj komunikatu `OK0` jako
  pewnej informacji o braku alertów, jeśli tarcza nie ukończyła pobierania.

## Zakres testów

`python3 tests/test_v3210.py` — 39 kontroli statycznych oraz testów modelowych.
Nie są to testy wykonania Monkey C na zegarku. Workflow kompiluje projekt
oficjalnym SDK; fizycznej stabilności nie da się potwierdzić samą kompilacją.

## Ograniczenia

IMGW może kiedyś zwiększyć liczbę ostrzeżeń i rozmiar odpowiedzi.
Zadanie Garmina ma niewielki limit RAM i maksymalny czas uruchomienia,
więc żadne testy offline nie gwarantują stabilności pobierania w przyszłości.
Nie używaj tej funkcji jako jedynego źródła ostrzeżeń pogodowych.
