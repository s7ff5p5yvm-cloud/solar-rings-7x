"""Regression contracts and independent reference matrices for v3.26.8.
Important: these checks inspect production Monkey C source and an independent
Python decision model, NOT executed Monkey C nor an actual Garmin simulator.
"""
import csv
from pathlib import Path
import re
import unittest
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
GW=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
OW=(ROOT/'source/SolarOpenWarnings.mc').read_text()
NW=(ROOT/'source/SolarOpenNetwork.mc').read_text()
OD=(ROOT/'source/SolarOpenData.mc').read_text()
UI=(ROOT/'source/SolarRings7X.mc').read_text()
SET=(ROOT/'resources/settings/settings.xml')
PROP=(ROOT/'resources/settings/properties.xml')
STR=(ROOT/'resources/strings.xml')

CATEGORIES = {
    'rain': ('RAIN', 'SHOWERS', 'HEAVY_RAIN', 'LIGHT_SHOWERS','CHANCE_OF_SHOWERS','CLOUDY_CHANCE_OF_RAIN'),
    'snow': ('SNOW', 'FLURRIES', 'HEAVY_SNOW', 'CHANCE_OF_SNOW','CLOUDY_CHANCE_OF_SNOW'),
    'mixed': ('WINTRY_MIX','RAIN_SNOW','CHANCE_OF_RAIN_SNOW','CLOUDY_CHANCE_OF_RAIN_SNOW'),
    'storm': ('THUNDERSTORMS','CHANCE_OF_THUNDERSTORMS'),
    'severe': ('HAIL','FREEZING_RAIN','TORNADO','SQUALL'),
}

def precip(chance, mode=1, custom_min=30, forecast=True, identified=True):
    if not identified: return False
    if not forecast: return True
    if chance is None: return True
    if type(chance) not in (int,float) or not 0<=chance<=100: return False
    if mode==0: return True
    if mode==1: return chance>=40
    return chance>=custom_min

def wind_code(wind=None,gust=None,threshold=10,gust_threshold=15,owm=True):
    return (isinstance(wind,(int,float)) and 0<=wind<=120 and wind>=threshold or
            (owm and isinstance(gust,(int,float)) and 0<=gust<=150 and gust>=gust_threshold))

class AllHazards3263(unittest.TestCase):
    def test_all_three_chance_modes_including_0_missing_and_invalid(self):
        count=0
        values=[None,0,5,10,20,29,30,39,40,41,49,50,59,60,70,99,100,-1,101,'50']
        for kind,minimum in [('rain',30),('snow',50),('mixed',40)]:
            for mode in [0,1,2]:
                for v in values:
                    with self.subTest(kind=kind,mode=mode,chance=v):
                        expected=(v is None or (type(v) in (int,float) and 0<=v<=100 and
                        (mode==0 or v >= (40 if mode==1 else minimum))))
                        self.assertEqual(precip(v,mode,minimum),expected)
                        count+=1
        self.assertEqual(count,180)
        self.assertIn('function forecastChanceMatches(chance, customMinimum)',GW)
        self.assertIn('if (chance == null) { return true; }',GW)
        self.assertIn('if (!validMeasure(chance, 0, 100)) { return false; }',GW)
        self.assertIn('if (sensitivity == 0) { return true; }',GW)
        self.assertIn('if (sensitivity == 1) { return chance >= 40; }',GW)
        self.assertIn('return chance >= customMinimum;',GW)
        self.assertIn('var rainAllowed = !forecast || forecastChanceMatches(pop,',OW)
        self.assertIn('var snowAllowed = !forecast || forecastChanceMatches(pop,',OW)
        self.assertIn('var mixAllowed = !forecast || forecastChanceMatches(pop, mixedLimit)',OW)

    def test_current_weather_bypasses_precipitation_filter(self):
        for pct in [None,0,5,20,99,100,-1]:
            self.assertTrue(precip(pct,forecast=False),pct)
        self.assertIn('!isForecast || forecastChanceMatches(chance,',GW)
        self.assertIn('rainAllowed = !forecast ||',OW)
        self.assertIn('snowAllowed = !forecast ||',OW)

    def test_no_forecast_from_percentage_alone_and_unknown_owm_id(self):
        for v in [None,0,30,40,90,100]:
            self.assertFalse(precip(v,identified=False))
        self.assertIn('var mapped = code != null && srOwmMappedCondition(code) != null;',OW)
        self.assertIn('(forecast && measuredRain && !freezing)',OW)
        self.assertIn('(forecast && measuredSnow)',OW)
        self.assertIn('var rain =',OW)
        self.assertIn('var snow =',OW)
        self.assertNotIn('if (pop >=',OW)

    def test_conditional_garmin_is_forecast_only(self):
        for group in CATEGORIES.values():
            for c in group: self.assertIn('Weather.CONDITION_'+c,GW)
        self.assertIn('(rainExplicit || isForecast) &&',GW)
        self.assertIn('(snowExplicit || isForecast) &&',GW)
        self.assertIn('(mixedExplicit || isForecast) &&',GW)
        self.assertIn('(isForecast && stormUncertain)',GW)

    def test_generic_pop_never_filters_storm_hail_freezing_rain(self):
        self.assertNotIn('"gwStormChanceV332"',GW)
        self.assertIn('stormUncertain',GW)
        self.assertIn('code >= 200 && code <= 232',OW)
        self.assertIn('code == 511',OW)
        self.assertIn('c == Weather.CONDITION_HAIL',GW)
        self.assertIn('c == Weather.CONDITION_FREEZING_RAIN',GW)
        menus=SET.read_text()
        self.assertNotIn('propertyKey="@Properties.gwStormChanceV332"',menus)
        self.assertIn('property id="gwStormChanceV332"',PROP.read_text())

    def test_freezing_rain_does_not_create_duplicate_ice_warning(self):
        self.assertIn('var wetWeather = rainExplicit || snowExplicit || mixedExplicit;',GW)
        self.assertNotIn('wetWeather = rainExplicit || snowExplicit || mixedExplicit ||\n                             c == Weather.CONDITION_FREEZING_RAIN',GW)
        self.assertIn('srSetting("gwIceOnV332", true) && !freezing',OW)
        self.assertIn('addAlert(k, 5)',OW)
        self.assertIn('addAlert(k, 5)',GW)

    def test_fog_explicit_and_numeric_low_visibility_even_without_weather_code(self):
        for src in [GW,OW]:
            self.assertIn('validMeasure(visibility, 0, 100000)',src)
            self.assertIn('visibility <= srSetting("gwFogMetersV332", 500)',src)
        self.assertIn('lowVisibility || c == Weather.CONDITION_FOG',GW)
        self.assertIn('lowVisibility || code == 741',OW)
        self.assertIn('if (c == null)',GW)
        self.assertIn('var mapped = code != null && srOwmMappedCondition(code) != null;',OW)
        self.assertIn('(forecast && measuredRain && !freezing)',OW)
        self.assertIn('(forecast && measuredSnow)',OW)

    def test_wind_gust_measurement_and_code_fallback(self):
        for wind,gust,owm,expected in [(9,16,True,True),(10,0,True,True),
                                        (9,14,True,False),(9,None,False,False),
                                        (None,17,True,True),(-5,-2,True,False)]:
            self.assertEqual(wind_code(wind,gust,owm=owm),expected)
        self.assertIn('srOwmGustV3263',OW)
        self.assertIn('h[9],true',OW)
        self.assertIn('d[15],false',OW)
        self.assertIn('wind == null && c == Weather.CONDITION_WINDY',GW)

    def test_heavy_only_and_air_quality_and_temperature_remain_separate(self):
        self.assertIn('gwRainHeavyV332',GW)
        self.assertIn('gwSnowHeavyV332',GW)
        self.assertIn('gwRainHeavyV332',OW)
        self.assertIn('gwSnowHeavyV332',OW)
        self.assertIn('rainRate >= 8',OW)
        self.assertIn('code == 602 || code == 622',OW)
        self.assertIn('srOwmAqiMinV326',OW)
        self.assertIn('srOwmAirV326',OW)
        self.assertIn('temperatureMarker(dc, weather',UI)
        self.assertIn('hasForecastUnderline',UI)

    @unittest.skip("v57 uses deadline fairness; replaced by test_v32657_recovery.py")
    def test_cadence_modes_and_reschedule_on_change(self):
        prop={x.get('id'):(x.text or '').strip() for x in ET.parse(PROP).getroot()}
        menus={x.get('propertyKey','').replace('@Properties.',''):x for x in ET.parse(SET).getroot()}
        self.assertEqual(prop['srOwmMinutesV326'],'5')
        self.assertEqual(prop['srPrecipModeV3263'],'1')
        self.assertEqual(prop['srOwmGustV3263'],'15')
        v={int(x.get('value')) for x in menus['srOwmMinutesV326'].find('settingConfig')}
        self.assertEqual(v,{5,15,30,60})
        self.assertIn('if (_interval != 5 && _interval != 15 && _interval != 30 && _interval != 60)',NW)
        self.assertIn('var refreshChanged = mode == 1 && oldRefresh != refresh;',OD)
        self.assertIn('srOwmWrite("srONextCV326", 0)',OD)
        self.assertIn('srOwmWrite("srONextFV326", 0)',OD)
        self.assertIn('new Time.Duration(5 * 60)',OD)
        self.assertIn('_interval * 60',NW)
        self.assertIn('function shortSeconds() { return _interval <= 15 ? 35 * 60 : 45 * 60; }',NW)
        self.assertIn('12 * 3600',NW)
        self.assertEqual(NW.count('Comm.makeWebRequest('),2)
        # Current, hourly, short, daily and AQI use independent deadlines.
        for current,forecast in [(15,20),(30,30),(60,60)]:
            total=1440/current+1440/forecast+24+24+2
            self.assertLessEqual(total, 240)

    def test_no_more_foreground_http_or_gps_and_preserved_version(self):
        self.assertNotIn('Comm.makeWebRequest(',GW+OW)
        self.assertEqual(NW.count('Comm.makeWebRequest('),2)
        self.assertNotIn('Position.enableLocationEvents(',OD)
        app=ET.parse(ROOT/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('version'),'3.26.57')
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')

    def test_ui_xml_property_references_resolve(self):
        props={x.get('id') for x in ET.parse(PROP).getroot()}
        strings={x.get('id') for x in ET.parse(STR).getroot()}
        for key in re.findall(r'@Properties\.([A-Za-z0-9_]+)',SET.read_text()):
            self.assertIn(key,props)
        for key in re.findall(r'@Strings\.([A-Za-z0-9_]+)',SET.read_text()):
            self.assertIn(key,strings)
        self.assertEqual(len(props),len(set(props)))
        settings=[x.attrib.get('propertyKey') for x in ET.parse(SET).getroot()]
        self.assertEqual(len(settings),len(set(settings)))

    def test_all_109_mapping_values_still_covered(self):
        with (ROOT/'WEATHER_CODE_MATRIX.csv').open(encoding='utf-8') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),109)
        self.assertEqual(len({(x['provider'],x['code']) for x in rows}),109)

if __name__=='__main__': unittest.main()
