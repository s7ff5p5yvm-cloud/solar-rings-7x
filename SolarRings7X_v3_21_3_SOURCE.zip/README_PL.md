# Solar Rings 7X v3.21.2 — stabilizacja IMGW

**Cel:** ograniczenie przydziału pamięci i liczby odczytów, przy zachowaniu
bezpośrednich zapytań GUGiK -> IMGW, bez gałęzi `imgw-feed`.

## Co zmieniono

- Usunięto nieużywane funkcje GitHub-feed i pamięć podręczną powiatu z zadania w tle.
- Tryb 4 i 5C uruchamiają identyczne zapytania i parser; rezultat ma ten sam identyfikator 11.
- Callback IMGW akceptuje rzeczywistą tablicę JSON bez błędnej deklaracji typu Dictionary.
- Wynik zadania jest odczytywany z pamięci tylko raz na odrysowanie; walidacja i ikona
  korzystają z tego samego obiektu, bez zbędnych deserializacji.
- Lokalizacja GPS nadal pochodzi z zegarka; nie ma zastępczego miasta.
- Nieprawidłowe, obce lub stare dane nie są traktowane jako brak alertów.
- Dostępne diagnostyki: 0/1/2/3/4/4C/4D/5A/5B/5C/6A/6B.
- Wyłączono przestarzałe diagnostyki 4A/4B wymagające GitHuba.

## Instalacja

1. Umieść `SolarRings7X_v3_21_0_SOURCE.zip` w katalogu głównym GitHub.
2. Umieść `SolarRings7X_v3_21_0_BUILD.yml` w `.github/workflows/`.
3. Uruchom `Build Solar Rings 7X v3.21.2` w Actions.
4. Po udanej kompilacji wgraj wygenerowany `.iq` przez dotychczasową metodę.
5. Włącz IMGW, diagnostykę, wybierz `4 – pełny IMGW`, odświeżanie 5 minut;
   ikony pozostaw **wyłączone** do sprawdzenia stabilności.

## Co sprawdzić na urządzeniu

- Najpierw poprawny wynik bez awarii, np. `T4 OK0 1261` lub `T4 ALERT 1261`.
- Następnie pozostaw tarczę na **co najmniej trzy pełne cykle** (w praktyce
  około 20–30 minut ze względu na opóźnienia systemu).
- Jeżeli stabilna, włącz ikony IMGW i powtórz obserwację.
- Jeśli Garmin zamknie tarczę, testy lokalne nie ujawniają przyczyny; potrzebny
  jest log Connect IQ lub test w symulatorze. Nie traktuj komunikatu `OK0` jako
  pewnej informacji o braku alertów, jeśli tarcza nie ukończyła pobierania.

## Zakres testów

`python3 tests/test_v3210.py` — 39 kontroli statycznych oraz testów modelowych.
Nie są to testy wykonania Monkey C na zegarku. Workflow kompiluje projekt
oficjalnym SDK; fizycznej stabilności nie da się potwierdzić samą kompilacją.

## Ograniczenia

IMGW może kiedyś zwiększyć liczbę ostrzeżeń i rozmiar odpowiedzi.
Zadanie Garmina ma niewielki limit RAM i maksymalny czas uruchomienia,
więc żadne testy offline nie gwarantują stabilności pobierania w przyszłości.
Nie używaj tej funkcji jako jedynego źródła ostrzeżeń pogodowych.


## Zmiana 3.21.2 — kompilacja Garmin SDK

Naprawiono 3 niezgodne z SDK 9.3.0 podpisy callbacków Communications.makeWebRequest
(onCountyResponse, onUnifiedImgwResponse i onDirectImgwResponse). Parametr statusu ma
typ Lang.Number, a odpowiedź pełną wymaganą unię typów. Nie zmieniono logiki IMGW.
Odpowiedź IMGW jest tablicą JSON i nadal wymaga walidacji w kodzie po stronie zegarka.

Testy lokalne nie zastępują kompilacji SDK w GitHub Actions ani sprawdzenia
stabilności zegarka.


## Poprawka 3.21.2 — stabilność lokalizacji i danych

- Czas lokalizacji oznacza **ostatnią obserwację pozycji przez tarczę**, a nie czas nowego ustalenia satelitarnego. Gdy Garmin nadal udostępnia `Activity.Info.currentLocation`, tarcza aktualizuje zapis maksymalnie co 15 minut. Nie odświeża go, jeśli GPS zwraca null.
- Zadanie w tle odrzuca uszkodzoną i starszą niż 6 godzin lokalizację. Bez dostępnej pozycji nie da się uczciwie zagwarantować ostrzeżeń dla bieżącego powiatu.
- Rezultat HTTP jest powiązany z pozycją, dla której wykonano żądanie. Zmiana pozycji po wysłaniu zapytania nie jest traktowana jako brak ostrzeżeń.
- Diagnostyka trybu 4: `T4 D7` = brak zapisu lokalizacji; `T4 D8` = nieaktualna obserwacja pozycji; `T4 D9` = pozycja zmieniła się po wykonaniu zapytania. Inne `T4 D...` oznaczają nieważny wynik/format i również nie stanowią potwierdzonego braku ostrzeżeń.
- `T4 PONOW` oznacza, że po błędzie GPS tarcza uzyskała nowszą lokalizację i oczekuje na kolejny cykl pobierania.
- Produkcyjny tryb 4 pozostaje bez pośrednictwa GitHuba i korzysta z tej samej ścieżki pobierania co 5C.

**Weryfikacja:** skryptowe testy strukturalne i modelowe nie uruchamiają Garmin SDK ani fizycznego zegarka. Po kompilacji przetestuj tryb 4 na urządzeniu przez kilka kolejnych cykli.
