import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
svc=(p/'source/ImgwService.mc').read_text()
face=(p/'source/SolarRings7X.mc').read_text()
properties=ET.parse(p/'resources/settings/properties.xml').getroot()
settings=ET.parse(p/'resources/settings/settings.xml').getroot()

class TestGpsFallback(unittest.TestCase):
    def test_automatic_priority(self):
        # Stage 4 uses the normal GPS/GUGiK request when it exists.
        self.assertIn('var loc = Storage.getValue("imgwLocV318")',svc)
        self.assertIn('if (stage == 4 && tryLastCountyWhenGpsMissing())',svc)
        self.assertIn('method(:onCountyResponse)',svc)

    def test_no_cross_test_pollution(self):
        # Fallback must only run for full mode, not diagnostic stage 3 or 5C.
        self.assertEqual(svc.count('stage == 4 && tryLastCountyWhenGpsMissing()'),2)

    def test_last_county_only_from_confirmed_geocoder(self):
        body=svc.split('function onCountyResponse(',1)[1]
        self.assertLess(body.find('_county = parseCounty(payload)'),body.find('Storage.setValue("imgwLastCountyV3213"'))
        self.assertIn('if (_county == null) { stop(7); return; }',body)
        self.assertIn('age <= 86400',svc)

    def test_non_gps_result_source_tag(self):
        self.assertIn('_source = 1;',svc)
        self.assertIn('_source = 2;',svc)
        self.assertIn('code, _stage, _source]);',svc)
        self.assertIn('result[8] == 1 || result[8] == 2',face)

    def test_cannot_silently_show_green_all_clear_on_fallback(self):
        self.assertIn('" BRAK? "',face)
        self.assertIn('"T4 O"',face)
        self.assertIn('"T4 M"',face)
        self.assertIn('imgwValidationProblem(stage, true, snapshot)',face)

    def test_number_or_float_cached_coordinates(self):
        self.assertIn('(last[1] instanceof Lang.Number || last[1] instanceof Lang.Float)',svc)
        self.assertIn('(last[2] instanceof Lang.Number || last[2] instanceof Lang.Float)',svc)

    def test_gps_onshow_and_onupdate(self):
        self.assertIn('function onShow() { captureImgwLocation(); }',face)
        self.assertIn('captureImgwLocation();',face.split('function onUpdate(dc)',1)[1])
        self.assertIn('imgwGpsReport(3); return;',face)
        self.assertIn('imgwGpsReport(5);',face)

    def test_backup_disabled_by_default(self):
        d={x.attrib['id']:x for x in properties}
        self.assertEqual(d['imgwFallbackCountyV3213'].text,'0')
        self.assertTrue(any('imgwFallbackCountyV3213' in x.attrib.get('propertyKey','') for x in settings))
        self.assertIn('manual >= 1000 && manual <= 9999',svc)

    def test_preserve_full_imgw_check(self):
        self.assertIn('processOfficialWarnings(payload);',svc)
        self.assertIn('method(:onUnifiedImgwResponse)',svc)
        self.assertIn('https://danepubliczne.imgw.pl/api/data/warningsmeteo',svc)

if __name__ == '__main__': unittest.main()
