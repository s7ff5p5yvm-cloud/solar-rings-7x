# Diagnostyka OpenWeather — Solar Rings v3.26.6

**Użyj, jeśli nadal brak temperatury po zmianie dostawcy.**

W Connect IQ wejdź w ustawienia Solar Rings i wybierz `Podgląd ostrzeżeń = TEST 15`. Po przejściu na zegarek w dolnym wierszu zobaczysz status OWM. Nie udostępniaj klucza API ani zrzutu ekranu zawierającego klucz.

| Status w TEST 15 | Znaczenie / dalszy krok |
|---|---|
| `OWM LOK: BRAK GPS` | Nie ma poprawnych współrzędnych w dostępnych metadanych. Pozostaw Garmin Connect połączony, poczekaj na aktualizację położenia. |
| `OWM TERAZ: POBIERANIE` | Zapytanie do aktualnej pogody wystartowało; wróć po kilku minutach. |
| `OWM TERAZ: OK` | Bieżąca odpowiedź została zaakceptowana i zapisana. |
| `OWM TERAZ: 401` | Serwer odmówił autoryzacji. Sprawdź aktywację klucza, nie udostępniaj go w rozmowie. |
| `OWM TERAZ: 403` | Serwer odmówił dostępu (HTTP). |
| `OWM TERAZ: 429` | Za dużo zapytań / ograniczenie usługi. |
| `OWM TERAZ: ODPOWIEDZ` | HTTP mógł zwrócić 200, ale odpowiedź nie spełniła wymaganego formatu lub nie zapisała się w pamięci. |
| `OWM TERAZ: BRAK TELEFONU` | W momencie wywołania zegarek nie miał aktywnego połączenia z telefonem. |
| `OWM PROG: TIMEOUT` | Poprzednie żądanie nie zakończyło się poprawnie; obserwuj fallback. |
| `OWM PROG: -403` | Connect IQ zgłosił błąd pamięci sieci (to nie jest HTTP 403). Fallback prognozy co godzinę powinien zadziałać. |

Ważne: napis `OWM PROG` odnosi się do prognozy, `OWM TERAZ` do temperatury i warunków bieżących. Kolejność pobierania: teraz → prognoza → doba → AQI (jeśli włączone). Przy pierwszym użyciu może to zająć kilka cykli pobierania. Sama lokalizacja nie dowodzi poprawności API. Zapisany klucz po aktualizacji aplikacji pozostaje w Connect IQ, bo nie zmieniliśmy identyfikatora ustawienia.

Nie gwarantujemy działania bez kompilacji i testu na zegarku. Nie dodano nowych regularnych zapytań API wyłącznie z powodu diagnostyki.
