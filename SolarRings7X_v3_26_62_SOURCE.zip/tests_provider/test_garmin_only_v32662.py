import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
P=Path(__file__).resolve().parent.parent
class CleanAndBattery(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s={p.name:p.read_text() for p in (P/'source').glob('*.mc')}
        cls.all="\n".join(cls.s.values())
    def test_version_identity(self):
        x=(P/'manifest.xml').read_text()
        self.assertIn('version="3.26.62"',x)
        self.assertIn('D1F8E1A4B7FC45BD91E8F0A0959041BF',x)
        self.assertNotIn('Positioning',x)
    def test_no_external_network_or_aqi(self):
        for phrase in ('"AQI"','makeWebRequest(', 'SolarOpenNetwork',
                       'srUseOpenWeather(', 'WeatherGuard(', 'http://', 'https://'):
            self.assertNotIn(phrase,self.all,phrase)
        self.assertNotIn('WEATHER_CODE_MATRIX.csv', ' '.join(p.name for p in P.iterdir()))
    def test_forecast_isolation(self):
        self.assertEqual(sum(t.count('Weather.getHourlyForecast()') for t in self.s.values()),1)
        self.assertIn('Weather.getHourlyForecast()',self.s['SolarRingsGarminService.mc'])
        self.assertIn('Props.getValue("gwForecastV332")',self.s['SolarRingsGarminService.mc'])
        self.assertIn('Props.getValue("gwOnV332")',self.s['SolarRingsGarminService.mc'])
        self.assertIn('Time.Duration(300)',self.s['SolarRings7X.mc'])
        self.assertNotIn('Ui.requestUpdate()',self.s['SolarRings7X.mc'])
    def test_alert_semantics(self):
        x=self.s['SolarRings7X.mc']
        self.assertIn('color = Gfx.COLOR_RED;',x)
        self.assertIn('color = 0x00FFFF;',x)
        self.assertIn('hasForecastUnderline = true;',x)
        self.assertIn('dc.fillRectangle(x - 8, y + 11, 16, 2);',x)
        self.assertIn('function onPartialUpdate(dc)',x)
    def test_regular_rain_and_snow_enabled_by_default(self):
        props=ET.parse(P/'resources/settings/properties.xml').getroot()
        values={e.get('id'): (e.text or '').strip() for e in props}
        self.assertEqual(values['gwRainOnV332'],'true')
        self.assertEqual(values['gwSnowOnV332'],'true')
        self.assertEqual(values['gwRainHeavyV332'],'false')
        self.assertEqual(values['gwSnowHeavyV332'],'false')
        src=self.s['GarminWeatherWarnings.mc']
        for code in ('RAIN','LIGHT_RAIN','HEAVY_RAIN','SHOWERS',
                     'SNOW','LIGHT_SNOW','HEAVY_SNOW','FLURRIES'):
            self.assertIn('Weather.CONDITION_'+code,src)
        self.assertIn('(!srSetting("gwSnowHeavyV332", false) || heavySnow)',src)
        self.assertIn('(!srSetting("gwRainHeavyV332", false) || heavyRain)',src)
    def test_forecast_refresh_and_current_fixed_to_five_minutes(self):
        app=self.s['SolarRings7X.mc']
        self.assertIn('Time.Duration(300)',app)
        self.assertIn('old.value() != 300',app)
        self.assertNotIn('Time.Duration(900)',app)
        warnings=self.s['GarminWeatherWarnings.mc']
        self.assertIn('now - _lastCheck >= 300',warnings)
        self.assertNotIn('srSetting("gwIntervalV332"',warnings)
    def test_settings(self):
        sett=ET.parse(P/'resources/settings/settings.xml').getroot()
        pp=ET.parse(P/'resources/settings/properties.xml').getroot()
        sk=[e.get('propertyKey').replace('@Properties.','') for e in sett]
        pk=[e.get('id') for e in pp]
        self.assertEqual(len(sk),len(set(sk)))
        self.assertEqual(len(pk),len(set(pk)))
        self.assertTrue(set(sk).issubset(set(pk)))
        self.assertNotIn('gwIntervalV332',sk)
        for key in ('slotTop2V3','gwForecastV332','gwHorizonV332','gwWindOnV332'):
            self.assertIn(key,sk)
        for dead in ('gwStormChanceV332','moonLabelV38','gwIntervalV332'):
            self.assertNotIn(dead,pk)
        sr={e.get('id') for e in ET.parse(P/'resources/strings.xml').getroot()}
        raw=(P/'resources/settings/settings.xml').read_text()+(P/'manifest.xml').read_text()
        self.assertTrue(set(re.findall(r'@Strings\.(\w+)',raw)).issubset(sr))
    def test_xml(self):
        for f in P.rglob('*.xml'): ET.parse(f)
if __name__=='__main__':unittest.main()
