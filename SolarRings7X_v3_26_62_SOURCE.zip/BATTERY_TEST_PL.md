# Test poboru energii Solar Rings v3.26.62

1. Naładuj Fenix 7X Pro Solar do 100% i odłącz kabel.
2. Zanotuj godzinę startu, baterię, ustawienie Pulse Ox i tryb telefonu.
3. Używaj tarczy 24 godziny; nie zmieniaj znacząco pozostałych ustawień.
4. Zanotuj stan po 6 h, 12 h i 24 h.
5. Porównaj ze standardową tarczą Garmin w zbliżonych warunkach.
6. Osobno sprawdź zmianę ustawień podczas aktywnej tarczy.
7. Zapisz CIQ_LOG.YML, jeśli pojawi się błąd po kompilacji/instalacji.

Brak gwarancji wyniku 5%/dobę: wymaga rzeczywistego pomiaru.

8. Przy porównaniu sprawdź wpływ zmiany z 15 na 5 minut dla odczytu prognozy.
