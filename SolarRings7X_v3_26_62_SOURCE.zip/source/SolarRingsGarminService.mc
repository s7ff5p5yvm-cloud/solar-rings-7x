using Toybox.Weather as Weather;
using Toybox.Time as Time;
using Toybox.Application as App;
using Toybox.Application.Properties as Props;
using Toybox.Background as Bg;
using Toybox.System as System;

// The only background task. Reads Garmin's ALREADY-CACHED hourly forecast;
// it does NOT contact any API or force a weather update.
// Its separate memory pool prevents a forecast read from being mixed with
// the memory-intensive watch-face drawing cycle.
(:background)
class SolarRingsGarminService extends System.ServiceDelegate {
    function initialize() { ServiceDelegate.initialize(); }
    function onTemporalEvent() {
        var result = null;
        try {
            // No need to allocate the hourly array if warnings/forecast are off.
            // Keep the 5m schedule registered so enabling later works.
            var enabled = Props.getValue("gwOnV332");
            var forecastEnabled = Props.getValue("gwForecastV332");
            if (enabled == false || forecastEnabled == false) {
                Bg.exit(null);
                return;
            }
            var forecast = Weather.getHourlyForecast();
            if (forecast != null) {
                var now = Time.now().value();
                var compact = [];
                // Only the first three future hours, never a full day array.
                // No UV/AQI/gust field reads: unnecessary for selected alerts.
                for (var i = 0; i < forecast.size() && compact.size() < 3; i++) {
                    var h = forecast[i];
                    if (h == null || h.forecastTime == null) { continue; }
                    var epoch = h.forecastTime.value();
                    if (epoch > now && epoch <= now + 10800) {
                        compact.add([epoch, h.condition, h.precipitationChance,
                                     h.windSpeed, h.temperature]);
                    }
                }
                // Expired/out-of-coverage forecasts are not preserved as new.
                App.Storage.setValue("srGarminForecastV32659", [now, compact]);
                result = 1;
            }
        } catch (e) {
            // An unavailable Garmin Weather dataset never takes down the
            // live watch face. A previous valid sample can expire naturally.
        }
        Bg.exit(result);
    }
}
