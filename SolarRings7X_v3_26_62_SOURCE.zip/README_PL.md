# Solar Rings 7X v3.26.62 — Garmin Weather only (TEST)

Kontynuacja wersji Garmin-only: oczyszczenie pozostałości po AQI i nieużywanego kodu,
bez usuwania działających ikon, kolorów, lokalizacji, ustawień ani ostrzeżeń.
Ostrzeżenia TERAZ = czerwony; prognoza = turkus; TERAZ i prognoza =
czerwony z turkusową kreską. Prognoza Garmin 1–3 h działa przez jedyne
zadanie Background co 5 min, bez zewnętrznego API.

Oszczędzanie baterii:
- Zredukowano systemowe odczyty bieżącej pogody przy wzbudzeniu tarczy.
- Wyeliminowano niepotrzebne pełne odświeżenie UI po zadaniu Background.
- Wyłączone ostrzeżenia / prognoza nie odczytują godzinowej tablicy Garmin.
- Zachowano tanią częściową rotację ikonek tylko przy >3 zagrożeniach.
- Bez nocnych timerów, wymuszonych odczytów HTTP i osobnej funkcji sleep.

Zachowano identyfikator aplikacji, a klucze widocznych ustawień nie uległy
zmianie. Pamięć ustawień nie jest modyfikowana wewnątrz onSettingsChanged().

UWAGA: Projekt jest kandydatem testowym. Kontrola kodu i XML nie zastępuje
kompilacji Monkey C, testów pamięci i 24-godzinnego pomiaru baterii.

## Zwykły deszcz i śnieg
Domyślnie zarówno zwykłe, lekkie, jak i intensywne opady wyzwalają
ostrzeżenia (gwRainHeavyV332=false, gwSnowHeavyV332=false).
W prognozie niepewne kody CHANCE_OF_* podlegają wybranej czułości
procentowej; jawne kody opadu Garmin (lekkie, zwykłe, intensywne)
nie są ukrywane przez ogólny procent opadu.
Harmonogram co 5 min dotyczy tylko ODCZYTU już dostępnych danych
Garmina, nie pobierania pogody z sieci.

## Harmonogram ostrzeżeń v3.26.62
- Bieżące ostrzeżenia: analiza aktualnych danych Garmina raz na 300 sekund.
- Prognoza godzinowa 1–3 h: jeden Background temporal event co 300 sekund.
- Garmin decyduje o czasie faktycznej aktualizacji danych pogodowych;
  częstszy odczyt nie zwiększa częstotliwości odświeżania źródła.
- Pole zmiany interwału zniknęło z ustawień, ponieważ wybór 15/30/60
  minut byłby niezgodny ze stałą częstotliwością 5 minut.
- Odczyt bieżącej pogody dla temperatury pozostaje buforowany przez 55 s,
  co pozwala aktualizować temperaturę w normalnym rytmie minutowym.
- W stanie nieaktywnym tarczy Garmin może opóźnić pracę zadania w tle.
- Bez kompilacji Garmin SDK i testu na urządzeniu stabilność jest niepotwierdzona.
