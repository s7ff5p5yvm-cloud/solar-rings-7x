# Garmin Weather: pełny audyt kodów 0–53 (v3.26.62)

Źródło: https://developer.garmin.com/connect-iq/api-docs/Toybox/Weather.html

To klasyfikacja warunków Garmin, nie oficjalne alerty RCB/IMGW.

| Kod | Garmin CONDITION_* | Zachowanie |
|---:|---|---|
| 0 | `CLEAR` | Bez ostrzeżenia meteorologicznego |
| 1 | `PARTLY_CLOUDY` | Bez ostrzeżenia meteorologicznego |
| 2 | `MOSTLY_CLOUDY` | Bez ostrzeżenia meteorologicznego |
| 3 | `RAIN` | Deszcz zależnie od ustawienia i intensywności |
| 4 | `SNOW` | Śnieg zależnie od ustawienia i intensywności |
| 5 | `WINDY` | Wiatr (wg progu) / gwałtowne zjawisko |
| 6 | `THUNDERSTORMS` | Burza (kody szansy tylko w prognozie) |
| 7 | `WINTRY_MIX` | Opady mieszane (jeden symbol) |
| 8 | `FOG` | Mgła lub zmniejszona widoczność |
| 9 | `HAZY` | Mgła lub zmniejszona widoczność |
| 10 | `HAIL` | Grad |
| 11 | `SCATTERED_SHOWERS` | Deszcz zależnie od ustawienia i intensywności |
| 12 | `SCATTERED_THUNDERSTORMS` | Burza (kody szansy tylko w prognozie) |
| 13 | `UNKNOWN_PRECIPITATION` | Nieokreślony opad: bez ostrzeżenia |
| 14 | `LIGHT_RAIN` | Deszcz zależnie od ustawienia i intensywności |
| 15 | `HEAVY_RAIN` | Deszcz zależnie od ustawienia i intensywności |
| 16 | `LIGHT_SNOW` | Śnieg zależnie od ustawienia i intensywności |
| 17 | `HEAVY_SNOW` | Śnieg zależnie od ustawienia i intensywności |
| 18 | `LIGHT_RAIN_SNOW` | Opady mieszane (jeden symbol) |
| 19 | `HEAVY_RAIN_SNOW` | Opady mieszane (jeden symbol) |
| 20 | `CLOUDY` | Bez ostrzeżenia meteorologicznego |
| 21 | `RAIN_SNOW` | Opady mieszane (jeden symbol) |
| 22 | `PARTLY_CLEAR` | Bez ostrzeżenia meteorologicznego |
| 23 | `MOSTLY_CLEAR` | Bez ostrzeżenia meteorologicznego |
| 24 | `LIGHT_SHOWERS` | Deszcz zależnie od ustawienia i intensywności |
| 25 | `SHOWERS` | Deszcz zależnie od ustawienia i intensywności |
| 26 | `HEAVY_SHOWERS` | Deszcz zależnie od ustawienia i intensywności |
| 27 | `CHANCE_OF_SHOWERS` | Deszcz zależnie od ustawienia i intensywności |
| 28 | `CHANCE_OF_THUNDERSTORMS` | Burza (kody szansy tylko w prognozie) |
| 29 | `MIST` | Mgła lub zmniejszona widoczność |
| 30 | `DUST` | Zamieć pyłowa/dym (nie AQI) |
| 31 | `DRIZZLE` | Deszcz zależnie od ustawienia i intensywności |
| 32 | `TORNADO` | Wiatr (wg progu) / gwałtowne zjawisko |
| 33 | `SMOKE` | Zamieć pyłowa/dym (nie AQI) |
| 34 | `ICE` | Oblodzenie i marznący deszcz (rozdzielone) |
| 35 | `SAND` | Zamieć pyłowa/dym (nie AQI) |
| 36 | `SQUALL` | Wiatr (wg progu) / gwałtowne zjawisko |
| 37 | `SANDSTORM` | Zamieć pyłowa/dym (nie AQI) |
| 38 | `VOLCANIC_ASH` | Zamieć pyłowa/dym (nie AQI) |
| 39 | `HAZE` | Mgła lub zmniejszona widoczność |
| 40 | `FAIR` | Bez ostrzeżenia meteorologicznego |
| 41 | `HURRICANE` | Wiatr (wg progu) / gwałtowne zjawisko |
| 42 | `TROPICAL_STORM` | Wiatr (wg progu) / gwałtowne zjawisko |
| 43 | `CHANCE_OF_SNOW` | Śnieg zależnie od ustawienia i intensywności |
| 44 | `CHANCE_OF_RAIN_SNOW` | Opady mieszane (jeden symbol) |
| 45 | `CLOUDY_CHANCE_OF_RAIN` | Deszcz zależnie od ustawienia i intensywności |
| 46 | `CLOUDY_CHANCE_OF_SNOW` | Śnieg zależnie od ustawienia i intensywności |
| 47 | `CLOUDY_CHANCE_OF_RAIN_SNOW` | Opady mieszane (jeden symbol) |
| 48 | `FLURRIES` | Śnieg zależnie od ustawienia i intensywności |
| 49 | `FREEZING_RAIN` | Oblodzenie i marznący deszcz (rozdzielone) |
| 50 | `SLEET` | Opady mieszane (jeden symbol) |
| 51 | `ICE_SNOW` | Opady mieszane (jeden symbol) |
| 52 | `THIN_CLOUDS` | Bez ostrzeżenia meteorologicznego |
| 53 | `UNKNOWN` | Bez ostrzeżenia meteorologicznego |

## Zasady ostrzeżeń

- TERAZ: świeży odczyt Garmin -> czerwony; odczyt 45–90 min -> szary (nie udajemy ostrzeżenia bieżącego).
- 1–3 h: turkus; ten sam typ TERAZ i 1–3 h: czerwony z turkusową kreską.
- Jawne kody `RAIN`, `LIGHT_RAIN`, `SNOW`, `LIGHT_SNOW` oraz `HEAVY_*` nie są ukrywane przez ogólny procent opadów.
- Zwykły deszcz/śnieg/opad mieszany: działa opcja "tylko intensywne"; próg procentowy dotyczy niepewnych kodów `CHANCE_OF_*` (jeśli Garmin podaje prawidłową wartość).
- `CHANCE_OF_*`: nie podnosi ostrzeżenia TERAZ; działa wyłącznie w prognozie.
- `WINDY`: próg prędkości z Garmin Weather, jeśli prędkość dostępna; w razie braku prędkości sam kod WINDY.
- `FOG`: kod wystarczy; `MIST`, `HAZY`, `HAZE`: same nie oznaczają mgły bez potwierdzonej niskiej widoczności.
- Prędkość wiatru z prognozy jest dostępna, ale porywy nie; nie przewidujemy alertu porywów.
- Godzinowa prognoza nie zawiera widoczności, więc mgłę prognozowaną rozpoznajemy po kodzie FOG.
- `FREEZING_RAIN` i `HAIL` to osobne alerty, `UNKNOWN_PRECIPITATION` nie zgaduje rodzaju opadu.
- Kody pył/dym/piasek/popiół oznaczają zjawisko pogodowe, NIE wskaźnik AQI.
- Nieznane przyszłe kody Garmin pozostają neutralne.
- Garmin aktualizuje dane systemowo; 5-minutowy odczyt prognozy przez tarczę nie wymusza pobrania nowej pogody.
