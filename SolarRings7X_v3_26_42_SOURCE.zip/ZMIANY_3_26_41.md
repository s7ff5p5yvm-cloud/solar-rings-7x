# Solar Rings 7X v3.26.41 — eksperymentalny SWAP OWM -> Open-Meteo

Punkt wyjścia: **potwierdzona stabilna 3.26.37** (bez zmian w pliku oryginalnym).

- Dwa tryby: Garmin Weather (0), Open-Meteo (1). OpenWeatherMap i jego parser JSON usunięte z binarium.
- Open-Meteo `models=best_match`, współrzędne z dotychczasowego systemu, bez klucza API.
- Prognoza 15-minutowa do trzech godzin z ostrożnym fallback na godzinową; tylko jeden request na uruchomienie zadania.
- Osobne API European AQI; UV i porywy, mgła, opady marznące i grad WMO 96/99.
- Rozkład i obliczenia pokrętła, większej godziny, baterii 0.1% oraz kapsuł BEZ ZMIAN wobec 3.26.37.
- Photon nie blokuje się przez 3-24 h, kolejka geokodowania nie ulega zagłodzeniu przez pobieranie bieżącej pogody; TEST 21 pokazuje etap / HTTP / kolejną próbę.
- Starsze prognozy OWM nie są przedstawiane jako Open-Meteo przy pierwszym uruchomieniu po aktualizacji.
- **Wersja testowa.** Brak potwierdzenia kompilacji SDK i testów fizycznych. Zapisane ustawienie wyboru OWM (1) po aktualizacji oznacza już Open-Meteo.
