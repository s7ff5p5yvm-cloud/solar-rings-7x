import unittest, pathlib, re, xml.etree.ElementTree as ET
P=pathlib.Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
D=(P/'source/SolarOpenData.mc').read_text()
G=(P/'source/WeatherGeocode.mc').read_text()
F=(P/'source/SolarRings7X.mc').read_text()
W=(P/'source/SolarOpenWarnings.mc').read_text()
S=(P/'resources/settings/settings.xml').read_text()
STR=(P/'resources/strings.xml').read_text()
class ReplacementRegression(unittest.TestCase):
    def test_version_and_same_app_identifier(self):
        m=ET.parse(P/'manifest.xml').getroot()
        a=m.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(a.attrib['version'],'3.26.42')
        self.assertEqual(a.attrib['id'],'D1F8E1A4B7FC45BD91E8F0A0959041BF')
    def test_no_owm_http_endpoint_or_key_needed(self):
        self.assertNotIn('api.openweathermap.org',N)
        self.assertNotIn('"appid"',N)
        self.assertIn('function srOwmKeyReady() {\n    return true;',D)
        self.assertNotIn('propertyKey="@Properties.srOpenKeyV326"',S)
    def test_two_sources_and_legacy_choice_reused(self):
        self.assertIn('value="0">@Strings.sr_source_garmin',S)
        self.assertIn('value="1">@Strings.sr_source_open',S)
        self.assertNotIn('value="2">@Strings.sr_source',S)
        self.assertIn('Open-Meteo (best_match)',STR)
        self.assertIn('if (provider != 1) {',N)
    def test_best_match_uses_actual_coords(self):
        self.assertIn('q["models"] = "best_match";',N)
        self.assertIn('"latitude" => _loc[0].format',N)
        self.assertIn('"longitude" => _loc[1].format',N)
        self.assertIn('https://api.open-meteo.com/v1/forecast',N)
    def test_air_separate_endpoint_no_extra_timer(self):
        self.assertIn('https://air-quality-api.open-meteo.com/v1/air-quality',N)
        self.assertIn('q["current"] = "european_aqi";',N)
        self.assertEqual(N.count('Comm.makeWebRequest('),2) # forecast OR Photon, exclusive per wake
        self.assertIn('startCityLookup();\n                return;',N)
    def test_15min_forecast_bounded_server_side(self):
        self.assertIn('q["forecast_minutely_15"] = "12";',N)
        self.assertIn('q["forecast_hours"] = "4";',N)
        self.assertIn('q["forecast_hours"] = "5";',N)
        self.assertIn('mini.size() >= (_shortRequest ? 12 : 5)',N)
        self.assertIn('forecastStorageKey()',N)
        self.assertIn('srOHoursV326',N)
    def test_weather_code_all_standard_wmo(self):
        mapping=N[N.index('function meteoId('):N.index('function meteoQuarterRain(')]
        wmo={0,1,2,3,45,48,51,53,55,56,57,61,63,65,66,67,71,73,75,77,80,81,82,85,86,95,96,97,99}
        for code in wmo:
            with self.subTest(code=code):
                self.assertRegex(mapping,r'\b'+str(code)+r'\b')
        self.assertIn('return null;',mapping)
    def test_hail_storm_freeze_uv_wind_fog(self):
        self.assertIn('code == 299',W)
        self.assertIn('gwHailOnV332',W)
        self.assertIn('addAlert(k, 8)',W)
        self.assertIn('gwFreezeOnV332',W)
        self.assertIn('gwUvOnV332',W)
        self.assertIn('gwWindOnV332',W)
        self.assertIn('gwFogOnV332',W)
        self.assertIn('wmo == 96 || wmo == 99',N)
    def test_same_data_layout_and_forecast_step(self):
        self.assertIn('var snapshot = [_loc[0], _loc[1], _now, tm.toNumber()',N)
        self.assertIn('meteoHourlyAt(hourlyExtra',N)
        self.assertIn('if (id == 299) { return Weather.CONDITION_HAIL; }',D)
    def test_migration_avoids_old_provider_data(self):
        self.assertIn('srOEngineV32641',D)
        self.assertIn('if (engineChanged || modeChanged) {',D)
        for key in ['srOCurrV326','srOHoursV326','srODayV326','srOAirV326']:
            self.assertIn(f'srOwmWrite("{key}", null);',D)
        self.assertIn('srOwmRead("srOEngineV32641") != 32641',D)
    def test_photon_cannot_starve_and_has_diagnostics(self):
        self.assertIn('if (cityLookupDue())',N)
        self.assertIn('if (!kindIs("current") || value("srOCurrV326") != null)',N)
        self.assertIn('"radius" => "5"',N)
        self.assertIn('srGDiagV32639',N)
        self.assertIn('if (page == 21)',F)
        self.assertIn('value="21">@Strings.gw_diag_21',S)
    def test_photon_no_three_hour_lockout(self):
        self.assertNotIn('3 * 3600',G[G.index('function retryLater('):G.index('function retryPhoneMissing(')])
        self.assertIn('minutes = failures == 1 ? 10',G)
        self.assertIn('http == 429',N)
    def test_foreground_does_not_fetch(self):
        self.assertNotIn('Comm.makeWebRequest(',F)
        self.assertNotIn('Bg.registerForTemporalEvent(',F[F.index('    function onUpdate(dc)'):])
    def test_system_state_still_stable_and_minimal(self):
        self.assertIn('99',F) # battery rendering still present
        self.assertIn('srUseOpenWeather()',F)
        self.assertIn('onUpdate(dc)',F)
    def test_aqi_5_level_contract(self):
        self.assertIn('var level = val <= 20 ? 1 : val <= 40 ? 2',N)
        self.assertIn('srOAirV326',N)
    def test_request_context_bounded_and_restored(self):
        self.assertIn('if (phase() == 0) { restoreRequestContext(); }',N)
        self.assertIn('r.size() != 6',N)
        self.assertIn('if (phase() == 0) { status(-19);',N)
    def test_stable_font_and_capsule_rendering_kept(self):
        # SHA-256 of the original 3.26.37 normal onUpdate drawing block: 2d5c1d8493a509e5d7bfa5756bc6b9df14377fa13f58f301d4ad8f3b1a4025eb
        token='        var clock = System.getClockTime();'
        end='        _srFrameSystemStats = null;\n    }'
        a=F.index(token,F.index('function onUpdate(dc)'))
        b=F.index(end,a)+len(end)
        import hashlib
        self.assertEqual(hashlib.sha256(F[a:b].encode()).hexdigest(),'2d5c1d8493a509e5d7bfa5756bc6b9df14377fa13f58f301d4ad8f3b1a4025eb')
        for marker in ['function drawBattery(', 'function capsule(', 'function outerProgressRing(']:
            self.assertIn(marker,F)
        self.assertIn('dc.drawRoundedRectangle(left, top, width, 39, 18)',F)
if __name__=='__main__': unittest.main()
