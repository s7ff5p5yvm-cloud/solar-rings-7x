import re, unittest, pathlib, xml.etree.ElementTree as ET, csv
P=pathlib.Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
D=(P/'source/SolarOpenData.mc').read_text()
F=(P/'source/SolarRings7X.mc').read_text()
S=(P/'resources/settings/settings.xml').read_text()
ST=(P/'resources/strings.xml').read_text()

class MeteoFullContract(unittest.TestCase):
    def test_all_codes_matrix_matches_wmo_mapping(self):
        with (P/'OPEN_METEO_WMO_MATRIX.csv').open() as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),29)
        block=N.split('function meteoId(',1)[1].split('function meteoQuarterRain(',1)[0]
        for r in rows:
            with self.subTest(wmo=r['wmo']):
                self.assertRegex(block,r'\b'+r['wmo']+r'\b')
                self.assertIn(r['internal_condition_id'],block)
    def test_no_remote_owm(self):
        self.assertNotIn('openweathermap.org',N)
        self.assertNotIn('appid',N)
        self.assertNotIn('srOpenKeyV326',N)
    def test_phone_labels_exclusive(self):
        self.assertNotIn('OpenWeather',ST)
        self.assertIn('Open-Meteo',ST)
        for i in range(16,21): self.assertIn(f'TEST {i}: Open-Meteo',ST)
        self.assertIn('TEST 21 - Photon',ST)
    def test_provider_two_modes_only(self):
        self.assertIn('provider == 1',N)
        self.assertNotIn('provider == 2',N)
        self.assertIn('q["models"] = "best_match";',N)
    def test_current_hourly_uv_wind_aqi_fog(self):
        self.assertIn('"uv_index"',N)
        self.assertIn('wind_gusts_10m',N)
        self.assertIn('visibility',N)
        self.assertIn('european_aqi',N)
        self.assertIn('apparent_temperature',N)
    def test_full_diagnostics(self):
        self.assertIn('if (page == 21)',F)
        for i in range(16,22):
            self.assertIn(f'value="{i}">@Strings.gw_diag_{i}',S)
        self.assertIn('WMO TERAZ',F)
        self.assertIn('WMO PROG',F)
        self.assertIn('M1 JSON 2 ODP',F)
    def test_engine_migration(self):
        self.assertIn('srOEngineV32641',D)
        self.assertIn('if (engineChanged || modeChanged)',D)
        self.assertIn('srOwmRead("srOEngineV32641") != 32641',D)
    def test_no_network_in_face_update(self):
        section=F.split('function onUpdate(dc)',1)[1]
        self.assertNotIn('makeWebRequest',section)
    def test_risk_markers(self):
        self.assertIn('cityLookupDue()',N)
        self.assertIn('srGDiagV32639',N)
        self.assertIn('limit" => "3',N)
        self.assertNotIn('3 * 3600',N[N.index('function cityRetry('):N.index('function cityLookupDue(')])
