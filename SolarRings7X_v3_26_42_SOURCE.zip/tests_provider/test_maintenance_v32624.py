"""Static safety contracts for 3.26.24. Tests do not execute Garmin SDK/Monkey C."""
from pathlib import Path
import re,unittest
P=Path(__file__).resolve().parents[1]
NET=(P/'source/SolarOpenNetwork.mc').read_text()
FACE=(P/'source/SolarRings7X.mc').read_text()
FIELDS=(P/'source/FieldData.mc').read_text()
CITY=(P/'source/WeatherCity.mc').read_text()
MANIFEST=(P/'manifest.xml').read_text()
SETTINGS=(P/'resources/settings/settings.xml').read_text()

class Maintenance32624(unittest.TestCase):
    def test_sleep_window_is_local_and_no_request(self):
        self.assertIn('hour >= 22 || hour < 6',NET)
        self.assertIn('if (nightWindow()) { waitForMorning(); return; }',NET)
        self.assertTrue(NET.index('if (nightWindow())') < NET.index('Comm.makeWebRequest('))
        self.assertIn('Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(seconds)))',NET)
        self.assertIn('if (seconds > 2 * 3600) { seconds = 2 * 3600; }',NET)
        self.assertNotIn('isSleepMode',NET)
    def test_retry_ble_does_not_disable_short_forecast(self):
        self.assertIn('var pause = code == -12 ? 5 * 60 : 60 * 60;',NET)
        self.assertIn('code != -12 && code != 401',NET)
        self.assertIn('pause = 6 * 3600;',NET)
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
    def test_diagnostics_still_visible_on_error(self):
        self.assertIn('if (stage != 18 && stage < 90 && trace < 16) { return; }',NET)
        self.assertIn('code != 200 || setting("gwPreviewV332", 0) >= 16',NET)
        self.assertIn('diagWrite(endpointKey(p)',NET)
        self.assertIn('status(code);',NET)
    def test_per_field_reuse_has_no_shared_alias(self):
        self.assertIn('var _srFieldOutput = {};',FIELDS)
        self.assertIn('var entry = _srFieldOutput[id];',FIELDS)
        self.assertIn('entry[0] = label;',FIELDS)
        part=FIELDS.split('function readField(id, info, w)')[1].split('// Concise 280px-friendly')[0]
        self.assertNotIn('return [',part)
        self.assertGreaterEqual(part.count('srFieldReuse(id'),35)
    def test_moon_city_cache_and_early_reject(self):
        self.assertIn('storedKeyLat',FACE)
        self.assertIn('_locationCache[0] == keyLat', FACE)
        self.assertIn('_locationCache[0] == storedKeyLat', FACE)
        self.assertIn('_locationCache = [storedKeyLat, storedKeyLon, location];',FACE)
        self.assertIn('dy > 30.0d || dy < -30.0d',CITY)
        self.assertIn('dx > 30.0d || dx < -30.0d',CITY)
    def test_visual_stability_and_alerts(self):
        self.assertIn('var requested = 94;',FACE)
        self.assertIn('var labelWidth = 105;',FACE)
        self.assertIn('lowerCenter = 179;',FACE)
        self.assertIn('var centers = [68, 91, 114];',FACE)
        self.assertNotIn('new StormGuard()',FACE)
    def test_release_integrity(self):
        self.assertIn('version="3.26.42"',MANIFEST)
        self.assertIn('D1F8E1A4B7FC45BD91E8F0A0959041BF',MANIFEST)
        self.assertNotIn('srpressure',SETTINGS.lower())
        self.assertIn('gwstormonv332', SETTINGS.lower())  # Genuine weather thunder remains
if __name__=='__main__': unittest.main()
