"""Specific regressions drawn from CIQ logs. Static tests cannot prove watch runtime safety."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
C=(ROOT/'source/Config.mc').read_text()
G=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
O=(ROOT/'source/SolarOpenWarnings.mc').read_text()
F=(ROOT/'source/SolarRings7X.mc').read_text()
B=(ROOT/'source/WeatherGeocode.mc').read_text()
N=(ROOT/'source/SolarOpenNetwork.mc').read_text()

class SettingsCrashRegression(unittest.TestCase):
    def test_invalidate_settings_cache_without_allocating_dictionary(self):
        self.assertIn('_srSettingCache = null;',C)
        self.assertIn('if (_srSettingCache == null) { _srSettingCache = {}; }',C)
        self.assertIn('value = srSettingTyped(value, fallback);',C)
        self.assertLess(C.index('value = srSettingTyped(value, fallback);'),C.index('_srSettingCache[key] = value;'))

    def test_invalid_provider_types_fallback_and_background_all_callbacks(self):
        self.assertIn('function selectedProvider()',B)
        self.assertIn('value.toNumber() == 1 ? 1 : 0',B)
        self.assertEqual(B.count('selectedProvider()'),4)
        self.assertIn('if (provider == 1)',B)
        self.assertIn('if (provider != 1)',N)
        self.assertNotIn('if (provider == 2)',B)

    def test_foreground_never_bulk_resets_storage_on_settings_changed(self):
        self.assertNotIn('srOwmProviderChanged()',F)
        self.assertIn('srOwmProviderChanged();',N)
        self.assertNotIn('srOwmProviderChanged();',F.split('function getInitialView()')[1].split('function onStart(')[0])
        self.assertNotIn('srOwmProviderChanged();',F.split('function refreshChangedSettings()')[1].split('function rebuildWeatherWarnings()')[0])
        self.assertIn('if (open) {',F)

    def test_weather_cadence_switch_is_applied_in_background(self):
        self.assertIn('value("srORefreshV3263") != configuredInterval',N)
        self.assertIn('value("srOShortEnabledV3264") != configuredShort',N)
        self.assertIn('srOwmProviderChanged();',N)

    def test_hourly_garmin_uses_preloaded_rules_and_memory_guard(self):
        self.assertIn('function prepareRules()',G)
        w=G.split('function warning(current)')[1].split('function allWarnings(current)')[0]
        self.assertIn('prepareRules();',w)
        eval_=G.split('function evaluate(current, now)')[1]
        self.assertLess(eval_.index('if (!rule(20))'),eval_.index('Weather.getHourlyForecast()'))
        self.assertLess(eval_.index('freeBeforeHourly < 51200'),eval_.index('Weather.getHourlyForecast()'))
        self.assertIn('var horizon = rule(21);',eval_)
        self.assertIn('_ruleValues = null;',w)

    def test_inherited_open_meteo_rule_methods_work_without_preload(self):
        self.assertIn('class SolarOpenWarnings extends GarminWeatherWarnings',O)
        self.assertIn('_ruleValues == null ? srSetting("srPrecipModeV3263", 1)',G)
        self.assertIn('_ruleValues == null ? srSetting("gwIceChanceV332", 50)',G)

    def test_font_guard_before_settings_refresh(self):
        on=F.split('function onUpdate(dc)')[1].split('dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);')[0]
        self.assertIn('freeMemory < 35000',on)
        self.assertLess(on.index('freeMemory < 35000'),on.index('refreshChangedSettings();'))

    def test_preserve_existing_open_meteo_and_photon(self):
        self.assertIn('best_match',N)
        self.assertIn('photon.komoot.io/reverse',B)
        self.assertIn('srGDiagV32639',B)
        self.assertIn('OPEN_METEO_WMO',str(ROOT/'OPEN_METEO_WMO_MATRIX.csv'))

if __name__=='__main__':unittest.main()
