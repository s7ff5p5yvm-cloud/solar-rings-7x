# Solar Rings 7X — v3.26.42 TEST (Open-Meteo zamiast OWM)

**Stabilna 3.26.37 pozostaje osobnym archiwum, bez zmian.**

Dostawcy: Garmin Weather (0) i Open-Meteo `best_match` (1). Nie trzeba klucza API.
OWM HTTP i parser usunięte. Wewnętrzne klucze `srO*` i `srOwm*` pozostają dla
kompatybilności z ustawieniami — nie oznacza to uruchamiania OWM.

- Temperatura / odczuwalna / wilgotność / wiatr / porywy / UV / widzialność / ciśnienie.
- Kody WMO (29 standardowych kodów łącznie z 97), tłumaczenie na istniejące ostrzeżenia: deszcz, śnieg, burza, grad (tylko 96/99), marznący deszcz i mżawka, mgła.
- AQI z osobnego API Open-Meteo; 5-stopniowy próg w ustawieniach.
- Krótka prognoza 15-minutowa (gdy API zwraca dane) z przejściem na 1h.
- Test 15: godziny i ostrzeżenia; 16–20: status HTTP i pamięci danych Open-Meteo; 21: Photon.
- Photon: jedna próba na uruchomienie zadania, 10/20/30/60 minut przy błędach, HTTP 429: 60 minut.
- Silnik i geometria wyświetlania 3.26.37 nie zostały przebudowane.
- Dane OWM z wcześniejszego builda są odrzucane po migracji.

**Status:** sprawdzenie źródeł i testy regresyjne; bez potwierdzonej kompilacji Garmin SDK i bez testu na zegarku.

Dodatkowe poprawki: `ZMIANY_3_26_42.md`.
