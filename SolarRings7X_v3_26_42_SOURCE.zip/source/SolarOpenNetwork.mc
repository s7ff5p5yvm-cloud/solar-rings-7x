using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;
using Toybox.System as Sys;
using Toybox.Time as Time;

// Solar Rings 7X v3.26.41: two providers, ONE background pipeline.
// Background code contains ONLY Open-Meteo/Photon; the old OWM network and
// parser are deliberately absent to limit runtime memory usage.
(:background)
class SolarOpenNetwork {
    var _kind;
    var _loc;
    var _now;
    var _interval;
    var _unsafe;
    var _shortEnabled;
    var _shortRequest;
    var _meteo;
    var _diagStep;
    var _diagMask;
    var _diagRows;
    var _diagAccepted;
    var _diagAge;
    var _pausedStatus;
    var _pausedKnown;
    function initialize() {
        _kind = "";
        _loc = null;
        _now = 0;
        _interval = 30;
        _unsafe = false;
        _shortEnabled = true;
        _shortRequest = false;
        _meteo = false;
        _diagStep = 0;
        _diagMask = 0;
        _diagRows = 0;
        _diagAccepted = 0;
        _diagAge = 0;
        _pausedStatus = null;
        _pausedKnown = false;
    }
    function setting(key, fallback) {
        try {
            var v = App.Properties.getValue(key);
            if (v == null) { return fallback; }
            if (fallback instanceof Lang.Number) {
                if (v instanceof Lang.Number) { return v; }
                if (v instanceof Lang.String || v instanceof Lang.Float ||
                    v instanceof Lang.Double || v instanceof Lang.Long) {
                    var parsed = v.toNumber();
                    return parsed instanceof Lang.Number ? parsed : fallback;
                }
                return fallback;
            }
            if (fallback instanceof Lang.Boolean) {
                if (v instanceof Lang.Boolean) { return v; }
                if (v instanceof Lang.Number) { return v != 0; }
                if (v instanceof Lang.String) {
                    if (v.equals("true") || v.equals("1")) { return true; }
                    if (v.equals("false") || v.equals("0")) { return false; }
                }
                return fallback;
            }
            if (fallback instanceof Lang.String) {
                return v instanceof Lang.String ? v : fallback;
            }
            return v;
        } catch (e) { return fallback; }
    }
    function num(v) {
        return v != null && (v instanceof Lang.Number || v instanceof Lang.Long ||
                             v instanceof Lang.Float || v instanceof Lang.Double);
    }
    function value(key) {
        try { return App.Storage.getValue(key); } catch (e) { return null; }
    }
    function write(key, v) {
        try {
            if (App.Storage.getValue(key) != v) { App.Storage.setValue(key, v); }
            return true;
        } catch (e) { _unsafe = true; return false; }
    }
    // Logging is best-effort. Failures of diagnostic storage MUST NOT mark
    // the entire meteorological update unsafe or stop normal weather writes.
    function diagWrite(key, v) {
        try { App.Storage.setValue(key, v); } catch (e) { }
    }
    function coords(v) {
        return v != null && v instanceof Lang.Array && v.size() >= 2 &&
            num(v[0]) && num(v[1]) && v[0] >= -90 && v[0] <= 90 &&
            v[1] >= -180 && v[1] <= 180;
    }
    function same(a, b) {
        return coords(a) && coords(b) &&
            a[0] > b[0] - 0.025d && a[0] < b[0] + 0.025d &&
            a[1] > b[1] - 0.035d && a[1] < b[1] + 0.035d;
    }
    // Garmin's scheduled sleep / wake events are the primary source of truth.
    // App-level WatchFace low-power callbacks do not indicate bedtime.
    // Manual sleep toggles are not exposed reliably by Connect IQ. Only if
    // events are missing/stale do we use the old local 22:00-06:00 fallback.
    function nightWindow() {
        try {
            var state = value("srOSleepStateV32624");
            if (state instanceof Lang.Array && state.size() == 2 &&
                num(state[0]) && num(state[1])) {
                var age = Time.now().value() - state[1];
                if (age >= 0 && age < (state[0] == 1 ? 12 * 3600 : 25 * 3600)) {
                    return state[0] == 1;
                }
            }
        } catch (e) { }
        try {
            var hour = Sys.getClockTime().hour;
            return hour >= 22 || hour < 6;
        } catch (e2) { return false; }
    }
    function waitForMorning() {
        // Wake event will reschedule the actual next weather query. The
        // watchdog checks for missed events and guarantees eventual recovery.
        var seconds = 2 * 3600;
        try {
            var state = value("srOSleepStateV32624");
            if (!(state instanceof Lang.Array && state.size() == 2 &&
                  num(state[0]) && state[0] == 1 && num(state[1]) &&
                  Time.now().value() - state[1] < 12 * 3600 &&
                  Time.now().value() >= state[1])) {
                // Fallback for a newly installed app or unsupported events.
                var c = Sys.getClockTime();
                var hours = c.hour >= 22 ? 30 - c.hour : 6 - c.hour;
                seconds = hours * 3600 - c.min * 60 - c.sec;
            }
            if (seconds < 300) { seconds = 300; }
            if (seconds > 2 * 3600) { seconds = 2 * 3600; }
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(seconds)));
        } catch (e) {
            try { Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(30 * 60))); }
            catch (e2) { }
        }
        Bg.exit(["OWM", 0]);
    }
    function deadline(key, snapshot, duration) {
        var d = value(key);
        if (!num(d) || d < 0 || d > _now + 48 * 3600) { d = 0; }
        var s = value(snapshot);
        if (same(s, _loc) && s.size() >= 3 && num(s[2]) &&
            s[2] <= _now && _now - s[2] <= 10800 &&
            s[2] + duration > d) { d = s[2] + duration; }
        return d;
    }
    function forecastStorageKey() {
        if (!_pausedKnown) {
            _pausedStatus = value("srOShortPausedV3264");
            _pausedKnown = true;
        }
        var paused = _pausedStatus;
        if (_shortEnabled && (!num(paused) || paused <= _now)) {
            return "srOShortV3264";
        }
        return "srOHoursV326";
    }
    // The 5-minute high-freshness profile uses ONE endpoint per Garmin
    // background wake (minimum 5 minutes), not one request per endpoint.
    // Current and short forecasts target 10-minute freshness to avoid redundant network
    // traffic. Open-Meteo model runs are not updated every five minutes. AQI and daily
    // retain hourly/12-hour cadences. 5-minute slots are shared fairly.
    function currentSeconds() {
        return _interval == 5 ? 10 * 60 : _interval * 60;
    }
    function forecastSeconds() {
        return _interval == 5 ? 10 * 60 : _interval * 120;
    }
    function schedule() {
        var now = Time.now().value();
        var earliest = deadline("srONextCV326", "srOCurrV326", currentSeconds());
        var f = deadline("srONextFV326", forecastStorageKey(), forecastSeconds());
        if (earliest == 0 || f < earliest) { earliest = f; }
        var daily = deadline("srONextDV326", "srODayV326", 12 * 3600);
        if (earliest == 0 || daily < earliest) { earliest = daily; }
        if (setting("srOwmAirV326", false)) {
            var a = deadline("srONextAV326", "srOAirV326", 3600);
            if (earliest == 0 || a < earliest) { earliest = a; }
        }
        var seconds = earliest - now;
        if (seconds < 300) { seconds = 300; }
        if (seconds > 6 * 3600) { seconds = 6 * 3600; }
        if (_unsafe) { seconds = 6 * 3600; }
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(seconds)));
        } catch (e) { _diagStep = 90; status(-222); }
    }
    // Endpoint index: 0=position, 1=current, 2=forecast, 3=daily, 4=AQI.
    // Diagnostic result uses HTTP code or a small local negative code.
    // Durable pipeline breadcrumbs: [epoch, gate, endpoint, currentWaitSec, forecastWaitSec].
    // Each gate is a concrete stage, not a guessed HTTP or GPS error.
    // Bounded numeric-only record, no token, URL, response text or coordinates.
    function gate(stage) {
        var trace = setting("gwPreviewV332", 0);
        if (stage != 18 && stage < 90 && trace < 16) { return; }
        var now = Time.now().value();
        var c = value("srONextCV326");
        var f = value("srONextFV326");
        var cw = -1;
        var fw = -1;
        if (num(c) && c > 0) { cw = c.toNumber() - now; }
        if (num(f) && f > 0) { fw = f.toNumber() - now; }
        // No persistent flash write at every internal stage in normal use.
        // Keep the request gate (needed for async callback recovery), terminal
        // failures and the verbose diagnostic mode.
        diagWrite("srODGateV3269", [now, stage, phase(), cw, fw]);
    }
    function runSafely() {
        try { start(); }
        catch (e) {
            // If anything fails before makeWebRequest or before its normal
            // error handler, retain a visible breadcrumb and retry safely.
            _diagStep = 91;
            gate(90);
            status(-230);
            try {
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(10 * 60)));
            } catch (e2) { }
            Bg.exit(["OWM", 0]);
        }
    }
    // Monkey C compares String references with ==; compare contents using equals().
    // Without this, every request can be labelled P0 and sent to the wrong endpoint.
    function kindIs(name) {
        return _kind instanceof Lang.String && _kind.equals(name);
    }
    function phase() {
        if (kindIs("current")) { return 1; }
        if (kindIs("forecast")) { return 2; }
        if (kindIs("daily")) { return 3; }
        if (kindIs("air")) { return 4; }
        return 0;
    }
    function endpointKey(p) {
        if (p == 1) { return "srODNowV3268"; }
        if (p == 2) { return "srODForecastV3268"; }
        if (p == 3) { return "srODDailyV3268"; }
        if (p == 4) { return "srODAirV3268"; }
        return "srODSystemV3268";
    }
    function status(code) {
        // Format of per-endpoint snapshot: [time, endpoint, stage, result,
        // structural flags, response records, accepted records, ageSec, 15m].
        // The legacy 3-field status remains readable by the old TEST 15.
        var p = phase();
        // Background can be killed/restarted during an async request. If
        // transient _kind is unavailable, use the last safely stored phase.
        if (p == 0 && code != 0) {
            var selected = value("srODGateV3269");
            if (selected instanceof Lang.Array && selected.size() == 5 &&
                num(selected[0]) && num(selected[2]) &&
                selected[0] <= Time.now().value() + 300 &&
                Time.now().value() - selected[0] <= 1800 &&
                selected[2] >= 1 && selected[2] <= 4) {
                p = selected[2];
            }
        }
        if (p == 0 && code != 0) {
            var ctx = value("srOReqCtxV3267");
            var tm = Time.now().value();
            if (ctx instanceof Lang.Array && ctx.size() == 6 &&
                num(ctx[0]) && num(ctx[1]) &&
                ctx[0] <= tm + 300 && tm - ctx[0] <= 1800 &&
                ctx[1] >= 1 && ctx[1] <= 4) { p = ctx[1]; }
        }
        var stamp = Time.now().value();
        diagWrite("srODiagV3266", [stamp, p, code]);
        diagWrite(endpointKey(p), [stamp, p, _diagStep, code, _diagMask,
                               _diagRows, _diagAccepted, _diagAge,
                               _shortRequest ? 1 : 0]);
        // Keep the last six terminal outcomes. Each entry is four integers.
        // Never retain the API token, request URL, location or response body.
        // Store failed attempts in full; successful requests already have a
        // per-endpoint status and need no duplicate history write every 5min.
        if (code != 100 && code != 0 &&
            (code != 200 || setting("gwPreviewV332", 0) >= 16)) {
            var old = value("srODHistoryV3268");
            var history = [];
            if (old instanceof Lang.Array) {
                var first = old.size() > 5 ? old.size() - 5 : 0;
                for (var i = first; i < old.size(); i++) {
                    if (old[i] instanceof Lang.Array && old[i].size() == 4) {
                        history.add(old[i]);
                    }
                }
            }
            history.add([stamp, p, code, _diagStep]);
            diagWrite("srODHistoryV3268", history);
        }
    }
    // A compact structural fingerprint, independent from the parser result.
    // Flags: 1=dict 2=array 4=nonempty 8=first record dict,
    // 16=dt 32=temp 64=weather ID 128=timezone 256=air.main.
    function restoreRequestContext() {
        var r = value("srOReqCtxV3267");
        var t = Time.now().value();
        if (!(r instanceof Lang.Array) || (r.size() != 6) ||
            !num(r[0]) || !num(r[1]) || !num(r[2]) || !num(r[3]) ||
            !num(r[4]) || !num(r[5]) || r[0] > t + 300 ||
            t - r[0] > 1800 || r[1] < 1 || r[1] > 4) { return false; }
        var pos = [r[2], r[3], r[0]];
        if (!coords(pos)) { return false; }
        _kind = r[1] == 1 ? "current" : r[1] == 2 ? "forecast" :
                r[1] == 3 ? "daily" : "air";
        // Request context has six fields (one provider), as in stable v3.26.37.
        _meteo = true;
        _now = r[0];
        _loc = pos;
        _interval = r[4];
        _shortRequest = r[5] == 1;
        return true;
    }
    function finish(changed) {
        var provider = setting("srProviderV326", 0);
        if (provider == 1) {
            schedule();
        }
        Bg.exit(["OWM", changed ? 1 : 0]);
    }
    function fail(code) {
        if (_diagStep < 20) { _diagStep = 12; }
        status(code);
        if (_shortRequest) { write("srOShortAttemptV3264", 0); }
        // A 15min endpoint failure must not disable the basic hourly alerts.
        // HTTP 401/403/429 are key/rate-limit problems; retrying the same
        // credentials against 1h would be wasteful. -403 is Garmin's network
        // out-of-memory error, NOT HTTP 403; fall back without a retry loop.
        if (kindIs("forecast") && _shortRequest &&
            code != -12 && code != 401 && code != 403 && code != 429) {
            write("srOShortPausedV3264", _now + 30 * 60);
            _pausedStatus = _now + 30 * 60;
            write("srONextFV326", _now + 10 * 60);
            finish(false);
            return;
        }
        // -12 is the watch's temporary BLE phone disconnection. Re-check
        // after 5min; no HTTP request was sent during the disconnect.
        var pause = code == -12 ? 5 * 60 : 60 * 60;
        if (code == 401 || code == 403 || code == 429 || code == -403) {
            pause = 6 * 3600;
        }
        if (kindIs("current")) { write("srONextCV326", _now + pause); }
        if (kindIs("forecast")) { write("srONextFV326", _now + pause); }
        if (kindIs("daily")) { write("srONextDV326", _now + pause); }
        if (kindIs("air")) { write("srONextAV326", _now + pause); }
        finish(false);
    }
    function reserveQuota() {
        var day = (_now / 86400).toNumber(); // UTC day
        var budget = value("srOBudgetV32613");
        var used = 0;
        if (budget instanceof Lang.Array && budget.size() == 2 &&
            num(budget[0]) && num(budget[1]) && budget[0] == day &&
            budget[1] >= 0 && budget[1] < 10000) {
            used = budget[1];
        }
        if (used >= 700) { return false; }
        // Reserve before makeWebRequest, including an unsuccessful attempt.
        return write("srOBudgetV32613", [day, used + 1]);
    }
    function start() {
        _now = Time.now().value();
        _diagStep = 10; // Background service actually woke.
        // Night suspension comes first: avoid diagnostic writes, flash I/O
        // and network calls while the sleep watch face is in use.
        if (nightWindow()) { waitForMorning(); return; }
        // Diagnostic wake time only while troubleshooting.
        if (setting("gwPreviewV332", 0) >= 16) {
            diagWrite("srODWakeV3268", _now);
        }
        gate(10);
        var provider = setting("srProviderV326", 0);
        _meteo = provider == 1;
        if (provider != 1) {
            gate(11);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        // Settings changed in Garmin Connect are applied in the background.
        // A weather interval or 15-minute forecast change must also update
        // the scheduler; do not do this work inside the watch-face redraw.
        var configuredInterval = setting("srOwmMinutesV326", 30);
        if (configuredInterval != 5 && configuredInterval != 15 &&
            configuredInterval != 30 && configuredInterval != 60) {
            configuredInterval = 30;
        }
        var configuredShort = setting("srOwm15MinV3264", true) == true;
        if (value("srOLastModeV326") != provider ||
            value("srOEngineV32641") != 32641 ||
            value("srORefreshV3263") != configuredInterval ||
            value("srOShortEnabledV3264") != configuredShort) {
            srOwmProviderChanged();
        }
        _loc = value("srOLocV326");
        // Use the last location seen on the face, even when a Garmin
        // weather observation is older than 3h. Never request data using
        // coordinates absent or not seen by the face for over 48h.
        if (!coords(_loc) || _loc.size() < 3 || !num(_loc[2]) ||
            _loc[2] > _now + 300 || _now - _loc[2] > 48 * 3600) {
            gate(13); status(-10);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        // One-time v3.26.39 migration: retire the old 3-24h Photon lockout.
        // Only the optional city geocoder is reset, never stored weather.
        if (value("srGPolicyV32639") != 1) {
            write("srGNextAt", 0);
            write("srGLastTry", 0);
            write("srGFail", 0);
            write("srGPolicyV32639", 1);
        }
        _interval = setting("srOwmMinutesV326", 30);
        if (_interval != 5 && _interval != 15 && _interval != 30 && _interval != 60) {
            _interval = 30;
        }
        _shortEnabled = setting("srOwm15MinV3264", true) == true;
        _pausedStatus = value("srOShortPausedV3264");
        _pausedKnown = true;
        var previousStatus = value("srODiagV3266");
        if (previousStatus instanceof Lang.Array && previousStatus.size() == 3 &&
            num(previousStatus[0]) && previousStatus[2] == 100 &&
            previousStatus[0] < _now - 8 * 60) {
            _diagStep = 90;
            status(-17);
            _diagStep = 10;
        }
        // Previous high-resolution call may have killed the background task
        // before any callback (e.g. JSON OOM). A stuck attempt triggers a
        // one-day circuit breaker instead of retrying the oversized payload.
        var orphaned = value("srOShortAttemptV3264");
        if (num(orphaned) && orphaned > 0 &&
            orphaned <= _now - 5 * 60 && orphaned >= _now - 24 * 3600) {
            write("srOShortPausedV3264", _now + 30 * 60);
            _pausedStatus = _now + 30 * 60;
            write("srONextFV326", 0);
        }
        if (num(orphaned) && orphaned > 0) {
            write("srOShortAttemptV3264", 0);
        }
        var nextC = deadline("srONextCV326", "srOCurrV326", currentSeconds());
        var nextF = deadline("srONextFV326", forecastStorageKey(), forecastSeconds());
        var nextD = deadline("srONextDV326", "srODayV326", 12 * 3600);
        var nextA = deadline("srONextAV326", "srOAirV326", 3600);
        if (_interval == 5) {
            // Earliest-due-first arbitration: prevents AQI/daily starvation
            // when current + forecast nearly saturate 5-minute wake slots.
            // Ties prefer current conditions and then short-term forecast.
            var oldest = _now + 1;
            if (nextC <= _now && nextC < oldest) {
                oldest = nextC; _kind = "current";
            }
            if (nextF <= _now && nextF < oldest) {
                oldest = nextF; _kind = "forecast";
            }
            if (nextD <= _now && nextD < oldest) {
                oldest = nextD; _kind = "daily";
            }
            if (setting("srOwmAirV326", false) &&
                nextA <= _now && nextA < oldest) {
                oldest = nextA; _kind = "air";
            }
        } else {
            if (nextC <= _now) { _kind = "current"; }
            else if (nextF <= _now) { _kind = "forecast"; }
            else if (nextD <= _now) { _kind = "daily"; }
            else if (setting("srOwmAirV326", false) && nextA <= _now) { _kind = "air"; }
        }
        // Look up the locality used for Open-Meteo request coordinates,
        // never the phone's GPS city. One small Photon request on an ordinary
        // weather wake, after CURRENT gets priority. No second background timer
        // and no additional HTTP request in the same wake.
        // Weather's first successful CURRENT has priority. Once cached,
        // a due city lookup gets a slot even if CURRENT becomes due again;
        // otherwise it could starve indefinitely in a 5-minute schedule.
        if (cityLookupDue()) {
            if (!Sys.getDeviceSettings().phoneConnected) {
                cityDiag(6, -12, 6);
            } else if (!kindIs("current") || value("srOCurrV326") != null) {
                startCityLookup();
                return;
            } else {
                cityDiag(1, 0, 0);
            }
        }
        if (kindIs("")) { gate(14); finish(false); return; }
        // Never send a request if the endpoint type is not known.
        if (phase() == 0) { gate(16); status(-232); finish(false); return; }
        gate(16); // Which endpoint was actually selected?
        if (!Sys.getDeviceSettings().phoneConnected) {
            gate(15); fail(-12); return;
        }
        // best_match selects model combinations for the actual coordinates.
        // All response sizes are limited at the SERVER before JSON parsing.
        var route = kindIs("air") ?
            "https://air-quality-api.open-meteo.com/v1/air-quality" :
            "https://api.open-meteo.com/v1/forecast";
        var q = {
            "latitude" => _loc[0].format("%.4f"),
            "longitude" => _loc[1].format("%.4f"),
            "timeformat" => "unixtime", "timezone" => "auto"
        };
        if (kindIs("air")) {
            q["current"] = "european_aqi";
        } else {
            q["models"] = "best_match";
            q["wind_speed_unit"] = "ms";
            if (kindIs("current")) {
                q["current"] = "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,wind_gusts_10m,cloud_cover,visibility,uv_index,surface_pressure";
                q["daily"] = "sunrise,sunset";
                q["forecast_days"] = "2";
            } else if (kindIs("forecast")) {
                _shortRequest = forecastStorageKey().equals("srOShortV3264");
                if (_shortRequest) {
                    q["minutely_15"] = "weather_code,rain,snowfall";
                    q["forecast_minutely_15"] = "12";
                    q["hourly"] = "temperature_2m,wind_speed_10m,wind_gusts_10m,visibility,precipitation_probability,uv_index";
                    q["forecast_hours"] = "4";
                } else {
                    q["hourly"] = "weather_code,temperature_2m,wind_speed_10m,wind_gusts_10m,visibility,precipitation_probability,uv_index,rain,snowfall";
                    q["forecast_hours"] = "5";
                }
            } else if (kindIs("daily")) {
                q["daily"] = "temperature_2m_min,temperature_2m_max";
                q["forecast_days"] = "1";
            }
        }
        // Conservative on-device total weather API budget (includes AQI).
        // User-configured request limits are not required for this free tier.
        if (!reserveQuota()) {
            _diagStep = 18; status(-234); finish(false); return;
        }
        // Protect against a missing callback or a killed background process.
        // A conservative deadline is persisted BEFORE the request, and a
        // one-shot 15-min watchdog is armed. Successful callback replaces the
        // watchdog with the normal schedule, without an extra persistent
        // write when the deadline remains the same.
        var nextKey = "srONextCV326";
        var nextEpoch = _now + currentSeconds();
        if (kindIs("forecast")) {
            nextKey = "srONextFV326";
            nextEpoch = _now + forecastSeconds();
        } else if (kindIs("daily")) {
            nextKey = "srONextDV326";
            nextEpoch = _now + 12 * 3600;
        } else if (kindIs("air")) {
            nextKey = "srONextAV326";
            nextEpoch = _now + 3600;
        }
        if (!write(nextKey, nextEpoch)) { status(-16); finish(false); return; }
        if (_shortRequest && !write("srOShortAttemptV3264", _now)) {
            finish(false); return;
        }
        // Persist just the request phase and location for callback recovery.
        var context = [_now, phase(), _loc[0], _loc[1],
                       _interval, _shortRequest ? 1 : 0];
        if (!write("srOReqCtxV3267", context)) {
            status(-154); finish(false); return;
        }
        gate(17); // Request context persisted.
        _diagStep = 20; // Request queued for Connect IQ.
        status(100);
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(15 * 60)));
        } catch (e) { fail(-221); return; }
        try {
            // The gate is persisted before the asynchronous network call.
            gate(18);
            Comm.makeWebRequest(route, q, {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            }, method(:onReceive));
        } catch (e) { fail(-220); }
    }
    // Use shared Garmin/Photon name cache and Open-Meteo request coordinates.
    // Never claim that a fallback city is an authoritative weather station.
    // Small, numbers-only diagnostic [UTC, provider, stage, HTTP, reason].
    // Stage 1=waiting, 2=sent, 3=response, 4=success, 5=failed,
    // 6=phone offline. Reason: 1=HTTP, 2=empty, 3=JSON,
    // 4=name, 5=changed position, 6=network, 7=exception, 8=timeout.
    function cityDiag(stage, http, reason) {
        diagWrite("srGDiagV32639", [_now, 1, stage, http, reason]);
    }
    function cityRetry(http, reason) {
        // Do not punish an offline device, empty village result or 5xx with 3h.
        var failures = value("srGFail");
        if (!num(failures) || failures < 0 || failures > 10) { failures = 0; }
        failures += 1;
        write("srGFail", failures);
        var seconds = failures <= 1 ? 10 * 60 : failures == 2 ? 20 * 60 : 30 * 60;
        if (http == 429) { seconds = 60 * 60; }
        write("srGNextAt", _now + seconds);
        cityDiag(5, http, reason);
    }
    function cityLookupDue() {
        try {
            var target = value("srGRequest");
            var known = value("srGResult");
            if (!coords(target) || !same(target, _loc)) { return false; }
            if (known instanceof Lang.Array && known.size() == 3 &&
                coords(known) && num(known[0]) && num(known[1]) &&
                target[0] > known[0] - 0.008d && target[0] < known[0] + 0.008d &&
                target[1] > known[1] - 0.012d && target[1] < known[1] + 0.012d &&
                known[2] instanceof Lang.String) { return false; }
            var next = value("srGNextAt");
            var last = value("srGLastTry");
            if (num(next) && next > _now) { return false; }
            if (num(last) && last > 0 && _now - last < 15 * 60) { return false; }
            return true;
        } catch (e) { return false; }
    }
    function startCityLookup() {
        // A single asynchronous network request; weather continues next wake.
        // Do NOT send Photon over disconnected BLE (old code locked for 3h).
        if (!Sys.getDeviceSettings().phoneConnected) {
            cityDiag(6, -12, 6);
            finish(false);
            return;
        }
        try {
            // Preserve the 15-minute fair-use spacing for successful retries.
            write("srGLastTry", _now);
            write("srGNextAt", _now + 15 * 60);
            cityDiag(2, 0, 0);
            var q = {
                "lat" => _loc[0].format("%.4f"),
                "lon" => _loc[1].format("%.4f"),
                "lang" => "pl",
                "osm_tag" => "place",
                "limit" => "3",
                // Photon's default radius may be only 1 km. A small village
                // can have no indexed settlement point within that radius.
                "radius" => "5"
            };
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(15 * 60)));
            Comm.makeWebRequest("https://photon.komoot.io/reverse", q, {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            }, method(:onCityReceive));
        } catch (e) {
            cityRetry(-1, 7);
            finish(false);
        }
    }
    function onCityReceive(code as Lang.Number,
        data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        var city = null;
        var reason = 0;
        var stamp = Time.now().value();
        _now = stamp;
        cityDiag(3, code, 0);
        try {
            if (code != 200) { reason = code < 0 ? 6 : 1; }
            else if (!(data instanceof Lang.Dictionary)) { reason = 3; }
            else {
                var list = data["features"];
                if (!(list instanceof Lang.Array) || list.size() == 0) {
                    reason = 2;
                } else {
                    // Find a valid populated settlement. Never use a road,
                    // hotel or shop's name as the locality.
                    for (var i = 0; i < list.size() && i < 3; i++) {
                        if (!(list[i] instanceof Lang.Dictionary)) { continue; }
                        var props = list[i]["properties"];
                        if (!(props instanceof Lang.Dictionary)) { continue; }
                        var key = props["osm_key"];
                        var name = props["name"];
                        if (key instanceof Lang.String && key.equals("place") &&
                            name instanceof Lang.String && name.length() >= 2 &&
                            name.length() <= 42) {
                            city = name.toUpper();
                            break;
                        }
                    }
                    if (city == null) { reason = 4; }
                }
            }
            if (city != null && (!same(_loc, value("srGRequest")) ||
                                 !same(_loc, value("srOLocV326")))) {
                city = null;
                reason = 5;
            }
            if (city != null) {
                write("srGResult", [_loc[0], _loc[1], city]);
                write("srGFail", 0);
                write("srGNextAt", _now + 30 * 60);
                cityDiag(4, 200, 0);
            } else {
                cityRetry(code, reason);
            }
        } catch (e) {
            cityRetry(code, 7);
            city = null;
        }
        finish(city != null);
    }
    function dictionary(v) { return v != null && v instanceof Lang.Dictionary; }
    function optionalNumber(d, k) {
        var v = d[k];
        return num(v) ? v : null;
    }
    function meteoId(wmo) {
        if (!num(wmo)) { return null; }
        if (wmo == 0) { return 800; }
        if (wmo == 1) { return 801; }
        if (wmo == 2) { return 803; }
        if (wmo == 3) { return 804; }
        if (wmo == 45 || wmo == 48) { return 741; }
        if (wmo == 51) { return 300; }
        if (wmo == 53) { return 301; }
        if (wmo == 55) { return 302; }
        if (wmo == 56 || wmo == 57 || wmo == 66 || wmo == 67) { return 511; }
        if (wmo == 61) { return 500; }
        if (wmo == 63) { return 501; }
        if (wmo == 65) { return 502; }
        if (wmo == 71) { return 600; }
        if (wmo == 73) { return 601; }
        if (wmo == 75) { return 602; }
        if (wmo == 77) { return 620; }
        if (wmo == 80) { return 520; }
        if (wmo == 81) { return 521; }
        if (wmo == 82) { return 522; }
        if (wmo == 85) { return 620; }
        if (wmo == 86) { return 622; }
        if (wmo == 95) { return 211; }
        if (wmo == 97) { return 212; }
        if (wmo == 96 || wmo == 99) { return 299; }
        return null;  // Unknown: fail closed rather than show misleading alerts.
    }
    
    // Open-Meteo 15-min rain amount is mm per quarter-hour, normalize
    // to OWM-style hourly rate (only a FORWARD forecast signal).
    function meteoQuarterRain(series, idx) {
        var r = meteoSeries(series, "rain", idx);
        return num(r) && r >= 0 && r <= 125 ? r * 4 : null;
    }
    // snowfall cm -> mm of snowfall per hour, never water equivalent.
    function meteoQuarterSnow(series, idx) {
        var r = meteoSeries(series, "snowfall", idx);
        return num(r) && r >= 0 && r <= 125 ? r * 40 : null;
    }
    function meteoSnowHour(series, idx) {
        var r = meteoSeries(series, "snowfall", idx);
        return num(r) && r >= 0 && r <= 500 ? r * 10 : null;
    }
    function meteoSeries(dict, key, idx) {
        if (!dictionary(dict)) { return null; }
        var a = dict[key];
        if (!(a instanceof Lang.Array) || idx < 0 || idx >= a.size()) { return null; }
        return num(a[idx]) ? a[idx] : null;
    }
    // The API's 15-minute rain/snow sums describe a time BUCKET; hourly
    // equivalents are for forecast intensity only, never a current sensor.
    function meteoRate(dict, key, idx) {
        var v = meteoSeries(dict, key, idx);
        if (!num(v) || v < 0) { return null; }
        return _shortRequest ? v * 4 : v;
    }
    // 15-minute rows use hourly UV and precipitation probability for their
    // enclosing hour. Never invent probabilities from WMO condition codes.
    // Only up to four hourly records are returned, so this linear scan is
    // cheaper than allocating a lookup Dictionary on the watch.
    function meteoHourlyAt(hourly, key, stamp) {
        if (!dictionary(hourly)) { return null; }
        var times = hourly["time"];
        var vals = hourly[key];
        if (!(times instanceof Lang.Array) || !(vals instanceof Lang.Array)) {
            return null;
        }
        var n = times.size();
        if (vals.size() < n) { n = vals.size(); }
        if (n > 5) { n = 5; }
        for (var j = 0; j < n; j++) {
            if (num(times[j]) && stamp >= times[j] && stamp < times[j] + 3600) {
                return num(vals[j]) ? vals[j] : null;
            }
        }
        return null;
    }
    function receiveMeteo(data) {
        if (!dictionary(data)) { fail(-301); return; }
        if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }
        var root = data as Lang.Dictionary;
        var ok = false;
        var reason = -303;
        _diagMask = 1; // JSON object
        _diagRows = 0;
        _diagAccepted = 0;
        _diagAge = 0;
        try {
            if (kindIs("current")) {
                var ob = root["current"];
                if (dictionary(ob)) {
                    _diagMask = _diagMask | 2;
                    var cur = ob as Lang.Dictionary;
                    var tm = optionalNumber(cur, "time");
                    var temp = optionalNumber(cur, "temperature_2m");
                    if (num(tm)) { _diagMask = _diagMask | 4; }
                    if (num(optionalNumber(cur, "weather_code"))) { _diagMask = _diagMask | 8; }
                    if (num(temp)) { _diagMask = _diagMask | 16; }
                    if (num(optionalNumber(cur, "uv_index"))) { _diagMask = _diagMask | 128; }
                    if (num(tm) && tm <= _now + 300 && _now - tm <= 5400 &&
                        num(temp) && temp > -100 && temp < 80) {
                        var rise = null;
                        var set = null;
                        var days = root["daily"];
                        if (dictionary(days)) {
                            rise = meteoSeries(days, "sunrise", 0);
                            set = meteoSeries(days, "sunset", 0);
                            if (num(rise) && num(set)) { _diagMask = _diagMask | 64; }
                        }
                        // Original 19-value weather snapshot layout unchanged.
                        // Current 15-minute precipitation sums do NOT prove rain now.
                        var snapshot = [_loc[0], _loc[1], _now, tm.toNumber(),
                            temp, optionalNumber(cur, "apparent_temperature"),
                            optionalNumber(cur, "wind_speed_10m"),
                            optionalNumber(cur, "relative_humidity_2m"),
                            optionalNumber(cur, "uv_index"),
                            optionalNumber(cur, "visibility"),
                            optionalNumber(cur, "cloud_cover"),
                            meteoId(optionalNumber(cur, "weather_code")),
                            optionalNumber(cur, "surface_pressure"), rise, set,
                            optionalNumber(cur, "wind_gusts_10m"), null, null, null];
                        reason = -154;
                        // Diagnostic-only WMO: raw code, mapped OWM-like ID.
                        diagWrite("srMRawNowV32638", [_now, optionalNumber(cur, "weather_code"), snapshot[11]]);
                        ok = write("srOCurrV326", snapshot);
                        if (ok) { write("srONextCV326", _now + currentSeconds()); _diagAccepted = 1; }
                    } else { reason = -304; }
                } else { reason = -302; }
            } else if (kindIs("forecast")) {
                var field = _shortRequest ? "minutely_15" : "hourly";
                var series = root[field];
                if (dictionary(series)) {
                    _diagMask = _diagMask | 2;
                    var t = series["time"];
                    if (t instanceof Lang.Array) {
                        if (t.size() > 0) { _diagMask = _diagMask | 4; }
                        var mini = [];
                        var count = t.size();
                        if (count > 12) { count = 12; }
                        var step = _shortRequest ? 900 : 3600;
                        var previous = 0;
                        // Remember the first RECOGNIZED row while it is still typed.
                        // Do not index the nested first-row diagnostic: Monkey C infers [] as an
                        // empty array type and rejects this nested constant index.
                        var firstRecognizedWmo = null;
                        var firstRecognizedId = null;
                        _diagRows = count;
                        for (var i = 0; i < count; i++) {
                            var stamp = t[i];
                            if (!num(stamp) || stamp <= _now - step ||
                                stamp > _now + 3 * 3600 || stamp <= previous) { continue; }
                            var rawWmo = meteoSeries(series, "weather_code", i);
                            var code = meteoId(rawWmo);
                            if (code != null) { _diagMask = _diagMask | 8; }
                            var hourlyExtra = root["hourly"];
                            var pop = _shortRequest ?
                                meteoHourlyAt(hourlyExtra, "precipitation_probability", stamp) :
                                meteoSeries(series, "precipitation_probability", i);
                            var uv = _shortRequest ?
                                meteoHourlyAt(hourlyExtra, "uv_index", stamp) :
                                meteoSeries(series, "uv_index", i);
                            if (pop != null && (pop < 0 || pop > 100)) { pop = -1; }
                            if (num(pop)) { _diagMask = _diagMask | 32; }
                            if (num(uv)) { _diagMask = _diagMask | 128; }
                            if (_shortRequest ? num(meteoHourlyAt(hourlyExtra, "temperature_2m", stamp)) :
                                 num(meteoSeries(series, "temperature_2m", i))) { _diagMask = _diagMask | 16; }
                            mini.add([stamp.toNumber(), code,
                                _shortRequest ? meteoHourlyAt(hourlyExtra, "wind_speed_10m", stamp) : meteoSeries(series, "wind_speed_10m", i),
                                _shortRequest ? meteoHourlyAt(hourlyExtra, "temperature_2m", stamp) : meteoSeries(series, "temperature_2m", i),
                                uv, pop,
                                _shortRequest ? meteoQuarterRain(series, i) : meteoRate(series, "rain", i),
                                _shortRequest ? meteoQuarterSnow(series, i) : meteoSnowHour(series, i),
                                _shortRequest ? meteoHourlyAt(hourlyExtra, "visibility", stamp) : meteoSeries(series, "visibility", i),
                                _shortRequest ? meteoHourlyAt(hourlyExtra, "wind_gusts_10m", stamp) : meteoSeries(series, "wind_gusts_10m", i)]);
                            if (code != null && firstRecognizedId == null) {
                                firstRecognizedWmo = rawWmo;
                                firstRecognizedId = code;
                            }
                            previous = stamp;
                            if (mini.size() >= (_shortRequest ? 12 : 5)) { break; }
                        }
                        var recognized = firstRecognizedId != null;
                        if (recognized) {
                            reason = -154;
                            diagWrite("srMRawForecastV32638",
                                      [_now, firstRecognizedWmo, firstRecognizedId]);
                            ok = write(_shortRequest ? "srOShortV3264" : "srOHoursV326",
                                       [_loc[0], _loc[1], _now, mini]);
                            if (ok) { write("srONextFV326", _now + forecastSeconds());
                                      _diagAccepted = mini.size(); }
                        } else { reason = -305; }
                    } else { reason = -302; }
                } else { reason = -302; }
            } else if (kindIs("daily")) {
                var daily = root["daily"];
                if (dictionary(daily)) { _diagMask = _diagMask | 2; }
                var tz = root["utc_offset_seconds"];
                var epoch = meteoSeries(daily, "time", 0);
                if (num(epoch)) { _diagMask = _diagMask | 4; }
                var low = meteoSeries(daily, "temperature_2m_min", 0);
                var high = meteoSeries(daily, "temperature_2m_max", 0);
                if (num(low) && num(high)) { _diagMask = _diagMask | 16; }
                if (num(tz) && num(epoch) && num(low) && num(high)) {
                    var dayId = ((epoch + tz) / 86400).toNumber();
                    var currentDay = ((_now + tz) / 86400).toNumber();
                    if (dayId == currentDay) {
                        reason = -154;
                        ok = write("srODayV326", [_loc[0],_loc[1],_now,dayId,low,high,tz]);
                        if (ok) { write("srONextDV326", _now + 12 * 3600); _diagAccepted = 1; }
                    } else { reason = -306; }
                } else { reason = -302; }
            } else if (kindIs("air")) {
                var aq = root["current"];
                if (dictionary(aq)) {
                    _diagMask = _diagMask | 2;
                    var obA = aq as Lang.Dictionary;
                    var val = optionalNumber(obA, "european_aqi");
                    var at = optionalNumber(obA, "time");
                    if (num(at)) { _diagMask = _diagMask | 4; }
                    if (num(val)) { _diagMask = _diagMask | 256; }
                    if (num(val) && val >= 0 && num(at) && at <= _now + 300 &&
                        _now - at <= 7200) {
                        // Open-Meteo European AQI 0..20..40..60..80..100+
                        // mapped to the existing OWM 1..5 alert preferences.
                        var level = val <= 20 ? 1 : val <= 40 ? 2 :
                                    val <= 60 ? 3 : val <= 80 ? 4 : 5;
                        reason = -154;
                        ok = write("srOAirV326", [_loc[0],_loc[1],_now,at.toNumber(),level]);
                        if (ok) { write("srONextAV326", _now + 3600); _diagAccepted = 1; }
                    } else { reason = -304; }
                } else { reason = -302; }
            }
        } catch (e) { ok = false; reason = -307; }
        if (!ok || _unsafe) { fail(reason); return; }
        _diagStep = 70;
        status(200);
        finish(true);
    }
    function onReceive(code as Lang.Number,
        data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        _diagStep = 25;
        if (phase() == 0) { restoreRequestContext(); }
        gate(19);
        if (setting("srProviderV326", 0) != 1) {
            status(-309); Bg.exit(null); return;
        }
        if (phase() == 0) { status(-19); Bg.exit(null); return; }
        if (code != 200) { fail(code); return; }
        _diagStep = 30;
        receiveMeteo(data);
    }
}
