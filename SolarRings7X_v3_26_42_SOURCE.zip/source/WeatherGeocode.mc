using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;
using Toybox.System as Sys;
using Toybox.Time as Time;

// Solar Rings 7X v3.24.29: bounded, persistent geocoding state machine.
// Single pending timer for ALL locations; no network calls in the render loop.
// Photon public endpoint: low-volume personal testing only. No GPS acquisition.
(:background)
class SolarRingsGeoService extends Sys.ServiceDelegate {
    var _requestedLat;
    var _requestedLon;
    var _openService;

    function initialize() {
        ServiceDelegate.initialize();
        _openService = null;
        _requestedLat = null;
        _requestedLon = null;
    }

    function storedNumber(key, fallback) {
        try {
            var value = App.Storage.getValue(key);
            if (value != null) { return value; }
        } catch (e) { }
        return fallback;
    }

    function saveNumber(key, value) {
        try { App.Storage.setValue(key, value); } catch (e) { }
    }

    function sameRegion(aLat, aLon, bLat, bLon) {
        return aLat < bLat + 0.008d && aLat > bLat - 0.008d &&
               aLon < bLon + 0.012d && aLon > bLon - 0.012d;
    }

    // Always use a single non-periodic Moment event; at least five minutes away.
    function armTimer(targetEpoch) {
        var now = Time.now().value();
        var delay = targetEpoch - now;
        if (delay < 5 * 60) { delay = 5 * 60; }
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(delay)));
            saveNumber("srGEventDue", now + delay);
        } catch (e) {
            saveNumber("srGEventDue", 0);
        }
    }

    function stopTimer() {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        saveNumber("srGEventDue", 0);
    }

    // Photon retry backoff is bounded (10/20/30/60 minutes); no multi-hour
    // lockout for an ordinary empty place result. HTTP 429 gets 60 minutes.
    // Missing phone and transport are treated separately from HTTP errors.
    function cityDiag(stage, http, reason) {
        try { App.Storage.setValue("srGDiagV32639",
                  [Time.now().value(), 0, stage, http, reason]); } catch (e) { }
    }

    function retryLater(http) {
        saveNumber("srGInFlight", 0);
        var failures = storedNumber("srGFail", 0) + 1;
        if (failures > 4) { failures = 4; }
        saveNumber("srGFail", failures);
        // 10 / 20 / 30 / 60 minutes rather than the legacy 3-24 hours.
        var minutes = failures == 1 ? 10 : failures == 2 ? 20 :
                      failures == 3 ? 30 : 60;
        if (http == 429) { minutes = 60; }
        var next = Time.now().value() + minutes * 60;
        saveNumber("srGNextAt", next);
        armTimer(next);
        Bg.exit(null);
    }

    // No phone means no HTTP call. Wait conservatively (one wake/hour) and
    // record the disconnect so the visible face can accelerate on reconnection.
    function retryPhoneMissing() {
        saveNumber("srGInFlight", 0);
        cityDiag(6, -12, 6);
        saveNumber("srGPhoneMissingV32624", 1);
        armTimer(Time.now().value() + 60 * 60);
        Bg.exit(null);
    }

    // Network transport errors and lost asynchronous callbacks are transient;
    // retry hourly without raising the long-lived server failure counter.
    function retryTransport() {
        saveNumber("srGInFlight", 0);
        cityDiag(5, -1, 6);
        var next = Time.now().value() + 10 * 60;
        // Never override an already-active server cooldown with a shorter one.
        var serverNext = storedNumber("srGNextAt", 0);
        if (serverNext > next) { next = serverNext; }
        armTimer(next);
        Bg.exit(null);
    }

    // Events follow Garmin's configured sleep/wake schedule rather than a
    // hard-coded clock window. Neither event represents a manual sleep toggle.
    // Settings can be absent or inconsistently typed after an upgrade.
    // An unrecognized value must never turn on the external network service.
    function selectedProvider() {
        var value = null;
        try { value = App.Properties.getValue("srProviderV326"); } catch (e) { return 0; }
        if (value instanceof Lang.Number) { return value == 1 ? 1 : 0; }
        if (value instanceof Lang.String || value instanceof Lang.Float ||
            value instanceof Lang.Double || value instanceof Lang.Long) {
            try { return value.toNumber() == 1 ? 1 : 0; } catch (e) { }
        }
        return 0;
    }

    function onSleepTime() as Void {
        try {
            var now = Time.now().value();
            App.Storage.setValue("srOSleepStateV32624", [1, now]);
            // Do not replace geocoding's timer if Garmin is the provider.
            // A wake event may override the external weather watchdog at the configured time.
            var provider = selectedProvider();
            if (provider == 1) {
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(2 * 3600)));
            }
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }

    function onWakeTime() as Void {
        try {
            var now = Time.now().value();
            App.Storage.setValue("srOSleepStateV32624", [0, now]);
            var provider = selectedProvider();
            if (provider == 1) {
                // Recover expired current weather and 15min forecasts first.
                // Keep daily/AQI cadence unchanged; one endpoint per wake.
                App.Storage.setValue("srONextCV326", 0);
                App.Storage.setValue("srONextFV326", 0);
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
            }
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }

    function onTemporalEvent() {
        // The same OS background slot serves either city geocoding for
        // Garmin mode OR OpenWeather fetches. They never run together.
        var provider = 0;
        provider = selectedProvider();
        if (provider == 1) {
            try {
                _openService = new SolarOpenNetwork();
                _openService.runSafely();
            } catch (e) {
                // Even an exception constructing the network service must
                // not disappear before the diagnostic breadcrumbs are saved.
                try {
                    var stamp = Time.now().value();
                    App.Storage.setValue("srODGateV3269", [stamp, 91, 0, -1, -1]);
                    App.Storage.setValue("srODiagV3266", [stamp, 0, -231]);
                    Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(10 * 60)));
                } catch (e2) { }
                Bg.exit(["OWM", 0]);
            }
            return;
        }
        saveNumber("srGEventDue", 0);
        var request = null;
        try { request = App.Storage.getValue("srGRequest"); } catch (e) { }
        if (!(request instanceof Lang.Array) || request.size() < 2 ||
            !(request[0] instanceof Lang.Number || request[0] instanceof Lang.Float ||
              request[0] instanceof Lang.Double) ||
            !(request[1] instanceof Lang.Number || request[1] instanceof Lang.Float ||
              request[1] instanceof Lang.Double)) {
            stopTimer();
            Bg.exit(null);
            return;
        }
        _requestedLat = request[0];
        _requestedLon = request[1];
        try {
            var answer = App.Storage.getValue("srGResult");
            if (answer instanceof Lang.Array && answer.size() == 3 &&
                answer[0] != null && answer[1] != null &&
                sameRegion(_requestedLat, _requestedLon, answer[0], answer[1])) {
                stopTimer();
                Bg.exit(null);
                return;
            }
            // Check Bluetooth BEFORE the HTTP watchdog or server cooldown.
            // A disconnect must never count as a Photon server failure.
            if (!Sys.getDeviceSettings().phoneConnected) {
                retryPhoneMissing();
                return;
            }
            // A lost async callback is a transport failure, not HTTP 429.
            if (storedNumber("srGInFlight", 0) == 1) {
                retryTransport();
                return;
            }
            if (storedNumber("srGPhoneMissingV32624", 0) == 1) {
                saveNumber("srGPhoneMissingV32624", 0);
            }
            var now = Time.now().value();
            var next = storedNumber("srGNextAt", 0);
            var fromLastRequest = storedNumber("srGLastTry", 0) + 15 * 60;
            if (fromLastRequest > next) { next = fromLastRequest; }
            if (now < next) {
                armTimer(next);
                Bg.exit(null);
                return;
            }
            // Shared minimum 15-minute spacing between Photon attempts.
            saveNumber("srGLastTry", now);
            cityDiag(2, 0, 0);
            saveNumber("srGInFlight", 1);
            // If response callback never fires, a watchdog detects this.
            armTimer(now + 15 * 60);
            var query = {
                "lat" => _requestedLat.format("%.4f"),
                "lon" => _requestedLon.format("%.4f"),
                "lang" => "pl",
                "osm_tag" => "place",
                "limit" => "3",
                "radius" => "5"
            };
            var options = {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            };
            Comm.makeWebRequest("https://photon.komoot.io/reverse",
                                query, options, method(:onReceive));
        } catch (e) {
            cityDiag(5, -1, 7);
            retryLater(-1);
        }
    }

    // Explicit callback signature required by the Connect IQ 9.3 typechecker.
    // Match the full makeWebRequest() response union, even though JSON
    // should arrive as a Dictionary. Never index other response types.
    function onReceive(code as Lang.Number,
                       data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        cityDiag(3, code, 0);
        if (code < 0) { retryTransport(); return; }
        if (code != 200) { cityDiag(5, code, 1); retryLater(code); return; }
        if (!(data instanceof Lang.Dictionary)) {
            cityDiag(5, code, 3); retryLater(code); return;
        }
        var city = null;
        try {
            var features = data["features"];
            if (features instanceof Lang.Array) {
                for (var i = 0; i < features.size() && i < 3; i++) {
                    if (!(features[i] instanceof Lang.Dictionary)) { continue; }
                    var props = features[i]["properties"];
                    if (!(props instanceof Lang.Dictionary)) { continue; }
                    var name = props["name"];
                    var key = props["osm_key"];
                    if (key instanceof Lang.String && key.equals("place") &&
                        name instanceof Lang.String && name.length() >= 2 &&
                        name.length() <= 42) { city = name.toUpper(); break; }
                }
            }
        } catch (e) { }
        if (city == null) { cityDiag(5, code, 4); retryLater(code); return; }

        var now = Time.now().value();
        saveNumber("srGInFlight", 0);
        saveNumber("srGFail", 0);
        saveNumber("srGNextAt", now + 30 * 60);
        var latest = null;
        try { latest = App.Storage.getValue("srGRequest"); } catch (e) { }
        if (latest == null || !(latest instanceof Lang.Array) || latest.size() < 2 ||
            !sameRegion(_requestedLat, _requestedLon, latest[0], latest[1])) {
            cityDiag(5, code, 5);
            armTimer(now + 15 * 60);
            Bg.exit(null);
            return;
        }
        cityDiag(4, 200, 0);
        stopTimer();
        Bg.exit([_requestedLat, _requestedLon, city]);
    }

}
