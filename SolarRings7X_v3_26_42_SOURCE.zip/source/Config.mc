using Toybox.Application.Properties as Props;
using Toybox.Graphics as Gfx;

// Cache ONLY persisted settings; dynamic device data is never cached here.
// All entries are invalidated on AppBase.onSettingsChanged().
// Limit persistent cache footprint; additional properties still load on demand.
var _srSettingCache = {};
var _srSettingCacheSize = 0;

function srResetSettingsCache() {
    // Do not allocate a fresh Dictionary inside the memory-sensitive
    // onSettingsChanged() callback. The next actual read allocates lazily.
    _srSettingCache = null;
    _srSettingCacheSize = 0;
}

// Values sent by Connect/Express may occasionally be strings or null.
// Convert only when the caller has a typed fallback, and reject all other
// values rather than letting invalid types reach arithmetic or drawing.
function srSettingTyped(value, fallback) {
    if (value == null) { return fallback; }
    try {
        if (fallback instanceof Toybox.Lang.Number) {
            if (value instanceof Toybox.Lang.Number) { return value; }
            if (value instanceof Toybox.Lang.Float ||
                value instanceof Toybox.Lang.Double ||
                value instanceof Toybox.Lang.Long ||
                value instanceof Toybox.Lang.String) {
                var converted = value.toNumber();
                if (converted instanceof Toybox.Lang.Number) { return converted; }
            }
            return fallback;
        }
        if (fallback instanceof Toybox.Lang.Boolean) {
            if (value instanceof Toybox.Lang.Boolean) { return value; }
            if (value instanceof Toybox.Lang.Number) { return value != 0; }
            if (value instanceof Toybox.Lang.String) {
                if (value.equals("true") || value.equals("1")) { return true; }
                if (value.equals("false") || value.equals("0")) { return false; }
            }
            return fallback;
        }
        if (fallback instanceof Toybox.Lang.String) {
            return value instanceof Toybox.Lang.String ? value : fallback;
        }
    } catch (e) { return fallback; }
    return value;
}

// Mobile app settings. All default keys are defined in resources/settings/properties.xml.
// Deliberately use NEW keys so stale v2.x settings cannot unexpectedly override
// the new three-ring layout. All 8 visible slots are selectable from the phone.
function srSetting(key, fallback) {
    // Malformed keys should never propagate into native Properties.getValue.
    if (!(key instanceof Toybox.Lang.String)) { return fallback; }
    // Version 3.18: font controls removed from Connect IQ settings because
    // they were not reliable on the MIP screen. Preserve the accepted layout
    // and ignore values persisted by previous versions of the phone app.
    if (key.equals("fontClockV31") || key.equals("fontDateV31") ||
        key.equals("fontTopV31") || key.equals("fontRingV31") ||
        key.equals("fontWeatherV31")) { return 2; }
    if (key.equals("fontFaceV36")) { return 0; }
    if (key.equals("fontExtraV36")) { return 1; }
    if (key.equals("sizeTopLeftV37") || key.equals("sizeTopMidV37") ||
        key.equals("sizeTopRightV37") || key.equals("sizeRingLeftV37") ||
        key.equals("sizeRingMidV37") || key.equals("sizeRingRightV37") ||
        key.equals("sizeWeatherValueV37") || key.equals("sizeWeatherLabelV37") ||
        key.equals("sizeFooterV37") || key.equals("moonFontV38")) { return -1; }
    if (_srSettingCache != null) {
        var cached = _srSettingCache[key];
        if (cached != null) { return srSettingTyped(cached, fallback); }
    }
    try {
        var value = Props.getValue(key);
        if (value == null) { return fallback; }
        // Important: do NOT store unvalidated values in the cache.
        value = srSettingTyped(value, fallback);
        if (_srSettingCacheSize < 64) {
            if (_srSettingCache == null) { _srSettingCache = {}; }
            _srSettingCache[key] = value;
            _srSettingCacheSize += 1;
        }
        return value;
    } catch (e) { }
    return fallback;
}

function srColor(value) {
    if (value == 0) { return Gfx.COLOR_RED; }
    if (value == 1) { return Gfx.COLOR_GREEN; }
    if (value == 2) { return Gfx.COLOR_BLUE; }
    if (value == 3) { return Gfx.COLOR_ORANGE; }
    if (value == 4) { return Gfx.COLOR_YELLOW; }
    if (value == 5) { return Gfx.COLOR_WHITE; }
    return 0x00FFFF;
}
