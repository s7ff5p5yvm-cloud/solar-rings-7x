# Archived OWM-only tests

These tests asserted OpenWeatherMap 4.0 endpoints, API keys, and OWM JSON schemas. They were NOT silently altered to pass after the deliberate OWM-to-Open-Meteo replacement. Source and tests are retained for audit; current regressions run in tests_provider.
