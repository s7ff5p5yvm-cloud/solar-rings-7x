# Solar Rings 7X — v3.26.42 TEST

Baza: v3.26.41 (dwa dostawcy: Garmin Weather i Open-Meteo best_match).
Wersja stabilna v3.26.37 nie jest modyfikowana.

- `Config.mc`: typowanie zgodne z wartościami domyślnymi, odrzucanie wadliwych typów i leniwa inicjalizacja cache; reset cache po zapisie ustawień bez alokacji Dictionary.
- `WeatherGeocode.mc`: `selectedProvider()` normalizuje Number/String/Float/Long i odrzuca inne tryby we wszystkich zdarzeniach tła.
- `SolarRings7X.mc`: usunięto `srOwmProviderChanged()` z `getInitialView` i `refreshChangedSettings`. W widoku zmieniamy wyłącznie istniejący timer przy przełączeniu dostawcy; migracja danych odbywa się w tle.
- `SolarOpenNetwork.mc`: harmonogram w tle reaguje także na zmianę interwału i przełącznika prognozy 15-minutowej, bez przywracania kosztownych zapisów w `onUpdate`.
- `GarminWeatherWarnings.mc`: przywrócono `prepareRules()` przed pobraniem tablicy godzinowej, a przekazanie prognozy podlega konserwatywnemu limitowi wolnej pamięci 50 KiB. Wspólne funkcje `forecastChanceMatches` i `iceChanceMatches` korzystają z fallback do `srSetting` dla dziedziczącego `SolarOpenWarnings`, by nie dopuścić do odczytu pustego `_ruleValues`.
- `onUpdate`: wyłączenie kosztownych czcionek wektorowych przy wolnej pamięci poniżej 35 KB. Wartość orientacyjna, nie gwarancja stabilności.
- Open-Meteo best_match/WMO/UV/AQI/Photon i ekran diagnostyki zachowane jak w 3.26.41.

**Ograniczenia:** testy źródłowe nie zastępują kompilacji Garmin SDK ani testów na zegarku. Nowa wersja nadal testowa.
