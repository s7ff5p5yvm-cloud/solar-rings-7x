"""Source-level v3.26.17 invariants and a modelled schedule. NOT Garmin SDK tests."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
N=(ROOT/'source/SolarOpenNetwork.mc').read_text()
W=(ROOT/'source/SolarOpenWarnings.mc').read_text()
G=(ROOT/'source/StormGuard.mc').read_text()
U=(ROOT/'source/SolarRings7X.mc').read_text()
D=(ROOT/'source/SolarOpenData.mc').read_text()
C=(ROOT/'source/Config.mc').read_text()

def simulate_day():
    """5min scheduler, no retries, current first; illustrative, not runtime."""
    due={'current':0,'minute':0,'hourly':0,'daily':0,'air':0}
    span={'current':10,'minute':30,'short':30,'hourly':60,'daily':720,'air':60}
    seen={k:[] for k in span}
    has_hourly=False
    for t in range(0,1440,5):
        if has_hourly and 'short' not in due:due['short']=t
        forecast_due=min(due['hourly'], due.get('short',1000000))
        if due['current']<=t:sel='current'
        elif due['daily']<=t-20:sel='daily'
        elif due['air']<=t-15:sel='air'
        elif due['minute']<=t-15:sel='minute'
        elif forecast_due<=t-15:
            sel='short' if due.get('short',1000000)<due['hourly'] else 'hourly'
        elif due['minute']<=t:sel='minute'
        elif forecast_due<=t:
            sel='short' if due.get('short',1000000)<due['hourly'] else 'hourly'
        elif due['air']<=t:sel='air'
        elif due['daily']<=t:sel='daily'
        else:continue
        seen[sel].append(t)
        due[sel]=t+span[sel]
        if sel=='hourly':has_hourly=True
    return seen

class Max316(unittest.TestCase):
    def test_release_and_original_identity(self):
        a=ET.parse(ROOT/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(a.get('version'),'3.26.17')
        self.assertEqual(a.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
    def test_one_background_network_request(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),1)
        self.assertNotIn('Comm.makeWebRequest',U)
        self.assertIn('if (used >= 700)',N)
        self.assertIn('srOBudgetV32613',N)
        self.assertIn('Comm.encodeURL(pending[3] as Lang.String)',N)
    def test_complete_timelines(self):
        for endpoint in ('onecall/current','onecall/timeline/1min','onecall/timeline/15min',
                         'onecall/timeline/1h','onecall/timeline/1day',
                         'onecall/alert/','2.5/air_pollution'):
            self.assertIn(endpoint,N)
        self.assertIn('srOwmForecastSnapshot()',W)
        self.assertIn('srOwmMinuteSnapshot()',W)
        self.assertIn('srOwmOfficialDetailKind()',W)
    def test_source_classification_not_mixed_with_observations(self):
        self.assertIn('addAlert(_lastKinds, 15 + 16)',W)
        self.assertIn('addAlert(_lastKinds, 14)',W)
        self.assertIn('addAlert(_lastKinds, officialKind + 16)',W)
        self.assertIn('addAlert(_lastKinds, currentKinds[i] + (elapsed > freshSeconds ? 64 : 0))',W)
        self.assertNotIn('t.find("flood")',N)
        self.assertIn('t.find("thunder")',N)
    def test_pressure_guard_and_transparency(self):
        self.assertIn('History.getPressureHistory',G)
        self.assertIn('History.getElevationHistory',G)
        self.assertIn('externalCorroboration',G)
        self.assertIn('ambiguousPressureAltitude',G)
        self.assertIn('var pressureLevel = _storm.warningLevel()',U)
        self.assertIn('drawAlertGlyph(dc, 45, pressureGlyph);',U)
        self.assertIn('if (tag == -1 || tag == -2)',U)
        self.assertIn('srOBaroHistoryV32616',G)
    def test_due_and_cleanup_for_every_endpoint(self):
        for name in ('srONextCV326','srONextFV326','srONextSV32615',
                     'srONextMV32616','srONextDV326','srONextAV326',
                     'srONextAlertV32616'):
            self.assertIn(name,N)
        self.assertIn('srOAlertAttemptV32616',N)
        self.assertIn('srOAlertSeenV32616',N)
        self.assertIn('markAlertChecked()',N)
        self.assertIn('_minuteEnabled = _interval == 5;',N)
        self.assertNotIn('rows.remove(0)',N)
    def test_one_time_profile_preserves_credentials(self):
        start=C.index('function srApplyOptimizedWeatherDefaults32616()')
        seg=C[start:]
        self.assertIn('Props.setValue("stormOnV3", true)',seg)
        self.assertIn('Props.setValue("srOwmMinutesV326", 5)',seg)
        self.assertNotIn('Props.setValue("srOpenKeyV326",',seg)
        self.assertNotIn('Props.setValue("srProviderV326",',seg)
        self.assertIn('srApplyOptimizedWeatherDefaults32616();',U)
    def test_contracts_and_no_secrets(self):
        for f in [ROOT/'resources/strings.xml',ROOT/'resources/settings/settings.xml',
                  ROOT/'resources/settings/properties.xml']:
            ET.parse(f)
        for i in (16,20,21,22): self.assertIn(f'page == {i}',U)
        self.assertNotIn('diagWrite("srOReqCtxV3267", _key)',N)
    def test_modelled_refresh_and_api_ceiling(self):
        h=simulate_day()
        self.assertEqual(h['current'], list(range(0,1440,10)))
        self.assertLessEqual(sum(map(len,h.values())),288)
        self.assertGreaterEqual(len(h['minute']),40)
        self.assertGreaterEqual(len(h['short']),35)
        self.assertGreaterEqual(len(h['hourly']),22)
        self.assertGreaterEqual(len(h['air']),22)
        self.assertEqual(len(h['daily']),2)

if __name__=='__main__': unittest.main()
