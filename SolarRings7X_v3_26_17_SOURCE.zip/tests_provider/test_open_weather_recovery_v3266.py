"""Contract checks for v3.26.8 location recovery and API troubleshooting."""
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=(ROOT/'source/SolarOpenData.mc').read_text()
NETWORK=(ROOT/'source/SolarOpenNetwork.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()

class TestOpenWeatherRecovery(unittest.TestCase):
    def test_version(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('version'),'3.26.17')
    def test_existing_settings_keys_kept_to_preserve_saved_api_key(self):
        settings=(ROOT/'resources/settings/properties.xml').read_text()
        self.assertIn('id="srOpenKeyV326"',settings)
        self.assertIn('id="srProviderV326"',settings)
    def test_recent_weather_preferred_but_activity_fallback_not_blocked_by_cached_pos(self):
        block=DATA.split('function srOwmUpdateLocation(garmin)')[1].split('// Settings changes')[0]
        self.assertIn('Activity.getActivityInfo()',block)
        self.assertIn('activityInfo.currentLocation.toDegrees()',block)
        self.assertNotIn('if (!srOwmCoordsValid(known))',block)
        self.assertIn('now - weatherStamp <= 3 * 3600',block)
        self.assertIn('now - weatherStamp <= 24 * 3600',block)
        self.assertIn('weatherStamp == 0',block)
        self.assertIn('srOwmCoordsValid(weatherCoords)',block)
        self.assertIn('srOwmCoordsValid(activityCoords)',block)
    def test_background_does_not_stop_for_12hour_old_location(self):
        self.assertIn('_now - _loc[2] > 48 * 3600',NETWORK)
        self.assertNotIn('_now - _loc[2] > 12 * 3600',NETWORK)
        self.assertIn('srOwmArmIfNeeded()',DATA)
    def test_weather_error_does_not_erase_location_on_dial(self):
        panel=FACE.split('function drawMoonPanel')[1].split('function topSlot')[0]
        self.assertIn('srOwmRead("srOLocV326")',panel)
        self.assertIn('srWeatherCityFromDegrees(storedLoc[0], storedLoc[1])',panel)
    def test_no_api_key_in_diagnostics(self):
        self.assertIn('srODiagV3266',NETWORK)
        self.assertIn('srODiagV3266',FACE)
        # Diagnostic array contains [time, phase, code], not key or URL.
        self.assertIn('diagWrite("srODiagV3266", [stamp, p, code]);', NETWORK)
        self.assertNotIn('[_now, phase(), _key]', NETWORK)
    def test_distinguish_http_and_data_errors(self):
        self.assertIn('if (code != 200) { fail(code); return; }',NETWORK)
        self.assertIn('if (!dictionary(data)) { fail(-151); return; }',NETWORK)
        self.assertIn('status(200);',NETWORK)
        for code in ('-10','-11','-12','-15','-17','-18'):
            self.assertIn(code,FACE)
    def test_stale_callback_does_not_replace_other_city(self):
        self.assertIn('if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }',NETWORK)
    def test_fallback_to_hourly_is_preserved(self):
        self.assertIn('"srOShortPausedV3264"',NETWORK)
        self.assertIn('"https://api.openweathermap.org/data/4.0/onecall/timeline/1h"',NETWORK)
        self.assertIn('"https://api.openweathermap.org/data/4.0/onecall/timeline/15min"',NETWORK)
    def test_no_foreground_http_or_active_gps(self):
        self.assertNotIn('Comm.makeWebRequest(',FACE)
        self.assertNotIn('Position.getInfo(',DATA)
        self.assertNotIn('Position.enableLocationEvents(',DATA)
    def test_valid_json_current_contract(self):
        snippet=NETWORK.split('var currentRows = data["data"]')[1].split('} else if (_kind == "forecast")')[0]
        self.assertIn('currentRows.size() > 0',snippet)
        self.assertIn('var d = currentRows[0] as Lang.Dictionary',snippet)
        self.assertIn('num(d["dt"]) && num(d["temp"])',snippet)

if __name__=='__main__':unittest.main()
