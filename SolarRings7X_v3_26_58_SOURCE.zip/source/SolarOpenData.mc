using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Position as Position;
using Toybox.Activity as Activity;
using Toybox.Lang as Lang;
using Toybox.Time as Time;
using Toybox.Weather as Weather;

// One source for ALL meteorological fields. Garmin is the default.
// Neither class below starts GPS. Garmin/position metadata is used solely
// to locate the OWM request; weather measurements never fall back to Garmin.
function srUseOpenWeather() {
    return srSetting("srProviderV326", 0) == 1;
}
function srOwmKeyReady() {
    var key = srSetting("srOpenKeyV326", "");
    return key != null && key instanceof Lang.String && key.length() >= 8;
}
function srOwmNumber(v) {
    return v != null && (v instanceof Lang.Number || v instanceof Lang.Long ||
                          v instanceof Lang.Float || v instanceof Lang.Double);
}
function srOwmRead(key) {
    try { return App.Storage.getValue(key); } catch (e) { return null; }
}
function srOwmWrite(key, data) {
    try {
        App.Storage.setValue(key, data);
        return true;
    } catch (e) { return false; }
}
function srOwmCoordsValid(a) {
    return a != null && a instanceof Lang.Array && a.size() >= 2 &&
           srOwmNumber(a[0]) && srOwmNumber(a[1]) &&
           a[0] >= -90 && a[0] <= 90 && a[1] >= -180 && a[1] <= 180;
}
function srOwmSamePlace(a, b) {
    return srOwmCoordsValid(a) && srOwmCoordsValid(b) &&
           a[0] > b[0] - 0.025d && a[0] < b[0] + 0.025d &&
           a[1] > b[1] - 0.035d && a[1] < b[1] + 0.035d;
}

// A unified view of weather for the EXISTING readField(), drawWeather(),
// weatherSymbol(), temperatureMarker(), age display and moon-city panel.
// Snapshot layout: lat,lon,fetchUTC,observationUTC,temp,feels,wind,humidity,
// uv,visibility,clouds,code,pressure,sunriseUTC,sunsetUTC,gust,pop%,rain,snow.
// Missing fields remain null: NEVER use Garmin values as substitutes.
class SolarOpenConditions {
    var temperature;
    var feelsLikeTemperature;
    var windSpeed;
    var relativeHumidity;
    var uvIndex;
    var visibility;
    var cloudCover;
    var precipitationChance;
    var highTemperature;
    var lowTemperature;
    var condition;
    var observationTime;
    var observationLocationPosition;
    var observationLocationName;
    var sunriseUtc;
    var sunsetUtc;

    function initialize(data, forecast, daily) {
        temperature = data[4];
        feelsLikeTemperature = data[5];
        windSpeed = data[6];
        relativeHumidity = data[7];
        uvIndex = data[8];
        visibility = data[9];
        cloudCover = data[10];
        condition = srOwmCondition(data[11]);
        precipitationChance = data[16];
        // -1 is an invalid OWM POP sentinel, never show -1% on the dial.
        if (precipitationChance != null && precipitationChance < 0) {
            precipitationChance = null;
        }
        // Current endpoint may omit POP; use nearest OWM forecast if VALID,
        // never Garmin precipitationChance. This field is informational only.
        if (precipitationChance == null && forecast != null &&
            forecast.size() > 0 && forecast[0] != null &&
            forecast[0].size() > 5 && forecast[0][5] != null &&
            srOwmNumber(forecast[0][5]) && forecast[0][5] >= 0) {
            precipitationChance = forecast[0][5];
        }
        highTemperature = daily == null ? null : daily[5];
        lowTemperature = daily == null ? null : daily[4];
        sunriseUtc = data[13];
        sunsetUtc = data[14];
        observationTime = new Time.Moment(data[3].toNumber());
        observationLocationPosition = new Position.Location({
            :latitude => data[0], :longitude => data[1], :format => :degrees
        });
        observationLocationName = null;
        // Full-day min/max are read only from OWM's 1day endpoint.
        // Hourly maximum/minimum is never mislabeled as an all-day extreme.
    }
}

// Code-to-icon translation only. Warnings have an independent OWM rule engine.
function srOwmCondition(id) {
    return srOwmMappedCondition(id);
}

function srOwmCurrentSnapshot() {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return null; }
    var d = srOwmRead("srOCurrV326");
    var loc = srOwmRead("srOLocV326");
    var now = Time.now().value();
    if (d == null || !(d instanceof Lang.Array) || d.size() != 19 ||
        !srOwmCoordsValid(d) || !srOwmSamePlace(d, loc) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        d[3] > now + 300 || now - d[3] > 90 * 60 ||
        !srOwmNumber(d[4])) { return null; }
    return d;
}
// Choose high-resolution warnings only while the 15-minute timeline is
// sufficiently fresh. An older 15-minute cache must NEVER hide a fresher
// hourly forecast. This also keeps bucket matching consistent with selection.
function srOwmPreferShort(s, h, loc, now) {
    if (srSetting("srOwm15MinV3264", true) != true) { return false; }
    var paused = srOwmRead("srOShortPausedV3264");
    if (srOwmNumber(paused) && paused > now) { return false; }
    if (!(s instanceof Lang.Array) || s.size() != 4 ||
        !srOwmSamePlace(s, loc) || !srOwmNumber(s[2]) ||
        s[2] > now + 300 || now - s[2] > 60 * 60 ||
        !(s[3] instanceof Lang.Array)) { return false; }
    // More recent hourly analysis outweighs a 15-minute forecast that is
    // at least 20 minutes older. Granularity is valuable, freshness first.
    if (h instanceof Lang.Array && h.size() == 4 &&
        srOwmSamePlace(h, loc) && srOwmNumber(h[2]) &&
        h[2] <= now + 300 && now - h[2] <= 2 * 3600 &&
        h[2] > s[2] + 20 * 60) { return false; }
    return true;
}
function srOwmForecastSource() {
    var now = Time.now().value();
    var loc = srOwmRead("srOLocV326");
    var h = srOwmRead("srOHoursV326");
    var s = srOwmRead("srOShortV3264");
    var f = srOwmPreferShort(s, h, loc, now) ? s : h;
    if (f == null || !(f instanceof Lang.Array) || f.size() != 4 ||
        !srOwmSamePlace(f, loc) || !srOwmNumber(f[2]) ||
        f[2] > now + 300 || now - f[2] > 120 * 60 ||
        !(f[3] instanceof Lang.Array)) { return null; }
    return f;
}
function srOwmForecastSnapshot() {
    var f = srOwmForecastSource();
    return f == null ? null : f[3];
}
// Use the SAME selected source for time-bucket validity as for alert data.
function srOwmForecastStepSeconds() {
    var now = Time.now().value();
    var loc = srOwmRead("srOLocV326");
    var h = srOwmRead("srOHoursV326");
    var s = srOwmRead("srOShortV3264");
    return srOwmPreferShort(s, h, loc, now) ? 900 : 3600;
}

function srOwmDailySnapshot() {
    var d = srOwmRead("srODayV326");
    var now = Time.now().value();
    if (d == null || !(d instanceof Lang.Array) || d.size() != 7 ||
        !srOwmSamePlace(d, srOwmRead("srOLocV326")) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        !srOwmNumber(d[4]) || !srOwmNumber(d[5]) ||
        !srOwmNumber(d[6]) || d[2] > now + 300 ||
        now - d[2] > 36 * 3600) { return null; }
    var localDay = ((now + d[6]) / 86400).toNumber();
    if (localDay != d[3]) { return null; }
    return d;
}
function srOwmVisibleCurrent() {
    var d = srOwmCurrentSnapshot();
    if (d == null) { return null; }
    try { return new SolarOpenConditions(d, srOwmForecastSnapshot(), srOwmDailySnapshot()); }
    catch (e) { return null; }
}

// Only one temporal background event exists. Called seldom: initial view,
// selected setting changed, or location changed. An existing event is reused.
function srOwmArmIfNeeded() {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return; }
    // Independent scheduled sleep/wake callbacks: keep registered even if a
    // location update has not arrived yet. No UserProfile permission needed.
    try {
        if (!Bg.getSleepEventRegistered()) { Bg.registerForSleepEvent(); }
        if (!Bg.getWakeEventRegistered()) { Bg.registerForWakeEvent(); }
    } catch (e) { /* Missing sleep event: stay awake, never assume fixed bedtime. */ }
    var loc = srOwmRead("srOLocV326");
    var now = Time.now().value();
    if (!srOwmCoordsValid(loc) || loc.size() < 3 ||
        !srOwmNumber(loc[2]) || loc[2] > now + 300 ||
        now - loc[2] > 48 * 3600) {
        srOwmWrite("srODiagV3266", [now, 0, -10]);
        return;
    }
    try {
        if (Bg.getTemporalEventRegisteredTime() != null) { return; }
        Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
    } catch (e) { srOwmWrite("srODiagV3266", [now, 0, -18]); }
}

// OWM location policy v3.26.23: use fresh, timestamped satellite fixes
// when the watch ALREADY has one; otherwise use Garmin's phone/weather
// coordinates. Position.getInfo() only reads metadata: it does not start GPS.
// Never trust a time-less activity coordinate over a newer weather location.
function srOwmUpdateLocation(garmin) {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return false; }
    var now = Time.now().value();
    var weatherCoords = null;
    var weatherStamp = 0;
    try {
        if (garmin != null && garmin.observationLocationPosition != null) {
            weatherCoords = garmin.observationLocationPosition.toDegrees();
            if (garmin.observationTime != null) {
                weatherStamp = garmin.observationTime.value();
            }
        }
    } catch (e) { weatherCoords = null; }
    if (!srOwmCoordsValid(weatherCoords)) { weatherCoords = null; }

    // A real GPS fix has its own timestamp, unlike Activity.currentLocation.
    // Don't start the GPS or accept QUALITY_LAST_KNOWN as a fresh measurement.
    // Keep the check cheap: this method runs only at the 5-minute location poll.
    var gpsCoords = null;
    var gpsStamp = 0;
    try {
        var gpsInfo = Position.getInfo();
        if (gpsInfo != null && gpsInfo.position != null &&
            gpsInfo.when != null &&
            gpsInfo.accuracy >= Position.QUALITY_USABLE) {
            gpsStamp = gpsInfo.when.value();
            if (gpsStamp > 0 && gpsStamp <= now + 300 &&
                now - gpsStamp <= 12 * 60) {
                gpsCoords = gpsInfo.position.toDegrees();
            }
        }
    } catch (e) { gpsCoords = null; }
    if (!srOwmCoordsValid(gpsCoords)) { gpsCoords = null; }
    // Reject a common uninitialized (0,0) receiver sentinel.
    if (gpsCoords != null && gpsCoords[0] > -0.001d &&
        gpsCoords[0] < 0.001d && gpsCoords[1] > -0.001d &&
        gpsCoords[1] < 0.001d) { gpsCoords = null; }

    // Fallback for older firmware. This is LAST-KNOWN location only; there
    // is no fix timestamp and it must never outrank a valid weather position.
    var activityCoords = null;
    try {
        var activityInfo = Activity.getActivityInfo();
        if (activityInfo != null && activityInfo.currentLocation != null) {
            activityCoords = activityInfo.currentLocation.toDegrees();
        }
    } catch (e) { activityCoords = null; }
    if (!srOwmCoordsValid(activityCoords)) { activityCoords = null; }

    var previous = srOwmRead("srOLocV326");
    var lastGpsStamp = srOwmRead("srOLastGpsFixV32623");
    if (!srOwmNumber(lastGpsStamp)) { lastGpsStamp = 0; }
    var coords = null;
    if (gpsCoords != null) {
        // New, high-quality GPS coordinates take precedence over old phone
        // metadata, even if the Garmin weather station has not yet moved.
        coords = gpsCoords;
        if (gpsStamp != lastGpsStamp) {
            srOwmWrite("srOLastGpsFixV32623", gpsStamp);
        }
    } else if (weatherCoords != null && weatherStamp > 0 &&
               weatherStamp <= now + 300 && now - weatherStamp <= 3 * 3600) {
        if (lastGpsStamp > 0 && lastGpsStamp <= now + 300 &&
            now - lastGpsStamp <= 2 * 3600 &&
            weatherStamp < lastGpsStamp && srOwmCoordsValid(previous) &&
            !srOwmSamePlace(previous, weatherCoords)) {
            // Don't jump back to yesterday's region while Garmin still
            // returns the observation from before the latest GPS fix.
            coords = [previous[0], previous[1]];
        } else {
            coords = weatherCoords;
        }
    } else if (activityCoords != null) {
        coords = activityCoords;
    } else if (weatherCoords != null &&
        ((weatherStamp > 0 && weatherStamp <= now + 300 &&
          now - weatherStamp <= 24 * 3600) || weatherStamp == 0)) {
        // Old weather metadata still beats having no location at all.
        coords = weatherCoords;
    }
    if (coords == null) {
        srOwmArmIfNeeded();
        return false;
    }
    var changed = !srOwmSamePlace(previous, coords);
    // Persist location once per hour while stationary; immediately on travel.
    // This timestamp denotes observation by the face, NOT age of a GPS fix.
    if (changed || !(previous instanceof Lang.Array) || previous.size() < 3 ||
        !srOwmNumber(previous[2]) || now < previous[2] ||
        now - previous[2] >= 3600) {
        if (!srOwmWrite("srOLocV326", [coords[0], coords[1], now])) { return false; }
        if (changed) {
            // Separate cities cannot share hysteresis confirmation history.
            srOwmWrite("srOGuardV32658", -1);
            // Never display the previous city's weather for a new position.
            srOwmWrite("srOCurrV326", null);
            srOwmWrite("srOHoursV326", null);
            srOwmWrite("srOShortV3264", null);
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srODayV326", null);
            srOwmWrite("srOAirV326", null);
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextSV32648", 0);
            srOwmWrite("srONextDV326", 0);
            srOwmWrite("srONextAV326", 0);
            srOwmWrite("srODiagV3266", [now, 0, 0]);
        }
    }
    if (changed) {
        // One shared temporal service, no extra timers or HTTP calls.
        try { Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60))); }
        catch (e) { srOwmArmIfNeeded(); }
    } else { srOwmArmIfNeeded(); }
    return changed;
}

// Settings changes do not invalidate OWM measurements, only refresh the
// schedule when the provider or API key actually changes. We store a hash
// of the key, never a duplicate key in app Storage.
function srOwmProviderChanged() {
    var mode = srUseOpenWeather() ? 1 : 0;
    if (mode == 0) {
        // Scheduled sleep/wake triggers belong to the OWM provider only.
        try { Bg.deleteSleepEvent(); Bg.deleteWakeEvent(); } catch (e) { }
    }
    var oldMode = srOwmRead("srOLastModeV326");
    var key = srSetting("srOpenKeyV326", "");
    var keyStamp = key instanceof Lang.String ? key.hashCode() : 0;
    var oldKeyStamp = srOwmRead("srOKeyHashV326");
    // A new diagnostics schema must never display old, misleading errors.
    // Reset it once per release and again on a provider/credential change.
    var diagVersion = srOwmRead("srODVersionV32612");
    var resetDiag = diagVersion != 32612;
    var refresh = srSetting("srOwmMinutesV326", 30);
    if (refresh != 5 && refresh != 15 && refresh != 30 && refresh != 60) { refresh = 30; }
    var oldRefresh = srOwmRead("srORefreshV3263");
    var shortMode = srSetting("srOwm15MinV3264", true) == true;
    var oldShortMode = srOwmRead("srOShortEnabledV3264");
    var shortChanged = mode == 1 &&
        (oldShortMode == null || oldShortMode != shortMode);
    var modeChanged = oldMode == null || oldMode != mode;
    var keyChanged = mode == 1 && (oldKeyStamp == null || oldKeyStamp != keyStamp);
    var refreshChanged = mode == 1 && oldRefresh != refresh;
    if (resetDiag || modeChanged || keyChanged) {
        var diagNames = ["srODNowV3268", "srODForecastV3268",
                         "srODDailyV3268", "srODAirV3268",
                         "srOD1hV32648", "srOD15mV32648",
                         "srODSystemV3268", "srODHistoryV3268"];
        for (var x = 0; x < diagNames.size(); x++) {
            srOwmWrite(diagNames[x], null);
        }
        srOwmWrite("srODWakeV3268", 0);
        srOwmWrite("srODGateV3269", null);
        srOwmWrite("srODVersionV32612", 32612);
        // A fresh release MUST get one chance to fetch now, even if an old
        // version left a future retry deadline after FORMAT/timeout errors.
        if (mode == 1 && resetDiag) {
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextSV32648", 0);
            srOwmWrite("srONextDV326", 0);
            srOwmWrite("srONextAV326", 0);
            srOwmWrite("srOReqCtxV3267", null);
            srOwmWrite("srOHourlyTinyV32611", 0);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
        }
    }
    if (modeChanged || keyChanged || refreshChanged || shortChanged) {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        srOwmWrite("srOLastModeV326", mode);
        srOwmWrite("srOKeyHashV326", keyStamp);
        srOwmWrite("srORefreshV3263", refresh);
        srOwmWrite("srOShortEnabledV3264", shortMode);
        if (shortChanged || keyChanged || modeChanged) {
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srOShortV3264", null);
        }
        if (keyChanged) {
            // New credentials must not display a previous key's weather.
            srOwmWrite("srOCurrV326", null);
            srOwmWrite("srOHoursV326", null);
            srOwmWrite("srODayV326", null);
            srOwmWrite("srOAirV326", null);
        }
        if (mode == 1) {
            srOwmWrite("srODiagV3266", [Time.now().value(), 0, 0]);
        }
        if (mode == 0) {
            // Provider switch invalidates any geocoding request left by an
            // earlier destination. A fresh Garmin weather location will
            // create its own request if the city is unknown. Keep the global
            // srGLastTry HTTP limiter; do not erase cached coordinate-gated results.
            if (modeChanged) {
                srOwmWrite("srGRequest", null);
                srOwmWrite("srGInFlight", 0);
                srOwmWrite("srGNextAt", 0);
                srOwmWrite("srGFail", 0);
                srOwmWrite("srGPhoneMissingV32624", 0);
            }
            srOwmWrite("srGEventDue", 0);
        } else {
            // Changing cadence must affect CURRENT/HOURLY immediately;
            // retain fresh cached data and unrelated DAILY/AQI deadlines.
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextSV32648", 0);
            if (modeChanged || keyChanged) {
                srOwmWrite("srONextDV326", 0);
                srOwmWrite("srONextAV326", 0);
            }
        }
    }
    // Do not leave an old OWM timer armed after removing the API key.
    if (mode == 1 && !srOwmKeyReady()) {
        try { Bg.deleteSleepEvent(); Bg.deleteWakeEvent(); } catch (e) { }
        srOwmWrite("srODiagV3266", [Time.now().value(), 0, -11]);
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        return;
    }
    srOwmArmIfNeeded();
}
