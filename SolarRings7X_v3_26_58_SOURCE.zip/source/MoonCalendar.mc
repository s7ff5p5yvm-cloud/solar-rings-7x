using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Math as Math;

// Independent astronomical estimate of new/full moon instants based on the
// Meeus lunar-phase series. Works offline and is calculated only when the
// local calendar day changes. The result is an estimate, not an ephemeris.
var _srFullMoonDayCache = null;

function srMoonSinDeg(degrees) {
    return Math.sin(degrees * 0.017453292519943295d);
}

// k is an integer for a new moon, k + 0.5 for a full moon.
// A Double is mandatory: Julian dates exceed Float's day resolution.
function srMoonPhaseEpoch(k, full) {
    var t = k / 1236.85d;
    var t2 = t * t;
    var t3 = t2 * t;
    var t4 = t3 * t;
    var meanJD = 2451550.09766d + 29.530588861d * k +
                 0.00015437d * t2 - 0.000000150d * t3 + 0.00000000073d * t4;
    var e = 1d - 0.002516d * t - 0.0000074d * t2;
    var m = 2.5534d + 29.1053567d * k - 0.0000014d * t2 - 0.00000011d * t3;
    var mp = 201.5643d + 385.81693528d * k + 0.0107582d * t2 +
             0.00001238d * t3 - 0.000000058d * t4;
    var f = 160.7108d + 390.67050284d * k - 0.0016118d * t2 -
            0.00000227d * t3 + 0.000000011d * t4;
    var omega = 124.7746d - 1.56375588d * k + 0.0020672d * t2 +
                0.00000215d * t3;
    var correction = (full ? -0.40614d : -0.40720d) * srMoonSinDeg(mp) +
                     (full ? 0.17302d : 0.17241d) * e * srMoonSinDeg(m) +
                     (full ? 0.01614d : 0.01608d) * srMoonSinDeg(2d * mp) +
                     (full ? 0.01043d : 0.01039d) * srMoonSinDeg(2d * f) +
                     (full ? 0.00734d : 0.00739d) * e * srMoonSinDeg(mp - m) -
                     (full ? 0.00515d : 0.00514d) * e * srMoonSinDeg(mp + m) +
                     (full ? 0.00209d : 0.00208d) * e * e * srMoonSinDeg(2d * m) -
                     0.00111d * srMoonSinDeg(mp - 2d * f) -
                     0.00057d * srMoonSinDeg(mp + 2d * f) +
                     0.00056d * e * srMoonSinDeg(2d * mp + m) -
                     0.00042d * srMoonSinDeg(3d * mp) +
                     0.00042d * e * srMoonSinDeg(m + 2d * f) +
                     0.00038d * e * srMoonSinDeg(m - 2d * f) -
                     0.00024d * e * srMoonSinDeg(2d * mp - m) -
                     0.00017d * srMoonSinDeg(omega) -
                     0.00007d * srMoonSinDeg(mp + 2d * m) +
                     0.00004d * srMoonSinDeg(2d * mp - 2d * f) +
                     0.00004d * srMoonSinDeg(3d * m) +
                     0.00003d * srMoonSinDeg(mp + m - 2d * f) +
                     0.00003d * srMoonSinDeg(2d * mp + 2d * f) -
                     0.00003d * srMoonSinDeg(mp + m + 2d * f) +
                     0.00003d * srMoonSinDeg(mp - m + 2d * f) -
                     0.00002d * srMoonSinDeg(mp - m - 2d * f) -
                     0.00002d * srMoonSinDeg(3d * mp + m) +
                     0.00002d * srMoonSinDeg(4d * mp);
    // Major common planetary perturbations (seconds-scale for this display).
    correction += 0.000325d * srMoonSinDeg(299.77d + 0.107408d * k - 0.009173d * t2) +
                  0.000165d * srMoonSinDeg(251.88d + 0.016321d * k) +
                  0.000164d * srMoonSinDeg(251.83d + 26.651886d * k) +
                  0.000126d * srMoonSinDeg(349.42d + 36.412478d * k) +
                  0.000110d * srMoonSinDeg(84.66d + 18.206239d * k);
    // The Meeus formula yields JDE (TT); subtract ~75s for 2026 UTC.
    // Within minutes across the expected service life, adequate for a day
    // countdown; unlike fixed 29.53-day cycles it won't drift by days.
    return ((meanJD + correction - 2440587.5d) * 86400d - 75d).toNumber();
}

function srMoonCalendarDay(date) {
    // Comparison is done using synthetic UTC noons of LOCAL calendar dates,
    // so DST changes do not shift a calendar-day countdown.
    return Gregorian.moment({:year => date.year, :month => date.month,
                             :day => date.day, :hour => 12, :minute => 0, :second => 0}).value();
}

// Returns [cyclePosition 0..1, "Xd" to NEXT full moon including today].
// Value and disk geometry are memoized by date: no trigonometry per redraw.
function srMoonDayInfo() {
    var now = Time.now();
    var local = Gregorian.info(now, Time.FORMAT_SHORT);
    var localDay = srMoonCalendarDay(local);
    var cached = _srFullMoonDayCache;
    if (cached != null && cached[0] == localDay) { return cached[1]; }
    var seconds = now.value();
    // k is the new-moon cycle number relative to Jan 2000.
    var cycle = Math.floor((seconds.toDouble() - 947168438d) / 2551443.0d).toNumber();
    var newAt = srMoonPhaseEpoch(cycle, false);
    if (seconds < newAt) { cycle -= 1; newAt = srMoonPhaseEpoch(cycle, false); }
    var nextNew = srMoonPhaseEpoch(cycle + 1, false);
    if (seconds >= nextNew) {
        cycle += 1;
        newAt = nextNew;
        nextNew = srMoonPhaseEpoch(cycle + 1, false);
    }
    var fullAt = srMoonPhaseEpoch(cycle + 0.5d, true);
    var phase = 0.0;
    if (seconds <= fullAt) {
        phase = (seconds - newAt).toDouble() / (fullAt - newAt).toDouble() * 0.5d;
    } else {
        phase = 0.5d + (seconds - fullAt).toDouble() /
                (nextNew - fullAt).toDouble() * 0.5d;
    }
    if (phase < 0) { phase = 0d; }
    if (phase > 1) { phase = 1d; }
    // If today's full moon has already passed, show 0d for the whole local
    // day. The following day resumes countdown to the next full moon.
    var fullDate = Gregorian.info(new Time.Moment(fullAt), Time.FORMAT_SHORT);
    var days = ((srMoonCalendarDay(fullDate) - localDay) / 86400).toNumber();
    if (days < 0) {
        var following = srMoonPhaseEpoch(cycle + 1.5d, true);
        var nextDate = Gregorian.info(new Time.Moment(following), Time.FORMAT_SHORT);
        days = ((srMoonCalendarDay(nextDate) - localDay) / 86400).toNumber();
    }
    if (days < 0) { days = 0; }
    var result = [phase, days.toString() + "d"];
    _srFullMoonDayCache = [localDay, result];
    return result;
}
