# Solar Rings 3.26.23 — automatyczna aktualizacja lokalizacji

Baza: **3.26.22** (bez StormGuard, bez szarych alertów historycznych, trzy miejsca na ikony).

## Co poprawiono
- Odczyt `Position.getInfo()` co 5 min podczas pracy tarczy w trybie OWM. To **odczyt ostatnich metadanych**, nie uruchamianie odbiornika GPS.
- Pozycja z jakościowym GPS (`QUALITY_USABLE` lub lepszym), z timestampem do 12 minut, ma pierwszeństwo przed starymi współrzędnymi Garmin Weather.
- Gdy Garmin Weather pokazuje obserwację sprzed ostatniego wiarygodnego fixa GPS, tarcza przez maks. 2 h nie przeskakuje od razu do starszej lokalizacji. Nowsza obserwacja Garmin Weather może przejąć lokalizację.
- Gdy brak wiarygodnego GPS, działa Garmin Weather i stara lokalizacja z aktywności (ostatnia tylko jako zapas).
- Zmiana współrzędnych czyści dane poprzedniego miasta oraz planuje nowy odczyt OWM, bez osobnych dodatkowych timerów i bez częstszego HTTP.

## Zachowane bez zmian
- Interwał usług w tle 5 min; docelowe pobieranie aktualnej pogody i prognozy co 10 min; AQI i prognoza dzienna według istniejącego harmonogramu.
- StormGuard usunięty; ciśnienie dostępne jako zwykłe pole danych.
- Brak historycznych ikon opadów; trzy oryginalne pozycje ostrzeżeń oraz czerwone ikony z turkusowym paskiem prognozy.
- Klucze ustawień dostawcy i API, identyfikator aplikacji, mechanizmy rysowania i przekazywania ostrzeżeń.

## Ograniczenia
- Tarcza nie może wymusić świeżego fixa GPS. Gdy Garmin Connect nie przesyła nowej pozycji, zmiana miasta może nie nastąpić automatycznie. Wtedy pomaga aktualizacja lokalizacji Garmin Weather / synchronizacja telefonu lub uzyskanie fixa GPS w aktywności.
- Odczyt `Position.getInfo()` wymaga uprawnienia Positioning (już obecnego w manifest.xml).
- Nie przeprowadzono kompilacji Garmin Monkey C ani testu na zegarku w środowisku roboczym. Wymagana kompilacja GitHub Actions i test rzeczywisty.
