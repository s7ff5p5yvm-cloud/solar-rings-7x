# Solar Rings 7X v3.26.37 — stabilna baza 3.26.30 + trzy poprawki

Projekt powstał przez skopiowanie stabilnego źródła **3.26.30**, NIE przez usuwanie Open-Meteo z niestabilnej serii 3.26.31–3.26.36.

1. **Bateria po przecinku** — tylko gdy Garmin faktycznie zwraca ułamek procenta. Nie dopisujemy sztucznego `,0` do liczb całkowitych. Zachowano skale i pozostałe pola.
2. **Nazwa lokalizacji pogodowej dla Garmin i OWM** — wspólny Photon dla współrzędnych obserwacji/prośby o pogodę. W szczególności OWM nie pokazuje już wyłącznie offline'owego dużego miasta: używa dokładniejszej nazwy z Photon, z odświeżeniem przy zmianie współrzędnych. `~` oznacza szacunkową nazwę z awaryjnej bazy offline. OWM wykonuje geokodowanie we własnym istniejącym zadaniu w tle, po priorytetowej bieżącej pogodzie, bez osobnego timera i bez dodatkowego wywołania HTTP podczas tego samego zadania. Łączny limit zapytań Photon: minimum 30 minut między próbami. Nazwa odnosi się do współrzędnych dla danych pogodowych, NIE do nieudokumentowanej lokalizacji serwera/stacji.
3. **Trzy kapsuły** — górna krawędź przeniesiona z y=167 na y=171, wysokość 44->39, dostosowane pozycje ikon, tekstów i pasków; odstęp od linii y=164 i y=215.

NIE dodano Open-Meteo. OWM i Garmin Weather pozostają jedynymi dostawcami. Nie zmieniano progów alertów, pogody, wykresów, Bluetooth, czasu, czcionek godziny, animacji, snu ani kryteriów pobierania prognoz.

Ograniczenie: testy źródłowe nie potwierdzają działania na urządzeniu i nie zastępują kompilacji Connect IQ SDK. Photon jest publicznym geokoderem o limitach i nazwach zależnych od danych OpenStreetMap.
