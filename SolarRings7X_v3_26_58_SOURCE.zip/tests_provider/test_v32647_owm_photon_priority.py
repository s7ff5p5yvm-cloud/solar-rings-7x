"""v3.26.47 workflow regression checks. Source checks + bounded scheduling model."""
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
SSET=(ROOT/'resources/settings/settings.xml').read_text()
GEO=(ROOT/'source/WeatherGeocode.mc').read_text()

class OwmPhotonPriority47(unittest.TestCase):
    def test_diagnostics_show_endpoints_without_network(self):
        setting=next(el for el in ET.fromstring(SSET).findall('setting')
                     if el.get('propertyKey')=='@Properties.gwPreviewV332')
        self.assertEqual([int(x.get('value')) for x in setting.find('settingConfig')],
                         [0, 15, 21, 22])
        self.assertIn('function drawPhotonDiag(dc)', FACE)
        self.assertIn('function drawOwmDiagnostics(dc)', FACE)
        self.assertNotIn('function drawOpenDiagPage(', FACE)
        panel=FACE.split('function drawPhotonDiag(dc)')[1].split('function onUpdate(dc)')[0]
        for token in ('Comm.makeWebRequest(', 'srOwmForecastSnapshot()',
                      'srOwmVisibleCurrent()', 'var lines = []'):
            self.assertNotIn(token,panel)
    @unittest.skip("v57 uses deadline fairness; replaced by test_v32657_recovery.py")
    def test_weather_queue_order_and_photon_reserved(self):
        tokens=['if (nextC <= _now) { _kind = "current"; }',
                'else if (nextF <= _now) { _kind = "forecast"; _shortRequest = false; }',
                'else if (_shortEnabled && shortReady() && nextS <= _now)',
                'else if (cityLookupDue() && Sys.getDeviceSettings().phoneConnected)',
                'else if (setting("srOwmAirV326", false) && nextA <= _now)',
                'else if (nextD <= _now) { _kind = "daily"; }']
        indexes=[NET.index(x,NET.index('    function start()')) for x in tokens]
        self.assertEqual(indexes,sorted(indexes))
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
    @unittest.skip("v57 uses deadline fairness; replaced by test_v32657_recovery.py")
    def test_hourly_and_short_are_independent(self):
        self.assertIn('"srONextFV326", "srOHoursV326"',NET)
        self.assertIn('"srONextSV32648", "srOShortV3264"',NET)
        self.assertIn('function shortReady()',NET)
        self.assertIn('function shortSeconds() { return _interval <= 15 ? 35 * 60 : 45 * 60; }',NET)
        self.assertIn('srOShortPausedV3264',NET)
    def test_location_poll_and_bounded_retry(self):
        self.assertIn('now - _lastOpenLocationPoll >= 5 * 60',FACE)
        self.assertIn('if (code == 429) { minutes = 60; }',NET)
        retry=NET.split('function cityRetry(code)')[1].split('function startCityLookup')[0]
        self.assertNotIn('24 * 3600',retry)
        self.assertIn('srGWideV32648',NET)
        self.assertIn('srGTraceV32647',NET)
        self.assertIn('srGTraceV32647',GEO)
    def test_scheduler_model_liveness(self):
        # One HTTP slot every 5 minutes; current and 1h have absolute
        # priority, 15m enrichment before Photon; AQI and daily remain lower-priority.
        next_at={'current':0, 'hourly':0,'short':0,
                 'photon':0,'air':0,'daily':0}
        periods={'current':15,'hourly':20,'short':60,
                 'photon':10**6,'air':60,'daily':720}
        seen=[]
        for now in range(0,180,5):
            choices=['current','hourly','short','photon','air','daily']
            if now < 5: choices.remove('short')  # Only after 1h bootstrap
            due=[p for p in choices if next_at[p]<=now]
            if not due: continue
            k=due[0]
            seen.append((now,k))
            next_at[k]=now+periods[k]
        self.assertEqual([k for _,k in seen[:3]],['current','hourly','short'])
        for k in ('short','air','daily'):
            self.assertIn(k,[name for _,name in seen])
        self.assertLessEqual(next(t for t,k in seen if k=='photon'),25)
    def test_all_api_snapshots_and_aqi(self):
        for key in ('srODNowV3268','srOD1hV32648','srOD15mV32648',
                    'srODDailyV3268','srODAirV3268'):
            self.assertIn(key,FACE)
        self.assertIn('if (setting("srOwmAirV326", false))',NET)
        self.assertIn('3600',NET)

    def test_storage_schema_and_app_id_unchanged(self):
        from hashlib import sha256
        # Stable v3.26.46 properties hash, independent of local parent folders.
        expected='e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63'
        self.assertEqual(sha256((ROOT/'resources/settings/properties.xml').read_bytes()).hexdigest(),expected)
        app=ET.parse(ROOT/'manifest.xml').getroot()[0]
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')

if __name__=='__main__': unittest.main()
