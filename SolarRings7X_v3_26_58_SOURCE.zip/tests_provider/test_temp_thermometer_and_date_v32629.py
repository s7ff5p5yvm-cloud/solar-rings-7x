"""Regressions from field screenshots: visual cold test must render thermometer."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
F=(ROOT/'source/SolarRings7X.mc').read_text()

class TempAndRightDateTests(unittest.TestCase):
    def test_test_mode_controls_both_value_and_thermometer(self):
        marker=F.split('function temperatureMarker(dc, w, x, y, diagnosticTemp) {')[1].split('// Small, independent',1)[0]
        weather=F.split('function drawWeather(dc, monitor, weather) {')[1].split('// Three ORIGINAL',1)[0]
        self.assertIn('temperatureMarker(dc, weather, 142, 224, diagnosticTemp);',weather)
        self.assertIn('var testCold = (diagnosticTemp == 1 || diagnosticTemp == 2);',marker)
        self.assertIn('var testHot = (diagnosticTemp == 3);',marker)
        self.assertIn('var isTest = testCold || testHot;',marker)
        self.assertIn('color = testCold ? 0x00CCFF : Gfx.COLOR_RED;',marker)
        self.assertIn('if (!isTest && !srSetting("tempAlertsV312", true))',marker)
        self.assertIn('if (temp > hot)',marker)
        self.assertIn('else if (temp < cold)',marker)
        self.assertIn('if (w.observationTime != null)',marker)
        self.assertIn('diagnosticTemp == 3) { shownTemp = "45°C";',weather)
        self.assertIn('lowerLabel = "ODCZ. 50°C";',weather)

    def test_test_options_and_real_thresholds(self):
        xml=ET.parse(ROOT/'resources/settings/settings.xml').getroot()
        properties=(ROOT/'resources/settings/properties.xml').read_text()
        strings=(ROOT/'resources/strings.xml').read_text()
        self.assertIn('<listEntry value="3">@Strings.tempLayoutTest_hot</listEntry>',ET.tostring(xml,encoding='unicode'))
        self.assertIn('<string id="tempLayoutTest_hot">',strings)
        self.assertIn('<property id="tempColdV312" type="number">0</property>',properties)
        self.assertIn('<property id="tempHotV312" type="number">30</property>',properties)

    def test_date_right_of_clock_without_overlap(self):
        date=F.split('function drawDate(dc, dayLabel, dateLabel) {')[1].split('// Connection status',1)[0]
        self.assertIn('dayLabel, 170, 100, 24, 29',date)
        self.assertIn('dateLabel, 225, 97, 82, 34',date)
        clock=F.split('function drawClock(dc, clock) {')[1].split('// Mini digits',1)[0]
        self.assertIn('var left = 9 + ((148 - groupW) / 2).toNumber();',clock)
        self.assertLessEqual(9+148+1, 170-24//2)
        self.assertLessEqual(170+24//2,225-82//2)

if __name__=='__main__': unittest.main()
