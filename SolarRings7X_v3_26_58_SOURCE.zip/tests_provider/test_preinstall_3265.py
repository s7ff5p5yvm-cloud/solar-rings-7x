from pathlib import Path
import unittest
P=Path(__file__).resolve().parents[1]
G=(P/'source/GarminWeatherWarnings.mc').read_text()
O=(P/'source/SolarOpenWarnings.mc').read_text()
N=(P/'source/SolarOpenNetwork.mc').read_text()
UI=(P/'source/SolarRings7X.mc').read_text()

def ice(pop, minimum=50, identified=True, is_forecast=True):
    if not identified: return False
    if not is_forecast: return True
    if pop is None:return True
    if type(pop) not in (int,float) or not 0<=pop<=100:return False
    return pop>=minimum

class Preinstall3265(unittest.TestCase):
    def test_ice_probability_boundary_independent_of_rain_mode(self):
        for threshold in (30,40,50,60,70,80,90):
            for value in (None,0,20,30,40,49,50,59,60,70,80,89,90,99,100,-1,101,'invalid'):
                expected = value is None or (type(value) in (int,float) and 0<=value<=100 and value>=threshold)
                self.assertEqual(ice(value,threshold),expected)
        self.assertIn('function iceChanceMatches(chance)',G)
        self.assertIn('gwIceChanceV332',G)
        self.assertIn('(!forecast || iceChanceMatches(pop))',O)
        self.assertIn('(!isForecast || iceChanceMatches(chance))',G)
        self.assertNotIn('forecastChanceMatches(chance,\n                     srSetting("gwIceChanceV332", 50))',G)
    def test_ice_current_not_filtered(self):
        for val in (0,10,100,None,-1): self.assertTrue(ice(val,is_forecast=False))
    def test_orphan_marker_persists_through_processing(self):
        receive=N.index('function onReceive(')
        portion=N[receive:]
        clear='write("srOShortAttemptV3264", 0)'
        self.assertNotIn(clear,portion[:portion.index('if (!ok || _unsafe)')])
        self.assertIn(clear,portion[portion.index('if (!ok || _unsafe)'):])
        self.assertIn('code != 401 && code != 403 && code != 429',N)
        self.assertIn('orphaned <= _now - 5 * 60',N)
    def test_rotation_when_overflow(self):
        self.assertEqual(UI.count('var phase = (Time.now().value() / 5).toNumber();'),2)
        self.assertNotIn('var phase = (Time.now().value() / 60).toNumber();',UI)
    def test_no_new_http(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),2)
if __name__=='__main__':unittest.main()
