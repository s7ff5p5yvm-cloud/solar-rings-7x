import unittest
class WeatherSyncModel(unittest.TestCase):
  def simulate(self,minutes=24*60,aux_every=25):
    due={"C":0,"F":0,"A":0}
    last_aux=-999
    last_core=None
    out=[]
    for t in range(0,minutes,5):
      nc=due['C'];nf=due['F'];na=due['A']
      wantc=nc<=t;wantf=nf<=t;aux=na<=t
      reserve=aux and nc>0 and nf>0 and t-last_aux>=aux_every
      if (wantc or wantf) and not reserve:
        if wantc and (not wantf or nc<nf or (nc==nf and last_core=='F')): k='C'
        else: k='F'
        last_core=k;due[k]=t+10
      elif aux:
        k='A';last_aux=t;due[k]=t+25
      else:continue
      out.append((t,k))
    return out
  def test_two_core_feeds_bounded(self):
    out=self.simulate()
    for name in 'CF':
      times=[t for t,k in out if k==name]
      self.assertTrue(times)
      self.assertLessEqual(max(b-a for a,b in zip(times,times[1:])),15)
      self.assertGreaterEqual(min(b-a for a,b in zip(times,times[1:])),10)
  def test_aux_never_starved(self):
    out=self.simulate()
    times=[t for t,k in out if k=='A']
    self.assertGreater(len(times),25)
    self.assertLessEqual(max(b-a for a,b in zip(times,times[1:])),35)
  def test_no_double_request(self):
    out=self.simulate()
    self.assertEqual(len({x[0] for x in out}),len(out))
    self.assertLessEqual(len(out),288)
  def test_initial_weather_before_aux(self):
    out=self.simulate(90)
    self.assertEqual([k for _,k in out[:2]], ['F','C'] if False else ['F','C'])
