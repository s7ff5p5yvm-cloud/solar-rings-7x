import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib
R=Path(__file__).resolve().parents[1]
C=(R/'source/Config.mc').read_text()
U=(R/'source/SolarRings7X.mc').read_text()
N=(R/'source/SolarOpenNetwork.mc').read_text()
G=(R/'source/GarminWeatherWarnings.mc').read_text()
class Recovery(unittest.TestCase):
 def test_settings_immediate_native_contract(self):
  cb=U.split('function onSettingsChanged()',1)[1].split('\n    }',1)[0]
  self.assertIn('srResetSettingsCache()',cb)
  self.assertIn('Ui.requestUpdate()',cb)
  self.assertNotIn('45000',U)
  self.assertNotIn('srBeginSettingsHold',C)
 def test_properties_schema_stable(self):
  self.assertEqual(hashlib.sha256((R/'resources/settings/properties.xml').read_bytes()).hexdigest(),'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
  keys={x.get('id') for x in ET.parse(R/'resources/settings/properties.xml').getroot()}
  import re
  for file in (R/'source').glob('*.mc'):
   for match in re.finditer(r'srSetting\("([^"\\]+)"',file.read_text()):
    self.assertIn(match.group(1),keys,match.group(1))
 def test_garmin_hourly_oom_path_removed(self):
  self.assertNotIn('Weather.getHourlyForecast()',G)
  self.assertNotIn('Weather.getHourlyForecast()',U)
 def test_weather_fairness(self):
  self.assertIn('srOLastCoreV32657',N)
  self.assertIn('srOAuxLastV32657',N)
  self.assertIn('srOSafePlanV32657',N)
  self.assertIn('10 * 60',N)
  self.assertIn('25 * 60',N)
  self.assertIn('function startCityLookup()',N)
  self.assertIn('one request',N.lower())
 def test_no_guess_sleep(self):
  self.assertNotIn('hour >= 22 || hour < 6',N)
  self.assertIn('srOSleepStateV32624',N)
 def test_debug_present(self):
  self.assertIn('drawPhotonDiag',U)
  self.assertIn('drawOwmDiagnostics',U)
  self.assertIn('Q BRAK',U)
 def test_keep_user_features(self):
  self.assertIn('srOpenKeyV326',(R/'resources/settings/properties.xml').read_text())
  self.assertIn('srOwm15MinV3264',(R/'resources/settings/properties.xml').read_text())
  self.assertIn('version="3.26.58"',(R/'manifest.xml').read_text())
