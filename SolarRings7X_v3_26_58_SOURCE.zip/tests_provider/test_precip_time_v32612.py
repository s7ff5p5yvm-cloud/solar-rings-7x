"""Source-contract and independent decision-model tests for Solar Rings 3.26.13.

These do not execute Monkey C and do not validate actual weather API payloads.
"""
import unittest
from pathlib import Path
P = Path(__file__).resolve().parents[1]
W = (P/'source/SolarOpenWarnings.mc').read_text()
N = (P/'source/SolarOpenNetwork.mc').read_text()
D = (P/'source/SolarOpenData.mc').read_text()
G = (P/'source/GarminWeatherWarnings.mc').read_text()
F = (P/'source/SolarRings7X.mc').read_text()
R = (P/'resources/settings/settings.xml').read_text()


def signal(id, rain, snow, forecast, pop=None, threshold=40, heavy_only=False):
    """Independent policy reference, not a Monkey C interpreter."""
    if id==511: return None  # freezing rain has its own hazard icon
    explicit_rain = id in [*range(300,303), *range(310,315),321,500,501,502,503,504,520,521,522,531]
    explicit_snow = id in (600,601,602,611,612,613,615,616,620,621,622)
    explicit_mix = id in (611,612,613,615,616)
    if isinstance(pop,(int,float)) and not 0<=pop<=100: return None
    if forecast and pop is not None and (not isinstance(pop,(int,float)) or pop<threshold): return None
    r = isinstance(rain,(int,float)) and 0.1<=rain<=500
    s = isinstance(snow,(int,float)) and 0.1<=snow<=500
    if forecast:
        if explicit_mix or r and s: return 'mixed' if not heavy_only else None
        if explicit_rain or r: return 'rain' if not heavy_only or id in (502,503,504,522) or r and rain>=8 else None
        if explicit_snow or s: return 'snow' if not heavy_only or id in (602,622) else None
        return None
    if explicit_mix: return 'mixed'
    if explicit_rain: return 'rain'
    if explicit_snow: return 'snow'
    # Last-hour amounts do not prove that rain/snow is happening NOW.
    return None

class WarningTime32612(unittest.TestCase):
    def test_past_hour_rain_does_not_generate_a_current_warning(self):
        self.assertIsNone(signal(803,.5,None,False))
        self.assertIsNone(signal(804,None,1.2,False))
        self.assertIsNone(signal(803,.4,.2,False))
        self.assertIsNone(signal(803,0,None,False))
        self.assertIsNone(signal(803,.05,None,False))
        self.assertNotIn('function recentPrecipitation(',W)
        self.assertNotIn('addAlert(out, 66)',W)
        self.assertNotIn('addAlert(out, 67)',W)
        self.assertNotIn('addAlert(out, 75)',W)
    def test_explicit_current_code_wins(self):
        self.assertEqual(signal(500,.2,None,False),'rain')
        self.assertEqual(signal(601,None,.3,False),'snow')
        self.assertEqual(signal(511,.3,None,False),None)
        self.assertIn('var currentKinds = kindsFor(',W)

    def test_forecast_cloud_and_quantified_amount_allowed_with_percentage(self):
        self.assertEqual(signal(803,.5,None,True,60),'rain')
        self.assertEqual(signal(804,None,.2,True,80),'snow')
        self.assertEqual(signal(803,.7,.2,True,60),'mixed')
        self.assertIsNone(signal(803,.7,None,True,20))
        self.assertIsNone(signal(800,None,None,True,100))
        self.assertIn('(forecast && measuredRain && !freezing)',W)
        self.assertIn('(forecast && measuredSnow)',W)
    def test_missing_probability_is_not_zero_invalid_is_rejected(self):
        self.assertEqual(signal(803,.5,None,True,None),'rain')
        self.assertIsNone(signal(803,.5,None,True,-1))
        self.assertIsNone(signal(803,.5,None,True,150))
        self.assertIn('forecastChanceMatches(pop,',W)
        self.assertIn('if (chance == null) { return true; }',G)
        self.assertIn('if (!validMeasure(chance, 0, 100)) { return false; }',G)
    def test_intensity_is_not_probability(self):
        self.assertIsNone(signal(803,5,None,True,80,heavy_only=True))
        self.assertEqual(signal(803,8,None,True,80,heavy_only=True),'rain')
        self.assertEqual(signal(502,None,None,True,80,heavy_only=True),'rain')
        self.assertIn('rainRate >= 8',W)
    def test_forecast_bucket_uses_15min_or_1h_and_remains_cyan(self):
        for x in ['var bucket = _shortRequest ? 900 : 3600;',
                  't <= _now - bucket', 't > _now + horizonSeconds']:
            self.assertIn(x,N)
        self.assertIn('h[0] <= now - slotSeconds',W)
        self.assertIn('futureKinds[z] + 16',W)
        self.assertIn('function srOwmForecastStepSeconds()',D)
    def test_warnings_expire_and_stale_temperature_fades(self):
        self.assertIn('elapsed <= 5400',W)
        self.assertIn('elapsed > 2700 ? 64 : 0',W)
        self.assertIn('age > 5400',F)
        self.assertIn('age > 2700',F)
        self.assertIn('now - air[3] > 2700 ? 64 : 0',W)
    def test_all_hazards_and_controls_still_present(self):
        settings=['gwOnV332','gwForecastV332','gwStormOnV332','gwRainOnV332',
                  'gwSnowOnV332','gwWindOnV332','gwFreezeOnV332','gwFogOnV332',
                  'gwIceOnV332','gwHailOnV332','gwUvOnV332','gwRainHeavyV332',
                  'gwSnowHeavyV332','srOwmAirV326']
        for s in settings:
            with self.subTest(s=s): self.assertIn(s,R)
        for kind in [1,2,3,4,5,6,7,9,10,11,13]:
            self.assertIn(f'addAlert(k, {kind})',W)
        self.assertIn('c == Weather.CONDITION_HAIL',G)
        self.assertIn('srOwmGustV3263',W)
        self.assertIn('srOwmAqiMinV326',W)
        self.assertIn('temperatureMarker(',F)
    def test_no_new_api_calls_background_timers_or_raw_api_secrets(self):
        self.assertEqual(N.count('Comm.makeWebRequest(route, q'),1)
        self.assertEqual(N.count('Bg.registerForTemporalEvent('),6)  # two sleep-window schedules
        self.assertNotIn('Comm.makeWebRequest',W)
        self.assertNotIn('Bg.registerForTemporalEvent',W)
        self.assertIn('OWM K',F)
        self.assertIn('1h R',F)
    def test_stale_recent_opad_has_no_new_red_tag(self):
        self.assertNotIn('addAlert(out, 2)',W)
        self.assertNotIn('addAlert(out, 3)',W)
        self.assertIn('color = Gfx.COLOR_LT_GRAY',F)

if __name__=='__main__': unittest.main()
