import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'source/SolarRings7X.mc').read_text()
class OriginalIconPositions(unittest.TestCase):
 def test_original_positions_kept(self):
  self.assertIn('var centers = [68, 91, 114];',s)
  self.assertNotIn('var centers = [55, 76, 97, 118];',s)
  self.assertIn('dc.setClip(103, 217, 22, 26);',s)
  self.assertIn('dc.fillRectangle(103, 217, 22, 26);',s)
  self.assertIn('drawAlertGlyph(dc, 114, kind);',s)
 def test_rotation_at_three(self):
  self.assertIn('if (fixedCount > 3) { fixedCount = 2; }',s)
  self.assertIn('if (count > 3)',s)
  self.assertIn('for (var k = 2; k < count; k++)',s)
 def test_pressure_warning_not_restored(self):
  self.assertNotIn('new StormGuard()',s)
  self.assertNotIn('stormBolt(dc, x, 228)',s)
