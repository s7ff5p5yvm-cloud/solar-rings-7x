"""Static regression checks for the 3.26.24 Photon audit changes.

These complement existing tests; they are NOT a Monkey C build or a device test.
"""
from pathlib import Path
import unittest
BASE = Path(__file__).resolve().parents[1]
GEO = (BASE/'source/WeatherGeocode.mc').read_text()
FACE = (BASE/'source/SolarRings7X.mc').read_text()
DATA = (BASE/'source/SolarOpenData.mc').read_text()
NETWORK = (BASE/'source/SolarOpenNetwork.mc').read_text()

class GeoAudit32624Tests(unittest.TestCase):
    def test_test15_new_error_codes_have_readable_labels(self):
        for code in [-202, -203, -204, -205, -206, -208, -209, -210,
                     -211, -212, -213, -214, -216, -220, -221, -222,
                     -230, -231, -232, -234]:
            self.assertIn(f'diag[2] == {code}', FACE, code)
        self.assertIn('statusLabel = "LIMIT DZIENNY"', FACE)
        self.assertIn('statusLabel = "BRAK TEMP"', FACE)
    def test_provider_change_clears_old_request_but_keeps_rate_limiter(self):
        start = DATA.index('if (mode == 0) {\n            // Provider switch invalidates')
        block = DATA[start:DATA.index('} else {', start)]
        self.assertIn('if (modeChanged)',block)
        self.assertIn('srOwmWrite("srGRequest", null)',block)
        self.assertIn('srOwmWrite("srGInFlight", 0)',block)
        self.assertNotIn('srGLastTry',block.split('if (modeChanged)')[1])
    def test_offline_does_not_escalate_server_backoff(self):
        offline = GEO.split('function retryPhoneMissing()')[1].split('function retryTransport()')[0]
        self.assertIn('srGPhoneMissingV32624',offline)
        self.assertIn('15 * 60',offline)
        self.assertNotIn('srGFail',offline)
        self.assertNotIn('Comm.makeWebRequest',offline)
        self.assertIn('if (code < 0) { photonTrace(27, code); retryTransport(); return; }', GEO)
        temp = GEO.split('function retryTransport()')[1].split('function onSleepTime()')[0]
        self.assertNotIn('srGFail',temp)
    def test_disconnect_is_checked_before_timeout_or_http(self):
        branch = GEO.split('function onTemporalEvent()')[1].split('function onReceive(')[0]
        self.assertLess(branch.index('if (!Sys.getDeviceSettings().phoneConnected)'),
                        branch.index('if (storedNumber("srGInFlight", 0) == 1)'))
        self.assertLess(branch.index('if (!Sys.getDeviceSettings().phoneConnected)'),
                        branch.index('Comm.makeWebRequest('))
        self.assertIn('retryPhoneMissing();',branch)
    def test_reconnection_rearms_once_and_respects_last_attempt(self):
        part = FACE.split('function remoteCityForWeatherPosition(')[1].split('function resetWeatherWarningCache()')[0]
        self.assertIn('phoneRecovered',part)
        self.assertIn('App.Storage.setValue("srGPhoneMissingV32624", 0)',part)
        self.assertIn('lastAttempt + 15 * 60',part)
        self.assertIn('var recoveryDelay = 5 * 60',part)
    def test_owm_warning_cadence_and_sleep_preserved(self):
        self.assertIn('if (nightWindow()) { waitForMorning(); return; }',NETWORK)
        self.assertIn('Bg.registerForSleepEvent()',DATA)
        self.assertIn('Bg.registerForWakeEvent()',DATA)
        self.assertEqual(NETWORK.count('Comm.makeWebRequest('),2)
        self.assertIn('var centers = [68, 91, 114];',FACE)

if __name__ == '__main__': unittest.main()
