from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
BG=(ROOT/'source/WeatherGeocode.mc').read_text()
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()
class ScheduledSleepTests(unittest.TestCase):
    def test_registered_events(self):
        self.assertIn('Bg.registerForSleepEvent()',DATA)
        self.assertIn('Bg.registerForWakeEvent()',DATA)
    def test_callbacks(self):
        self.assertIn('function onSleepTime() as Void',BG)
        self.assertIn('function onWakeTime() as Void',BG)
        self.assertIn('srOSleepStateV32624',BG)
    def test_no_http_while_scheduled_sleep(self):
        self.assertIn('if (nightWindow()) { waitForMorning(); return; }',NET)
        self.assertIn('state[0] == 1',NET)
        self.assertIn('App.Storage.setValue("srOSleepStateV32624", [1, now])',BG)
    def test_forecast_recovery_on_wake(self):
        self.assertIn('App.Storage.setValue("srONextCV326", 0)',BG)
        self.assertIn('App.Storage.setValue("srONextFV326", 0)',BG)
        self.assertIn('Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)))',BG)
