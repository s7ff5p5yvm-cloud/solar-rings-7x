"""v3.26.58 source/contract checks. Not a substitute for Monkey C SDK or device tests."""
import hashlib
import re
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

R=Path(__file__).resolve().parents[1]
G=(R/'source/GarminWeatherWarnings.mc').read_text()
O=(R/'source/SolarOpenWarnings.mc').read_text()
N=(R/'source/SolarOpenNetwork.mc').read_text()
U=(R/'source/SolarRings7X.mc').read_text()
D=(R/'source/SolarOpenData.mc').read_text()
CFG=(R/'source/Config.mc').read_text()


class WeatherGuardV58(unittest.TestCase):
    def test_same_settings_schema_and_user_keys(self):
        actual=hashlib.sha256((R/'resources/settings/properties.xml').read_bytes()).hexdigest()
        self.assertEqual(actual,'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
        props={x.get('id') for x in ET.parse(R/'resources/settings/properties.xml').getroot()}
        self.assertIn('srOpenKeyV326',props)
        self.assertIn('gwOnV332',props)
        self.assertEqual(len(props),77)
        for path in (R/'source').glob('*.mc'):
            for key in re.findall(r'srSetting\("([^"\\]+)"',path.read_text()):
                self.assertIn(key,props, (path.name,key))

    def test_manifest_and_unchanged_id(self):
        app=ET.parse(R/'manifest.xml').getroot()[0]
        self.assertEqual(app.attrib['version'],'3.26.58')
        self.assertEqual(app.attrib['id'],'D1F8E1A4B7FC45BD91E8F0A0959041BF')

    def test_no_known_garmin_heap_exhaustion_path(self):
        self.assertNotIn('Weather.getHourlyForecast()',G)
        self.assertNotIn('Weather.getHourlyForecast()',U)
        self.assertNotIn('getHourlyForecast()',O)

    def test_no_added_network_endpoints_or_timers(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),2)
        self.assertNotIn('Comm.makeWebRequest(',G+O+U)
        self.assertNotIn('registerForTemporalEvent',G+O)
        self.assertIn('if (seconds > 5 * 60) { seconds = 5 * 60; }',N)
        self.assertIn('if (seconds < 300) { seconds = 300; }',N)

    def test_idle_heartbeat_does_not_redraw_watch_face(self):
        finish=N.split('function finish(changed)',1)[1].split('\n    }',1)[0]
        self.assertIn('if (changed || setting("gwPreviewV332", 0) >= 16)',finish)
        self.assertIn('Bg.exit(null);',finish)

    def test_critical_sources_prioritized_with_one_request(self):
        self.assertIn('srOLastCoreV32657',N)
        self.assertIn('srOAuxLastV32657',N)
        self.assertIn('25 * 60',N)
        self.assertIn('if (_guardMode == 2) { return 10 * 60; }',N)
        self.assertIn('if (_guardMode == 1) { return 15 * 60; }',N)
        self.assertIn('return currentSeconds();',N)

    def test_no_breaking_change_settings_callback(self):
        cb=U.split('function onSettingsChanged()',1)[1].split('\n    }',1)[0]
        self.assertIn('srResetSettingsCache()',cb)
        self.assertIn('Ui.requestUpdate()',cb)
        self.assertNotIn('srOwmWrite(',cb)
        self.assertNotIn('Bg.registerForTemporalEvent(',cb)
        self.assertNotIn('45000',CFG+U)

    def test_three_states_and_no_data_protection(self):
        self.assertIn('var _guardLevel;',G)
        self.assertIn('_guardLevel = -1;',G)
        self.assertIn('raw = 2;',G)
        self.assertIn('raw = 1;',G)
        self.assertIn('raw = 0;',G)
        self.assertIn('if (raw < 0) { return; }',G)
        self.assertIn('guardChanged(_guardLevel);',G)

    def test_confirmed_downgrade_no_duplicate_frames(self):
        self.assertIn('if (stamp <= _guardClearStamp) { return; }',G)
        self.assertIn('if (stamp <= 0 || stamp <= _guardSourceStamp',G)
        self.assertIn('if (_guardClearCount < 2) { return; }',G)
        self.assertIn('_guardClearTarget != raw',G)
        self.assertIn('if (raw == _guardLevel)',G)

    def test_air_source_is_independent(self):
        self.assertIn('cause = baseKind(tag) == 12 ? 3 : 1;',G)
        self.assertIn('(_guardCause == 3 ? airStamp : currentStamp)',G)
        self.assertIn('airStamp = air[3];',O)
        self.assertIn('guardObserve(now, currentStamp, forecastStamp, airStamp);',O)

    def test_new_weather_cache_does_not_erase_guard(self):
        b=U.split('function resetWeatherWarningCache()',1)[1].split('\n    }',1)[0]
        self.assertIn('_weatherWarnings.invalidateCache()',b)
        self.assertNotIn('_weatherWarnings.reset()',b)
        self.assertIn('function invalidateCache() { _lastCheck = 0; }',G)

    def test_new_city_resets_only_guard_and_weather(self):
        self.assertIn('srOwmWrite("srOGuardV32658", -1);',D)
        self.assertIn('if (srOwmUpdateLocation(locationMetadata) &&',U)
        self.assertIn('_weatherWarnings.reset();',U)

    def test_anti_429_throttle_not_bypassed(self):
        self.assertIn('lastResultSuccessful(key, s[2])',N)
        self.assertIn('record[3] == 200;',N)
        self.assertIn('record[1] == 200;',N)
        self.assertIn('if (code == 403 || code == 429) { pause = 60 * 60; }',N)
        self.assertIn('if (used >= 700) { return false; }',N)

    def test_only_one_persisted_integer_per_transition(self):
        hook=O.split('function guardChanged(level)',1)[1].split('\n    }',1)[0]
        self.assertIn('srOwmRead("srOGuardV32658") != level',hook)
        self.assertIn('srOwmWrite("srOGuardV32658", level)',hook)
        self.assertNotIn('registerForTemporalEvent',hook)

    def test_garmin_and_owm_icons_unchanged(self):
        self.assertIn('function classify(',G)
        self.assertIn('function kindsFor(',O)
        self.assertIn('function drawGarminWarningIcon(',U)
        self.assertIn('return _lastKinds;',O)
        self.assertIn('drawAlertCenter(dc, w)',U)
        self.assertIn('srOwmForecastSource()',O)
        self.assertIn('function srOwmForecastSnapshot()',D)

    def test_diagnostic_not_loading_full_forecast(self):
        diag=U.split('function drawOwmDiagnostics(dc)',1)[1].split('\n    }',1)[0]
        self.assertIn('srOwmRead("srOGuardV32658")',diag)
        self.assertIn('"GUARD " + guardText',diag)
        self.assertNotIn('srOwmForecastSnapshot()',diag)
        self.assertNotIn('Weather.getHourlyForecast()',diag)


if __name__=='__main__':
    unittest.main()
