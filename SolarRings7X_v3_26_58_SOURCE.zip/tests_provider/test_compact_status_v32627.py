"""Static tests: Bluetooth/age alone on top, weekday before date below."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()

class CompactStatusTests(unittest.TestCase):
    def test_date_is_below_status_not_vice_versa(self):
        date=FACE.split('function drawDate(dc, dayLabel, dateLabel) {')[1].split('// Connection status',1)[0]
        self.assertIn('dayLabel, 170, 100, 24, 29',date)
        self.assertIn('dateLabel, 225, 97, 82, 34',date)
        self.assertLessEqual(100+29,135)
        self.assertLessEqual(97+34,135)
        self.assertLessEqual(170+24//2,225-82//2)
        self.assertLessEqual(225+82//2,269)

    def test_bluetooth_age_adjacent_on_same_row_for_long_times(self):
        phone=FACE.split('function drawPhoneBluetooth(dc) {')[1].split('// Observation age supplied',1)[0]
        age=FACE.split('function drawWeatherAge(dc, current) {')[1].split('// Native 1px separators',1)[0]
        self.assertIn('dc.drawLine(195, 77, 195, 91)',phone)
        self.assertIn('dc.drawLine(190, 91, 200, 77)',phone)
        self.assertIn('drawSized(dc, ageLabel, 235, 75, 56, 20',age)
        self.assertIn('drawPhoneBluetooth(dc);',age)
        self.assertIn('ageLabel = minutes.toString() + "m";',age)
        self.assertIn('ageLabel = hours.toString() + "h" + remainingMinutes.toString() + "m";',age)
        # Upper row: BT x190..200; age x207..263. No weekday.
        self.assertGreaterEqual((235-56//2)-200,6)
        self.assertLessEqual(235+56//2,265)
        self.assertNotIn('dayLabel',phone)
        self.assertLess(75+20,97)

    def test_preserve_weather_and_sleep_core_exactly(self):
        prev=Path('/mnt/data/SolarRings7X_v3_26_27_LAYOUT_FINAL_SOURCE/source')
        for name in ('SolarOpenNetwork.mc','SolarOpenData.mc','SolarOpenWarnings.mc',
                     'WeatherGeocode.mc','SolarWeatherCodes.mc','GarminWeatherWarnings.mc',
                     'FieldData.mc','Config.mc'):
            older=prev/name
            if older.exists():
                self.assertEqual((ROOT/'source'/name).read_bytes(),older.read_bytes(),name)

if __name__=='__main__': unittest.main()
