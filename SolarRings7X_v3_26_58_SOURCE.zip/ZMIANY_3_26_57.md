# Solar Rings v3.26.57 — RECOVERY (kandydat do testow, NIE wersja produkcyjna)

Odbudowana od podstaw z działającej na zegarku v3.26.49 (działający Photon). Cel: usunąć regresje pamięci/ustawień z v54–v56 zamiast dodawać kolejne opóźnienia.

- Zachowano BEZ ZMIAN 77 definicji właściwości Garmin, 58 ustawień aplikacji, Config.mc i dotychczasowy mechanizm `onSettingsChanged` z v49. Odrzucono problematyczny 45-sekundowy hold i walidatory `instanceof` wprowadzone w v56.
- Przywrócono lżejszą główną tarczę i diagnostykę TEST 21/22, bez ciężkiego TEST 23 i dodatkowego skanera Garmin Weather przy każdej analizie ryzyka.
- Usunięto wywołanie `Weather.getHourlyForecast()` Garmina z rysowania ostrzeżeń i TEST 15; to był udowodniony OOM w v54. OWM 1h nie zmieniono.
- WeatherSync Safe: 5-minutowy zegar wybudzeń, jedno żądanie na wybudzenie, wybór TERAZ/1H na podstawie terminu/naprzemienności, co ok. 10-15m przy regularnej pracy i dwóch cyklach pomocniczych na godzinę (Photon, AQI, dzienna, opcjonalna 15m).
- Opcjonalna 15m ma duży JSON i nadal może zawieść; ochronny cooldown 24h z v49 pozostaje. Nie traktuj 15m jako wymaganej dla podstawowych ostrzeżeń.
- TEST 22: K200 i czasy ostatnich pobrań + Q (wybór ostatniego zadania, opóźnienie C/F w minutach), TEST 21: Photon.
- Sen wyłącznie według zarejestrowanego zdarzenia Garmina; usunięto stałą 22-06. Pobudka wybudza terminarz zgodnie z callbackiem.
- Brak modyfikacji zapisanego pliku `.SET`. NIE jest gwarantowane, że urządzenie/telefon nie podmieni jego zawartości na wartości fabryczne. Przed instalacją zachowaj kopię `GARMIN/APPS/SETTINGS/GBE63537.SET`, jeśli istnieje. Jeśli kolejna zmiana ustawień spowoduje błąd getValue, zbierz `.SET` przed i po; może chodzić o problem importu na firmware, nie o callback tworzony przez tarczę.
- Ograniczenie: w tej wersji przywrócono stabilniejszy model pojedynczego źródła prognozy do wyświetlania ikon (preferencja świeższej 15m zamiast 1h). Nie ma nowego rozbudowanego WeatherGuard z v54; podłączymy go dopiero po potwierdzeniu stabilnego importu ustawień.
- Brak w tej chwili kompilacji Monkey C w lokalnym kontenerze ani testu na urządzeniu: wersja wymagająca GitHub SDK + testu fizycznego Garmina.

## Testy
12 dawnych testow sprawdzalo doslowne fragmenty nieaktualnego harmonogramu v49; sa pomijane i zastapione przez testy WeatherSync 5. Nie jest to dowod stabilnosci hardware.
