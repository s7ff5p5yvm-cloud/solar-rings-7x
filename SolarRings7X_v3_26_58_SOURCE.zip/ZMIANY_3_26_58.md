# Solar Rings v3.26.58 — WeatherGuard + WeatherSync 5 — kandydat testowy

Baza: **v3.26.57 RECOVERY**, z zachowaniem 77 właściwości, 58 opcji Connect IQ, ID aplikacji, układu tarczy, Photon, standardowych ikon i progów. Nie jest to wersja zatwierdzona na urządzeniu.

## WeatherGuard
- `SPOKOJNA` (0): świeży odczyt, brak sklasyfikowanych ostrzeżeń.
- `CZUJNOŚĆ` (1): zagrożenie w prognozie do 1/2/3 h lub historyczny odczyt (45–90 min), bez potwierdzonego świeżego ostrzeżenia TERAZ.
- `ZAGROŻENIE` (2): świeży alert bieżący, w tym opcjonalnie AQI przy aktywnej opcji.
- `BRAK DANYCH` (-1): nie wolno wnioskować, że nie ma zagrożeń z samego braku połączenia. Jest to stan niezidentyfikowany, a nie czwarty poziom ostrzegania.
- Eskalacja natychmiastowa na podstawie **odczytanego** niebezpiecznego zjawiska. Obniżenie po **dwóch różnych, nowszych** odczytach *tego źródła*, które spowodowało podwyższenie. Renderowanie ekranu co sekundę lub co minutę nie zastępuje odczytu.
- Osobny stempel danych dla bieżącej pogody, prognozy i AQI. Brak prognozy nie anuluje zagrożenia TERAZ. Zmiana miasta zeruje historię strażnika.
- Stan strażnika **nie blokuje istniejących ikon** i nie pokazuje nieaktualnego czerwonego alertu jako potwierdzenia aktualnego niebezpieczeństwa. Ikony wykorzystują dotychczasowy silnik klasyfikacji.
- Tylko OWM zapisuje małą pojedynczą liczbę w `App.Storage` przy **zmianie poziomu**. Garmin Weather ocenia ten sam stan w pamięci, bez nowych zapisów i odczytu ciężkiej tablicy godzinowej.

## WeatherSync 5 i ograniczenia zasobów
- Jeden istniejący slot zdarzenia okresowego, *wybudzenie kontrolne* co min. 5 minut; **jeden request na wybudzenie** i tylko jeśli czas pobrania upłynął. Garmin może opóźnić wykonanie zdarzenia okresowego.
- Zależnie od `guard`: podstawowy interwał użytkownika / 15 minut / 10 minut. Dotyczy pobierania danych TERAZ i 1H, nie płynnej animacji. Obydwa podstawowe źródła zachowują równe priorytety.
- Na eskalacji skracane mogą być jedynie deadline'y po potwierdzonym **HTTP 200**; nie omijamy blokady po 401, 403, 429 ani błędach sieci.
- Bez nowych **typów** zapytań API, bez `Weather.getHourlyForecast()` w renderze, bez nowego serwisu BG, bez dodatkowej tablicy prognozy. W stanach CZUJNOŚĆ/ZAGROŻENIE zapytania TERAZ/1H są częstsze zgodnie z harmonogramem.
- Gdy pięciominutowe wybudzenie nie pobiera niczego nowego, serwis kończy się bez przekazywania danych do UI: **bez niepotrzebnego pełnego odrysowania tarczy**.
- 15-minutowy endpoint OWM pozostaje **opcjonalny** i zabezpieczony osobnym 24-godzinnym cooldownem, ponieważ jego odpowiedź JSON może przekraczać limity pamięci.
- Sen oparty o zdarzenia Garmin, bez stałych godzin.

## Diagnostyka
TEST 22 zawiera wiersz `GUARD SPOKOJNA / CZUJNOSC / ZAGROZENIE / BRAK DANYCH` (ostatni oceniony stan OWM). Aby odświeżyć strażnika, wróć do zwykłej tarczy, odbierz aktualizację i ponownie wejdź do TEST 22.

## Znane granice weryfikacji
Wersja przeszła testy Python kontraktów źródeł, weryfikację XML i pliku workflow. W bieżącym środowisku nie jest zainstalowany Garmin Connect IQ SDK ani nie ma dostępu do fizycznego Fenixa 7X Pro. Dopiero zielony build GitHub Actions potwierdzi kompilację Monkey C. Dopiero logi/obserwacja na zegarku potwierdzą działanie w pamięci i przy zmianie ustawień. Nie ma uczciwej podstawy do zapewnienia o 100% bezawaryjności przed tymi etapami.
