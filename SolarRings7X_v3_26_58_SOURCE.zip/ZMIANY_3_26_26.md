# Solar Rings 3.26.26 — krytyczna poprawka po logu CIQ

## Przyczyna awarii 3.26.25

Na Fenix 7X Pro Solar w CIQ_LOG.YML: `Not Enough Arguments Error` (dwa razy).
Funkcja `drawDate()` podczas rysowania miesiąca wywoływała metodę
`dateLabel.substring(splitAt + 1)` z jednym argumentem. Garmin Monkey C
wymaga dwóch argumentów: początkowego i końcowego indeksu. Kod został
zmieniony na `dateLabel.substring(splitAt + 1, dateLabel.length())`.

## Zakres
- Zachowano geometrię dużej godziny `HH:MM`, daty i miasta z 3.26.25.
- Zachowano całą logikę OWM, ostrzeżeń, pamięci, snu i odzyskiwania BLE z 3.26.24.
- Test regresyjny sprawdza wszystkie wywołania `.substring()` w plikach source/*.mc.
- Wersja manifestu i GitHub Actions: 3.26.26, nowa suma kontrolna SOURCE.zip.

## Walidacja
Testy statyczne Python i XML lokalnie; kompilację Monkey C i prawidłowy obraz
na zegarku należy potwierdzić na GitHub Actions / Fenixie. Sam log nie
udowadnia, że nie ma innych niezależnych błędów.
