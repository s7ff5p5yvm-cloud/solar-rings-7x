# Solar Rings 7X 3.26.30 — finalna korekta linii i księżyca

- Linia nad panelem księżyca: `y=135 -> y=134` (1 px wyżej).
- Linia pod panelem księżyca / nazwą miasta: `y=163 -> y=164` (1 px niżej).
- Dolna linia biegnie teraz `x=28..252` jak górna, zamiast `x=99..242`.
- Dysk księżyca: `x=52, y=150 -> y=149, r=12`, aby uzyskać symetryczne odstępy 3 px do obu linii.
- Nie zmieniono funkcji ostrzeżeń, komunikacji OWM, obsługi Bluetooth i snu, rozmieszczenia daty i godziny, trzech kapsuł ani położeń ikon.
- Dodano test regresyjny geometrii linii i skorygowano wcześniejszy test pozycji separatora.
- Zaktualizowano numer wersji i workflow GitHub wraz z sumą SHA-256 źródeł.

Testy statyczne nie zastępują kompilacji i testu na Fenixie.
