# Solar Rings 7X 3.26.46 — naprawa Photon na źródle stabilnej 3.26.37

Źródło: oryginalne `SolarRings7X_v3_26_37_SOURCE.zip`. Brak TEST 21.

- OWM inicjuje i aktualizuje żądanie miasta niezależnie od cyklu wyświetlania tarczy.
- Po pobraniu bieżącej pogody Photon nie jest blokowany przez kolejne żądania CURRENT.
- Jeden wspólny timer OWM planuje również zaległą próbę Photon (nie tworzy drugiego timera).
- Ponawianie po błędach 15/30/60 min, stare blokady 3–24h nie są honorowane.
- Odpowiedź JSON ograniczona do jednego obiektu, promień 10 km.
- Wynik musi być `place` z niepustą nazwą i pasować do współrzędnych OWM, a zapis `srGResult` musi się udać.
- Garmin Weather: analogiczne opóźnienia i zapis wyniku już w procesie tła.
- Awaryjny napis `~` jest lokalnie ponownie sprawdzany po 5 min, bez odpytywania sieci w rysowaniu.
- Zachowane niezmienione XML ustawień i ich wartości, identyfikator aplikacji, layout, prognozy i OWM API.

## Ważne ograniczenie

Analiza kodu i testy statyczne nie dowodzą działania na fizycznym Garminie.
Projekt musi być skompilowany w Connect IQ SDK i przetestowany na zegarku.
