# Solar Rings 7X v3.26.47 — prognoza przed Photon, odchudzony TEST 21

Baza: działająca na zegarku v3.26.46 (wywodząca się ze stabilnej v3.26.37).

## Co zmieniono
- OWM ma pierwszeństwo w każdym zadaniu w tle: **forecast -> current -> daily -> AQI -> Photon**, jeśli termin danego zadania minął. Jedno żądanie HTTP na wybudzenie. Przy profilu 5 min prognoza ma okres 10 min, pogoda aktualna 15 min, aby nie zagłodzić Photon, AQI i prognozy dziennej.
- Pierwsza prognoza po instalacji/zmianie miejsca pobierana z lżejszego `timeline/1h` nawet gdy użytkownik preferuje 15-min; po uzyskaniu bazowej 1h można próbować 15-min. Błędy 15-min uruchamiają istniejące przełączenie na 1h.
- Sprawdzanie zmian współrzędnych pozostaje co 5 min podczas działania tarczy OWM; Photon otrzymuje termin na istniejącym timerze, a nie 12/24-godzinną blokadę. Bez bezcelowych żądań Photon przy nieruchomej lokalizacji potwierdzonej wcześniej.
- Menu diagnostyczne: tylko Wyłączony, TEST 15 (prognoza/ostrzeżenia), TEST 21 (Photon i ostatnia odpowiedź prognozy). Usunięto symulacje ikon TEST 1-14 i ciężkie ekrany TEST 16-20 (TEST 16 powodował awarię zegarka).
- TEST 21 minimalny: bez pośrednich list napisów i bez czytania pełnego cache prognozy; wyświetla ślad `[czas, etap, HTTP]`, status celu i rozpoznania, ostatnią próbę, kolejny retry, prognozę OWM oraz Bluetooth.
- Trace zapisywany wyłącznie przy rzeczywistym request/callback Photon. Brak przechowywania tokena, współrzędnych, miasta, URL i JSON w diagnostyce.
- Zachowane: app ID, wszystkie klucze i wartości domyślne ustawień, właściwa tarcza, wygląd, separatory i alerty.

## Uwaga
- Testy Python sprawdzają źródła i zasady, nie kompilują Monkey C. SDK/GitHub Actions i test zegarka są nadal konieczne.
- Jeśli Photon zwróci etap 23, problemem jest brak nazwy miejsca w JSON; etap 21 HTTP, 22 błędny JSON, 25 problem zapisu, 27 transport, 29 nieobsłużony wyjątek.
