# Solar Rings 3.26.27 — finalna korekta czytelności przed testem baterii

Podstawa: 3.26.26 — wersja, która uruchamiała się i pobierała dane OWM.

## Dokładne zmiany
1. HH:MM: pary cyfr przesunięte o 4 piksele do dwukropka (centra x59, x98, x138 zamiast x55, x98, x142). Docelowy rozmiar cyfr i ograniczenia pamięci zachowano.
2. Pogrubienie HH i MM: dodatkowe przesunięte o 1 piksel rysowanie każdej pary przy użyciu tej samej cached czcionki RobotoCondensedBold. Bez kolejnego fontu i bez zmian odświeżania.
3. Data: rysowana w dwóch rzędach po prawej stronie, dzień tygodnia y71..91 i liczba+miesiąc y92..118. Liczba i miesiąc nadal skaluje się niezależnie i mieszczą się także przy dwucyfrowym dniu.
4. Bluetooth i wiek pogody: przeniesione do wspólnego trzeciego wiersza y119..134; ikona x189..199, czas x204..274. Czas mieści także dłuższy zapis 1h25m/9h59m poprzez automatyczne dobieranie czcionki.
5. Zachowano poprawkę `substring(splitAt + 1, dateLabel.length())` z 3.26.26, by uniknąć `Not Enough Arguments Error`.
6. Nie zmieniano kodu łączności, aktualizacji, lokalizacji, ostrzeżeń, harmonogramu snu, AQI ani progów API.

## Weryfikacja
Testy Python / XML / integralność paczek. Brak lokalnego Garmin Connect IQ SDK, dlatego kompilację Monkey C wykonuje GitHub Actions. Obraz i stabilność potwierdza test zegarka.
