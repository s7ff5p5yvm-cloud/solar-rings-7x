# Solar Rings 3.26.22 — aktualne i prognozowane ostrzeżenia

## Zmiana względem 3.26.21 (wersja z poprawionym układem ikon)

- Usunięto generator szarych ikon opadów z **ostatniej godziny** (`recentPrecipitation`). Ilość deszczu `rain.1h` / śniegu `snow.1h` nie oznacza, że opad występuje w tej chwili. Dane pozostają dostępne diagnostycznie, ale nie tworzą alertu.
- Zachowano ostrzeżenia o **aktualnych zjawiskach** na podstawie kodów bieżącej pogody oraz **prognozy** z `timeline/15min` (z awaryjnym przejściem na `timeline/1h`). Prognozowane ilości opadów pozostają używane jako sygnał prognozy, nie historii.
- Zachowano bez zmian cztery reguły bezpieczeństwa odświeżania: maks. jedno zapytanie HTTP na wybudzenie usługi, minimalnie 5 min między wybudzeniami, cel odświeżenia aktualnej pogody i prognozy co 10 min przy wybranym profilu 5 min oraz bezpośrednie odświeżenie ekranu po odebraniu danych. Nie zwiększono liczby zapytań.
- **Układ:** tylko 3 istniejące pozycje ikon `x=68/91/114`; przy większej liczbie alertów ostatnia rotuje. Nie wykorzystano przestrzeni po StormGuard. Turkusowy pasek prognozy nie został przesunięty.
- Nie przywrócono StormGuard. Nie zmieniono innych ustawień, ich kluczy ani identyfikatora aplikacji.

## Ustawienia wymagane dla najświeższych prognoz

W Connect IQ ustaw „OpenWeather — częstotliwość / bateria” na **5 min**, opcję „Prognoza 15 min” na **włączoną**, a „Ostrzeżenia: sprawdzaj dane co” na **5 min**. Domyślne wartości w tej wersji są już tak ustawione. Pamiętaj, że wcześniejsze zapisane ustawienia mogą je nadpisywać. Horyzont prognozy ustaw osobno na 1–3 h.

**Ograniczenia:** Garmin Connect IQ nie pozwala uruchamiać czasowego zadania tła częściej niż co 5 minut; dostawca OWM 4.0 aktualizuje model około co 10 minut. Wybudzenia mogą być opóźnione przez system/telefon/sieć. Samo przeliczenie ostrzeżeń nie wywołuje pobrania nowych danych z serwera. Ten pakiet nie przeszedł kompilacji Monkey C ani testu na zegarku — wymaga ich weryfikacji.
