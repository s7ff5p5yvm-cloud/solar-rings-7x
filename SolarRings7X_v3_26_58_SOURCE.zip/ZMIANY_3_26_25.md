# Solar Rings 3.26.25 — finalne powiększenie zegara i daty

Baza: 3.26.24 FINAL po audycie geokodowania (wszystkie naprawy pogody,
ostrzeżenia, automatyczne zdarzenia zaplanowanego snu, ograniczenia baterii).

## Zmiany UI

1. **Godzina naprawdę większa:** podział `HH:MM` na dwie osobno mierzone pary
   `HH` i `MM` oraz dwukropek w środku. Dzięki temu ograniczenie szerokości
   164 px całego napisu nie wymusza starej małej czcionki. Pole godziny rośnie
   z 52 do 60 px, kandydat wektorowy 94 px na ustawieniu XL.
2. **Odzyskano wysokość:** górne pola przesunięte o 6 px w górę;
   poziome separatory na y=70 i y=135. Strefa księżyca została zwarta do 28 px;
   paski, ostrzeżenia i temperatura nie zmieniają położenia.
3. **Data większa:** dzień tygodnia w polu 64x29; dzień miesiąca i nazwa
   miesiąca mierzone i dopasowywane osobno w drugim wierszu.
4. **Miasto bardziej widoczne:** pole zwiększone ze 112x24 do 126x25,
   cel wielkości czcionki wyższy, z redukcją długich miejscowości.
5. **BT i wiek pogody:** oba wskaźniki umieszczone w odrębnych polach po prawej:
   czas aktualizacji u góry, Bluetooth niżej, bez nachodzenia na datę.
6. **Awaria pogody:** `BRAK DANYCH` odrobinę mniejsze i mniej kontrastowe niż
   główna godzina; pozostałe nazwy warunków i podpis ODCZ. bez zmian.
7. **Plan awaryjny:** przy braku dostępnej czcionki wektorowej (lub niskim RAM)
   zegar jest rysowany trzema polami Garmin-native zamiast skalowania całego
   5-znakowego napisu w jednej ramce.

## Bez zmian

- 3 pozycje ikon pogodowych `[68,91,114]`, ikonka temperatury, bieżące
  czerwone ostrzeżenia i prognoza w turkusie.
- Pobieranie Garmin/OWM, One Call API, AQI i progi alertów.
- Obsługa zaplanowanego snu/pobudki, szybkie odzyskanie BLE i geokodowania.
- Dotychczasowe identyfikatory ustawień i App.Storage — aktualizacja bez resetu.

## Weryfikacja

Wykonano statyczne testy Python, kontrolę XML, integralności archiwów i workflow.
Kompilacja Monkey C w GitHub Actions oraz rzeczywisty wygląd na Fenix 7X Pro Solar
**wymagają potwierdzenia**. W szczególności porównaj skalę cyfr i odstępy między
`HH : MM`, datą i wskaźnikami po prawej oraz aktualizacje OWM po nocy.
