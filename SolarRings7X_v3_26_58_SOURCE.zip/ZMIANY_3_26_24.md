# Solar Rings 3.26.24 — zbiorcze poprawki

Baza: rzeczywisty kod v3.26.23. Nie zmieniono identyfikatora aplikacji ani kluczy ustawień Connect IQ.

## Naprawy i optymalizacje

1. **Poranne odświeżanie / BLE:** `SolarOpenNetwork.fail()` odróżnia kod lokalny `-12` (brak telefonu) od błędów HTTP. Po `-12` ponowienie następuje po 5 minutach, a nie po 60 minutach. W razie rozłączenia telefonu prognoza 15-minutowa NIE trafia do 24-godzinnej blokady/fallbacku. Długie wycofanie przy HTTP 401/403/429 oraz OOM zostaje.
2. **Tryb nocny:** w godzinach 22:00–06:00 (czas lokalny zegarka) proces OWM kończy się przed HTTP i diagnostyką. Następne nocne wybudzenie przypada najwyżej po 4 godzinach (żeby obsłużyć zmianę strefy i DST); pierwsze wybudzenie rano wraca do standardowego harmonogramu. To stały przedział czasowy, nie odczyt dynamicznych godzin snu Garmina. Zmiana nocnego harmonogramu będzie wymagać zmiany konfiguracji/kodu.
3. **Diagnostyka:** `gate()` pomija wewnętrzne etapy w zwykłym użyciu, pozostawiając etap zlecenia oraz błędy i pełny ślad w TEST >=16. Sukcesy zachowują wynik każdego endpointu; historia zapisuje błędy i pełne testy diagnostyczne. Zmniejsza liczbę zapisów do pamięci.
4. **Odczyty OWM:** stan pauzy 15-minutowej prognozy buforowany jest w pamięci jednej sesji procesu w tle. Nadal ponownie odczytujemy lokalizację przy odbieraniu odpowiedzi HTTP, by odrzucić spóźnione dane po podróży.
5. **RAM:** `readField()` ponownie wykorzystuje odrębny wynik 3-elementowy dla każdego ID pola; wspólny bufor dla wszystkich pól byłby błędem.
6. **Cache miasta:** przy braku `weather` korzysta z `_locationCache` według pozycji, z unieważnianiem na zmianie współrzędnych i ustawień. `WeatherCity.mc` pomija miasta z odległością >30 km na jednej osi, zanim liczy dystans kwadratowy.
7. **Wygląd:** większa bazowa czcionka godziny, większe nominalne rozmiary dwóch linii daty, nazwa miasta (z automatycznym dopasowaniem) oraz przesunięcie podpisu temperatury odczuwalnej w prawo, z zachowaniem ograniczenia szerokości.

## Bez zmian

- OpenWeatherMap i Garmin Weather, prognoza 15-minutowa, AQI, progi oraz kolory alertów.
- Trzy pozycje ikon ostrzeżeń [68,91,114], czerwień aktualnych zagrożeń i turkusowy pasek prognozy.
- Usunięty StormGuard (burza z ciśnienia) oraz brak ikon opadów historycznych.
- Odświeżanie podczas dnia (wybudzenie min. 5 min, aktualna pogoda i prognoza cel 10 min) oraz identyfikator Connect IQ.

## Ograniczenia i testy po instalacji

Nie wykonano kompilacji Monkey C ani testów na rzeczywistym Fenixie: wymagany jest GitHub Actions SDK i weryfikacja działania. Żadna optymalizacja nie gwarantuje 3–5% baterii na dobę; porównaj ze zmierzonym ~8% w 3.26.23.

Kontrola zegarka po instalacji: zmiana ustawień wyglądu bez resetu, poprawne temperatury odczuwalne od -35 do +35, czytelność daty i miasta, TEST16 K200 w dzień, brak prób HTTP nocą, szybkie wznowienie po 06:00 oraz po krótkim odłączeniu Bluetooth. Następnie test baterii 24–48h przy tych samych ustawieniach.


### Korekta pakietu 3.26.24: automatyczny harmonogram snu
- Zdarzenia `Background.registerForSleepEvent()` i `registerForWakeEvent()` sterują wstrzymaniem zapytań OWM zgodnie z harmonogramem zapisanym w Garminie, zamiast stosować sztywne 22:00–06:00.
- Pobieranie po zdarzeniu pobudki zostaje ponownie zaplanowane po 5 min, z priorytetem aktualnej pogody i prognozy.
- 22:00–06:00 służy wyłącznie jako mechanizm awaryjny, gdy zegarek nie dostarczy wiarygodnego zdarzenia snu/pobudki (np. przy pierwszej instalacji).
- **Ograniczenie platformy:** ręcznego włączenia/wyłączenia trybu snu nie można niezawodnie odczytać z Connect IQ. Zdarzenia dotyczą ustawionych godzin, nie rzeczywistej aktywności użytkownika.
- Weryfikacja sprzętowa `onSleepTime()`/`onWakeTime()` na Fenix 7X Pro Solar wymagana przed potwierdzeniem działania.


## Uzupełnienie 3.26.24 — korekty po audycie (wariant FINAL)

1. **TEST 15:** dopisano czytelne opisy błędów parsera One Call 4.0 `-202…-214`, błędów zadania w tle oraz limitu dobowego `-234`. Istniejące kody zachowano do kompatybilności. Diagnostyka nie pokazuje kluczy ani współrzędnych.
2. **Zmiana dostawcy OWM → Garmin:** unieważniane są stare `srGRequest` i `srGInFlight`, a także nieaktualne terminy i licznik błędów geokodowania. Pozostaje globalny limit żądań Photon `srGLastTry` oraz wynik `srGResult` chroniony zgodnością współrzędnych. Nowa pozycja Garmina w razie potrzeby tworzy nowe żądanie.
3. **Rozłączenie Bluetooth / brak Internetu:** brak telefonu i ujemne statusy transportowe oraz utracony callback nie zwiększają już 3→6→12→24-godzinnej blokady serwera. Brak telefonu = brak HTTP i kontrola najwyżej raz/godzinę. Po przywróceniu połączenia, podczas wyświetlania nazwy miasta, tarcza przyspiesza następną próbę do ≥5 minut, z zachowaniem globalnego limitu Photon (30 min). HTTP błędy serwera i niepoprawne dane wciąż używają ograniczania prób.
4. **Bez zmian:** logika alertów, częstotliwość OWM, 3 ikony, ekran, sleep/wake, optymalizacje RAM.

Testy Python w paczce obejmują kontrolę przepływu kodu. Nadal wymagane jest skompilowanie Monkey C w GitHub Actions i test na Fenixie.
