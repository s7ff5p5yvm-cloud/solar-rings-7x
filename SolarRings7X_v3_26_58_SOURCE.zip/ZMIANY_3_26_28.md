# Solar Rings 7X 3.26.28 — dopracowanie zegara i daty

## Wyłącznie zmiany układu tarczy (bazą jest działająca 3.26.27)

1. **Godzina HH:MM:** usunięto trzy stałe współrzędne osi tekstów, które mimo wcześniejszych przesunięć dawały duże przerwy. Nowy mechanizm mierzy prawdziwą szerokość godzin, dwukropka i minut na Fenixie i układa je z 3-pikselowymi odstępami. Cała grupa jest centrowana w polu x=25..175, a użyta czcionka jest dopasowywana do najtrudniejszego wariantu `88:88`.
2. **Wyraźniejsze cyfry:** dotychczasowy RobotoCondensedBold, plus rysowanie godzin i minut z przesunięciem -1/0/+1 px. Nie pobieramy nowej czcionki dla każdego odświeżenia; pozycje są zapamiętywane na całą minutę. Istnieje natywny fallback bez czcionek wektorowych.
3. **Data:** `19 LIS` jest rysowane razem jako jeden większy napis w polu x=177..269, y=97..131; nie ma już małego i rozdzielonego `19` i `LIS`. Data jest automatycznie dopasowywana do długości.
4. **Bluetooth i wiek pogody:** przeniesiono na górny wiersz po prawej stronie, razem z dniem tygodnia: `CZ [BT] 24m`. Bluetooth jest w x=209..219, czas aktualizacji w x=223..265. Wartości `59m`, `1h25m`, `10h11m` używają automatycznego zmniejszania czcionki.
5. **Bezpieczeństwo okrągłego ekranu:** krawędzie tekstów zostały odsunięte od granicy 280-pikselowego okręgu, szczególnie blisko y=75.
6. **Utrzymanie optymalizacji:** obliczenia pozycji zegara i rozmiarów fontów są cache'owane; dodatkowe rysowanie bold bez tworzenia nowych fontów.

## Nie zmieniono

- OWM, Garmin Weather, AQI, progi ostrzeżeń, rozmieszczenie 3 ikon, turkusowe paski
- Harmonogram odświeżania w ciągu dnia, obsługa snu, ponawianie po błędach Bluetooth
- Geokodowanie, układ pasków, wyświetlanie temperatury i odczuwalnej
- Identyfikator aplikacji, ustawienia i klucze API

## Sprawdzenie

- 184 testy uruchomione; 183 przeszły, 1 pominięty.
- Testy Python to testy źródłowe; lokalnie nie jest dostępny kompilator Garmin Monkey C. **Nie potwierdzono jeszcze kompilacji ani zachowania na Fenixie**.
- Wydanie wymaga zainstalowania `.prg` po udanym GitHub Actions, a następnie sprawdzenia tekstów dla kilku wariantów godzin i wieku pogodowego.
