# Solar Rings v3.26.49 — korekta Photon i priorytetów pogodowych

Punkt wyjścia: v3.26.48 (pochodna stabilnej 3.26.37). Bez zmian identyfikatora aplikacji, definicji ustawień, ekranu i ikon ostrzeżeń.

## Kolejność pobierania (nie mylić z wyborem danych do wyświetlenia)
1. Pogoda bieżąca OWM — temperatura i aktualne ostrzeżenia.
2. OWM 1h — stabilna podstawa prognozowanych ostrzeżeń 1–3h (potwierdzone działanie K200 w poprzednim teście).
3. OWM 15min — większa rozdzielczość krótkoterminowa po uzyskaniu 1h, jeżeli opcja włączona.
4. Photon — przy braku potwierdzonego miasta, po danych krytycznych.
5. AQI — tylko gdy włączone; osobny termin co około 60 min, z priorytetem przed prognozą dzienną.
6. OWM 1day — około co 12h, min/max temperatury dziennej.

Jeden request HTTP na wzbudzenie tła (minimum co 5 minut). Przy najszybszym profilu: aktualna pogoda ~15 min, prognoza 1h ~20 min, prognoza 15min ~35 min. Przy wolniejszych profilach bieżąca i 1h dostosowują się do wyboru użytkownika; 15min ~45 min. Dalsze żądania mają osobne terminy. Terminy są orientacyjne i Garmin może przesuwać wykonania. Gdy jest brak połączenia / błąd odpowiedzi, obowiązują odrębne krótkie retry i diagnostyka.

## Ostrzeżenia
Dane bieżące = czerwone ostrzeżenia; przyszłość = ikony z turkusowym paskiem. Prognoza 1h pozostaje podstawą po nieudanym 15min. Jeżeli 15min jest wystarczająco świeża, może zastąpić 1h do dokładniejszej oceny; starsza 15min nie maskuje świeższej 1h. Podczas snu zachowano wcześniejszą przerwę od pytań tła (oszczędność baterii, ale brak aktualizacji ostrzeżeń).

## Photon
Obie ścieżki (OWM i Garmin Weather) nie wysyłają już `lang=pl`. Publiczna instancja Photon mogła dla niego zwracać HTTP 400. Przy pierwszej aktywacji wersji klucz migracyjny zeruje stary termin błędu, aby nowy request miał szansę wystartować. Zapytanie używa `lat`, `lon`, `limit=2`, `radius` i najpierw `osm_tag=place`; drugi etap szuka pola `city` w pobliskiej odpowiedzi, bez przyjmowania nazw ulic. Powtórzenia 15–30 minut, HTTP 429: 60 minut. Nie ponawiamy wciąż poprawnie rozpoznanego miasta. Zmiana współrzędnych powoduje nowe rozpoznanie.

## OWM 15 minut, pamięć i bezpieczeństwo
OpenWeather może zwrócić do 50 rekordów w odpowiedzi 15min; kod zapisuje najwyżej 12 najbliższych rekordów i nie przechowuje pełnego JSON. `cnt=12` jest wysyłane, ale dokumentacja nie gwarantuje ograniczenia rozmiaru odpowiedzi przez ten parametr. Garmin może nadal zgłosić błąd pamięci -403 przy deserializacji; istniejący 24h circuit breaker dotyczy WYŁĄCZNIE 15min po podejrzeniu awarii, a nie Photon lub 1h. Gdy 15min zawiedzie, ostrzeżenia używają 1h. Zalecany test na zegarku.

## Diagnostyka i API
TEST 21: etap/kod Photon, ostatnia próba, retry, status 1h i połączenia.
TEST 22: osobno bieżące, 1h, 15min, dzienne, AQI; `K200` to zapis odpowiedzi, `K401` odrzucenie klucza, `K403` uprawnienia, `K429` limity, `--` brak zarejestrowanej próby, liczby ujemne błędy lokalne. Klucza API nie wyświetlamy.

## Weryfikacja
Testy Python i modele harmonogramu (to nie jest symulator Connect IQ), weryfikacja ustawień i aplikacji, test CRC ZIP, wykonanie dwóch kroków GitHub Actions w czystym katalogu. W środowisku NIE ma Garmin `monkeyc`: rzeczywista kompilacja i test na Fenix 7X Pro pozostają do zrobienia na GitHubie i zegarku. Nie deklarujemy stabilności produkcyjnej.
