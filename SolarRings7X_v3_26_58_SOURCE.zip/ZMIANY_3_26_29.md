# Solar Rings 3.26.29 — data i test termometru

- Godzina HH:MM przesunięta w lewo o 16 px w ramach obszaru bezpiecznego dla okrągłego ekranu.
- Dzień tygodnia `CZ` przeniesiony bezpośrednio przed `19 LIS` w dolnym wierszu obok godziny.
- W górnym prawym wierszu są już tylko Bluetooth i wiek pogody. Miejsce na długie zapisy `1h25m` / `10h11m` bez zmiany częstotliwości odświeżania.
- Test temperatury `-35°C` / `-99°C` pokazuje niebieski termometr niezależnie od rzeczywistej temperatury OWM. Dodano test `45°C` pokazujący czerwony termometr. W trybie rzeczywistym progi i ważność obserwacji nie zostały zmienione.
- Poprawka jest wizualna i diagnostyczna: bez zmian w pobieraniu pogody, ostrzeżeniach, geokodowaniu, AQI, śnie i kosztach API.
- Po testach w ustawieniach należy wyłączyć `TEST układu temperatury`.
- Nie wykonano lokalnej kompilacji Monkey C; wymagany build GitHub oraz test na zegarku.
