# Solar Rings 7X v3.26.48 — kolejka pogody, Photon i diagnostyka AQI

Baza: źródła v3.26.47 (wywodzące się ze stabilnej v3.26.37).

## Zachowanie kolejki
- Jeden request HTTP na cykl pracy w tle (co najmniej 5 min odstępu, zależnie od Garmin OS).
- Priorytet: 1) bieżące warunki, 2) prognoza godzinowa 1h, 3) Photon, gdy miasto niepotwierdzone, 4) opcjonalna prognoza 15-min, 5) AQI jeśli włączone, 6) prognoza dzienna.
- Dwa podstawowe feedy mają osobne terminy: przy profilu 5/15 minut bieżące co około 15 min, 1h co około 20 min. Przy profilu 30/60 minut obydwa odpowiednio co 30/60 min.
- Opcjonalna prognoza 15-min: co około 45 min, dopiero po dostępności 1h; osobny termin `srONextSV32648` i osobna diagnostyka. Jej błąd pamięci nie blokuje prognozy 1h. Historyczna blokada 24h po crashu dużego JSON dotyczy WYŁĄCZNIE endpointu 15-min, nie Photon.
- AQI: co około 60 min, wyłącznie gdy włączone w ustawieniach; własny cache `srOAirV326` i termin `srONextAV326`. Błędy AQI nie blokują warunków bieżących, prognozy 1h i Photon.
- Prognoza dzienna: co około 12h. Podczas wyznaczonego snu zapytania nie są wykonywane (zachowany dotychczasowy mechanizm).

## Photon
- Po otrzymaniu współrzędnych i uruchomieniu podstawowych zapytań ma gwarantowany dostęp do wolnego cyklu, przed dodatkowymi feedami; `~` znika dopiero po realnym rozpoznaniu nazwy.
- Brak wielogodzinnego okresu ciszy po błędzie. Błąd sieci zwykle 30 min; brak miasta 45 min; HTTP 429 60 min. Pierwszy `HTTP 200` bez miejscowości powoduje próbę awaryjną za około 15 min: odczyt pola `city` pobliskiego obiektu. Nazwa ulicy nie może być przyjęta jako miasto.
- Bez wymuszania GPS i bez rozpoznawania ponownie tej samej już potwierdzonej lokalizacji.

## Diagnostyka
- TEST 15: ostrzeżenia i prognoza godzinowa (zachowany).
- TEST 21: Photon / nazwa, czas, transport i odpowiedź HTTP (zachowany).
- TEST 22: lekki ekran API OWM: TERAZ / 1H / 15M / DZIEN / AQI, kod ostatniego zapytania i jego wiek, ogólny status klucza.
- K100 = rozpoczęte/zlecone, K200 = poprawna odpowiedź i zapis danych, K401 = nieprawidłowy klucz, K403 = brak uprawnień do usługi, K429 = limit, liczby ujemne = błędy lokalne. Brak zapytania = --.
- Ekran nie wyświetla wartości klucza API ani odpowiedzi JSON, nie wykonuje zapytań z poziomu rysowania.

## Zachowane
- Identyfikator Garmin aplikacji, komplet kluczy/wartości domyślnych ustawień, bazowa grafika, pozycje pól i separatory, zasady ostrzeżeń i obsługa Garmin Weather.

## Weryfikacja
- Testy źródłowe Python oraz test symulowanej kolejki, CRC ZIP, XML, kroki rozpakowania i walidacji GitHub Actions.
- NIE jest to realny test Monkey C na urządzeniu: wymaga GitHub Actions i testu Fenix 7X Pro. Wyniku na zegarku nie można zagwarantować bez tego kroku.
