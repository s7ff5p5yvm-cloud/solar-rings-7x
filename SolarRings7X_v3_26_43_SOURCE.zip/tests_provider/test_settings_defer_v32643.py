from pathlib import Path
import unittest
P=Path(__file__).resolve().parents[1]
F=(P/'source/SolarRings7X.mc').read_text(encoding='utf-8')
C=(P/'source/Config.mc').read_text(encoding='utf-8')

class SettingsDefer(unittest.TestCase):
    def test_no_immediate_native_properties_read_from_settings_callback(self):
        code=F.split('function onSettingsChanged()')[1].split('\n    }',1)[0]
        self.assertNotIn('Ui.requestUpdate();',code)
        self.assertNotIn('srUseOpenWeather()',code)
        self.assertNotIn('Bg.registerForTemporalEvent',code)
        self.assertIn('markSettingsChanged();',code)
    def test_only_provider_switch_invalidates_current_weather(self):
        code=F.split('function refreshChangedSettings()')[1].split('function rebuildWeatherWarnings()',1)[0]
        self.assertIn('if (open != _srSelectedProvider)',code)
        inside=code.split('if (open != _srSelectedProvider)',1)[1].split('\n            }',1)[0]
        self.assertIn('_cachedWeatherAt = 0',inside)
        self.assertNotIn('rebuildWeatherWarnings();',code)
        self.assertIn('new SolarOpenWarnings()',code)
        self.assertNotIn('srOwmProviderChanged()',code)
    def test_avoid_expensive_first_alert_refresh(self):
        self.assertIn('_srSkipAlertFrame = true;',F)
        self.assertIn('if (_srSkipAlertFrame) { _srSkipAlertFrame = false; return; }',F)
        self.assertIn('_srSkipAlertFrame = false;',F)
    def test_settings_cache_preserves_stable_capacity_and_type_guard(self):
        self.assertIn('_srSettingCacheSize < 96',C)
        self.assertIn('value = srSettingTyped(value, fallback);',C)
    def test_meteo_best_match_still_present(self):
        n=(P/'source/SolarOpenNetwork.mc').read_text(encoding='utf-8')
        self.assertIn('best_match',n)
        self.assertIn('air-quality-api.open-meteo.com',n)

if __name__=='__main__': unittest.main()
