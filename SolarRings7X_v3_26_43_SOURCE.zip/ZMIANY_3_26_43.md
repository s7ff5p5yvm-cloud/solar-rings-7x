# Solar Rings 7X — 3.26.43 (TEST, regresja ustawień)

Baza **3.26.42**, Open-Meteo best_match zamiast OWM, Garmin Weather bez zmian.
Stabilna **3.26.37** pozostaje nietknięta.

## Awaria i poprawki

- Log z 3.26.41: `Unexpected Type Error` w `Config.mc:37`, wywołany przez `srUseOpenWeather()` w `refreshChangedSettings()` podczas pierwszego `onUpdate()` po synchronizacji ustawień.
- `onSettingsChanged()` nie wymusza już natychmiastowego `Ui.requestUpdate()`. Zmiany są odczytywane na **następnym normalnym odświeżeniu tarczy** (typowo do 1 minuty), kiedy transakcja Connect IQ jest zakończona.
- Przy zwykłej zmianie wyglądu nie unieważnia się cache pogody ani nie pobiera ponownie całego stanu Garmin Weather.
- Przy przełączeniu dostawcy jedno odczytanie nowego wyboru wystarcza do zmiany silnika ostrzeżeń; nie ma powtórnego odczytu `Properties.getValue()` w `rebuildWeatherWarnings()`.
- Po zmianie dowolnego ustawienia pomijana jest tylko **jedna klatka obliczania ostrzeżeń**, aby nie ładować godzinowej prognozy w trakcie ponownego wczytywania ustawień. Kolejna zwykła aktualizacja je przywraca.
- Limit cache ustawień zwiększono z 64 do sprawdzonej w 3.26.37 wartości 96, aby uniknąć wielokrotnego natywnego `Properties.getValue()` po zapełnieniu cache.
- Zachowane: Photon, diagnostyka 15–21, Open-Meteo best_match, WMO, UV, AQI, szczegółowa bateria oraz geometria pól.

## Ograniczenia

Testy statyczne nie są kompilacją Connect IQ SDK ani testem pamięci rzeczywistego Fenix 7X Pro. Bez logu po wgraniu 3.26.43 nie wolno nazywać tej wersji finalną ani gwarantować braku awarii.
