# Solar Rings 7X v3.22.1 — awaryjna poprawka stabilności

Ta wersja została przygotowana na bazie **sprawdzonej na zegarku v3.21.9**, a nie na awaryjnej v3.22.0. Wycofano duży zestaw dodatkowych odczytów pamięci i zmian GPS z v3.22.0, który zbiegł się z natychmiastowym zamknięciem tarczy. Bez logu CIQ_LOG.YML nie potwierdzono jeszcze dokładnej przyczyny awarii.

Jedyna zmiana logiki: ostatnia pozycja z Activity, jeśli była obserwowana w ciągu godziny, nie zostaje zastąpiona współrzędnymi stacji Garmin Weather tylko dlatego, że jej obserwacja jest nowsza. Zachowano wszystkie poprzednie funkcje IMGW, ikony, kolory, Body Battery i temperaturę odczuwalną.

Nie dodano żadnego nowego klucza pamięci, żądania sieciowego ani zadania w tle. Test 1 ma widoczny znacznik `T1v21`. Nie dowodzi on pozyskania świeżego fixa GPS: tarcza Connect IQ nie może sama włączyć satelitów, a pole `Activity.currentLocation` może być `null`.

## Wgrywanie

Plik `SolarRings7X_v3_22_1_SOURCE.zip` umieść w głównym katalogu repozytorium GitHub. Plik `SolarRings7X_v3_22_1_BUILD.yml` dodaj do `.github/workflows/`. Uruchom **Build Solar Rings 7X v3.22.1** i pobierz `SolarRings7X_v3221.prg`.

Po instalacji: IMGW Test 4, TERYT=0 i dotychczasowe 50 minut. Jeśli nadal będzie awaria, wróć do v3.21.9 i skopiuj z zegarka `/GARMIN/APPS/LOGS/CIQ_LOG.YML` (lub CIQ_LOG.TXT).
