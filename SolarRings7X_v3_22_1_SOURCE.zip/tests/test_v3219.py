from pathlib import Path
import unittest
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parents[1]
src=(root/'source/SolarRings7X.mc').read_text()
class GpsDiagnosticV3219(unittest.TestCase):
    def test_direct_stage_one_has_version_marker(self):
        self.assertIn('gpsLine = "T1v21 " + gpsResult.substring', src)
        self.assertIn('gpsLine = "T1v21 ERR"', src)
    def test_stage_one_returns_before_legacy_status(self):
        start=src.index('// Test 1 has a DEDICATED rendering path')
        end=src.index('// In other diagnostic modes use the label lane',start)
        self.assertIn('return;', src[start:end])
        self.assertNotIn('RxxK',src[start:end].replace('"GPS? RxxK"',''))
    def test_marker_is_only_in_test_one(self):
        self.assertEqual(src.count('gpsLine = "T1v21 " + gpsResult.substring'),1)
        self.assertIn('imgwLocationTestLine()',src)
    def test_no_position_enum_method(self):
        self.assertNotIn('currentLocationAccuracy.toNumber()',src)
    def test_resources(self):
        a=ET.parse(root/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(a.attrib['version'],'3.22.1')
if __name__=='__main__': unittest.main()
