import unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'source/SolarRings7X.mc').read_text()
class TestV3215(unittest.TestCase):
 def test_no_manual_banner_clobbers_feelslike(self):
  weather=s.split('function drawWeather(dc, monitor, weather)',1)[1].split('function drawBattery',1)[0]
  self.assertNotIn('lowerLabel = srcLabel',weather)
  self.assertNotIn('lowerLabel = "RECZNY',weather)
  self.assertIn('lowerLabel = "ODCZ. " + weather.feelsLikeTemperature',weather)
  self.assertIn('if (diag != null && srSetting("imgwTestStageV3194", 0) == 4',weather)
  self.assertIn('diag = null;',weather)
 def test_both_thermal_and_imgw(self):
  w=s.split('function drawWeather(dc, monitor, weather)',1)[1].split('function drawBattery',1)[0]
  self.assertIn('if (hasThermometer) { temperatureMarker(dc, weather, 124, 224); }',w)
  self.assertIn('hasThermometer ? 144 : 124',w)
  self.assertIn('hasImgw && hasThermometer',w)
 def test_position_cache_proof(self):
  g=s.split('function imgwMatchesLastCounty(d)',1)[1].split('function activeImgwAlert',1)[0]
  self.assertIn('cached[0].equals(d[0])',g)
  self.assertIn('Math.abs(cached[1] - d[4]) <= 0.002',g)
  self.assertIn('Math.abs(cached[2] - d[5]) <= 0.002',g)
  self.assertIn('age >= 0 && age <= 86400',g)
 def test_full_icon_fallback_is_not_gps(self):
  a=s.split('function activeImgwAlert(snapshot)',1)[1].split('function imgwDiagnosticLine',1)[0]
  self.assertIn('source = 1;',a)
  self.assertIn('imgwMatchesLastCounty(snapshot)',a)
  self.assertIn('verifiedImgwResult(4, false, snapshot)',a)
 def test_weather_api_shared(self):
  self.assertIn('captureImgwLocation(w);',s)
  self.assertIn('function captureImgwLocation(weatherData)',s)
  self.assertIn('var wx = weatherData;',s)
  self.assertIn('function onShow() { captureImgwLocation(null); }',s)
 def test_detailed_weather_fallback_diagnostics(self):
  self.assertIn('fallbackReason = 8;',s)
  self.assertIn('fallbackReason = 9;',s)
  self.assertIn('fallbackReason = 10;',s)
  self.assertIn('imgwGpsReport(fallbackReason);',s)
 def test_avoid_unsafe_position_enable(self):
  self.assertNotIn('Position.enableLocationEvents',s)
if __name__=='__main__': unittest.main()
