# Zmiany v3.22.1 (hotfix)

- Punkt wyjścia: sprawdzona v3.21.9, a nie v3.22.0.
- Cofnięte ryzykowne dodatkowe operacje Storage dla GPS na każdym odświeżeniu tarczy.
- `preferRecentGps`: jeżeli poprzednia lokalizacja pochodzi z Activity i ma mniej niż 1 godzinę według czasu zaobserwowania przez tarczę, stacja pogodowa nie zastępuje jej tylko nowszym czasem raportu.
- Bez nowych kluczy Storage i bez zmiany background IMGW.
- Test 1: oznaczenie v21.
- Ograniczenie: bez logu awarii nie da się wskazać dokładnego powodu crashu v3.22.0.
