using Toybox.System as Sys;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Application.Storage as Storage;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Application.Properties as Props;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as PersistedContent;

// IMGW beta: one HTTPS request per activation; county and feed resolved in separate cycles.
// Background service cannot enable GPS. The face stores a recent GPS fix.
// Privacy: coordinates are sent to GUGiK for geocoding; IMGW receives no coords.
(:background)
class ImgwServiceV318 extends Sys.ServiceDelegate {
    var _county;
    var _lat;
    var _lon;
    // HTTP error (code 6/8) or exact GUGiK payload validation reason (code 7).
    var _httpStatus;
    // Diagnostic checkpoint for status 10 (local exception).
    var _phase;
    var _stage;
    var _requestMode;

    function initialize() {
        ServiceDelegate.initialize();
        _county = null;
        _lat = 0.0;
        _lon = 0.0;
        _httpStatus = 0;
        _phase = 0;
        _stage = 0;
        _requestMode = 0;
    }

    // Missing or stale location/network => no warning, not a false all-clear.
    // Status: 1 active alert, 2 verified no alert, 3 no GPS, 4 stale GPS,
    // 5 outside Poland, 6 county HTTP, 7 county format,
    // 8 IMGW HTTP, 9 IMGW format, 10 local processing error, 13 stale feed.
    // 14 test 4A: text probe passed; 15 test 4B: JSON probe passed.
    // 16: county resolved; next scheduled run will fetch IMGW.
    function stop(code) {
        var county = _county == null ? "" : _county;
        // Unlike earlier versions, status 10 carries the exact failing phase.
        // This is not a network code and must NEVER be mistaken for no alerts.
        var networkDetail = code == 10 ? _phase :
            ((code == 6 || code == 7 || code == 8) ? _httpStatus : 0);
        Bg.exit([county, networkDetail, 0, Time.now().value(), _lat, _lon, code, _stage]);
    }

    // Shared base URL; GitHub workflow replaces ONE placeholder in the
    // compile-only copy. The two test stages do not contact GUGiK,
    // do not require GPS and never produce a weather all-clear.
    function smallFeedUrl(fileName) {
        return "https://raw.githubusercontent.com/__GITHUB_OWNER_REPO__/imgw-feed/feed/"
            + fileName;
    }

    // Stage 4 never makes two HTTPS requests in a single background task.
    // Only verified GUGiK responses, persisted by onBackgroundData, are used.
    // Cache expires after four hours or when the saved GPS fix changes.
    function cachedCountyForLocation() {
        _phase = 31;
        var cache = Storage.getValue("imgwCountyCacheV31916");
        if (cache == null || !(cache instanceof Lang.Array) || cache.size() < 4) {
            return null;
        }
        if (!(cache[0] instanceof Lang.String) || cache[0].length() != 4 ||
            !(cache[1] instanceof Lang.Number || cache[1] instanceof Lang.Float) ||
            !(cache[2] instanceof Lang.Number || cache[2] instanceof Lang.Float) ||
            !(cache[3] instanceof Lang.Number)) { return null; }
        var age = Time.now().value() - cache[3];
        if (age < 0 || age > 14400) { return null; }
        // Values come from the stored GPS fix, not an approximate region.
        if (cache[1] - _lat > 0.0001 || _lat - cache[1] > 0.0001 ||
            cache[2] - _lon > 0.0001 || _lon - cache[2] > 0.0001) {
            return null;
        }
        for (var i = 0; i < 4; i++) {
            if ("0123456789".find(cache[0].substring(i, i + 1)) == null) {
                return null;
            }
        }
        return cache[0];
    }

    // Single lightweight HTTPS request, as validated by test 4B.
    function beginCountyFeedRequest() {
        _phase = 35;
        var feedUrl = smallFeedUrl(_county.substring(0, 2) + ".json");
        _phase = 36;
        Comm.makeWebRequest(feedUrl, null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
            method(:onWarningsResponse));
    }

    // v3.19.18: independent, direct FULL IMGW response tests.
    // No GUGiK, GitHub, county matching, warning processing or display.
    // JSON mode still invokes Garmin's INTERNAL JSON decoding; this cannot
    // be avoided by merely omitting application-level parsing.
    function beginDirectImgwProbe(asText) {
        _phase = asText ? 81 : 71;
        var url = "https://danepubliczne.imgw.pl/api/data/warningsmeteo";
        var kind = asText ? Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN :
            Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON;
        _phase = asText ? 82 : 72;
        Comm.makeWebRequest(url, null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => kind },
            method(:onDirectImgwResponse));
    }

    function onDirectImgwResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        // Intentionally DO NOT read/copy/store/inspect the response payload.
        // Only check network status; never report zero active alerts.
        try {
            _phase = 83;
            if (responseCode != 200) {
                _httpStatus = responseCode;
                stop(8);
                return;
            }
            var requestedStage = Props.getValue("imgwTestStageV3194");
            if (requestedStage == 7) {
                Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 17, _stage]);
            } else if (requestedStage == 8) {
                Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 18, _stage]);
            } else {
                _phase = 84;
                stop(10);
            }
        } catch (e) { stop(10); }
    }

    // Consolidated diagnostics: official IMGW data, NO GitHub relay.
    //  4 = county-cached two scheduled activations, FULL warnings
    //  9 = GUGiK -> IMGW one activation, HTTP 200 only
    // 10 = GUGiK -> IMGW one activation, JSON root only
    // 11 = GUGiK -> IMGW one activation, FULL warnings
    // 12 = IMGW only, JSON root only
    // 13 = IMGW only, FULL warnings for TEST county 1261
    function beginUnifiedImgwRequest(mode) {
        _requestMode = mode;
        _phase = 60;
        var url = "https://danepubliczne.imgw.pl/api/data/warningsmeteo";
        _phase = 61;
        Comm.makeWebRequest(url, null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
            method(:onUnifiedImgwResponse));
    }

    function onUnifiedImgwResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            _phase = 62;
            if (responseCode != 200) {
                _httpStatus = responseCode;
                stop(8);
                return;
            }
            if (_requestMode == 9) {
                // HTTP transport only - do not dereference payload.
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 19, _stage]);
                return;
            }
            _phase = 63;
            if (!(payload instanceof Lang.Array)) { stop(9); return; }
            if (payload.size() > 800) { stop(9); return; }
            if (_requestMode == 10 || _requestMode == 12) {
                // Verify only root shape and bounding, not warning records.
                var code = _requestMode == 10 ? 20 : 21;
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, code, _stage]);
                return;
            }
            _phase = 64;
            processOfficialWarnings(payload);
        } catch (e) { stop(10); }
    }

    // Timestamp strings in IMGW's warningsmeteo endpoint are Polish civil
    // time (yyyy-MM-dd HH:mm:ss). On a watch set to Europe/Warsaw this
    // compares exact active validity intervals; invalid dates NEVER mean OK.
    function localDateStamp() {
        var t = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        return t.year.format("%04d") + "-" + t.month.format("%02d") + "-" +
               t.day.format("%02d") + " " + t.hour.format("%02d") + ":" +
               t.min.format("%02d") + ":" + t.sec.format("%02d");
    }

    function classifyOfficialWarning(s) {
        var name = s.toLower();
        if (name.find("burz") != null) { return 1; }
        if (name.find("zawiej") != null || name.find("zamie") != null) { return 11; }
        if (name.find("wiatr") != null || name.find("sztorm") != null) { return 2; }
        if (name.find("marzn") != null || name.find("gołoled") != null ||
            name.find("gololed") != null) { return 6; }
        if (name.find("oblodz") != null) { return 5; }
        if (name.find("śnieg") != null || name.find("snieg") != null ||
            name.find("śnież") != null) { return 4; }
        if (name.find("deszcz") != null || name.find("opad") != null) { return 3; }
        if (name.find("przymroz") != null) { return 9; }
        if (name.find("roztop") != null) { return 12; }
        if (name.find("upa") != null) { return 7; }
        if (name.find("mróz") != null || name.find("mroz") != null) { return 8; }
        if (name.find("mgł") != null || name.find("mgl") != null) { return 10; }
        return 13;
    }

    // Parse ONLY the minimal fields required by the watch, and write only
    // small primitives to background storage. No strings/arrays of warnings
    // are retained. All-clear requires a complete valid response.
    function processOfficialWarnings(records) {
        _phase = 65;
        if (_county == null || _county.length() != 4) { stop(7); return; }
        var stamp = localDateStamp();
        var bestLevel = 0;
        var bestKind = 0;
        var count = records.size();
        for (var j = 0; j < count; j++) {
            _phase = 66;
            var record = records[j];
            if (!(record instanceof Lang.Dictionary)) { stop(9); return; }
            var ids = record["teryt"];
            var since = record["obowiazuje_od"];
            var until = record["obowiazuje_do"];
            var label = record["nazwa_zdarzenia"];
            var severity = record["stopien"];
            if (!(ids instanceof Lang.Array) || ids.size() > 500 ||
                !(since instanceof Lang.String) || since.length() < 19 ||
                !(until instanceof Lang.String) || until.length() < 19 ||
                !(label instanceof Lang.String) ||
                !(severity instanceof Lang.String)) { stop(9); return; }
            var lvl = severity.toNumber();
            if (lvl == null || lvl < 1 || lvl > 3) { stop(9); return; }
            _phase = 67;
            var target = false;
            for (var n = 0; n < ids.size(); n++) {
                if (!(ids[n] instanceof Lang.String) || ids[n].length() != 4) {
                    stop(9); return;
                }
                if (ids[n].equals(_county)) { target = true; }
            }
            _phase = 68;
            if (target && since.substring(0, 19).compareTo(stamp) <= 0 &&
                until.substring(0, 19).compareTo(stamp) >= 0) {
                var kind = classifyOfficialWarning(label);
                if (lvl > bestLevel || (lvl == bestLevel && kind < bestKind)) {
                    bestLevel = lvl;
                    bestKind = kind;
                }
            }
        }
        _phase = 69;
        var code = bestLevel > 0 ? 1 : 2;
        Bg.exit([_county, bestLevel, bestKind, Time.now().value(), _lat,
                 _lon, code, _stage]);
    }

    function beginTextProbe() {
        _county = "1261"; // Fixed diagnostic probe for Krakow, never used as GPS county.
        Comm.makeWebRequest(smallFeedUrl("health.txt"), null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN },
            method(:onTextProbeResponse));
    }

    function beginJsonProbe() {
        _county = "1261"; // Fixed diagnostic province 12; NO GUGiK lookup here.
        Comm.makeWebRequest(smallFeedUrl("12.json"), null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
            method(:onJsonProbeResponse));
    }

    function onTextProbeResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
            if (!(payload instanceof Lang.String) ||
                payload.find("IMGW_FEED_OK") != 0) { stop(9); return; }
            Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 14, _stage]);
        } catch (e) { stop(10); }
    }

    function onJsonProbeResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
            if (!(payload instanceof Lang.Dictionary) || payload["v"] != 1) { stop(9); return; }
            var when = payload["ts"];
            var alerts = payload["a"];
            if (!(when instanceof Lang.Number) || !(alerts instanceof Lang.Dictionary)) { stop(9); return; }
            _phase = 53;
            var age = Time.now().value() - when;
            if (age < -300 || age > 7200) { stop(13); return; }
            // Only JSON transport + minimal schema: no county matching, no icons.
            Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 15, _stage]);
        } catch (e) { stop(10); }
    }

    function onTemporalEvent() {
        try {
            _phase = 20;
            if (Props.getValue("imgwOnV317") != true) { stop(10); return; }
            var stage = Props.getValue("imgwTestStageV3194");
            if (stage == null) { stage = 0; }
            _stage = stage;
            // Isolate the scheduler itself. No GPS, no network, no JSON.
            if (stage == 2) {
                Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 11, _stage]);
                return;
            }
            // 4A (value 5): one raw GitHub text request, no JSON/GPS/GUGiK.
            if (stage == 5) { beginTextProbe(); return; }
            // 4B (value 6): one compact GitHub JSON request, no GPS/GUGiK.
            if (stage == 6) { beginJsonProbe(); return; }
            // The direct IMGW probes return BEFORE reading GPS or contacting
            // either GUGiK or GitHub, and make just ONE HTTP request.
            if (stage == 7) { beginDirectImgwProbe(false); return; }
            if (stage == 8) { beginDirectImgwProbe(true); return; }
            // No GPS/GUGiK required: inspect JSON root or run full county
            // analysis for a fixed TEST county. Never use fixed county in mode 4.
            if (stage == 12 || stage == 13) {
                _county = "1261";
                beginUnifiedImgwRequest(stage);
                return;
            }
            if (stage != 3 && stage != 4 && stage != 9 && stage != 10 && stage != 11) { stop(10); return; }
            _phase = 21;
            var loc = Storage.getValue("imgwLocV318");
            if (loc == null || !(loc instanceof Lang.Array) || loc.size() < 3) { stop(3); return; }
            var age = Time.now().value() - loc[2];
            if (age < 0 || age > 21600) { stop(4); return; } // max 6-hour-old GPS fix
            _phase = 22;
            _lat = loc[0].toFloat();
            _lon = loc[1].toFloat();
            if (_lat < 49.0 || _lat > 55.1 || _lon < 14.0 || _lon > 24.3) { stop(5); return; }
            // Production mode 4 uses the EXACT validated test-5C path:
            // GUGiK -> direct IMGW -> full warnings analysis in one
            // background event, with two sequential HTTP requests.
            // Do NOT use the old county-cache branch: only the production
            // mode was crashing after tests 5A/5B/5C all passed.
            // No GitHub feed or cached TERYT is used in production mode.
            // Official ULDK. WKT EPSG:4326 order is longitude,latitude.
            _phase = 37;
            var coords = _lon.format("%.5f") + "," + _lat.format("%.5f") + ",4326";
            // Use the documented ULDK GET URL directly. A fixed set of
            // parameter names and validated numeric coordinates means no
            // query dictionary transformation is needed here.
            var url = "https://uldk.gugik.gov.pl/?request=GetCountyByXY&xy="
                + coords + "&result=teryt";
            _phase = 38;
            Comm.makeWebRequest(url, null,
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN },
                method(:onCountyResponse));
        } catch (e) { stop(10); }
    }

    // GUGiK ULDK uses a plain text status line and a TERYT value on
    // the following line. Validate strictly, but accept LF or CRLF and
    // harmless whitespace before the TERYT code.
    // Diagnostic reason on code 7 (FORMAT):
    // F1 empty; F2 non-string; F3 too short; F4 no newline;
    // Hxx.xx unexpected first line: leading Unicode codepoints in hex;
    // F6 missing code; F7 non-digit code.
    // Do not interpret any nonzero ULDK service status as successful.
    function parseCounty(raw) {
        _httpStatus = 0;
        if (raw == null) { _httpStatus = 1; return null; }
        if (!(raw instanceof Lang.String)) { _httpStatus = 2; return null; }
        if (raw.length() < 2) { _httpStatus = 3; return null; }
        var nl = raw.find("\n");
        if (nl == null) { _httpStatus = 4; return null; }
        var header = raw.substring(0, nl);
        // Accept harmless ASCII whitespace around the status, but require
        // the complete first line to be exactly 0 afterwards.
        // The status must be exactly the ASCII digit 0 after removing only
        // the recognized BOM/invisible separators from the text response.
        // Compare numeric Unicode codepoints; Monkey C does not support
        // backslash-u escapes in source string literals.
        var status = "";
        var statusChars = header.toCharArray();
        for (var h = 0; h < statusChars.size(); h++) {
            var cp = statusChars[h].toNumber();
            if (cp != 32 && cp != 9 && cp != 13 &&
                cp != 0xFEFF && cp != 0x00A0 &&
                cp != 0x200B && cp != 0x2060) {
                status += statusChars[h].toString();
            }
        }
        // IMPORTANT: Monkey C compares String references with ==/!=.
        // Compare contents with equals(); H30 confirmed the server sends '0'.
        // A correct status must be recognized even when rebuilt char by char.
        if (!status.equals("0")) {
            // Preserve a tiny, ASCII-only sample of the server's first line.
            // This exposes e.g. status 1/-1 or HTML errors directly on the
            // watch, without logging coordinates or showing a false OK.
            var preview = "";
            for (var k = 0; k < status.length() && preview.length() < 4; k++) {
                var x = status.substring(k, k + 1);
                if ("0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".find(x) != null) {
                    preview += x;
                }
            }
            // For an unexpected status line report its ACTUAL character codes.
            // The previous F5-0 lost invisible/control characters and was
            // impossible to distinguish from a genuine success header.
            // Up to 3 hexadecimal code points are enough to identify BOM,
            // CR/LF, NUL, control characters, or a different service status.
            // No coordinates or sensitive data are displayed/stored.
            var hexHeader = "H";
            var count = statusChars.size();
            if (count > 3) { count = 3; }
            for (var j = 0; j < count; j++) {
                if (j > 0) { hexHeader += "."; }
                hexHeader += statusChars[j].toNumber().format("%X");
            }
            if (count == 0) { hexHeader += "EMPTY"; }
            _httpStatus = hexHeader;
            return null;
        }
        var pos = nl + 1;
        while (pos < raw.length()) {
            var ch = raw.substring(pos, pos + 1);
            var chCode = ch.toCharArray()[0].toNumber();
            if (chCode != 13 && chCode != 10 && chCode != 32 && chCode != 9 &&
                chCode != 0xFEFF && chCode != 0x00A0 &&
                chCode != 0x200B && chCode != 0x2060) { break; }
            pos++;
        }
        if (pos + 4 > raw.length()) { _httpStatus = 6; return null; }
        var code = raw.substring(pos, pos + 4);
        for (var i = 0; i < 4; i++) {
            if ("0123456789".find(code.substring(i, i + 1)) == null) {
                _httpStatus = 7;
                return null;
            }
        }
        // Check the following character so malformed 5+-digit IDs are
        // not silently mapped to the wrong district.
        if (pos + 4 < raw.length() &&
            "0123456789".find(raw.substring(pos + 4, pos + 5)) != null) {
            _httpStatus = 7;
            return null;
        }
        return code;
    }

    function onCountyResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            _phase = 40;
            if (responseCode != 200) { _httpStatus = responseCode; stop(6); return; }
            _county = parseCounty(payload);
            if (_county == null) { stop(7); return; }
            if (Props.getValue("imgwTestStageV3194") == 3) {
                // GUGiK verified. End before contacting IMGW.
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 12, _stage]);
                return;
            }
            // Production mode 4 and successful 5C test (stage 11) share
            // the same request + parse path. Modes 9/10 remain diagnostics.
            if (_stage == 4 || _stage == 9 || _stage == 10 || _stage == 11) {
                _phase = 43;
                // Production mode 4 reuses the proven mode-11 request/parser,
                // but the result remains tagged with the selected stage (4).
                // This avoids a separate mode-4 HTTP or parsing implementation.
                beginUnifiedImgwRequest(_stage == 4 ? 11 : _stage);
                return;
            }
            // Store county in the BACKGROUND process itself. According to
            // Garmin API >=3.2.0, Application.Storage is available here.
            // This avoids depending on when onBackgroundData() is delivered;
            // Garmin may run another background event before that callback.
            _phase = 41;
            try {
                Storage.setValue("imgwCountyCacheV31916",
                    [_county, _lat, _lon, Time.now().value()]);
            } catch (e) { /* foreground onBackgroundData saves the same county */ }
            // IMPORTANT: never chain GitHub here. Status 16 is pending,
            // NOT a weather all-clear. Next activation does only the feed.
            _phase = 42;
            Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 16, _stage]);
            return;
        } catch (e) { stop(10); }
    }

    // Tiny, validated JSON replaces the national IMGW payload. Format:
    // {"v":1, "ts":<Unix epoch>, "a":{"1261":[2,4], ...}}
    // An absent county is safe to treat as 'no alerts' ONLY if this whole feed
    // is valid and fresh. 0/invalid/stale data is never silently an all-clear.
    function onWarningsResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        _phase = 50;
        if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
        if (payload == null) { stop(9); return; }
        try { processWarnings(payload); }
        catch (e) { stop(10); }
    }

    function processWarnings(body as Lang.Object) as Void {
        try {
            _phase = 51;
            if (!(body instanceof Lang.Dictionary)) { stop(9); return; }
            _phase = 52;
            if (body["v"] != 1) { stop(9); return; }
            var when = body["ts"];
            var alerts = body["a"];
            if (!(when instanceof Lang.Number) ||
                !(alerts instanceof Lang.Dictionary)) { stop(9); return; }
            _phase = 53;
            var age = Time.now().value() - when;
            // Publishing pauses/errors must never appear as no warnings.
            if (age < -300 || age > 7200) { stop(13); return; }
            _phase = 54;
            var match = alerts[_county];
            if (match == null) {
                _phase = 55;
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 2, _stage]);
                return;
            }
            if (!(match instanceof Lang.Array) || match.size() != 2 ||
                !(match[0] instanceof Lang.Number) ||
                !(match[1] instanceof Lang.Number)) { stop(9); return; }
            _phase = 56;
            var level = match[0];
            var kind = match[1];
            if (level < 1 || level > 3 || kind < 1 || kind > 13) {
                stop(9); return;
            }
            _phase = 57;
            Bg.exit([_county, level, kind, Time.now().value(), _lat, _lon, 1, _stage]);
        } catch (e) { stop(10); }
    }
}
