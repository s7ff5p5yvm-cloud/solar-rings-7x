#!/usr/bin/env python3
"""Regression checks: stage 4 uses mode-11 backend; UI fails closed.
This is code-structure validation, NOT an on-device execution test.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
svc=(r/'source/ImgwService.mc').read_text()
face=(r/'source/SolarRings7X.mc').read_text()
manifest=ET.parse(r/'manifest.xml').getroot()
app=manifest.find('{http://www.garmin.com/xml/connectiq}application')
assert app.get('version')=='3.20.2'
# Both full modes run the same service and parser, but retain stage tags.
assert 'beginUnifiedImgwRequest(_stage == 4 ? 11 : _stage);' in svc
assert 'Bg.exit([_county, bestLevel, bestKind, Time.now().value(), _lat,' in svc
assert '_lon, code, _stage]);' in svc
# Shared validation and display for stage 4 and 11.
start=face.index('function imgwDiagnosticLine()')
end=face.index('function drawWeather(',start)
chunk=face[start:end]
assert 'if (stage == 4 || stage == 11)' in chunk
assert 'verifiedImgwResult(stage, stage == 4)' in chunk
assert 'result[7] != stage' in chunk
assert 'stage == 9 || stage == 10 || stage == 12 || stage == 13' in chunk
assert 'if (stage == 9 || stage == 10 || stage == 11 || stage == 12 || stage == 13)' not in chunk
# Invalid, stale, wrong-stage or wrong-location data NEVER reports no alert.
validator=face[face.index('function verifiedImgwResult('):face.index('function activeImgwAlert()')]
for token in ('d[7] != stage','d[6] != 1 && d[6] != 2',
              'age > 7200','fixAge > 21600','d[4] - loc[0]',
              'd[5] - loc[1]', 'd[1] > 3','d[2] > 13'):
    assert token in validator,token
# Diagnostics are just text, never unvalidated automatic alert drawing.
active=face[face.index('function activeImgwAlert()'):face.index('function imgwDiagnosticLine()')]
assert 'srSetting("imgwDiagnosticsV3193", false)' in active
assert 'verifiedImgwResult(4, true)' in active
assert 'd[6] != 1' in active
# Guard the weather renderer so ordinary UI exceptions don't kill the face.
assert 'try {\n            drawWeather(dc, monitor, w);' in face
assert 'IMGW UI ERR' in face
assert 'T4 DANE' in face
print('PASS: stage 4 shares stage 11 transport/parser, guarded & validated foreground')
