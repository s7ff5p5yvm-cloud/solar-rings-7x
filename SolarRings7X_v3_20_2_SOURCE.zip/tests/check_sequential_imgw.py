#!/usr/bin/env python3
"""Regression: production stage 4 MUST use the previously successful 5C path."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'source/ImgwService.mc').read_text()
f=(r/'source/SolarRings7X.mc').read_text()
run=s.split('function onTemporalEvent()',1)[1].split('function parseCounty(',1)[0]
cb=s.split('function onCountyResponse(',1)[1].split('function onWarningsResponse(',1)[0]
assert 'cachedCountyForLocation()' not in run
assert 'beginUnifiedImgwRequest(4)' not in run
assert 'if (_stage == 4 || _stage == 9 || _stage == 10 || _stage == 11)' in cb
assert 'beginUnifiedImgwRequest(_stage == 4 ? 11 : _stage);' in cb
assert cb.index('if (_stage == 4') < cb.index('Storage.setValue("imgwCountyCacheV31916"')
assert 'processOfficialWarnings(payload)' in s
assert 'if (stage == 4)' not in run
assert 'response[6] == 10' in f
assert 'T4 OK0 ' in f and 'T4 ALERT ' in f
print('PASS: stage4 shares GUGiK -> direct IMGW -> full analysis with successful stage11')
