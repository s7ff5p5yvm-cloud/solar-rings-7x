# Solar Rings 7X v3.20.2 — stabilizacja trybu IMGW

## Dlaczego ta wersja?
Na Garmin Fenix 7X Pro Solar test 5C (T11 OK0) działał, natomiast tryb 4
powodował wyjście z tarczy, mimo podobnego przetwarzania danych. Bez logu
urządzenia nie da się jednoznacznie wskazać przyczyny. Ta poprawka izoluje
rozbieżności w rysowaniu wyniku i chroni tarczę przed zwykłymi wyjątkami UI.

## Wprowadzone zmiany
- Pełny tryb 4 używa dokładnie tej samej gałęzi żądania i analizy IMGW co tryb 5C.
- Wspólny walidator wyniku dla trybu 4 i 5C: tylko wynik bieżącego etapu,
  z poprawnym statusem, kodem powiatu, czasem i pozycją GPS.
- Błędne, stare lub obce dane NIE są traktowane jako brak ostrzeżeń.
- Przy włączonej diagnostyce tryb 4 pokazuje rzeczywisty status IMGW
  tekstowo, bez nakładania dodatkowej ikony (jak w udanym teście 5C).
- Po wyłączeniu diagnostyki sprawdzona ikona aktywnego ostrzeżenia jest
  nadal dostępna.
- Błąd rysowania pola pogody jest odizolowany od reszty tarczy;
  pojawia się 'IMGW UI ERR' zamiast nieobsłużonego wyjątku w tym polu.
- Żadnych danych z gałęzi GitHub imgw-feed w produkcyjnym trybie 4.
- Wszystkie poprzednie pola i 35 ustawień tarczy pozostają.

## Instalacja
1. Umieść SolarRings7X_v3_20_2_SOURCE.zip w katalogu głównym repozytorium.
2. Umieść SolarRings7X_v3_20_2_BUILD.yml w .github/workflows/ na domyślnej gałęzi.
3. GitHub Actions > Build Solar Rings 7X v3.20.2 > Run workflow.
4. Pobierz plik wynikowy .iq/.prg z artefaktu GitHub Actions i zainstaluj
   jak poprzednie wersje (przy zachowaniu tego samego identyfikatora aplikacji).

## Test na zegarku
1. IMGW: włączone; Etap 4: pełny IMGW; Diagnostyka: włączona;
   odświeżanie co 5 min.
2. Sprawdź, czy pojawi się T4 OK0 1261 / T4 ALERT 1261 albo kod błędu.
3. Odczekaj co najmniej dwa uruchomienia usługi (GitHub nie bierze udziału
   w pobieraniu IMGW).
4. Jeśli tryb 4 jest stabilny, wyłącz samą diagnostykę i sprawdź zwykłą
   ikonę ostrzegawczą. Po zakończeniu ustaw odświeżanie np. co 30 minut.

## Ograniczenia
- Testy offline i analiza struktury nie zastępują kompilacji Garmin SDK,
  prób w symulatorze ani wykonania na fizycznym zegarku.
- Nie da się gwarantować odporności na problemy pamięci podczas automatycznego
  dekodowania pełnej odpowiedzi IMGW przez Garmin; do tego potrzebna jest
  obserwacja działania na zegarku i ewentualnie logi CIQ.
- Jeśli nadal wyrzuca tarczę podczas drugiego cyklu, nie należy traktować
  IMGW jako niezawodnego źródła alertów w tej wersji. Wtedy trzeba zastosować
  mały, filtrowany feed lub przegląd błędu CIQ na urządzeniu.
