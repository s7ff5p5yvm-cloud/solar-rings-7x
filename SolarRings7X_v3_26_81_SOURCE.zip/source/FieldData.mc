using Toybox.SensorHistory as History;
using Toybox.Activity as Activity;
using Toybox.ActivityMonitor as Monitor;
using Toybox.System as System;
using Toybox.Weather as Weather;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;

// Bounded caches: one entry per history type (<= 6) and per solar event.
// Never cache phone connection, steps, live pulse, weather state,
// battery or battery charging: those still reflect every face refresh.
var _srHistorySamples = {};
var _srSolarTimes = {};
// One short-lived cache for the nearest next solar event. Expiration happens
// at the event instant itself, so crossing sunrise/sunset is never delayed.
var _srNextSunEvent = null;

// Shared only while onUpdate() draws one frame. Never retain the last charge
// or battery level between redraws. Null outside rendering falls back to SDK.
var _srFrameSystemStats = null;
function srSystemStatsForFrame() {
    if (_srFrameSystemStats != null) { return _srFrameSystemStats; }
    return System.getSystemStats();
}

function twoDigits(n) {
    return (n < 10 ? "0" : "") + n.toString();
}

function compact(n) {
    if (n >= 1000000) { return (n.toFloat() / 1000000.0).format("%.1f") + "m"; }
    if (n >= 10000) { return (n.toFloat() / 1000.0).format("%.1f") + "k"; }
    return n.toString();
}

function numeric(x) {
    if (x == null) { return "--"; }
    return x.toNumber().toString();
}

// Display real fractional battery telemetry when the DEVICE provides it.
// Some Garmin firmware versions expose only integer percentages; never
// manufacture tenths (or append a misleading ",0"). One decimal is shown
// without rounding UP to the next tenth; daily test snapshots remain raw.
function srBatteryPercentText(x) {
    if (x == null) { return "--"; }
    var v = x.toFloat();
    if (v < 0 || v > 100) { return "--"; }
    var whole = v.toNumber();
    // A minuscule epsilon protects exact tenth values stored as binary float.
    var tenths = (v * 10.0 + 0.00001).toNumber();
    var remainder = tenths - whole * 10;
    if (remainder <= 0 || remainder >= 10) {
        return whole.toString() + "%";
    }
    return whole.toString() + "," + remainder.toString() + "%";
}

function sampleValue(type) {
    var key = type.toString();
    var now = Time.now().value();
    var cached = _srHistorySamples[key];
    // SensorHistory is a historical snapshot, not live telemetry. Cache each
    // configured history type for two minutes to reduce repeated iterator
    // reads. The live optical heart rate uses recentHeartRate() instead and
    // remains uncached, including during high-power 1Hz redraws.
    if (cached != null && now >= cached[0] && now - cached[0] < 120) {
        return cached[1];
    }
    var value = null;
    try {
        var it = null;
        var opt = { :period => new Time.Duration(3600), :order => History.ORDER_NEWEST_FIRST };
        if (type == 1) { it = History.getHeartRateHistory(opt); }
        else if (type == 3) { it = History.getBodyBatteryHistory(opt); }
        else if (type == 11) { it = History.getOxygenSaturationHistory(opt); }
        else if (type == 22) { it = History.getPressureHistory(opt); }
        else if (type == 23) { it = History.getElevationHistory(opt); }
        else if (type == 10) { it = History.getStressHistory(opt); }
        if (it != null) {
            var item = it.next();
            var inspected = 0;
            while (item != null && inspected < 24) {
                if (item.data != null) { value = item.data; break; }
                item = it.next();
                inspected++;
            }
        }
    } catch (e) { }
    _srHistorySamples[key] = [now, value];
    return value;
}

// Prefer the newest *valid* activity-monitor pulse sample, which can be
// fresher than the historical SensorHistory series. Watch faces cannot use
// Toybox.Sensor for continuous live HR; MIP rendering still refreshes slowly.
// Current heart rate from the optical sensor, not old history.
// A missing measurement (e.g. after removing the watch) is displayed as "--".
// Do NOT use the last valid historical sample as a live heart rate.
function recentHeartRate() {
    try {
        var activity = Activity.getActivityInfo();
        if (activity == null) { return null; }
        var hr = activity.currentHeartRate;
        if (hr != null && hr > 0 && hr < 255) { return hr; }
    } catch (e) { }
    return null;
}

function sunClock(isRise, w) {
    var now = Time.now();
    var nowSeconds = now.value();
    var day = Gregorian.info(now, Time.FORMAT_SHORT);
    var dayKey = day.year * 10000 + day.month * 100 + day.day;
    var observation = 0;
    try {
        if (w != null && w.observationTime != null) {
            observation = w.observationTime.value();
        }
    } catch (e) { }
    var key = isRise ? "rise" : "set";
    var cached = _srSolarTimes[key];
    // The solar time for the same day/location is stable. Re-evaluate if
    // the weather observation changes, midnight passes, or after 10 minutes.
    if (cached != null && cached[1] == dayKey && cached[2] == observation &&
        nowSeconds >= cached[0] && nowSeconds - cached[0] < 600) {
        return cached[3];
    }
    var result = "--:--";
    var location = null;
    if (w != null) { location = w.observationLocationPosition; }
    if (location == null) {
        try {
            var info = Activity.getActivityInfo();
            if (info != null) { location = info.currentLocation; }
        } catch (e) { }
    }
    if (location != null) {
        try {
            var moment = isRise ? Weather.getSunrise(location, now)
                                : Weather.getSunset(location, now);
            if (moment != null) {
                var g = Gregorian.info(moment, Time.FORMAT_SHORT);
                result = twoDigits(g.hour) + ":" + twoDigits(g.min);
            }
        } catch (e) { }
    }
    _srSolarTimes[key] = [nowSeconds, dayKey, observation, result];
    return result;
}

// Upcoming solar event. Re-evaluated on every onUpdate() call so that
// the selected field switches after sunrise/sunset and updates on new days.
// [true => sunrise, false => sunset, formatted LOCAL hour].
// Uses the same weather-location/GPS fallback as the separate solar fields.
// Null means the device has no location or Garmin cannot calculate solar times.
function nextSunEvent(w) {
    var now = Time.now();
    var nowSeconds = now.value();
    var observation = 0;
    try {
        if (w != null && w.observationTime != null) {
            observation = w.observationTime.value();
        }
    } catch (e) { }
    var cached = _srNextSunEvent;
    if (cached != null && cached[1] == observation &&
        nowSeconds >= cached[0] &&
        nowSeconds - cached[0] < (cached[3] == null ? 30 : 600) &&
        (cached[2] == 0 || nowSeconds < cached[2])) {
        return cached[3];
    }
    var location = null;
    try {
        if (w != null) { location = w.observationLocationPosition; }
    } catch (e) { }
    if (location == null) {
        try {
            var info = Activity.getActivityInfo();
            if (info != null) { location = info.currentLocation; }
        } catch (e) { }
    }
    if (location == null) {
        _srNextSunEvent = [nowSeconds, observation, 0, null];
        return null;
    }
    try {
        var rise = Weather.getSunrise(location, now);
        var set = Weather.getSunset(location, now);
        var selected = null;
        var isRise = true;
        // Use absolute Instants; never compare local HH:MM strings.
        if (rise != null && rise.value() > now.value()) {
            selected = rise;
            isRise = true;
        }
        if (set != null && set.value() > now.value()) {
            if (selected == null || set.value() < selected.value()) {
                selected = set;
                isRise = false;
            }
        }
        // After sunset the next relevant event is tomorrow's sunrise.
        if (selected == null) {
            var tomorrow = now.add(new Time.Duration(86400));
            var tomorrowRise = Weather.getSunrise(location, tomorrow);
            if (tomorrowRise != null && tomorrowRise.value() > now.value()) {
                selected = tomorrowRise;
                isRise = true;
            }
        }
        if (selected == null) {
            _srNextSunEvent = [nowSeconds, observation, 0, null];
            return null;
        }
        var localTime = Gregorian.info(selected, Time.FORMAT_SHORT);
        var result = [isRise, twoDigits(localTime.hour) + ":" + twoDigits(localTime.min)];
        _srNextSunEvent = [nowSeconds, observation, selected.value(), result];
        return result;
    } catch (e) { }
    _srNextSunEvent = [nowSeconds, observation, 0, null];
    return null;
}

function conditionText(w) {
    if (w == null || w.condition == null) { return "BRAK DANYCH"; }
    var c = w.condition;
    // Exact descriptions for unambiguous threats; common display groups
    // preserve the earlier concise Polish weather labels.
    if (c == Weather.CONDITION_TORNADO) { return "TORNADO"; }
    if (c == Weather.CONDITION_HURRICANE) { return "HURAGAN"; }
    if (c == Weather.CONDITION_TROPICAL_STORM) { return "BURZA TROP."; }
    if (c == Weather.CONDITION_SQUALL) { return "SZKWAL"; }
    if (c == Weather.CONDITION_HAIL) { return "GRAD"; }
    if (c == Weather.CONDITION_FREEZING_RAIN) { return "DESZCZ MARZ."; }
    if (c == Weather.CONDITION_ICE) { return "LOD"; }
    if (c == Weather.CONDITION_SMOKE) { return "DYM"; }
    if (c == Weather.CONDITION_VOLCANIC_ASH) { return "POPIOL"; }
    if (c == Weather.CONDITION_SANDSTORM) { return "BURZA PIASK."; }
    if (c == Weather.CONDITION_UNKNOWN_PRECIPITATION) { return "OPADY"; }
    if (c == Weather.CONDITION_MIST || c == Weather.CONDITION_HAZE ||
        c == Weather.CONDITION_HAZY) { return "ZAMGLENIE"; }
    var group = srGarminDisplayGroup(c);
    if (group == 0) { return "SLONECZNIE"; }
    if (group == 1) { return "CZ. ZACHM."; }
    if (group == 2) { return "POCHMURNIE"; }
    if (group == 3) { return "DESZCZ"; }
    if (group == 4) { return "SNIEG"; }
    if (group == 5) { return "DESZCZ/SNIEG"; }
    if (group == 6) { return "BURZA"; }
    if (group == 7) { return "MGLA"; }
    if (group == 8) { return "WIATR"; }
    if (group == 10) { return "PYL / DYM"; }
    if (group == 11) { return "OBLODZENIE"; }
    return "BRAK DANYCH";
}

// All lunar fields use the same calendar-based offline phase model as the
// enlarged Moon panel; it is computed once per local day for battery savings.
function moonFraction() {
    return srMoonDayInfo()[0];
}

function moonPhaseLabel() {
    var p = moonFraction();
    if (p < 0.055 || p >= 0.945) { return "NOW"; }
    if (p < 0.195) { return "PRZYB."; }
    if (p < 0.305) { return "I KW."; }
    if (p < 0.445) { return "GAR.+"; }
    if (p < 0.555) { return "PEL."; }
    if (p < 0.695) { return "GAR.-"; }
    if (p < 0.805) { return "III KW."; }
    return "UBYW.";
}

// Each field is [short label, displayed value, ratio or null].
// No invented goals: non-goal metrics have a neutral, unfilled ring.
// Per-field reusable output tuples; one buffer per ID avoids cross-field
// aliases and the per-second allocation of [label, value, ratio].
var _srFieldOutput = {};
function srFieldReuse(id, label, value, ratio) {
    var entry = _srFieldOutput[id];
    if (entry == null) {
        entry = [label, value, ratio];
        _srFieldOutput[id] = entry;
    } else {
        entry[0] = label;
        entry[1] = value;
        entry[2] = ratio;
    }
    return entry;
}

function readField(id, info, w) {
    var x = null;
    var goal = null;
    if (id == 0) { return srFieldReuse(id, "", "", null); }
    if (id == 1) {
        x = recentHeartRate();
        return srFieldReuse(id, "PULS", numeric(x), null);
    }
    if (id == 2) {
        x = info.steps;
        goal = info.stepGoal;
        return srFieldReuse(id, "KROKI", x == null ? "--" : (x < 1000000 ? x.toString() : compact(x)), (x != null && goal != null && goal > 0) ? x.toFloat() / goal : null);
    }
    if (id == 3) {
        x = sampleValue(3);
        return srFieldReuse(id, "BODY", numeric(x), x == null ? null : x.toFloat() / 100.0);
    }
    if (id == 4) {
        goal = info.activeMinutesWeekGoal;
        x = info.activeMinutesWeek == null ? null : info.activeMinutesWeek.total;
        return srFieldReuse(id, "MIN/T", numeric(x), (x != null && goal != null && goal > 0) ? x.toFloat() / goal : null);
    }
    if (id == 5) {
        x = info.activeMinutesDay == null ? null : info.activeMinutesDay.total;
        return srFieldReuse(id, "MIN/D", numeric(x), null);
    }
    if (id == 6) { return srFieldReuse(id, "KCAL", numeric(info.calories), null); }
    if (id == 7) {
        x = info.distance;
        return srFieldReuse(id, "DYST", x == null ? "--" : (x.toFloat() / 100000.0).format("%.1f") + "km", null);
    }
    if (id == 8) {
        x = info.floorsClimbed;
        goal = info.floorsClimbedGoal;
        return srFieldReuse(id, "PIETRA", numeric(x), (x != null && goal != null && goal > 0) ? x.toFloat() / goal : null);
    }
    if (id == 9) { return srFieldReuse(id, "W DOL", numeric(info.floorsDescended), null); }
    if (id == 10) {
        x = sampleValue(10);
        if (x == null) { x = info.stressScore; }
        return srFieldReuse(id, "STRES", numeric(x), x == null ? null : x.toFloat() / 100.0);
    }
    if (id == 11) {
        x = sampleValue(11);
        return srFieldReuse(id, "SPO2", x == null ? "--" : numeric(x) + "%", x == null ? null : x.toFloat() / 100.0);
    }
    if (id == 12) { return srFieldReuse(id, "ODDECH", numeric(info.respirationRate), null); }
    if (id == 13) { return srFieldReuse(id, "REGEN", info.timeToRecovery == null ? "--" : numeric(info.timeToRecovery) + "h", null); }
    if (id == 14) { return srFieldReuse(id, "WSCHOD", sunClock(true, w), null); }
    if (id == 15) { return srFieldReuse(id, "ZACHOD", sunClock(false, w), null); }
    if (id == 35) {
        var event = nextSunEvent(w);
        if (event == null) { return srFieldReuse(id, "SLONCE", "--:--", null); }
        return srFieldReuse(id, event[0] ? "WSCHOD" : "ZACHOD", event[1], null);
    }
    if (id == 16) { return srFieldReuse(id, "POGODA", w == null ? "--" : numeric(w.temperature) + "°C", null); }
    if (id == 17) {
        x = srSystemStatsForFrame().battery;
        return srFieldReuse(id, "BAT", srBatteryPercentText(x), x.toFloat() / 100.0);
    }
    if (id == 18) { return srFieldReuse(id, "TEMP", w == null ? "--" : numeric(w.temperature) + "°C", null); }
    if (id == 19) { return srFieldReuse(id, "ODCZUW", w == null ? "--" : numeric(w.feelsLikeTemperature) + "°C", null); }
    if (id == 20) {
        x = w == null ? null : w.relativeHumidity;
        return srFieldReuse(id, "WILGOT", x == null ? "--" : numeric(x) + "%", x == null ? null : x.toFloat() / 100.0);
    }
    if (id == 21) { return srFieldReuse(id, "WIATR", w == null || w.windSpeed == null ? "--" : w.windSpeed.format("%.1f") + "m/s", null); }
    if (id == 22) {
        x = sampleValue(22);
        return srFieldReuse(id, "hPa", x == null ? "--" : (x.toFloat() / 100.0).format("%.0f"), null);
    }
    if (id == 23) {
        x = sampleValue(23);
        return srFieldReuse(id, "WYS", x == null ? "--" : numeric(x) + "m", null);
    }
    if (id == 24) { return srFieldReuse(id, "CEL KR", info.stepGoal == null ? "--" : compact(info.stepGoal), null); }
    if (id == 25) { return srFieldReuse(id, "CEL MIN", numeric(info.activeMinutesWeekGoal), null); }
    if (id == 26) { return srFieldReuse(id, "MAX", w == null ? "--" : numeric(w.highTemperature) + "°C", null); }
    if (id == 27) { return srFieldReuse(id, "MIN", w == null ? "--" : numeric(w.lowTemperature) + "°C", null); }
    if (id == 28) { return srFieldReuse(id, "RUCH", numeric(info.moveBarLevel), null); }
    if (id == 29) { return srFieldReuse(id, "UV", w == null ? "--" : numeric(w.uvIndex), null); }
    if (id == 30) {
        x = w == null ? null : w.precipitationChance;
        return srFieldReuse(id, "OPADY", x == null ? "--" : numeric(x) + "%", x == null ? null : x.toFloat() / 100.0);
    }
    if (id == 31) {
        var c = System.getClockTime();
        return srFieldReuse(id, "CZAS", twoDigits(c.hour) + ":" + twoDigits(c.min), null);
    }
    if (id == 32) {
        var d = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        return srFieldReuse(id, "DATA", twoDigits(d.day) + "." + twoDigits(d.month), null);
    }
    if (id == 34) { return srFieldReuse(id, "KSIEZYC", moonPhaseLabel(), null); }
    if (id == 33) {
        x = w == null ? null : w.cloudCover;
        return srFieldReuse(id, "CHMURY", x == null ? "--" : numeric(x) + "%", x == null ? null : x.toFloat() / 100.0);
    }
    return srFieldReuse(id, "", "--", null);
}


// Concise 280px-friendly names, used by the optional moon phase panel.
// Astronomical approximation based on synodic month (not an ephemeris).

