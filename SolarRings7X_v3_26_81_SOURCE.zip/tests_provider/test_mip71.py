import unittest, re
from pathlib import Path
P = Path(__file__).resolve().parent.parent
S = (P/'source/SolarRings7X.mc').read_text()
F = (P/'source/FieldData.mc').read_text()
M = (P/'manifest.xml').read_text()
class Mip71(unittest.TestCase):
    def test_palette_roles(self):
        self.assertIn('0x55AAFF, false,', S) # weekday
        self.assertIn('0xAAFFFF, false,', S) # date
        self.assertIn('var primary = isRise ? 0xFFAA55 : 0xAA55FF;', S)
        self.assertIn('dc.setColor(0x5555FF, Gfx.COLOR_TRANSPARENT);', S) # BB ring
        for color in ['0x55AAFF','0xAAFFFF','0xAA55FF','0xFFAA55','0x5555FF','0xFFFF55','0xFFAA00','0xFFFFAA']:
            components=[(int(color,16)>>n)&255 for n in [16,8,0]]
            self.assertTrue(all(c in [0,85,170,255] for c in components),(color,components))
        self.assertNotIn('0xDEECFF',S)
    def test_weather_sun_contrast(self):
        self.assertIn('dc.setColor(0xFFFF55, Gfx.COLOR_TRANSPARENT);', S)
        self.assertIn('dc.setColor(0xFFAA00, Gfx.COLOR_TRANSPARENT);', S)
        self.assertIn('dc.setColor(0xFFFFAA, Gfx.COLOR_TRANSPARENT);', S)
    def test_no_functional_changes(self):
        assert 'Weather.getHourlyForecast(' not in S
        assert 'function drawCurrentWeatherIcon(' in S
        assert 'temp > srSetting("tempHotV312", 30)' in S
        assert 'temp < srSetting("tempColdV312", 0)' in S
        assert 'var hr = activity.currentHeartRate;' in F
        assert 'version="3.26.81"' in M
        assert 'function markSettingsChanged()' in S
    def test_battery_unchanged(self):
        assert 'drawIcon(dc, 124, 261, id, footerColor)' in S
        assert 'drawSized(dc, d[1], 167, 251, 60, 20' in S
    def test_photon_unchanged(self):
        assert 'srPhotonScheduleIfNeeded()' in S
        assert 'Weather.getCurrentConditions()' in S
        assert 'registerForTemporalEvent(' not in S
if __name__=='__main__': unittest.main()
