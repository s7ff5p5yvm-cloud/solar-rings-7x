import unittest
from pathlib import Path

P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text(encoding='utf-8')
F=(P/'source/FieldData.mc').read_text(encoding='utf-8')
B=(P/'source/SolarRingsGarminService.mc').read_text(encoding='utf-8')
class HistoryCache81(unittest.TestCase):
    def test_history_ttl(self):
        self.assertIn('now - cached[0] < 120',F)
        self.assertNotIn('now - cached[0] < 30',F)
        for kind in ['getBodyBatteryHistory','getOxygenSaturationHistory',
                     'getPressureHistory','getElevationHistory','getStressHistory']:
            self.assertIn(kind,F)
    def test_live_measurements_unaffected(self):
        self.assertIn('var hr = activity.currentHeartRate;',F)
        self.assertIn('x = recentHeartRate();',F)
        self.assertNotIn('sampleValue(1)',F)
        self.assertIn('var monitor = Monitor.getInfo();',S)
        self.assertIn('var stats = null;',S)
    def test_no_new_render_or_background_callbacks(self):
        for token in ('onPartialUpdate(', 'onEnterSleep(', 'onExitSleep('):
            self.assertNotIn(token,S)
        self.assertNotIn('Weather.getHourlyForecast(',S+B)
        self.assertIn('dc.drawText(layout[3] - 1',S)
        self.assertIn('dc.drawText(layout[3] + 1',S)
        self.assertIn('photonWatchOrWeatherCoordinates(weather)',S)
    def test_version(self):
        self.assertIn('version="3.26.81"',(P/'manifest.xml').read_text())
