from pathlib import Path
import unittest
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text(encoding='utf-8')
F=(P/'source/FieldData.mc').read_text(encoding='utf-8')
M=(P/'manifest.xml').read_text(encoding='utf-8')
class BodyBattery72(unittest.TestCase):
 def glyph(self):
  a=S.index('function bodyBatteryIcon(dc, x, y, color)')
  b=S.index('function intensityTimerIcon(dc, x, y, color)',a)
  return S[a:b]
 def test_faithful_reference(self):
  s=self.glyph()
  self.assertIn('dc.fillRoundedRectangle(x - 3, y + 1, 7, 8, 1);',s)
  self.assertIn('dc.fillCircle(x, y - 3, 2);',s)
  self.assertIn('dc.drawLine(x - 5, y - 1, x - 6, y - 3);',s)
  self.assertIn('dc.drawLine(x + 5, y - 1, x + 6, y - 3);',s)
  self.assertIn('dc.drawLine(x - 3, y - 9, x + 2, y - 9);',s)
 def test_distinct_battery_symbol(self):
  s=self.glyph()
  self.assertNotIn('batteryIcon(',s)
  self.assertNotIn('drawArc(',s)
  self.assertIn('dc.setColor(color, Gfx.COLOR_TRANSPARENT);',s)
  self.assertIn('dc.setColor(0x5555FF, Gfx.COLOR_TRANSPARENT);',s)
  self.assertIn('dc.setPenWidth(1);',s)
 def test_display_coupling(self):
  self.assertIn('else if (id == 3) { bodyBatteryIcon(dc, x, y, color); }', S)
  self.assertIn('statusIconColor(id, d[2], col)',S)
  self.assertIn('version="3.26.81"',M)
 def test_no_polling_and_live_hr(self):
  self.assertNotIn('Weather.getHourlyForecast(',S)
  self.assertNotIn('registerForTemporalEvent(',S)
  self.assertIn('var hr = activity.currentHeartRate;',F)
if __name__=='__main__':unittest.main()
