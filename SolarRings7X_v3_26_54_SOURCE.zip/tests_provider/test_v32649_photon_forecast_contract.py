from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
GEO=(ROOT/'source/WeatherGeocode.mc').read_text()
UI=(ROOT/'source/SolarRings7X.mc').read_text()

class PhotonForecast49(unittest.TestCase):
    def test_photon_query_has_no_unsupported_pl(self):
        # The public Photon instance rejects lang=pl with HTTP 400.
        for source in (NET,GEO):
            self.assertNotIn('"lang" => "pl"',source)
            self.assertIn('https://photon.komoot.io/reverse',source)
            self.assertIn('"limit" => "2"',source)
            self.assertIn('"radius"',source)
    def test_photon_old_400_deadline_migrated_once(self):
        self.assertIn('srGQueryV32649',NET)
        self.assertIn('write("srGNextAt", 0);',NET)
        self.assertIn('write("srGLastTry", 0);',NET)
        self.assertIn('var minutes = 30;',NET)
        self.assertIn('if (code == 429) { minutes = 60; }',NET)
        self.assertIn('write("srGResult", [_loc[0], _loc[1], city.toUpper()])',NET)
        self.assertIn('var feature = items[i] as Lang.Dictionary;',NET)
    def test_weather_queue_fairness_and_photon_reserved(self):
        part=NET.split('    function start()')[1] if 'NET' in globals() else NETWORK.split('    function start()')[1]
        for token in ('var wantC = nextC <= _now;', 'var wantF = nextF <= _now;',
                      'var cityDue = cityLookupDue();',
                      'if ((wantC || wantF) && !reserveAux)',
                      'ageC <= 16 * 60 && ageF <= 16 * 60',
                      'if (cityDue && Sys.getDeviceSettings().phoneConnected)',
                      'startCityLookup(); return;'):
            self.assertIn(token,part)
        self.assertLess(part.index('if ((wantC || wantF) && !reserveAux)'),
                        part.index('if (cityDue && Sys.getDeviceSettings().phoneConnected)'))

    def test_separate_hourly_and_15min_storage_diagnostics(self):
        for value in ('srOHoursV326','srOShortV3264',
                      'srONextFV326','srONextSV32648',
                      'srOD1hV32648','srOD15mV32648',
                      'timeline/15min','timeline/1h'):
            self.assertIn(value,NET)
        self.assertIn('drawOwmDiagRow(dc, 110, "1H"',UI)
        self.assertIn('drawOwmDiagRow(dc, 141, "15M"',UI)
        self.assertIn('if (kindIs("forecast") && _shortRequest',NET)
        self.assertIn('function srOwmPreferShort(s, h, loc, now)',(ROOT/'source/SolarOpenData.mc').read_text())
        self.assertIn('h[2] > s[2] + 20 * 60',(ROOT/'source/SolarOpenData.mc').read_text())
        self.assertIn('write("srOShortPausedV3264", _now + pauseShort)',NET)
    def test_aqi_and_daily_independent(self):
        for k in ('srONextAV326','srOAirV326','srONextDV326','srODayV326'):
            self.assertIn(k,NET)
        self.assertIn('setting("srOwmAirV326", false)',NET)
        self.assertIn('3600',NET)
    def test_settings_and_version(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('version'),'3.26.54')
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        settings=ET.parse(ROOT/'resources/settings/settings.xml').getroot()
        modes=next(v for v in settings if v.get('propertyKey')=='@Properties.gwPreviewV332')
        self.assertEqual([int(x.get('value')) for x in modes.find('settingConfig')],[0,15,21,22,23])

if __name__=='__main__': unittest.main()
