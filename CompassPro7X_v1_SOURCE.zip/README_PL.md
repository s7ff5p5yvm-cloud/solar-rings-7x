# Compass Pro 7X — aplikacja Connect IQ 1.0

**Niezależna od Solar Rings.** Kompas i nawigacja do zadanego azymutu dla Garmin Fenix 7X Pro Solar (z Wi-Fi oraz bez Wi-Fi). Bez GPS, bez połączeń sieciowych, bez nagrywania aktywności. Aplikacja używa tylko uprawnienia `Sensor` i zapisuje ustawienia lokalnie w pamięci zegarka.

## Ekran kompasu

- Róża kompasu z 36 kreskami, N/E/S/W i wyróżnioną na czerwono północą.
- Stały biały znacznik na godz. 12 — wskazuje kierunek, w którym skierowana jest górna część zegarka.
- Duży azymut: stopnie lub 6400 mils (NATO artillery mil).
- Opcjonalny cel w turkusie; wskazanie w lewo / prawo i odchyłka.
- Bieżący odczyt na podstawie `Sensor.getInfo().heading` (północ rzeczywista), z rezerwowym odczytem `Activity.currentHeading`. Rezerwowy odczyt może się nie odświeżać na postoju — na ekranie pokazuje się wówczas `SYSTEM` zamiast `SENSOR`.
- `BRAK KIERUNKU` gdy system nie udostępnia odczytu — aplikacja nie udaje sprawnego kompasu.

## Przyciski

**Główny kompas:** START zapisuje chwilowy azymut jako aktywny cel i przechodzi do prowadzenia. UP otwiera zapamiętane kierunki, DOWN otwiera menu. BACK zamyka aplikację.

**Prowadzenie do azymutu:** strzałka/cel na obręczy i kierunek skrętu. UP/DOWN zmienia zadany azymut o 1°. START otwiera menu. BACK wraca do kompasu.

**Menu:** UP/DOWN wybiera pozycję; START zatwierdza; BACK wraca. Opcje: zapisz cel do jednego z pięciu slotów, ustaw ręcznie azymut, odczytaj zapisane, usuń cel, ustawienia, pomoc/kalibracja.

**Ręczne ustawianie azymutu:** UP/DOWN zmienia wartość o ±5° albo ±10 mil, START zatwierdza, BACK anuluje.

**Ustawienia:** północ TRUE/MAG*, deklinacja -30 do +30° w krokach 0,5°, stopnie/milsy, odświeżanie SMOOTH (~350 ms) i ECO (~1000 ms).

## Północ geograficzna i magnetyczna

Odczyt `Sensor.Info.heading` jest według dokumentacji odniesiony do **północy rzeczywistej (TRUE)**. Tryb **MAG\*** to obliczenie `TRUE minus ręcznie ustawiona deklinacja`, nie niezależny pomiar magnetycznej północy i **nie automatyczna deklinacja**. Na przykład: dla deklinacji wschodniej +5° azymut MAG = TRUE - 5°. Zmiana trybu nie zmienia zapisanych azymutów (wszystkie przechowywane są jako TRUE). W terenie należy używać poprawnej deklinacji dla miejsca i daty.

## Kalibracja i bezpieczeństwo danych

Zegarek trzymaj poziomo, z dala od magnesów i metalu. Kalibrację przeprowadza się w systemowej aplikacji Kompas Garmina, nie wewnątrz Compass Pro 7X. Odczyt magnetometru może być zakłócany. Nie jest to certyfikowany instrument nawigacyjny; podczas wędrówek warto mieć niezależną metodę orientacji.

## Użycie baterii

- SMOOTH: zapytanie o kierunek co 350 ms, tylko gdy ekran kompasu/prowadzenia jest otwarty.
- ECO: co 1000 ms, tylko na tych samych ekranach.
- W menu, na ekranach ustawień i po zamknięciu aplikacji timer zostaje zatrzymany.
- Brak połączeń sieciowych i GPS. Nie ma wiarygodnej wartości % zużycia bez testu sprzętowego; odczyt i rysowanie odbywają się tylko w trakcie korzystania.

## Co wymaga testu na prawdziwym zegarku

1. Czy `Sensor.getInfo().heading` na Fenix 7X Pro zwraca odczyt na postoju i jak często odświeża dane (SDK nie gwarantuje częstotliwości zmian).
2. Czy START, UP, DOWN, MENU, BACK wykonują oczekiwane czynności dla danej wersji oprogramowania zegarka.
3. Czy wskazania są poprawne po przejściu 359° → 0°, czy nie ma problemu z drganiami wskazania i stanem uśpienia.
4. Czy ekran MIP jest czytelny w obu trybach i czy każda zmiana ustawienia jest zapisywana.
5. Rzeczywisty pobór energii dla 5, 15 i 30 minut korzystania z aplikacji w trybach SMOOTH i ECO.

## Budowanie

Projekt Monkey C zawiera `manifest.xml`, `monkey.jungle`, `source/`, `resources/` i `tests/`. Testy statyczne `python3 -m unittest discover -s tests -v`. Build Garmin SDK 9.3.0: `monkeyc -f monkey.jungle -d fenix7xpro -o CompassPro7X.prg -y signing_key.der -w -O 2`. Nie jest konieczna instalacja SDK na komputerze — dołączony `CompassPro7X_BUILD.yml` buduje na GitHub Actions (patrz `GITHUB_INSTRUKCJA_PL.md`).

**Status:** kompletna wersja źródłowa i testy statyczne. Sama zgodność API i funkcjonalność na sprzęcie wymagają jeszcze wyniku kompilacji Connect IQ SDK oraz instalacji na zegarku. Nie należy przedstawiać tej paczki jako już skompilowanej aplikacji `.prg`.
