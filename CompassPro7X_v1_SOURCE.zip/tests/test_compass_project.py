import math
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def wrap(angle):
    return angle % 360.0

def difference(current, target):
    delta = wrap(target - current)
    return delta - 360 if delta > 180 else delta

def mils(angle):
    return round(wrap(angle) * 6400 / 360) % 6400

class CompassTests(unittest.TestCase):
    def test_manifest(self):
        manifest = ET.parse(ROOT / 'manifest.xml').getroot()
        app = manifest.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['type'], 'watch-app')
        self.assertEqual(app.attrib['entry'], 'CompassProApp')
        self.assertNotEqual(app.attrib['id'], 'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertTrue(app.attrib['version'].startswith('1.'))
        ids = [p.attrib['id'] for p in manifest.iter('{http://www.garmin.com/xml/connectiq}product')]
        self.assertEqual(ids, ['fenix7xpro','fenix7xpronowifi'])
        self.assertEqual([p.attrib['id'] for p in manifest.iter('{http://www.garmin.com/xml/connectiq}uses-permission')], ['Sensor'])

    def test_resources(self):
        ET.parse(ROOT / 'resources' / 'strings.xml')
        self.assertTrue((ROOT / 'monkey.jungle').exists())

    def test_rollover(self):
        self.assertEqual(wrap(360), 0)
        self.assertEqual(wrap(-1), 359)
        self.assertEqual(wrap(721), 1)

    def test_shortest_sign(self):
        self.assertEqual(difference(350, 10), 20)
        self.assertEqual(difference(10, 350), -20)
        self.assertEqual(difference(90, 90), 0)

    def test_target_right(self):
        self.assertEqual(difference(0, 90), 90)

    def test_target_left(self):
        self.assertEqual(difference(0, 270), -90)

    def test_mils(self):
        self.assertEqual(mils(90), 1600)
        self.assertEqual(mils(180), 3200)
        self.assertEqual(mils(270), 4800)

    def test_display_reference_round_trip(self):
        for true in (0, 1, 89, 120, 359):
            for decl in (-10.5, 0, 5.5):
                display = wrap(true - decl)
                stored = wrap(display + decl)
                self.assertAlmostEqual(stored, true)

    def test_angular_smoothing_wrap(self):
        result = wrap(359 + difference(359, 1) * 0.5)
        self.assertAlmostEqual(result, 0)

    def test_sensor_is_scoped(self):
        s = (ROOT/'source/CompassScreen.mc').read_text()
        self.assertIn('Sensor.getInfo()',s)
        self.assertIn('activityInfo.currentHeading',s)
        self.assertIn('function onHide()',s)
        self.assertIn('_stopTimer();',s)
        self.assertIn('_shown && isCompassPage()',s)
        self.assertNotIn('Position.enableLocationEvents', s)
        self.assertNotIn('ActivityRecording.createSession',s)

    def test_persistent_bearings(self):
        s = (ROOT/'source/CompassScreen.mc').read_text()
        self.assertIn('CompassStore.slot(_selection)',s)
        self.assertIn('CompassStore.slotKey(_selection)',s)
        self.assertIn('target_true',s)
        self.assertIn('bearing_', (ROOT/'source/CompassStore.mc').read_text())

    def test_settings_available(self):
        s=(ROOT/'source/CompassScreen.mc').read_text()
        for feature in ('decl10', 'magnetic', 'mils', 'eco', 'POMOC / KAL.'):
            self.assertIn(feature,s)

    def test_permission_no_gps_or_network(self):
        m=(ROOT/'manifest.xml').read_text()
        self.assertNotIn('Communications',m)
        self.assertNotIn('Positioning',m)
        self.assertNotIn('Background',m)

    def test_save_and_load_reference_true(self):
        s=(ROOT/'source/CompassMath.mc').read_text()
        self.assertIn('function toDisplay',s)
        self.assertIn('function toTrue',s)
        self.assertIn('function shortest',s)

if __name__ == '__main__':
    unittest.main()
