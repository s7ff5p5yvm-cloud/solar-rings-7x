using Toybox.WatchUi as Ui;
using Toybox.Graphics as G;
using Toybox.Sensor as Sensor;
using Toybox.Activity as Activity;
using Toybox.Timer as Timer;
using Toybox.System as Sys;
using Toybox.Math as M;

class CompassScreen extends Ui.View {
    // 0 compass, 1 guidance, 2 menu, 3 saved, 4 save slot,
    // 5 manual bearing, 6 settings, 7 manual declination, 8 help
    var _page = 0;
    var _selection = 0;
    var _returnPage = 0;
    var _timer;
    var _timerActive = false;
    var _shown = false;
    var _heading = null;
    var _filtered = null;
    var _source = "BRAK";
    var _lastValid = 0;
    var _target = null; // Always TRUE north
    var _edit = 0.0; // Display-referenced desired heading
    var _decEdit = 0; // Tenths of a degree
    var _decl10 = 0;
    var _magnetic = false;
    var _mils = false;
    var _eco = false;
    var _toast = null;

    function initialize() {
        View.initialize();
        _timer = new Timer.Timer();
        _target = CompassStore.read("target_true", null);
        _magnetic = CompassStore.read("magnetic", false);
        _decl10 = CompassStore.read("decl10", 0);
        _mils = CompassStore.read("mils", false);
        _eco = CompassStore.read("eco", false);
    }

    function isCompassPage() { return _page == 0 || _page == 1; }

    function onShow() {
        _shown = true;
        _readHeading();
        _refreshTimer();
    }

    function onHide() {
        _shown = false;
        _stopTimer();
    }

    function _stopTimer() {
        if (_timerActive) {
            _timer.stop();
            _timerActive = false;
        }
    }

    function _refreshTimer() {
        _stopTimer();
        if (_shown && isCompassPage()) {
            _timer.start(method(:_tick), _eco ? 1000 : 350, true);
            _timerActive = true;
        }
        Ui.requestUpdate();
    }

    function _tick() {
        _readHeading();
        Ui.requestUpdate();
    }

    function _readHeading() {
        var reading = null;
        var source = "BRAK";
        try {
            var info = Sensor.getInfo();
            if (info != null && info.heading != null) {
                reading = info.heading * 180.0 / M.PI;
                source = "SENSOR";
            }
        } catch (e) { }

        // Fallback supplied by Garmin, not interpreted as a calibrated
        // standstill magnetometer. The UI identifies this fallback explicitly.
        if (reading == null) {
            try {
                var activityInfo = Activity.getActivityInfo();
                if (activityInfo != null && activityInfo.currentHeading != null) {
                    reading = activityInfo.currentHeading * 180.0 / M.PI;
                    source = "SYSTEM";
                }
            } catch (e) { }
        }

        if (reading != null && reading >= -360.0 && reading <= 720.0) {
            _heading = CompassMath.wrap(reading);
            if (_filtered == null) {
                _filtered = _heading;
            } else {
                var alpha = _eco ? 0.55 : 0.48;
                _filtered = CompassMath.wrap(_filtered + CompassMath.shortest(_filtered, _heading) * alpha);
            }
            _source = source;
            _lastValid = Sys.getTimer();
        } else {
            _source = "BRAK";
        }
    }

    function _valid() {
        if (_filtered == null || _source == "BRAK") { return false; }
        var age = Sys.getTimer() - _lastValid;
        return age >= 0 && age < 3500;
    }

    function _display(deg) {
        return CompassMath.toDisplay(deg, _magnetic, _decl10 / 10.0);
    }

    function _goto(page) {
        _page = page;
        _selection = 0;
        _refreshTimer();
    }

    function _rememberTarget(value) {
        _target = CompassMath.wrap(value);
        CompassStore.write("target_true", _target);
    }

    function select() {
        _toast = null;
        if (_page == 0) {
            if (_valid()) {
                _rememberTarget(_filtered);
                _goto(1);
            } else {
                _edit = 0.0;
                _goto(5);
            }
        } else if (_page == 1) {
            _goto(2);
        } else if (_page == 2) {
            _chooseMenu();
        } else if (_page == 3) {
            var s = CompassStore.slot(_selection);
            if (s != null) {
                _rememberTarget(s);
                _goto(1);
            } else {
                _toast = "PUSTY SLOT";
                Ui.requestUpdate();
            }
        } else if (_page == 4) {
            if (_target != null && CompassStore.write(CompassStore.slotKey(_selection), _target)) {
                _toast = "ZAPISANO #" + (_selection + 1).toString();
                _goto(1);
            } else {
                _toast = "BRAK CELU / PAMIECI";
                _goto(2);
            }
        } else if (_page == 5) {
            _rememberTarget(CompassMath.toTrue(_edit, _magnetic, _decl10 / 10.0));
            _goto(1);
        } else if (_page == 6) {
            _chooseSettings();
        } else if (_page == 7) {
            _decl10 = _decEdit;
            CompassStore.write("decl10", _decl10);
            _goto(6);
        }
    }

    function _chooseMenu() {
        if (_selection == 0) {
            if (_target == null && _valid()) { _rememberTarget(_filtered); }
            if (_target == null) {
                _edit = 0.0;
                _goto(5);
            } else {
                _goto(4);
            }
        } else if (_selection == 1) {
            _edit = _target != null ? _display(_target) : (_valid() ? _display(_filtered) : 0.0);
            _goto(5);
        } else if (_selection == 2) {
            _goto(3);
        } else if (_selection == 3) {
            _target = null;
            CompassStore.write("target_true", null);
            _goto(0);
        } else if (_selection == 4) {
            _goto(6);
        } else if (_selection == 5) {
            _goto(8);
        } else {
            _goto(_target != null ? 1 : 0);
        }
    }

    function _chooseSettings() {
        if (_selection == 0) {
            _magnetic = !_magnetic;
            CompassStore.write("magnetic", _magnetic);
        } else if (_selection == 1) {
            _decEdit = _decl10;
            _goto(7);
            return;
        } else if (_selection == 2) {
            _mils = !_mils;
            CompassStore.write("mils", _mils);
        } else if (_selection == 3) {
            _eco = !_eco;
            CompassStore.write("eco", _eco);
        } else {
            _goto(2);
            return;
        }
        Ui.requestUpdate();
    }

    function up() { _navigate(-1); }
    function down() { _navigate(1); }

    function _navigate(direction) {
        _toast = null;
        if (_page == 0) {
            _goto(direction < 0 ? 3 : 2);
            return;
        }
        if (_page == 1) {
            if (_target != null) {
                _rememberTarget(_target + direction);
            }
        } else if (_page == 2) {
            _selection = (_selection + direction + 7) % 7;
        } else if (_page == 3 || _page == 4) {
            _selection = (_selection + direction + 5) % 5;
        } else if (_page == 5) {
            _edit = CompassMath.wrap(_edit + direction * (_mils ? 0.5625 : 5.0));
        } else if (_page == 6) {
            _selection = (_selection + direction + 5) % 5;
        } else if (_page == 7) {
            _decEdit += direction * 5;
            if (_decEdit > 300) { _decEdit = 300; }
            if (_decEdit < -300) { _decEdit = -300; }
        }
        Ui.requestUpdate();
    }

    function menu() {
        _goto(2);
    }

    function back() {
        _toast = null;
        if (_page == 0) {
            _stopTimer();
            Sys.exit();
        } else if (_page == 1) {
            _goto(0);
        } else if (_page == 2) {
            _goto(_target != null ? 1 : 0);
        } else if (_page == 3 || _page == 4 || _page == 5 || _page == 6 || _page == 8) {
            _goto(2);
        } else if (_page == 7) {
            _goto(6);
        }
    }

    function onUpdate(dc) {
        dc.setColor(G.COLOR_BLACK, G.COLOR_BLACK);
        dc.clear();
        if (isCompassPage()) {
            _drawCompass(dc);
        } else {
            _drawPanel(dc);
        }
    }

    function _pointX(cx, r, deg) { return cx + (M.sin(CompassMath.radians(deg)) * r).toNumber(); }
    function _pointY(cy, r, deg) { return cy - (M.cos(CompassMath.radians(deg)) * r).toNumber(); }

    function _drawCompass(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();
        var cx = w / 2;
        var cy = h / 2 - 11;
        var rad = (w < h ? w : h) / 2 - 40;
        var heading = _valid() ? _display(_filtered) : null;
        var active = heading != null;

        dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
        dc.drawText(cx, 5, G.FONT_XTINY, _page == 0 ? "COMPASS PRO 7X" : "NAWIGUJ DO AZYMUTU", G.TEXT_JUSTIFY_CENTER);

        dc.setPenWidth(2);
        dc.setColor(0x50616F, G.COLOR_TRANSPARENT);
        dc.drawCircle(cx, cy, rad);
        dc.drawCircle(cx, cy, rad - 14);
        dc.setPenWidth(1);

        // Compass card and tick marks rotate against the watch's forward axis.
        if (active) {
            for (var a = 0; a < 360; a += 10) {
                var screenAngle = CompassMath.wrap(a - heading);
                var isMajor = (a % 30) == 0;
                var r1 = rad - (isMajor ? 12 : 7);
                var r2 = rad - 2;
                dc.setColor(isMajor ? 0xE4E7E9 : 0x677984, G.COLOR_TRANSPARENT);
                dc.drawLine(_pointX(cx, r1, screenAngle), _pointY(cy, r1, screenAngle),
                            _pointX(cx, r2, screenAngle), _pointY(cy, r2, screenAngle));
            }
            var names = ["N", "E", "S", "W"];
            for (var k = 0; k < 4; k++) {
                var cardAngle = CompassMath.wrap(k * 90.0 - heading);
                dc.setColor(k == 0 ? 0xFF4545 : G.COLOR_WHITE, G.COLOR_TRANSPARENT);
                dc.drawText(_pointX(cx, rad - 33, cardAngle), _pointY(cy, rad - 33, cardAngle) - 9,
                            G.FONT_SMALL, names[k], G.TEXT_JUSTIFY_CENTER);
            }
        }

        // Fixed sighting triangle: pointing the 12 o'clock watch axis at a landmark.
        dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
        dc.fillPolygon([[cx,cy-rad+3],[cx-8,cy-rad-13],[cx+8,cy-rad-13]]);

        if (active) {
            var northAngle = CompassMath.wrap(0.0 - heading);
            dc.setColor(0xF04444, G.COLOR_TRANSPARENT);
            dc.setPenWidth(4);
            dc.drawLine(_pointX(cx, 27, northAngle), _pointY(cy, 27, northAngle),
                        _pointX(cx, 58, northAngle), _pointY(cy, 58, northAngle));
            dc.setPenWidth(1);
        }

        if (_page == 1 && _target != null && active) {
            var bearing = _display(_target);
            var diff = CompassMath.shortest(heading, bearing);
            var aim = CompassMath.wrap(diff);
            dc.setColor(0x15D6B6, G.COLOR_TRANSPARENT);
            dc.fillCircle(_pointX(cx, rad - 8, aim), _pointY(cy, rad - 8, aim), 6);
            dc.setColor(0x15D6B6, G.COLOR_TRANSPARENT);
            dc.drawText(cx, cy + 46, G.FONT_TINY,
                        (diff > 2.0 ? "W PRAWO " : (diff < -2.0 ? "W LEWO " : "NA KIERUNKU "))
                        + CompassMath.text(diff < 0.0 ? -diff : diff, _mils), G.TEXT_JUSTIFY_CENTER);
        }

        dc.setColor(G.COLOR_WHITE, G.COLOR_BLACK);
        var bigNumber = "---";
        if (active) {
            bigNumber = (_mils ? CompassMath.degreesToMils(heading) % 6400
                                : ((heading + 0.5).toNumber() % 360)).toString();
        }
        dc.drawText(cx, cy - 36, active ? G.FONT_NUMBER_MEDIUM : G.FONT_LARGE,
                    bigNumber, G.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx, cy + 22, G.FONT_XTINY,
            active ? ((_mils ? "MIL" : "STOPNI") + "  /  " + (_magnetic ? "MAG*" : "TRUE")) : "BRAK ODCZYTU",
            G.TEXT_JUSTIFY_CENTER);

        dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
        dc.drawText(cx, h - 49, G.FONT_XTINY,
            active ? (_source + (_eco ? " | ECO" : " | SMOOTH")) : "BRAK KIERUNKU - SPRAWDZ CZUJNIK",
            G.TEXT_JUSTIFY_CENTER);
        dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
        dc.drawText(cx, h - 31, G.FONT_TINY,
            _page == 0 ? "START: ZAPISZ   DOWN: MENU" : "CEL " + CompassMath.text(_display(_target), _mils),
            G.TEXT_JUSTIFY_CENTER);
        dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
        dc.drawText(cx, h - 15, G.FONT_XTINY,
            _page == 0 ? "UP: ZAPISANE" : "UP/DOWN: +/-1   START: MENU", G.TEXT_JUSTIFY_CENTER);
        if (_toast != null) {
            dc.setColor(0xFFDF62, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 24, G.FONT_TINY, _toast, G.TEXT_JUSTIFY_CENTER);
        }
    }

    function _drawPanel(dc) {
        var cx = dc.getWidth() / 2;
        var items = [];
        var title = "";
        if (_page == 2) {
            title = "MENU";
            items = ["ZAPISZ CEL", "USTAW AZYMUT", "ZAPISANE", "USUN CEL", "USTAWIENIA", "POMOC / KAL.", "WROC"];
        } else if (_page == 3 || _page == 4) {
            title = _page == 3 ? "ZAPISANE AZYMUTY" : "ZAPISZ DO SLOTU";
            for (var i = 0; i < 5; i++) {
                var value = CompassStore.slot(i);
                items.add((i + 1).toString() + "   " + (value == null ? "PUSTY" : CompassMath.text(_display(value), _mils)));
            }
        } else if (_page == 6) {
            title = "USTAWIENIA";
            items = ["POLNOC: " + (_magnetic ? "MAG*" : "TRUE"),
                     "DEKLINACJA: " + (_decl10 / 10.0).toString(),
                     "JEDNOSTKI: " + (_mils ? "MIL" : "STOPNIE"),
                     "ODSWIEZANIE: " + (_eco ? "ECO" : "SMOOTH"), "WROC"];
        }
        dc.setColor(0x18CAB6, G.COLOR_TRANSPARENT);
        dc.drawText(cx, 22, G.FONT_MEDIUM, title, G.TEXT_JUSTIFY_CENTER);

        if (_page == 8) {
            dc.setColor(0x18CAB6, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 22, G.FONT_MEDIUM, "POMOC / KALIBRACJA", G.TEXT_JUSTIFY_CENTER);
            dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 71, G.FONT_TINY, "TRZYMAJ ZEGAREK POZIOMO", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 103, G.FONT_TINY, "ODDAL OD METALU I MAGNESOW", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 135, G.FONT_TINY, "KALIBRUJ W MENU GARMINA", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 166, G.FONT_XTINY, "BRAK ODCZYTU = BRAK KOMPASU", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 199, G.FONT_XTINY, "MAG* WYMAGA RECZNEJ DEKLINACJI", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 235, G.FONT_XTINY, "BACK: MENU", G.TEXT_JUSTIFY_CENTER);
            return;
        }

        if (_page == 5 || _page == 7) {
            dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 50, G.FONT_SMALL, _page == 5 ? "USTAW CEL" : "DEKLINACJA (E+ / W-)", G.TEXT_JUSTIFY_CENTER);
            var val = _page == 5 ? CompassMath.text(_edit, _mils) : (_decEdit / 10.0).toString() + "°";
            dc.drawText(cx, 102, G.FONT_LARGE, val, G.TEXT_JUSTIFY_CENTER);
            dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
            dc.drawText(cx, 189, G.FONT_SMALL, _page == 5 ? (_mils ? "UP/DOWN: +/-10 mil" : "UP/DOWN: +/-5°") : "UP/DOWN: +/-0.5°", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 216, G.FONT_TINY, "START: ZATWIERDZ", G.TEXT_JUSTIFY_CENTER);
            dc.drawText(cx, 240, G.FONT_XTINY, "BACK: ANULUJ", G.TEXT_JUSTIFY_CENTER);
            return;
        }

        for (var j = 0; j < items.size(); j++) {
            var y = 60 + j * 27;
            if (j == _selection) {
                dc.setColor(0x1C3639, G.COLOR_BLACK);
                dc.fillRoundedRectangle(26, y - 2, dc.getWidth() - 52, 28, 7);
                dc.setColor(0x48F0D1, G.COLOR_TRANSPARENT);
            } else {
                dc.setColor(G.COLOR_WHITE, G.COLOR_TRANSPARENT);
            }
            dc.drawText(38, y, G.FONT_TINY, (j == _selection ? "> " : "  ") + items[j], G.TEXT_JUSTIFY_LEFT);
        }
        dc.setColor(0x8A9BA7, G.COLOR_TRANSPARENT);
        dc.drawText(cx, dc.getHeight() - 30, G.FONT_XTINY, "UP/DOWN: WYBOR  START: OK", G.TEXT_JUSTIFY_CENTER);
        if (_toast != null) {
            dc.setColor(0xFFDF62, G.COLOR_TRANSPARENT);
            dc.drawText(cx, dc.getHeight() - 48, G.FONT_XTINY, _toast, G.TEXT_JUSTIFY_CENTER);
        }
    }
}
