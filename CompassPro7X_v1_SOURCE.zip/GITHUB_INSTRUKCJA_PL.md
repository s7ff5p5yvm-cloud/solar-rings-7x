# Compass Pro 7X — kompilacja w GitHub Actions

## Najbezpieczniejsza ścieżka (osobne repozytorium)

1. Utwórz **osobne** repo GitHub `compass-pro-7x` (publiczne albo prywatne). Nie zmieniaj repo Solar Rings.
2. Na gałęzi `main` dodaj do katalogu głównego `CompassPro7X_v1_SOURCE.zip` (nie rozpakowuj go na GitHubie).
3. Utwórz folder `.github/workflows` i dodaj plik `CompassPro7X_BUILD.yml`.
4. GitHub Actions uruchomi testy i kompilację automatycznie na `main`. W zakładce Actions możesz też uruchomić `workflow_dispatch` ręcznie.
5. Po poprawnym zakończeniu otwórz uruchomienie → Artifacts → `CompassPro7X_v1_build` i pobierz paczkę. Wybierz `CompassPro7X_fenix7xpro.prg`, skopiuj do `GARMIN/APPS` po podłączeniu zegarka USB.
6. Wybierz `Compass Pro 7X` z listy aplikacji / aktywności zegarka. To osobna aplikacja, nie tarcza.

Workflow generuje tymczasowy klucz deweloperski, jeśli w nowym repo nie ma sekretu `CONNECTIQ_DEVELOPER_KEY_BASE64`. Pozwala to skompilować i przetestować `.prg` bez kopiowania sekretu z repo Solar Rings. Taki klucz **nie nadaje się do późniejszych aktualizacji aplikacji publikowanej w sklepie**. Do wersji sklepowej utwórz odrębny trwały klucz podpisu dla Compass Pro 7X i zapisz go w sekretach nowego repo.

Nie udostępniaj pliku prywatnego klucza ani wartości sekretu. `monkeyc -e` (eksport `.iq` do Store) jest wykonywany tylko wtedy, gdy dostępny jest trwały klucz.

## Weryfikacja

Wynik `success` potwierdza kompilację i przejście testów statycznych, a **nie** dokładność kompasu ani działanie wszystkich przycisków. Po instalacji przetestuj obracanie zegarka o 90°/180°/360°, przejście 359°→0°, zapis i odczyt pięciu slotów oraz obsługę BACK. Jeśli kompas nie aktualizuje kierunku na postoju, zbierz informacje z ekranu (`SENSOR`, `SYSTEM` lub `BRAK`); nie włączaj od razu GPS.
