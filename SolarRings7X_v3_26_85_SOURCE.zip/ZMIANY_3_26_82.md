# Solar Rings 7X 3.26.82 — eksperymentalne buforowanie tekstu zegara

Bazą jest zweryfikowane archiwum 3.26.81 (SHA-256: `c68178fce11c117a7bc8b97ec2e248a167e044e683f160477c70786a2ab7cc16`).

## Jedyna zmiana funkcjonalna
- `source/SolarRings7X.mc`, metoda `drawClock`: wynik `twoDigits` dla godziny i minut zapisujemy razem z napisem `HH:MM` w istniejącym `_clockTextCache`. Przy ponownym rysowaniu tej samej minuty nie wywołujemy już `substring(0,2)` i `substring(3,5)`.
- Geometria tekstu, dobór czcionki, pogrubienie, siedem `drawText`, obsługa zegara, zmian ustawień, pogody, Photona i HR są niezmienione.
- Manifest podniesiony z 3.26.81 do 3.26.82. Asercje numeru wersji w testach dostosowane; dodano 6 nowych testów struktur i zachowania tekstu.

## Ograniczenia
To mała optymalizacja alokacji i CPU podczas wyświetlania sekundowym. Nie jest dowodem na oszczędność baterii. Pamięć podręczna przechowuje dwa dodatkowe odwołania do napisów (godzina i minuta). SDK kompiluje tę wersję dopiero w GitHub Actions, po wgraniu plików.
