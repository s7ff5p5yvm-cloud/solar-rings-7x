# Solar Rings v3.26.81 — Photon GPS zegarka + optymalizacje v3.26.79

- Priorytet współrzędnych dla Photon: `Position.getInfo().position` zegarka (tylko świeża dostępna pozycja, maksymalnie 2 h, gdy znany czas fixu), następnie `Activity.getActivityInfo().currentLocation`, a dopiero w przypadku braku odczytu: `Weather.getCurrentConditions().observationLocationPosition`.
- **Nie włącza GPS**: Garmin Connect IQ watch face nie pozwala wywołać `Position.enableLocationEvents()`. Korzystamy z istniejących danych zapisanych przez zegarek, a nie z nowego ustalenia satelitarnego.
- Identyczne wybrane współrzędne sterują żądaniem do Photon oraz lokalizacją pokazywaną na tarczy; nazwa stacji Garmin Weather jest używana wyłącznie, gdy współrzędne odpowiadają wybranemu punktowi.
- Walidacja współrzędnych (w tym odrzucenie 0,0 i błędnych wartości) oraz obsługa braku GPS bez awarii tarczy.
- Lokalizacja sprawdzana nie częściej niż raz na 55 s, brak dodatkowego cyklicznego wybudzania, Photon tylko po zmianie obszaru i z dotychczasowym ograniczeniem żądań.
- Zachowano bez zmian wszystkie ikony i wygląd v3.26.79, tętno na żywo, Garmin Weather oraz poprzednie optymalizacje.
- **Wymaga kompilacji Monkey C przez GitHub Actions i rzeczywistego testu na Fenix 7X Pro Solar.** Statyczne testy projektu nie są dowodem kompilacji ani prawidłowego działania GPS na urządzeniu.
