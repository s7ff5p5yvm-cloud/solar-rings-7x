# Solar Rings v3.26.75

## Co poprawiono
- Duże ikony pogody zostały przerysowane w bardziej premium stylu MIP.
- Chmury mają teraz warstwową bryłę z miękkim cieniem i subtelnymi refleksami.
- Deszcz, śnieg i burza zostały dopracowane wizualnie, bez zmiany logiki pogody.
- Ikony Księżyca otrzymały bardziej premium wygląd w każdej fazie: chłodniejszy cień, jaśniejszą tarczę i wyraźniejszą obwódkę.
- Nie dodano żadnych timerów, bitmap ani dodatkowych zapytań pogodowych.

## Co zostało bez zmian
- Tętno na żywo.
- Photon uruchamiany po zmianie lokalizacji.
- Garmin Weather tylko dla bieżących warunków.
- Termometry zimna i upału.
- Układ tarczy i optymalizacje baterii z v3.26.74.
