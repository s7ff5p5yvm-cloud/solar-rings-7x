import unittest, re
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text()
W=S.split('// v3.26.76: original blue weather glyphs',1)[1].split('// Battery footer occupies',1)[0]
class BlueWeather76(unittest.TestCase):
    def test_mip_palette(self):
        for color in re.findall(r'0x([0-9A-Fa-f]{6})',W):
            self.assertTrue(all(int(color[i:i+2],16) in (0,85,170,255) for i in (0,2,4)),color)
    def test_drawing_helpers_defined(self):
        declared=set(re.findall(r'function (currentWeather\w+)\(',W))
        called=set(re.findall(r'(currentWeather\w+)\(dc,',W))
        self.assertEqual(called,declared)
    def test_all_groups_and_intensity(self):
        for i in range(14): self.assertIn('group == '+str(i),W)
        for code in ('DRIZZLE','LIGHT_RAIN','HEAVY_RAIN','LIGHT_SNOW','HEAVY_SNOW'):
            self.assertIn('Weather.CONDITION_'+code,W)
        self.assertIn('rainLevel = 3',W)
        self.assertIn('snowLevel = 3',W)
    def test_no_extra_work_sources(self):
        for token in ('makeWebRequest','registerForTemporalEvent','getHourlyForecast','getCurrentConditions','new ','Storage.','onPartialUpdate'):
            self.assertNotIn(token,W)
    def test_moon_no_unmasked_marks(self):
        moon=S.split('function drawLunarDisk(',1)[1].split('// Moon/day-to-full',1)[0]
        self.assertNotIn('litDir',moon)
        self.assertEqual(moon.count('dc.fillCircle('),1)
        self.assertIn('dc.setPenWidth(1);',moon)
