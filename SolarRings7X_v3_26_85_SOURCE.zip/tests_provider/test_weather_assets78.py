from pathlib import Path
import unittest, hashlib, xml.etree.ElementTree as ET, struct
P=Path(__file__).resolve().parent.parent
D=P/'resources/drawables'
class WeatherAssets78(unittest.TestCase):
    def test_unique_icons(self):
        files=list((D/'weather').glob('*.png'))
        self.assertEqual(len(files),18)
        self.assertEqual(len({hashlib.sha256(f.read_bytes()).digest() for f in files}),18)
    def test_palette_entries(self):
        for e in ET.parse(D/'drawables.xml').getroot().findall('bitmap'):
            if not e.attrib['id'].startswith('Weather'): continue
            palette=[c.text for c in e.findall('palette/color')]
            self.assertEqual(len(palette),len(set(palette)))
            self.assertTrue(1<=len(palette)<=64)
            self.assertEqual(struct.unpack('>II',(D/e.attrib['filename']).read_bytes()[16:24]),(68,33))
