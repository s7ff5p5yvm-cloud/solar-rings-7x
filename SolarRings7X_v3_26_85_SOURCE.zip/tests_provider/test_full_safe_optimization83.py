"""Regression checks for 3.26.83's cross-component caching changes.

These are structural and model-level tests; they cannot certify hardware runtime,
CPU energy, heap peaks, or visual output on the actual Fenix MIP display.
"""
import hashlib
import re
import unittest
from pathlib import Path
from datetime import datetime, timezone, timedelta
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT/'source/SolarRings7X.mc').read_text(encoding='utf-8')
FIELD = (ROOT/'source/FieldData.mc').read_text(encoding='utf-8')
MOON = (ROOT/'source/MoonCalendar.mc').read_text(encoding='utf-8')
CONFIG = (ROOT/'source/Config.mc').read_text(encoding='utf-8')
SERVICE = (ROOT/'source/SolarRingsGarminService.mc').read_bytes()

class FullOptimization83(unittest.TestCase):
    def test_app_id_and_permissions(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertIsNotNone(app)
        self.assertEqual(app.attrib['version'],'3.26.85')
        self.assertEqual(app.attrib['id'],'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        for key in ('Positioning','Background','Communications','SensorHistory'):
            self.assertIn(f'id="{key}"',(ROOT/'manifest.xml').read_text())

    def test_shared_calendar_reused_before_derived_fields(self):
        self.assertIn('function srRememberLocalCalendar(local, minuteKey)',FIELD)
        self.assertIn('function srLocalCalendarInfo(now)',FIELD)
        self.assertIn('cached[0] == minuteKey',FIELD)
        self.assertIn('srRememberLocalCalendar(_cachedCalendar, minuteKey);',FACE)
        self.assertIn('var day = srLocalCalendarInfo(now);',FIELD)
        self.assertIn('var local = srLocalCalendarInfo(now);',MOON)
        self.assertIn('var d = srLocalCalendarInfo(Time.now());',FIELD)
        self.assertIn('_srLocalCalendarCache = null;',FACE)

    def test_moon_date_guard_precedes_moment_calculation(self):
        start=MOON.index('function srMoonDayInfo()')
        body=MOON[start:]
        self.assertLess(body.index('cached[2] == local.year'),body.index('var localDay = srMoonCalendarDay(local);'))
        self.assertIn('cached[3] == local.month',body)
        self.assertIn('cached[4] == local.day',body)
        self.assertIn('_srFullMoonDayCache = [localDay, result, local.year, local.month, local.day];',body)
        self.assertIn('var fullDate = Gregorian.info(new Time.Moment(fullAt)',body)
        self.assertIn('srMoonPhaseEpoch(cycle + 1.5d, true)',body)
        self.assertIn('Math.cos(2.0 * Math.PI * phase)',FACE)

    def test_day_rollover_and_timezone_shift_model(self):
        # Per-minute memoization must recompute at a new UTC-minute, even when
        # the local date stays the same. Astronomical results still use Y/M/D.
        for offset in (-12, -4, 0, 1, 2, 5, 14):
            tz=timezone(timedelta(hours=offset))
            for start in (datetime(2026,3,29,22,59,tzinfo=timezone.utc),
                          datetime(2026,10,25,22,59,tzinfo=timezone.utc),
                          datetime(2026,12,31,23,59,tzinfo=timezone.utc)):
                next_minute=start+timedelta(minutes=1)
                self.assertEqual(int(next_minute.timestamp()//60),int(start.timestamp()//60)+1)
                local1=start.astimezone(tz).date()
                local2=next_minute.astimezone(tz).date()
                if local1!=local2:
                    self.assertNotEqual((local1.year,local1.month,local1.day),
                                        (local2.year,local2.month,local2.day))

    def test_sunrise_sunset_location_fallback_and_transition_kept(self):
        self.assertIn('Weather.getSunrise(location, now)',FIELD)
        self.assertIn('Weather.getSunset(location, now)',FIELD)
        self.assertIn('var tomorrow = now.add(new Time.Duration(86400));',FIELD)
        self.assertIn('nowSeconds < cached[2]',FIELD)
        self.assertIn('if (rise != null && rise.value() > nowSeconds)',FIELD)
        self.assertIn('if (set != null && set.value() > nowSeconds)',FIELD)
        self.assertIn('nowSeconds - cached[0] < 600',FIELD)

    def test_cached_font_settings_and_capped_storage(self):
        self.assertLess(CONFIG.index('var cached = _srSettingCache[key];'),
                        CONFIG.index('var fixed = null;'))
        self.assertIn('if (_srSettingCacheSize < 96)',CONFIG)
        self.assertIn('function srResetSettingsCache()',CONFIG)
        self.assertIn('srResetSettingsCache();',FACE)
        for key,val in [('fontClockV31',2),('fontDateV31',2),('fontTopV31',2),
                        ('fontRingV31',2),('fontWeatherV31',2),('fontFaceV36',0),
                        ('fontExtraV36',1),('sizeTopLeftV37',-1),
                        ('sizeRingMidV37',-1),('moonFontV38',-1)]:
            self.assertIn(f'key.equals("{key}")',CONFIG)
        self.assertIn('return fixed;',CONFIG)
        self.assertIn('var value = Props.getValue(key);',CONFIG)

    def test_sensor_cache_without_string_keys(self):
        fun=FIELD.split('function sampleValue(type) {',1)[1].split('function recentHeartRate()',1)[0]
        self.assertIn('var key = type;',fun)
        self.assertNotIn('type.toString()',fun)
        self.assertIn('now - cached[0] < 120',fun)
        self.assertIn('_srHistorySamples[key] = [now, value];',fun)
        self.assertIn('var hr = activity.currentHeartRate;',FIELD)
        self.assertIn('x = recentHeartRate();',FIELD)

    def test_no_compromised_rendering_or_new_pollers(self):
        self.assertIn('dc.drawText(layout[3] - 1',FACE)
        self.assertIn('dc.drawText(layout[5] + 1',FACE)
        self.assertIn('drawCurrentWeatherIcon(dc, w)',FACE)
        self.assertIn('drawMoonPanel(dc, w)',FACE)
        self.assertIn('updatePhotonTarget(w);',FACE)
        self.assertIn('var monitor = Monitor.getInfo();',FACE)
        self.assertIn('var stats = null;',FACE)
        self.assertIn('dc.clear();',FACE)
        self.assertNotIn('onPartialUpdate(',FACE)
        self.assertNotIn('enableLocationEvents(',FACE)
        self.assertNotIn('Weather.getHourlyForecast(',FACE+FIELD)
        self.assertNotIn('Weather.getDailyForecast(',FACE+FIELD)
        self.assertEqual(SERVICE.count(b'Comm.makeWebRequest('),1)

    def test_background_service_exact_baseline_hash(self):
        # This checksum was obtained from the verified 3.26.82 source.
        self.assertEqual(hashlib.sha256(SERVICE).hexdigest(),
                         '2a020b41a6fb93a92630db425c84ae2f707427f8aa789ed4efc5c57232b2ca8e')

    def test_resource_and_icon_references(self):
        for f in (ROOT/'resources').rglob('*.xml'): ET.parse(f)
        self.assertEqual(len(list((ROOT/'source').glob('*.mc'))),8)
        self.assertIn('_weatherBitmapId',FACE)
        self.assertIn('function drawLunarDisk(',FACE)

if __name__=='__main__': unittest.main()
