"""Conservative static and pixel-equivalence regression checks for v3.26.84."""
import math
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text(encoding='utf-8')
ORIGINAL_EXTENTS_7=[math.sqrt(7*7-y*y) for y in range(-7,8)]
ORIGINAL_EXTENTS_12=[math.sqrt(12*12-y*y) for y in range(-12,13)]

class MoonSpanCache84(unittest.TestCase):
    def test_moon_cache_guards_and_fallback(self):
        self.assertIn('var _moonRowCache;',FACE)
        self.assertGreaterEqual(FACE.count('_moonRowCache = null;'),2)
        self.assertIn('rowCache[0] != dayKey',FACE)
        self.assertIn('rowCache[1] != r',FACE)
        self.assertIn('if (!_lowMemory && rowCache != null)',FACE)
        self.assertIn('var extent = r == 12 ? _srMoonExtents12[row + 12]',FACE)
        self.assertIn('var startX = x + (extent * cosPhase).toNumber();',FACE)
        self.assertIn('var endX = x - (extent * cosPhase).toNumber();',FACE)
        self.assertIn('dc.drawCircle(x, y, r);',FACE)

    def test_identical_pixel_spans_all_days(self):
        # The same extents/rounding formula as the original code; spot-check
        # waxing, quarters, full moon, waning and 0..1 boundaries.
        phases=[x/1000.0 for x in range(1001)]
        for r,values in [(7,ORIGINAL_EXTENTS_7),(12,ORIGINAL_EXTENTS_12)]:
            for phase in phases:
                c=math.cos(2*math.pi*phase)
                for extent in values:
                    left=-int(extent)
                    right=int(extent)
                    if phase < 0.5:
                        expected=(int(extent*c),right)
                        stored=(int(extent*c),int(extent))
                    else:
                        expected=(left,-int(extent*c))
                        stored=(-int(extent),-int(extent*c))
                    self.assertEqual(expected,stored)
                    self.assertEqual(expected[0]<=expected[1],stored[0]<=stored[1])

    def test_frame_calendar_uses_one_moment(self):
        self.assertIn('var calendarNow = Time.now();',FACE)
        self.assertIn('var minuteKey = (calendarNow.value() / 60).toNumber();',FACE)
        self.assertIn('Gregorian.info(calendarNow, Time.FORMAT_SHORT);',FACE)
        self.assertIn('srRememberLocalCalendar(_cachedCalendar, minuteKey);',FACE)

    def test_live_fields_and_weather_unchanged(self):
        for token in ('Monitor.getInfo()', 'getCachedConditions()',
                      'updatePhotonTarget(w)', 'drawCurrentWeatherIcon(dc, w)',
                      'drawBattery(dc, monitor, w)', 'drawMoonPanel(dc, w)',
                      'refreshChangedSettings()'):
            self.assertIn(token,FACE)

if __name__ == '__main__': unittest.main()
