from pathlib import Path
import re, struct, unittest, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text()
D=P/'resources/drawables/drawables.xml'
class WeatherBitmap77(unittest.TestCase):
    def test_resources(self):
        root=ET.parse(D).getroot()
        entries=[e for e in root.findall('bitmap') if e.attrib['id'].startswith('Weather')]
        self.assertEqual(len(entries),18)
        self.assertEqual({e.attrib['id'] for e in entries},set(re.findall(r'Rez.Drawables.(Weather\w+)',S)))
        for e in entries:
            data=(D.parent/e.attrib['filename']).read_bytes()
            self.assertEqual(data[:8],b'\x89PNG\r\n\x1a\n')
            self.assertEqual(struct.unpack('>II',data[16:24]),(68,33))
            self.assertEqual(e.attrib['scope'],'foreground')
            self.assertEqual(e.attrib['dithering'],'none')
            self.assertEqual(e.find('palette').attrib['disableTransparency'],'false')
            for c in e.findall('palette/color'):
                self.assertTrue(all(int(c.text[i:i+2],16) in (0,85,170,255) for i in (0,2,4)))
    def test_cached_load_and_fallback(self):
        block=S.split('function tryWeatherBitmap(',1)[1].split('// v3.26.76:',1)[0]
        self.assertIn('if (_lowMemory) { return false; }',block)
        self.assertIn('if (_weatherBitmapId != id)',block)
        self.assertEqual(block.count('App.loadResource('),1)
        self.assertIn('dc.drawBitmap(46, 216, _weatherBitmap)',block)
        self.assertIn('if (tryWeatherBitmap(dc, group, code)) { return; }',S)
        self.assertIn('_lowMemory = true;\n                    _weatherBitmap = null;',S)
        self.assertNotIn('Weather.getHourlyForecast(',S)
