"""Regressions for the isolated v3.26.82 drawClock text-cache change.

These structural tests do not replace SDK compilation and on-watch testing.
"""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / "source" / "SolarRings7X.mc").read_text(encoding="utf-8")

class ClockCache82Tests(unittest.TestCase):
    def test_cache_reset_is_preserved(self):
        self.assertIn("_clockTextCache = null;", SRC)

    def test_cache_uses_minute_of_day(self):
        self.assertIn("var minuteOfDay = clock.hour * 60 + clock.min;", SRC)
        self.assertIn("cachedText[0] == minuteOfDay", SRC)

    def test_cache_contains_rendered_hour_and_minute(self):
        self.assertIn('hourText = twoDigits(clock.hour);', SRC)
        self.assertIn('minuteText = twoDigits(clock.min);', SRC)
        self.assertIn('value = hourText + ":" + minuteText;', SRC)
        self.assertIn('_clockTextCache = [minuteOfDay, value, hourText, minuteText];', SRC)
        self.assertIn('hourText = cachedText[2];', SRC)
        self.assertIn('minuteText = cachedText[3];', SRC)

    def test_no_per_frame_substrings_in_clock(self):
        section = SRC.split('function drawClock(dc, clock) {', 1)[1].split('    // Mini digits for compact times', 1)[0]
        self.assertNotIn('value.substring(', section)

    def test_draw_and_fallback_unchanged(self):
        section = SRC.split('function drawClock(dc, clock) {', 1)[1].split('    // Mini digits for compact times', 1)[0]
        self.assertIn('fitScaled(dc, value, 99, top, 146, slotH,', section)
        self.assertIn('dc.drawText(layout[3] - 1, layout[6], font, hourText', section)
        self.assertIn('dc.drawText(layout[5] + 1, layout[6], font, minuteText', section)

    def test_minute_rollover_semantics(self):
        # Mirrors the old and new HH:MM construction for all legal times.
        for hour in range(24):
            for minute in range(60):
                old = f"{hour:02d}:{minute:02d}"
                hour_text = f"{hour:02d}"
                minute_text = f"{minute:02d}"
                self.assertEqual(old, hour_text + ":" + minute_text)
                self.assertEqual((old[:2], old[3:5]), (hour_text, minute_text))
                self.assertEqual(hour * 60 + minute, (hour * 60 + minute) % 1440)

if __name__ == '__main__': unittest.main()
