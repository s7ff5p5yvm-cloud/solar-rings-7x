from pathlib import Path
import unittest
R=Path(__file__).parents[1]
S=(R/'source/SolarRings7X.mc').read_text()
B=(R/'source/SolarRingsGarminService.mc').read_text()
M=(R/'manifest.xml').read_text()

class TestGpsPhoton80(unittest.TestCase):
    def test_primary_watch_position_and_activity_fallback(self):
        section=S.split('function photonWatchOrWeatherCoordinates(weather)',1)[1].split('function updatePhotonTarget',1)[0]
        self.assertTrue(section.index('Position.getInfo()') < section.index('Activity.getActivityInfo()') < section.index('weather.observationLocationPosition'))
        self.assertIn('photonValidCoordinates(fix.position)',section)
        self.assertIn('photonValidCoordinates(activity.currentLocation)',section)
        self.assertIn('fix.when.value()',section)
        self.assertIn('age <= 7200',section)
    def test_no_new_gps_fixes_no_background_polling(self):
        self.assertNotIn('enableLocationEvents',S)
        self.assertNotIn('Weather.getHourlyForecast(',S+B)
        self.assertNotIn('Bg.registerForTemporalEvent(',S)
        self.assertIn('now - _photonTargetCheckAt < 55',S)
        self.assertIn('srPhotonScheduleIfNeeded()',S)
    def test_same_source_for_photon_and_display(self):
        self.assertIn('var ll = photonWatchOrWeatherCoordinates(weather);',S)
        panel=S.split('function drawMoonPanel(dc, weather)',1)[1].split('function topSlot(',1)[0]
        self.assertIn('var ll = _photonTargetCache;',panel)
        self.assertIn('weatherMatches = srPhotonSameRegion(weatherLl, ll);',panel)
    def test_manifest_identity_and_permissions(self):
        self.assertIn('version="3.26.85"',M)
        self.assertIn('id="Positioning"',M)
        self.assertIn('id="Communications"',M)

if __name__=='__main__':unittest.main()
