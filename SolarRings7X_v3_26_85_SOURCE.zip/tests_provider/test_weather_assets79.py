from pathlib import Path
import unittest, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent.parent
class WeatherAssets79(unittest.TestCase):
    def test_compact_palettes(self):
        entries=[e for e in ET.parse(P/'resources/drawables/drawables.xml').getroot().findall('bitmap') if e.attrib['id'].startswith('Weather')]
        self.assertEqual(len(entries),18)
        for e in entries:
            self.assertTrue(1 <= len(e.findall('palette/color')) <= 4)
    def test_ids_and_transparency(self):
        for e in ET.parse(P/'resources/drawables/drawables.xml').getroot().findall('bitmap'):
            if e.attrib['id'].startswith('Weather'):
                self.assertEqual(e.find('palette').get('disableTransparency'),'false')
                self.assertEqual(e.get('scope'),'foreground')
