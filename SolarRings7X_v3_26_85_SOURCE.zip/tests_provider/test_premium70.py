import re, unittest, xml.etree.ElementTree as ET
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text()
class Premium70(unittest.TestCase):
 def test_battery_gap_even_at_max_text_width(self):
  assert 'chargingBatteryIcon(dc, 124, 261' in S
  assert 'drawIcon(dc, 124, 261, id, footerColor)' in S
  assert 'drawSized(dc, d[1], 167, 251, 60, 20' in S
  # Battery outer rightmost x+11=135; text minimum left x-60/2=137.
  self.assertGreaterEqual(167-60/2-(124+11),2)
  self.assertLessEqual(167+60/2,210) # in physical circular screen at y=261
 def test_temperature_logic_and_premium_glyph(self):
  assert 'function premiumWarningThermometer(dc, x, y, color)' in S
  assert 'function temperatureMarker(dc, w, x, y, diagnosticTemp)' in S
  assert 'if (isTemp) { temperatureMarker(dc, weather, 142, 224, diagnosticTemp); }' in S
  assert 'if (!isTest && !srSetting("tempAlertsV312", true)) { return; }' in S
  assert 'temp > srSetting("tempHotV312", 30)' in S
  assert 'temp < srSetting("tempColdV312", 0)' in S
  assert 'premiumWarningThermometer(dc, x, y, color)' in S
  assert 'testCold ? 0x32C8FF : 0xFF5F55' in S
  # thermometer only needs local current-condition data; never a forecast.
  assert 'Weather.getHourlyForecast(' not in S
  assert 'registerForTemporalEvent(' not in S
 def test_settings_compatibility(self):
  props=ET.parse(P/'resources/settings/properties.xml').getroot()
  s=ET.parse(P/'resources/settings/settings.xml').getroot()
  ids={p.attrib['id'] for p in props}
  visible={x.attrib['propertyKey'].split('.')[-1] for x in s}
  for k in ('tempAlertsV312','tempHotV312','tempColdV312'):
   self.assertIn(k,ids)
   self.assertIn(k,visible)
  known={x.attrib['id'] for x in ET.parse(P/'resources/strings.xml').getroot()}
  for node in s.iter():
   if node.text and node.text.startswith('@Strings.'):
    self.assertIn(node.text.split('.',1)[1],known)
 def test_no_general_weather_warnings_restored(self):
  assert not (P/'source/GarminWeatherWarnings.mc').exists()
  assert 'function drawAlertCenter(' not in S
  assert 'function drawCurrentWeatherIcon(' in S
  assert 'Weather.getCurrentConditions()' in S
  assert 'Weather.getHourlyForecast(' not in S
 def test_scope_and_version(self):
  assert 'version="3.26.85"' in (P/'manifest.xml').read_text()
  assert 'var hr = activity.currentHeartRate;' in (P/'source/FieldData.mc').read_text()
if __name__=='__main__': unittest.main()
