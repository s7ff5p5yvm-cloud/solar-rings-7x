# Solar Rings v3.26.78 — Refined Weather MIP
- 18 od nowa zaprojektowanych autorskich ikon, w tej samej ramce 68 × 33 px. Naturalne błękitne chmury z zaokrągloną sylwetką, złote słońce, osobne symbole opadów, gradu, lodu, mgły, wiatru i burzy.
- Palety bitmap zawierają wyłącznie rzeczywiście użyte kolory RGB222. Przezroczyste tło, bez ditheringu na zegarku.
- Wszystkie moduły Monkey C są identyczne bajtowo z v3.26.77. Bez zmian ustawień, tętna, Photona, faz Księżyca i odświeżania. Nadal jedna ładowana bitmapa i awaryjny rysownik wektorowy.
- Podgląd PNG jest wygenerowany z tych samych zasobów, nie z symulatora Garmina. Kompilacja i zużycie energii wymagają weryfikacji na urządzeniu.
