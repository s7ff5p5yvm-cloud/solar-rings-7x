# Solar Rings v3.26.77 — Smooth Weather MIP
- 18 autorskich ikon pogody w rozdzielczości 68 × 33 px, z paletą RGB222 i przezroczystym tłem. Kontury wygładzone offline, bez skalowania na zegarku.
- Zasoby tylko dla procesu foreground. W pamięci trzymana jest jedna aktualna ikona. Przy braku pamięci lub błędzie ładowania pozostaje rysownik wektorowy v76.
- Zachowano wszystkie grupy warunków, intensywność opadów, termometry, fazy Księżyca, tętno i Photona. Nie dodano zapytań ani timerów.
- Wpływ na pamięć, baterię i wygląd wymaga potwierdzenia na zegarku. Brak lokalnej kompilacji Monkey C.
