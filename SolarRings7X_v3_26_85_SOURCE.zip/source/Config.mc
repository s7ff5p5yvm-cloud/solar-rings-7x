using Toybox.Application.Properties as Props;
using Toybox.Graphics as Gfx;

// Cache ONLY persisted settings; dynamic device data is never cached here.
// All entries are invalidated on AppBase.onSettingsChanged().
// A 96-entry cap bounds the settings cache and protects drawing memory.
var _srSettingCache = {};
var _srSettingCacheSize = 0;

function srResetSettingsCache() {
    _srSettingCache = {};
    _srSettingCacheSize = 0;
}

// Mobile app settings. All default keys are defined in resources/settings/properties.xml.
// Deliberately use NEW keys so stale v2.x settings cannot unexpectedly override
// the new three-ring layout. All 8 visible slots are selectable from the phone.
function srSetting(key, fallback) {
    if (!(key instanceof Toybox.Lang.String)) { return fallback; }
    // Cache immutable, disabled font controls TOO. Previously every field
    // lookup repeated up to 20 string comparisons on every redraw. The cache
    // was already bounded to 96 entries and reset after settings changes.
    var cached = _srSettingCache[key];
    if (cached != null) { return cached; }
    var fixed = null;
    if (key.equals("fontClockV31") || key.equals("fontDateV31") ||
        key.equals("fontTopV31") || key.equals("fontRingV31") ||
        key.equals("fontWeatherV31")) { fixed = 2; }
    else if (key.equals("fontFaceV36")) { fixed = 0; }
    else if (key.equals("fontExtraV36")) { fixed = 1; }
    else if (key.equals("sizeTopLeftV37") || key.equals("sizeTopMidV37") ||
        key.equals("sizeTopRightV37") || key.equals("sizeRingLeftV37") ||
        key.equals("sizeRingMidV37") || key.equals("sizeRingRightV37") ||
        key.equals("sizeWeatherValueV37") || key.equals("sizeWeatherLabelV37") ||
        key.equals("sizeFooterV37") || key.equals("moonFontV38")) { fixed = -1; }
    if (fixed != null) {
        if (_srSettingCacheSize < 96) {
            _srSettingCache[key] = fixed;
            _srSettingCacheSize += 1;
        }
        return fixed;
    }
    try {
        var value = Props.getValue(key);
        if (value != null) {
            // Older diagnostic keys may have persisted malformed values;
            // reject them before numeric comparisons.
            if (key.equals("gwPreviewV332") &&
                !(value instanceof Toybox.Lang.Number)) { return fallback; }
            if (_srSettingCacheSize < 96) {
                _srSettingCache[key] = value;
                _srSettingCacheSize += 1;
            }
            return value;
        }
    } catch (e) { }
    return fallback;
}

function srColor(value) {
    if (value == 0) { return Gfx.COLOR_RED; }
    if (value == 1) { return Gfx.COLOR_GREEN; }
    if (value == 2) { return Gfx.COLOR_BLUE; }
    if (value == 3) { return Gfx.COLOR_ORANGE; }
    if (value == 4) { return Gfx.COLOR_YELLOW; }
    if (value == 5) { return Gfx.COLOR_WHITE; }
    return 0x00FFFF;
}
