using Toybox.WatchUi as Ui;
using Toybox.Complications as Complications;

// v3.26.85 - experimental direct launch of Compass Pro 7X.
// This delegate does no work in the display update path: it is invoked only
// after a touch-and-hold. No timer, background service or subscription.
class SolarRingsCompassShortcut extends Ui.WatchFaceDelegate {
    function initialize() {
        WatchFaceDelegate.initialize();
    }

    function onPress(event as Ui.ClickEvent) as Boolean {
        // Both switches are optional and default to keeping old behavior.
        if (!srSetting("moonPanelV38", true) ||
            !srSetting("moonCompassShortcutV32685", true)) {
            return false;
        }

        // The actual moon disk in Solar Rings is centered at (52,149).
        // Invisible 94 x 44 px hit area includes the lunar countdown but
        // excludes the location field (begins at x=125).
        var xy = null;
        try { xy = event.getCoordinates(); } catch (e) { return false; }
        if (xy == null || xy.size() < 2) { return false; }
        var x = xy[0];
        var y = xy[1];
        if (x == null || y == null || x < 22 || x > 116 ||
            y < 127 || y > 171) {
            return false;
        }

        // The Id for a third-party complication is assigned by the system;
        // it cannot be deduced from the app UUID or resource index.
        // Select only the deliberately unique publisher labels.
        try {
            var items = Complications.getComplications();
            if (items == null) { return false; }
            var entry = items.next();
            while (entry != null) {
                if (entry.complicationId != null &&
                    entry.longLabel != null &&
                    entry.shortLabel != null &&
                    entry.longLabel.equals("Compass Pro 7X Link") &&
                    entry.shortLabel.equals("CP7X")) {
                    try {
                        Complications.exitTo(entry.complicationId);
                        return true;
                    } catch (launchError) {
                        // App missing/unavailable: let Garmin handle the hold.
                        return false;
                    }
                }
                entry = items.next();
            }
        } catch (e) {
            // No installed publisher or unsupported complication runtime.
            // Never interrupt the clock or its normal touch behavior.
        }
        return false;
    }
}
