# Solar Rings v3.26.79 — Clean Weather MIP

- 18 autorskich bitmap pogodowych: naturalne obłe sylwetki, bez gradientowych pasów, jasnych obwódek i fioletowych refleksów.
- Rozmiar 68 × 33 px, maksymalnie 4 nieprzezroczyste kolory z palety MIP64 na ikonę. Binarny kanał alfa; każdy kolor zapisany w XML.
- Lekki/zwykły/intensywny opad pozostaje rozróżniony. Mgła, wiatr, burza, grad, oblodzenie i marznący deszcz zachowują własne symbole.
- Wszystkie moduły Monkey C, identyfikator aplikacji, ustawienia i pozostałe zasoby (w tym Body Battery, Księżyc, termometry) identyczne jak w v3.26.78. Bez nowych wybudzeń, timerów, pobrań ani dodatkowego buforowania tętna. Zużycie energii wymaga pomiaru na zegarku.
- Podgląd 1:1 zawiera rzeczywiste zasoby, 3:1 to powiększenie bez interpolacji. To nie render fizycznego MIP.
- Kompilacja Monkey C wymagana przed instalacją.
