# Solar Rings v3.26.83 — zbiorcza optymalizacja zachowawcza

Baza: v3.26.82 (eksperymentalny bufor tekstu godziny), wywodząca się bezpośrednio ze stabilnej v3.26.81. Nie zmieniono identyfikatora aplikacji, interfejsu, konfiguracji mobilnej, zasobów graficznych, ani kodu żądań do Photon.

## Wprowadzono
1. **Wspólny bufor lokalnego kalendarza na minutę** — dane `Gregorian.info()` już pobierane przez `onUpdate()` są ponownie wykorzystywane przez pola wschodu/zachodu słońca, księżyca i opcjonalną datę. Każda nowa minuta i zmiana dnia powodują odświeżenie bufora.
2. **Księżyc** — cache wyniku dziennego sprawdzany jest najpierw po lokalnej dacie (rok/miesiąc/dzień). Na trafieniu omija się zbędną konstrukcję obiektu `Gregorian.moment()`; algorytm fazy i pełni nie został zmieniony.
3. **Ustawienia** — niezmienne, celowo wyłączone ustawienia typografii zostały dodane do istniejącego bufora odczytu wartości. Zamiast każdorazowego łańcucha porównań tekstu wykonywana jest pojedyncza próba odczytu z już istniejącego słownika. Reset po zmianie ustawień zachowany.
4. **Historia czujników** — klucz słownika jest liczbą identyfikującą rodzaj historii, zamiast nowo tworzonego łańcucha. TTL 120 s i odczyt **bieżącego**, nie historycznego tętna są niezmienione.
5. **Następny wschód/zachód** — porównania momentów wykorzystują już odczytany `nowSeconds`, zamiast ponownych odczytów `now.value()`.
6. **Kompilacja** — workflow testuje kod w Connect IQ SDK 9.3.0 i korzysta z oficjalnego poziomu optymalizacji kompilatora `-O 2` (poziom optymalizacji jeszcze do zweryfikowania w kompilacji GitHub Actions).

## Z czego celowo zrezygnowano
- Brak ograniczania aktualizacji tętna, kroków, Bluetooth, pogody i baterii.
- Brak nowego timera i ograniczania odświeżeń ekranu.
- Brak rezygnacji z pogrubienia cyfr przez wielokrotne `drawText` — zachowujemy wygląd.
- Brak zmian progów temperaturowych, ikon i położenia danych.
- Nie zwiększono przerw pomiędzy odczytami pogody ani Photona.

## Walidacja
- 80 testów lokalnych Python `unittest` przechodzi.
- Źródłowy kod `SolarRingsGarminService.mc`, mapowanie pogody, zasoby obrazów, pliki ustawień oraz `monkey.jungle` są bajtowo identyczne z v3.26.82.
- Analiza XML, numeru wersji i identyfikatora aplikacji przechodzi.
- Przed instalacją wymagane jest jeszcze potwierdzenie kompilacji Garmin SDK na GitHub Actions; testy strukturalne nie dowodzą poprawności runtime ani oszczędności baterii.

## Weryfikacja na Garminie
Po instalacji sprawdzić: godzinę/datę, pulsometr na żywo, aktualność pogody, lokalizację Photon, fazę księżyca, wschód/zachód, Bluetooth, ikony temperatury, pierścienie postępu, zmianę ustawień i brak resetów. Osobno sprawdzić przejście przez północ. Dopiero po pozytywnej weryfikacji rozpocząć pomiar baterii przez 48–72 h w porównywalnych warunkach. Przy problemie powrócić do zachowanego pliku 3.26.81.

## Uwaga
Optymalizacje zmniejszają liczbę powtarzanych operacji, ale nie dowodzą konkretnego zysku energetycznego. Bez profilowania na zegarku nie da się zagwarantować, że jest to absolutne minimum poboru energii.
