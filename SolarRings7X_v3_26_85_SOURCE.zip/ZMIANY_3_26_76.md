# Solar Rings v3.26.76 — Blue Weather MIP

Autorskie ikony inspirowane niebieską stylistyką Ventusky; bez wykorzystania jego plików graficznych. 18 wariantów znanych warunków, dodatkowy symbol braku danych. Wszystkie 54 kody Garmin nadal mapowane. Oddzielne warianty intensywności opadów wynikają wyłącznie z kodu bieżących warunków. Kolory pogody należą do palety 64 RGB (0/85/170/255). Zachowano środek i obszar panelu. Skorygowano obręcz faz Księżyca i usunięto niekontrolowane akcenty, które mogły pojawiać się na ciemnej części tarczy.

Nie zmieniono pozostałych modułów, ustawień, zasobów, odczytu tętna, Photona i buforowania Weather. Nie dodano wybudzeń, bitmap ani zapytań. Zmieniono koszt rysowania ikon; rzeczywisty wpływ na baterię pozostaje do zmierzenia.

Podgląd PNG jest renderem pomocniczym z tej samej geometrii, nie z symulatora Garmin. Weryfikacja lokalna: testy statyczne, XML, walidacja archiwów. Kompilacja SDK i test na urządzeniu wymagane.
