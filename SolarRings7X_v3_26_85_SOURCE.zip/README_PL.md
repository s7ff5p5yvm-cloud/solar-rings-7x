# Solar Rings v3.26.81 — Premium MIP + GPS Photon + optymalizacja historii

Na podstawie v3.26.80 zachowano wygląd i mechanizm lokalizacji GPS zegarka. Zmiana v3.26.81 ogranicza zbędne odczyty `SensorHistory`: TTL 30 → 120 s, przy niezmienionym bieżącym tętnie, krokach i baterii.

Do kompilacji w GitHub Actions wykorzystaj `SolarRings7X_v3_26_81_SOURCE.zip` i plik workflow `SolarRings7X_v3_26_81_BUILD.yml`. Repozytorium potrzebuje sekretu `CONNECTIQ_DEVELOPER_KEY_BASE64`.

Pełny opis: `ZMIANY_3_26_81.md`. Plik `BATTERY_TEST_PL.md` opisuje porównanie.
