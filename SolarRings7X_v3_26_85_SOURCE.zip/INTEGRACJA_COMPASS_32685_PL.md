# Solar Rings 3.26.85 - eksperymentalny skrót do Compass Pro

ZMIANY względem 3.26.84:
* Odpowiedź na przytrzymanie obszaru księżyca (52, 149; hitbox x22..116, y127..171).
* Jednorazowe wyszukanie systemowej komplikacji `Compass Pro 7X Link` (`CP7X`) i otwarcie przez `Complications.exitTo()`.
* Przełącznik `moonCompassShortcutV32685`, domyślnie włączony.
* Nie zmienia pogody, tętna, grafiki, rozmiarów czcionek ani algorytmu Solar Rings.
* Bez skanowania komplikacji w `onUpdate()` i bez dodatkowych timerów.
* Gdy aplikacja nie jest zainstalowana, przytrzymanie pozostaje nieobsłużone i zegarek może wykonać własną akcję.

WAŻNE: Aplikacja Compass Pro 7X v1.3.5 MUSI być zainstalowana z własną komplikacją opublikowaną w resources/complications.xml. Kompilację i funkcję trzeba potwierdzić na Fenix 7X Pro. Nie modyfikuj stabilnej wersji źródłowej v3.26.84.

Kolejność testu: (1) zainstaluj Compass Pro 1.3.5, (2) otwórz go raz i wróć BACK, (3) zainstaluj eksperymentalną Solar Rings 3.26.85, (4) włącz dotyk w zegarku i przytrzymaj obszar księżyca ~1–2 s, (5) sprawdź, czy kompas otwiera się bez listy. (6) przetestuj opcję WYŁ. w ustawieniach tarczy. Na końcu porównaj zużycie baterii.
