# Solar Rings v3.26.81 — cache SensorHistory 120 s

Baza: **v3.26.80** (Photon: pozycja GPS zegarka → ostatni GPS aktywności → Garmin Weather; poprzednie optymalizacje).

Jedyna zmiana wykonawcza: `source/FieldData.mc`, `sampleValue(type)` — TTL pamięci podręcznej historii pomiarów z **30 sekund do 120 sekund**. Zmiana dotyczy tylko danych pochodzących z `Toybox.SensorHistory`: Body Battery, stres, SpO2, ciśnienie i wysokość. Odczyty tych parametrów mogą wskazywać poprzednią wartość przez maksymalnie około 2 minuty. Powtarzający się odczyt w tym czasie nie otwiera nowego iteratora historii.

**Bez zmian:** tętno na żywo `Activity.getActivityInfo().currentHeartRate`, kroki, godzina, wygląd i wymiary wszystkich ikon Premium MIP, potrójny obrys cyfr, księżyc, lokalizacja Photona i harmonogram jego zapytań, wszystkie pozostałe ustawienia i optymalizacje.

Brak modyfikacji `onUpdate()` / `onEnterSleep()` / `onExitSleep()` — pomijanie rysowania na podstawie trybu bez osobnego profilu urządzenia może powodować puste klatki, a zaawansowane buforowanie 280x280 grozi zużyciem pamięci na Fenixie 7X Pro. Zachowujemy pełne rysowanie dla prawidłowej aktualizacji bieżącego tętna, kroków i baterii.

To wersja do przetestowania dopiero po zakończeniu aktualnego testu v3.26.79. Nie zakładamy konkretnej oszczędności baterii: wynik trzeba potwierdzić w pomiarze 24–48 h. Wymagana kompilacja Monkey C w GitHub Actions; testy statyczne nie zastępują kompilacji i testu na zegarku.
