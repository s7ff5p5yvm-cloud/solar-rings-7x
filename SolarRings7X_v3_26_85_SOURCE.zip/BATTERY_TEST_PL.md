# Test baterii — v3.26.81

Po zakończeniu obecnego testu v3.26.79 naładuj zegarek do około 100%. Wgraj v3.26.81 (zastępuje przygotowaną wcześniej v3.26.80), zanotuj godzinę i stan baterii oraz odczyty po 24 i 48 godzinach. Korzystaj z tych samych ustawień, podobnej liczby aktywacji ekranu i warunków Bluetooth/GPS.

Cel: porównać rzeczywiste zużycie; żadna procentowa poprawa nie jest gwarantowana. Weryfikuj też czy Body Battery i stres aktualizują się w akceptowalnym czasie oraz czy tętno pozostaje bieżące.
