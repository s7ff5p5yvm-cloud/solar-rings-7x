# Solar Rings v3.26.84 — pakiet testowy

Baza: v3.26.83 (zachowuje modyfikacje 3.26.82 względem stabilnej 3.26.81).

- Rysowanie oświetlenia księżyca: zachowano **identyczne wzory, zaokrąglenia i rysowanie linii**; całodzienne, stałe współrzędne 25 wierszy są liczone raz i buforowane zamiast ponawiać wielokrotnie mnożenia i konwersje Double. Bufor przechowuje 50 małych wartości liczbowych i jest automatycznie czyszczony przy trybie małej pamięci, wtedy używany jest **oryginalny** sposób rysowania.
- Odczyt kalendarza w `onUpdate`: `Time.now()` pobierane raz dla klucza minuty i `Gregorian.info`, eliminując drugi odczyt i graniczne niespójności przy zmianie minuty.
- Bez zmian: czas odświeżania, puls, kroki, bateria, pogodę GW, Photon, BT, ikony, UI, alerty (wyłączone jak w 3.26.81), wszystkie ustawienia i fizyczny wygląd rysowania.
- Workflow kompilacji: poprawione sprawdzenie numeru w manifeście (wadliwy warunek `3.26.82` pozostawiony przypadkiem w workflow 3.26.83). Wzmocnione testy i poprawność sum kontrolnych.
- Nowa wersja **nie jest jeszcze potwierdzona** kompilacją Garmin SDK ani testem na fizycznym urządzeniu; test Python nie jest profilerem baterii.

Nie dodano bufora bitmapowego ani dodatkowych timerów — rozwiązania te mogłyby zwiększyć zużycie RAM lub ryzyko regresji. W tym zakresie dalszy zysk wymaga rzeczywistego profilowania.
