"""15-minute OWM forecast contracts and independent algorithm model.

These checks inspect Monkey C source and simulate representative One Call 4.0
JSON data. They DO NOT run Garmin Monkey C or verify background RAM on watch.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1]
NW = (ROOT/'source/SolarOpenNetwork.mc').read_text()
OD = (ROOT/'source/SolarOpenData.mc').read_text()
OW = (ROOT/'source/SolarOpenWarnings.mc').read_text()
UI = (ROOT/'source/SolarRings7X.mc').read_text()

# Independent Python reference to the Monkey C compact timeline policy.
def compact(rows, now, short=True):
    selected=[]
    last=0
    max_age=3*3600 if short else 5*3600
    for h in rows[:50]:
        if not isinstance(h, dict) or type(h.get('dt')) not in (int,float):
            continue
        t=int(h['dt'])
        if t<=now or t>now+max_age or t<=last:
            continue
        weather=h.get('weather')
        first=(weather[0].get('id') if isinstance(weather,list) and weather
               and isinstance(weather[0],dict) else None)
        p=h.get('pop')
        pct=None if p is None else (p*100 if type(p) in (int,float) and 0<=p<=1 else -1)
        selected.append([t,first,h.get('wind_speed'),h.get('temp'),h.get('uvi'),pct,
                         (h.get('rain') or {}).get('1h') if isinstance(h.get('rain'),dict) else None,
                         (h.get('snow') or {}).get('1h') if isinstance(h.get('snow'),dict) else None,
                         h.get('visibility'),h.get('wind_gust')])
        last=t
        if len(selected)>=(12 if short else 5):break
    if short and selected and all(x[1] is None for x in selected):return []
    return selected

class ShortTimelineV3264(unittest.TestCase):
    def test_official_endpoint_and_one_request_per_wakeup(self):
        self.assertIn('https://api.openweathermap.org/data/4.0/onecall/timeline/15min',NW)
        self.assertIn('https://api.openweathermap.org/data/4.0/onecall/timeline/1h',NW)
        self.assertEqual(NW.count('Comm.makeWebRequest('),2)
        self.assertIn('q["cnt"] = "12"',NW) # OWM 4.0 supports server-side response limit
        self.assertNotIn('"next"',NW) # no pagination of 48h for 3h horizon
        self.assertIn('var count = records.size()',NW)
        self.assertIn('if (count > 50) { count = 50; }',NW)
        self.assertIn('var maxRows = _shortRequest ? 12 : 5;',NW)

    def test_fifty_results_reduce_to_twelve_future_rows(self):
        now=1800000000
        response={'lat':50.0,'lon':20.0,'data':[
            {'dt':now+900*i,'temp':2,'pop':.4,'wind_speed':4,
             'rain':{'1h':5},'weather':[{'id':500}]} for i in range(1,51)]}
        short=compact(response['data'],now,True)
        self.assertEqual(len(short),12)
        self.assertEqual(short[0][0],now+900)
        self.assertEqual(short[-1][0],now+10800)
        self.assertEqual(short[1][1],500)
        self.assertEqual(short[1][5],40)
        self.assertEqual(short[1][6],5)
        self.assertEqual(short[0][2],4)

    def test_cannot_mislabel_chance_and_no_spurious_forecasts(self):
        now=1800000000
        records=[{'dt':now-900,'pop':1,'weather':[{'id':500}]},
                 {'dt':now+900,'pop':0,'weather':[{'id':500}]},
                 {'dt':now+1800,'pop':None,'weather':[{'id':600}]},
                 {'dt':now+2700,'pop':3,'weather':[{'id':500}]},
                 {'dt':now+3600,'pop':'bad','weather':[{'id':500}]},
                 {'dt':now+4500,'pop':0.4,'weather':[{'id':200}]},
                 {'dt':now+4*3600,'pop':.8,'weather':[{'id':500}]}]
        rows=compact(records,now)
        self.assertEqual([x[1] for x in rows],[500,600,500,500,200])
        self.assertEqual([x[5] for x in rows],[0,None,-1,-1,40])
        self.assertIn('forecastChanceMatches(pop,',OW)
        self.assertIn('var futureKinds = kindsFor(',OW)
        self.assertIn('h[0] > now + horizon * 3600',OW)

    def test_missing_weather_codes_not_accepted_as_valid_short_reply(self):
        now=1800000000
        rows=[{'dt':now+900*i,'pop':.9,'weather':[]} for i in range(1,13)]
        self.assertEqual(compact(rows,now),[])
        self.assertIn('var recognized = false;',NW)
        self.assertIn('valid = recognized;',NW)

    def test_bad_timestamps_out_of_order(self):
        now=1800000000
        rows=[{'dt':now+1800,'weather':[{'id':500}]},
              {'dt':now+900,'weather':[{'id':500}]},
              {'dt':now+1800,'weather':[{'id':500}]},
              {'dt':now+2700,'weather':[{'id':500}]}]
        out=compact(rows,now)
        self.assertEqual([x[0] for x in out],[now+1800,now+2700])
        self.assertIn('t <= previous',NW)

    def test_error_circuit_breaker_and_hourly_fallback(self):
        self.assertIn('code != 401 && code != 403 && code != 429',NW)
        self.assertIn('code == -403',NW)
        self.assertIn('write("srOShortPausedV3264", _now + 24 * 3600)',NW)
        self.assertIn('write("srONextFV326", _now + 10 * 60)',NW)
        self.assertIn('function shortReady()',NW)
        self.assertIn('if (f == null) { f = srOwmRead("srOHoursV326"); }',OD)
        # Missing background callback due to killed process cannot retry forever.
        self.assertIn('"srOShortAttemptV3264"',NW)
        self.assertIn('orphaned <= _now - 5 * 60',NW)
        self.assertIn('write("srOShortAttemptV3264", 0)',NW)

    def test_settings_and_location_rearm_and_clear_properly(self):
        props={p.get('id'):(p.text or '').strip() for p in
               ET.parse(ROOT/'resources/settings/properties.xml').getroot()}
        self.assertEqual(props['srOwm15MinV3264'],'true')
        settings=(ROOT/'resources/settings/settings.xml').read_text()
        strings=(ROOT/'resources/strings.xml').read_text()
        self.assertIn('@Properties.srOwm15MinV3264',settings)
        self.assertIn('sr_open_short_forecast',strings)
        self.assertIn('var shortChanged = mode == 1',OD)
        self.assertIn('modeChanged || keyChanged || refreshChanged || shortChanged',OD)
        self.assertGreaterEqual(OD.count('srOwmWrite("srOShortV3264", null)'),2)
        self.assertGreaterEqual(OD.count('srOwmWrite("srOShortAttemptV3264", 0)'),2)
        self.assertIn('srOwmSamePlace(f, loc)',OD)

    def test_diagnostic_reports_which_timeline_is_running(self):
        for text in ['TEST 15: OWM 15M','TEST 15: OWM FALLBACK',
                     'TEST 15: OWM 1H','TEST 15: OWM 15M?']:
            self.assertIn(text,UI)
        self.assertIn('srOwmForecastSnapshot()',UI)
        self.assertIn('diagnosticsSource',UI)

    def test_unchanged_garmin_and_aqi_data(self):
        self.assertIn('if (setting("srProviderV326", 0) != 1)',NW)
        self.assertIn('"https://api.openweathermap.org/data/2.5/air_pollution"',NW)
        self.assertIn('class SolarOpenWarnings extends GarminWeatherWarnings',OW)
        self.assertNotIn('Comm.makeWebRequest(',OW)
        self.assertIn('srOwm15MinV3264',NW)

if __name__=='__main__':unittest.main()
