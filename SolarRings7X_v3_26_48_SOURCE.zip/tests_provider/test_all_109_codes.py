"""Exhaustive source-derived classification tests. These don't execute Monkey C.
Code paths are parsed from the actual compiled source (not just a duplicate lookup).
"""
from pathlib import Path
import csv, re, unittest
from code_reference import GARMIN, OWM

ROOT=Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'source/SolarWeatherCodes.mc').read_text()
OWARN=(ROOT/'source/SolarOpenWarnings.mc').read_text()
GWARN=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()
UI=(ROOT/'source/SolarRings7X.mc').read_text()
TEXT=(ROOT/'source/FieldData.mc').read_text()


def extract_group_function(func):
    start=SOURCE.index('function '+func+'(')
    end=SOURCE.find('\nfunction ', start+10)
    if end<0:end=len(SOURCE)
    return SOURCE[start:end]


def parse_garmin():
    code=extract_group_function('srGarminDisplayGroup')
    got={}
    for predicate,group in re.findall(r'if \((.*?)\) \{ return (-?\d+); \}',code,re.S):
        names=re.findall(r'code == Weather\.CONDITION_([A-Z_]+)',predicate)
        if not names:  # null guard, not a named weather condition
            continue
        for n in names:
            assert n not in got, f'duplicate Garmin enum {n}'
            got[n]=int(group)
    return got


def parse_openweather():
    code=extract_group_function('srOwmMappedCondition')
    got={}
    for predicate, enum in re.findall(r'if \((.*?)\) \{ return Weather\.CONDITION_([A-Z_]+); \}',code,re.S):
        ids=re.findall(r'code == (\d+)',predicate)
        assert len(ids)>0
        for raw in ids:
            id=int(raw)
            assert id not in got, f'duplicate OWM code {id}'
            got[id]=enum
    return got


class CompleteWeatherCodeCoverage(unittest.TestCase):
    def test_garmin_full_0_to_53_without_duplicate_mapping(self):
        result=parse_garmin()
        self.assertEqual(set(result), {name for name,category in GARMIN.values()})
        self.assertEqual(len(result),54)
        for code,(name,group) in GARMIN.items():
            with self.subTest(provider='Garmin',code=code,condition=name):
                self.assertEqual(result[name],group)
        self.assertEqual(result['UNKNOWN'],-1)

    def test_owm_all_55_official_ids_and_no_synthetic_ranges(self):
        result=parse_openweather()
        self.assertEqual(len(result),55)
        self.assertEqual(set(result),set(OWM))
        for code,enum in OWM.items():
            with self.subTest(provider='OWM',code=code):
                self.assertEqual(result[code],enum)
        for unknown in [0,199,203,220,233,299,303,400,505,510,512,523,599,
                        603,610,614,617,623,702,722,732,742,770,780,782,799,805,999]:
            with self.subTest(unsupported=unknown): self.assertNotIn(unknown,result)

    def test_provider_codes_are_never_used_as_garmin_enum_numbers(self):
        self.assertIn('return srOwmMappedCondition(id);',DATA)
        self.assertIn('var mapped = code != null && srOwmMappedCondition(code) != null;',OWARN)
        self.assertIn('var storm = mapped &&', OWARN)
        self.assertIn('(forecast && measuredRain && !freezing)', OWARN)
        self.assertIn('if (c != null && srGarminDisplayGroup(c) < 0)',GWARN)

    def test_extreme_conditions_not_synthetic_numeric_wind_readings(self):
        for x in ('CONDITION_TORNADO','CONDITION_HURRICANE',
                  'CONDITION_TROPICAL_STORM','CONDITION_SQUALL'):
            self.assertIn('c == Weather.'+x,GWARN)
        for id in (771,781):self.assertRegex(OWARN,rf'code == {id}\b')
        self.assertIn('addAlert(k, 13)',GWARN)
        self.assertIn('addAlert(k, 13)',OWARN)
        self.assertIn('if (k == 13) { return 110; }',GWARN)
        self.assertIn('kind == 13',UI)
        self.assertIn('hasForecastUnderline',UI)
        self.assertIn('wind >= srSetting("gwWindV332", 10)',GWARN)
        self.assertIn('wind >= srSetting("gwWindV332", 10)',OWARN)

    def test_owm_distinct_weather_families(self):
        m=parse_openweather()
        for id,enum in [(701,'MIST'),(721,'HAZE'),(741,'FOG'),(511,'FREEZING_RAIN'),
                        (771,'SQUALL'),(781,'TORNADO'),(500,'LIGHT_RAIN'),
                        (502,'HEAVY_RAIN'),(531,'SHOWERS'),(602,'HEAVY_SNOW'),
                        (615,'LIGHT_RAIN_SNOW'),(622,'HEAVY_SNOW'),
                        (803,'MOSTLY_CLOUDY'),(804,'CLOUDY')]:
            with self.subTest(owm=id):self.assertEqual(m[id],enum)
        self.assertNotIn('code == 531;', OWARN.split('var heavyR =',1)[1].split(';',1)[0])
        self.assertIn('code == 522;',OWARN)

    def test_every_garmin_condition_has_display_group_and_text_fallback(self):
        garmin=parse_garmin()
        self.assertIn('srGarminDisplayGroup(c)',TEXT)
        self.assertIn('srGarminDisplayGroup(c)',UI)
        for enum in ('CONDITION_TORNADO','CONDITION_HURRICANE',
                     'CONDITION_TROPICAL_STORM','CONDITION_SQUALL',
                     'CONDITION_HAIL','CONDITION_FREEZING_RAIN'):
            self.assertIn(enum,TEXT)
        self.assertEqual(len(garmin),54)
        self.assertIn('BRAK DANYCH',TEXT)

    def test_csv_inventory_109_unique_correct_rows(self):
        with (ROOT/'WEATHER_CODE_MATRIX.csv').open(encoding='utf-8') as file:
            rows=list(csv.DictReader(file))
        self.assertEqual(len(rows),109)
        self.assertEqual(len({(r['provider'],r['code']) for r in rows}),109)
        self.assertEqual({int(r['code']) for r in rows if r['provider']=='Garmin'},set(GARMIN))
        self.assertEqual({int(r['code']) for r in rows if r['provider']=='OpenWeatherMap'},set(OWM))
        for row in rows:
            with self.subTest(provider=row['provider'],code=row['code']):
                self.assertTrue(row['warning_rule'])
                self.assertTrue(row['display_group_or_garmin_symbol'])

    def test_not_every_forecast_condition_is_an_alert(self):
        self.assertIn('srSetting("gwWindOnV332", true)',OWARN)
        self.assertIn('srSetting("gwWindOnV332", true)',GWARN)
        self.assertIn('srSetting("gwFogOnV332", true)',OWARN)
        self.assertIn('srSetting("gwFogOnV332", true)',GWARN)
        self.assertIn('visibility <= srSetting("gwFogMetersV332", 500)',OWARN)
        self.assertIn('visibility <= srSetting("gwFogMetersV332", 500)',GWARN)
        self.assertIn('srSetting("gwHailOnV332", true)',GWARN)
        self.assertNotIn('addAlert(k, 8)',OWARN) # OWM has no separate hail code
        self.assertIn('code == 511',OWARN)
        self.assertIn('srSetting("gwFreezeOnV332", true)',OWARN)
        self.assertIn('srSetting("gwForecastV332", true)',OWARN)

    def test_version_and_old_setting_identifiers(self):
        self.assertIn('version="3.26.48"',(ROOT/'manifest.xml').read_text())
        self.assertIn('srProviderV326',DATA)
        self.assertNotIn('SolarFusionMatcher',UI)

if __name__=='__main__': unittest.main()
