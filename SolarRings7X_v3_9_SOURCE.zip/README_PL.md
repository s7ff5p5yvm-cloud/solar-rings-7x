# Solar Rings 7X v3.9.0 — kapsuła kroków i czytelniejsze litery

Wersja bazuje na v3.8 i zachowuje ID aplikacji Garmin, konfigurację z iPhone'a,
trzy pola u góry, godzinę z datą, fazę Księżyca, pogodę, baterię,
opcjonalny obwodowy pierścień oraz ostrzeżenie o spadku ciśnienia.

## Co zmieniono

- Boczne pierścienie: 54 × 44 px, środki X=63 i X=217.
- Środkowe pole: szeroka kapsuła 90 × 44 px, X=95..185, Y=168..212.
- Ikona, duża liczba i osobny pasek wypełnienia względem rzeczywistego celu.
- Kroki: pełne wartości pięciocyfrowe (np. 12345), bez skracania do „12.3k”.
- Nowe ustawienie iPhone'a: „Wykonane kroki” lub „Pozostałe do celu”.
  Przy braku celu pozostają wyświetlane wykonane kroki.
- Godzina i data: powiększony docelowy rozmiar z zachowaniem pomiaru
  szerokości i automatycznego dopasowania do własnych pól.
- Ikona pogody 4 piksele niżej, bez zmiany tekstów i warunków pogodowych.

**Uwaga:** pasek postępu jest rysowany tylko dla pól z dostępnym
celem / miarą postępu. Dla tętna taki cel nie jest wymyślany.

## Kompilacja GitHub

1. Umieść SolarRings7X_v3_9_SOURCE.zip w głównym katalogu repozytorium.
2. Zastąp .github/workflows/build-v3.yml zawartością pliku SolarRings7X_v3_9_BUILD.yml.
3. Actions > Build Solar Rings 7X v3.9 (capsule) > Run workflow.
4. Po udanej kompilacji pobierz archiwum z Artifacts i użyj .IQ do aktualizacji
   istniejącej bety w Connect IQ.

Zachowano klucze 35 dotychczasowych ustawień i dodano jedno nowe.
Nie udostępniaj prywatnego klucza deweloperskiego Garmin.

## Status weryfikacji

Testy lokalne obejmują XML, powiązania ustawień, geometrię 280×280,
obecność odczytu celu, trzech pól i poprawne spakowanie ZIP-a.
Wymagane jest jeszcze przejście kompilacji Garmin SDK i test na Fenixie.
