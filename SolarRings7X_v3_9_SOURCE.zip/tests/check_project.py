#!/usr/bin/env python3
"""Source and geometry checks for Solar Rings 7X v3.9.
These do NOT replace a Garmin SDK build and on-device test.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
text=(root/'source/SolarRings7X.mc').read_text(encoding='utf-8')
fields=(root/'source/FieldData.mc').read_text(encoding='utf-8')
ns='{http://www.garmin.com/xml/connectiq}'
app=ET.parse(root/'manifest.xml').getroot().find(ns+'application')
assert app.attrib['version']=='3.9.0'
assert app.attrib['id']=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
settings=ET.parse(root/'resources/settings/settings.xml').getroot()
props=ET.parse(root/'resources/settings/properties.xml').getroot()
strings=ET.parse(root/'resources/strings.xml').getroot()
pids=[p.attrib['id'] for p in props]
assert len(pids)==len(set(pids))==36, (len(pids),len(set(pids)))
strids={s.attrib['id'] for s in strings}
settingkeys=[]
for setting in settings:
    sk=setting.attrib['propertyKey'].split('.')[-1]
    settingkeys.append(sk)
    assert sk in pids
    assert setting.attrib['title'].split('.')[-1] in strids
    for e in setting.findall('.//listEntry'):
        assert e.text.split('.')[-1] in strids
assert len(settingkeys)==len(set(settingkeys))==36
assert set(settingkeys)==set(pids)
assert 'capsuleStepsModeV39' in pids
for token in ('function centerCapsule(', 'dc.drawRoundedRectangle(95, 168, 90, 44, 15)',
              'dc.fillRoundedRectangle(107, 205, 66, 4, 2)',
              'centerCapsule(dc, srSetting("slotRing2V3", 2)',
              'ring(dc, 63,', 'ring(dc, 217,', 'weatherSymbol(dc, 74, 233, weather)',
              'drawMoonPanel(dc);', 'drawClock(dc, clock)',
              'drawDate(dc, days[date.day_of_week - 1]', 'srSetting("capsuleStepsModeV39", 0)',
              'monitor.stepGoal - steps'):
    assert token in text, token
assert 'recentHeartRate()' in fields
# All three indicator outlines stay inside the display, do not touch
# each other, and fit vertically between the moon separator and weather.
left=(63-27,168,63+27,212)
center=(95,168,185,212)
right=(217-27,168,217+27,212)
assert left[2] < center[0] and center[2] < right[0], (left,center,right)
assert 0<left[0]<right[2]<280
assert 163 < center[1] and center[3] <215
# A 5-digit count is shown raw, not converted to a compact value.
for steps in [9999,10000,12345,25000,99999]:
    displayed=str(steps)
    assert len(displayed)<=5 and displayed.isdigit()
# Clamp progress to a real goal without exceeding the available bar.
for steps,goal in [(0,10000),(2500,10000),(10000,10000),(12500,10000)]:
    ratio=max(0.,min(1.,steps/goal))
    filled=int(ratio*66)
    assert 0<=filled<=66
# Track 107..173 is within capsule 95..185, and y205..209 within y168..212
assert 95<107<173<185 and 168<205<209<212
# Cloud's larger visual extends no lower than y=249, above footer y=253.
assert 233+16<253
print('PASS v3.9: 36 mobile settings, Garmin ID/version, capsule with real progress, 5-digit steps, zones, weather and pulse preserved')
