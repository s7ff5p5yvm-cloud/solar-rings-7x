using Toybox.SensorHistory as History;
using Toybox.Time as Time;

// Conservative *trend indication* (not an official storm warning).
// Sensor barometric elevation also changes with weather, therefore this
// filter cannot perfectly distinguish climbing from atmospheric changes.
// Fail closed if there is insufficient pressure/elevation history.
class StormGuard {
    var _lastCheck;
    var _lastResult;

    function initialize() {
        _lastCheck = 0;
        _lastResult = false;
    }

    function warning() {
        if (!srSetting("stormOnV3", false)) { return false; }
        var now = Time.now().value();
        if (_lastCheck != 0 && now - _lastCheck < 300) { return _lastResult; }
        _lastCheck = now;
        _lastResult = evaluate();
        return _lastResult;
    }

    function evaluate() {
        try {
            var now = Time.now().value();
            var p = History.getPressureHistory({
                :period => new Time.Duration(10800),
                :order => History.ORDER_NEWEST_FIRST
            });
            if (p == null) { return false; }
            var sample = p.next();
            var firstPa = null;
            var lastPa = null;
            var tNewest = null;
            var tOldest = null;
            var n = 0;
            while (sample != null && n < 400) {
                if (sample.data != null) {
                    if (firstPa == null) {
                        firstPa = sample.data.toFloat();
                        tNewest = sample.when.value();
                    }
                    lastPa = sample.data.toFloat();
                    tOldest = sample.when.value();
                    n++;
                }
                sample = p.next();
            }
            if (n < 5 || tNewest == null || tOldest == null) { return false; }
            if (now - tNewest > 1200 || tNewest - tOldest < 9000) { return false; }
            var dropHpa = (lastPa - firstPa) / 100.0;
            if (dropHpa < srSetting("stormDropV3", 4)) { return false; }

            var e = History.getElevationHistory({
                :period => new Time.Duration(10800),
                :order => History.ORDER_NEWEST_FIRST
            });
            if (e == null) { return false; }
            var item = e.next();
            var minAlt = 100000.0;
            var maxAlt = -100000.0;
            var tA = null;
            var tB = null;
            var count = 0;
            while (item != null && count < 400) {
                if (item.data != null) {
                    var a = item.data.toFloat();
                    if (a < minAlt) { minAlt = a; }
                    if (a > maxAlt) { maxAlt = a; }
                    if (tA == null) { tA = item.when.value(); }
                    tB = item.when.value();
                    count++;
                }
                item = e.next();
            }
            if (count < 5 || tA == null || tB == null) { return false; }
            if (now - tA > 1200 || tA - tB < 9000) { return false; }
            return maxAlt - minAlt < srSetting("stormAltitudeV3", 20);
        } catch (e) { return false; }
    }
}
