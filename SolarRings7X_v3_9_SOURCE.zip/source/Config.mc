using Toybox.Application.Properties as Props;
using Toybox.Graphics as Gfx;

// Mobile app settings. All default keys are defined in resources/settings/properties.xml.
// Deliberately use NEW keys so stale v2.x settings cannot unexpectedly override
// the new three-ring layout. All 8 visible slots are selectable from the phone.
function srSetting(key, fallback) {
    try {
        var value = Props.getValue(key);
        if (value != null) { return value; }
    } catch (e) { }
    return fallback;
}

function srColor(value) {
    if (value == 0) { return Gfx.COLOR_RED; }
    if (value == 1) { return Gfx.COLOR_GREEN; }
    if (value == 2) { return Gfx.COLOR_BLUE; }
    if (value == 3) { return Gfx.COLOR_ORANGE; }
    if (value == 4) { return Gfx.COLOR_YELLOW; }
    if (value == 5) { return Gfx.COLOR_WHITE; }
    return 0x00FFFF;
}
