# v3.21.8 — IMGW Test 4 production-only banner guard

Zmiana w `drawWeather`: po pobraniu diagnostyki natychmiast ją wyłączamy, jeśli aktywny tryb to 4. Dzięki temu ani flaga debug, ani błąd walidacji nie zasłaniają temperatury odczuwalnej. Debug: Test 1 i Test 11. Icon preview: nadal etykieta `TEST`, celowo.

Pozostałe funkcje v3.21.6, w tym kolory, ikony i fallback lokalizacji, nie są zmieniane. Wynik Test 4 nadal nie dowodzi świeżego fixa GPS.
