# Solar Rings 7X v3.21.9 — niezależna diagnostyka GPS

Test 1 wyświetla teraz **`T1v19 ...`** bez przechodzenia przez stary mechanizm skracania statusów do `GPS? RxxK`. Dzięki temu na zegarku widać zarówno wersję faktycznie wykonywanego kodu, jak i źródło lokalizacji.

Przykłady: `T1v19 BRAK G3` — Activity.Info nie zwróciło współrzędnych, a inna ważna pozycja nie jest dostępna; `T1v19 A3 2m` — ostatnie współrzędne Activity o jakości 3 zapisane 2 minuty temu; `T1v19 P 1h` — przybliżona lokalizacja pogodowa; `T1v19 K 3m` — wykorzystana pamięć współrzędnych; `T1v19 O 1261` — ostatni potwierdzony powiat.

**Nie oznacza to, że GPS jest już naprawiony.** Garmin Connect IQ nie pozwala tarczy uruchomić odbiornika GPS. Nowa ścieżka testowa służy odróżnieniu rzeczywistego braku pozycji od mylącego komunikatu UI. Produkcyjny Test 4, ikony, temperatura odczuwalna, kolory i pobieranie IMGW pozostają niezmienione.

Po instalacji: IMGW włączone, Test 1, TERYT 0, diagnostyka włączona, podgląd ikon wyłączony. W kolejnej fazie wrócić do Test 4.
