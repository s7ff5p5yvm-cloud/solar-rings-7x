# Solar Rings 7X v3.21.8 — poprawka kompilacji

Naprawiono błąd kompilatora Monkey C: `Position.Quality` nie ma metody `toNumber()` (poprzednio `SolarRings7X.mc:1073`). Jakość pozycji jest teraz mapowana przez nazwane stałe `Position.QUALITY_*` na liczby 0–4 zapisywane w diagnostyce. Nie zmieniono algorytmu IMGW, wyglądu ani pobierania GPS.

Ta wersja zachowuje produkcyjny Test 4 bez napisów technicznych i testy GPS (Test 1) oraz IMGW (Test 11). Lokalnie uruchomiono testy Python i kontrolę XML; **kompilacja SDK Garmin wymaga potwierdzenia w GitHub Actions**.
