# Solar Rings 7X — v3.22.0: GPS przed lokalizacją stacji pogodowej

## Co naprawiono

- **Osobne zapisy:** ostatnie współrzędne udostępnione przez `Activity.getActivityInfo().currentLocation` są trzymane w `imgwGpsFixV3220`, niezależnie od `Weather.CurrentConditions.observationLocationPosition`.
- **Priorytet danych:** po odczycie GPS (jakość 2–4) zegarek wykorzystuje tę pozycję. Gdy Garmin przestaje ją podawać, przez maksymalnie 24 godziny może wykorzystać zapis z wyraźnym statusem `KGPS` — bez odświeżania jego czasu. Dopiero bez takiego zapisu próbuje `startLocation` z niedawnej aktywności, następnie pozycję stacji Garmin Weather (maksymalnie 2-godzinną).
- **Nie miesza powiatów:** wynik GUGiK dla stacji pogodowej jest zapisywany osobno jako `imgwWeatherCountyV3220`. Nie nadpisuje ostatniego powiatu z GPS.
- **Czas pochodzenia:** zapis powiatu wyznaczonego z pamięci GPS lub danych pogodowych wykorzystuje czas źródła, a nie moment późniejszego pobrania z GUGiK. Nie można więc przedłużać go bez końca samym odświeżaniem IMGW.
- **Odporność:** dodatkowa kontrola typów zapisanego wyniku i migracja ostatniej współrzędnej GPS z poprzedniej wersji, bez fałszywego oznaczania jej jako świeżego fixa.
- **Diagnostyka:** `T1v20 A2/A3/A4` (pozycja Activity z jakością), `T1v20 KGPS` (zapisana lokalizacja pochodząca z Activity), `T1v20 S` (początek ostatniej aktywności), `T1v20 P` (stacja pogodowa), `T1v20 O` (ostatni powiat), `T1v20 BRAK G...` (brak danych). Podawany wiek to wiek zapisu/obserwacji, niekoniecznie wiek fixa satelitarnego.

## Ważne ograniczenie Connect IQ

Aplikacja typu **Watch Face nie może sama włączyć GPS**. Garmin udostępnia jej tylko niektóre istniejące dane, w szczególności `Activity.Info.currentLocation`, które może być `null`. `Weather.observationLocationPosition` to miejsce obserwacji (stacja), nie gwarantowana pozycja użytkownika. Żaden algorytm samej tarczy nie daje 100% automatycznego ustalenia aktualnego powiatu, kiedy Garmin nie udostępnia pozycji. W razie braku aktualnego fixa dane ze źródeł zastępczych **nie są potwierdzeniem lokalizacji użytkownika**. Podczas podróży zachowaj ostrożność — dla pewnego aktualnego powiatu potrzebna jest nowa pozycja z urządzenia lub osobna aplikacja z uprawnieniem do włączenia GPS.

## Instalacja i poranny test

1. Do głównego katalogu repozytorium GitHub wgraj `SolarRings7X_v3_22_0_SOURCE.zip`.
2. Do `.github/workflows/` dodaj `SolarRings7X_v3_22_0_BUILD.yml`.
3. Uruchom **Build Solar Rings 7X v3.22.0**. Pobierz z artefaktów `SolarRings7X_v3220.prg` i zainstaluj na Fenix 7X Pro Solar.
4. Pozostaw IMGW: **włączone**, **Test 4**, TERYT **0**, interwał **50 minut** (jeśli taki jest Twój wybór), podgląd ikon TEST **wyłączony**. Normalny widok pozostaje bez technicznych napisów i z temperaturą odczuwalną.
5. Jeśli chcesz zobaczyć pochodzenie lokalizacji, przełącz tymczasowo na **Test 1** i odczytaj `T1v20 ...`; potem wróć na Test 4. Test 1 nie pobiera IMGW w tle.

## Weryfikacja

- 108/108 testów lokalnych Python zaliczonych (w tym 8 nowych kontroli dotyczących GPS/powiatu).
- Kontrola składni XML, plików archiwum i spójności nazw workflow.
- **Nie wykonano lokalnej kompilacji Garmin SDK ani testu na rzeczywistym zegarku**; wynik GitHub Actions i próba na Fenixie są niezbędne przed uznaniem poprawki za potwierdzoną.

Nie zmieniano klasyfikacji alertów, mapowania ikon, kolorów stopni IMGW ani Body Battery, temperatury odczuwalnej i termometru.
