# Solar Rings 7X v3.21.3 — GPS / ostatni znany powiat

- Automatyczny GPS pozostaje pierwszym wyborem. Odczyt jest ponawiany przy powrocie tarczy (onShow) i podczas odświeżeń.
- T4 GPS? G2: brak danych Activity; G3: Activity.currentLocation == null; G4: nieprawidłowe współrzędne; G5: błąd zapisu/odczytu.
- Po prawidłowym ustaleniu powiatu przez GUGiK jego kod jest zachowywany do 24 godzin jako **ostatni znany powiat**.
- Gdy Garmin nie udostępnia już GPS, IMGW może sprawdzić ostrzeżenia dla ostatniego potwierdzonego powiatu. Tarcza pokazuje `T4 O####! (alert) lub T4 O####? (brak alertu, ale lokalizacja ostatnio znana)` — nie udaje aktualnej pozycji.
- Opcjonalnie w Connect IQ: `IMGW: powiat awaryjny TERYT` (0=wyłączony, np. 1261=Kraków), gdy brak zapisanej lokalizacji; wynik `T4 M####!` (alert) lub `T4 M####?` (brak alertu, ale bez potwierdzenia aktualnej lokalizacji) dotyczy wybranego powiatu, a nie automatycznie aktualnego GPS.
- Odpowiedzi dla ostatniego lub ręcznego powiatu nie są pokazywane jako zielony **potwierdzony brak ostrzeżeń dla bieżącego miejsca** i nie uruchamiają ikon. To zabezpieczenie na wypadek podróży.
- Bez zapamiętanej lokalizacji i bez ręcznego wyboru tarcza nadal musi wyświetlić brak GPS: watchface nie może sama aktywować satelitów.
- Po udanym GUGiK i bieżącym GPS tryb 4 wciąż pobiera bezpośrednio IMGW, identycznie jak wcześniej.
- Testy offline są testami źródeł/modelu; kompilację i działanie na Fenix 7X Pro należy sprawdzić przez GitHub Actions i na zegarku.
