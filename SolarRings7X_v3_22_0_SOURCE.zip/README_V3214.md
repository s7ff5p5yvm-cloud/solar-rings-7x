# Zmiany wersji 3.21.4

- Podgląd 13 kategorii piktogramów IMGW i stopnia 1/2/3 bez pobierania danych — zawsze oznaczony TEST.
- Obsługa prawdziwej ikony IMGW przy ręcznie wybranym TERYT nawet bez współrzędnych GPS, przy zachowaniu walidacji czasu i typu ostrzeżenia.
- Jawne pierwszeństwo ręcznego TERYT w pełnym trybie 4.
- Alternatywne źródło orientacyjnej pozycji po błędzie G3 z Garmin Weather, ograniczone czasem obserwacji, ze źródłem oznaczonym jako przybliżone.
- Zapobieganie traktowaniu przybliżonej pozycji jako dokładnego GPS.
- W kodzie nie wprowadzono nowego źródła ostrzeżeń: pozostają bezpośrednie zapytania IMGW/GUGiK.
