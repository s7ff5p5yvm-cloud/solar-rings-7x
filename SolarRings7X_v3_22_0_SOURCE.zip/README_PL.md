# Solar Rings 7X v3.22.0 — priorytet GPS dla IMGW

Wersja naprawia regresję, w której świeża obserwacja stacji Garmin Weather potrafiła wyprzeć ostatnią współrzędną GPS zegarka. Zachowuje osobno współrzędne GPS i stacji pogodowej, nie odświeża czasu starych danych przez samą synchronizację i nie miesza potwierdzonych powiatów. Dotychczasowe ikony IMGW, kolory, termometr i temperatura odczuwalna są niezmienione.

**Plik do GitHuba:** `SolarRings7X_v3_22_0_SOURCE.zip` do katalogu głównego repozytorium, `SolarRings7X_v3_22_0_BUILD.yml` do `.github/workflows/`. Po kompilacji pobierz `SolarRings7X_v3220.prg`.

**Po instalacji:** IMGW włączone, Test 4, TERYT 0, 50 minut, podgląd ikon wyłączony. Do sprawdzania źródła lokalizacji można wybrać Test 1; rozpoznasz go po komunikacie `T1v20`.

Ograniczenie: sama tarcza Connect IQ nie może uruchomić GPS. `Activity.currentLocation` może być puste; `Weather.observationLocationPosition` wskazuje stację pogodową i nie potwierdza powiatu użytkownika. Szczegóły w `README_V3220.md`.
