# Solar Rings 7X v3.21.5

Zmiany:
- Usunięto automatyczny napis `RĘCZNY 1205 ALERT!`, `OSTATNI ...` i `PRZYBL.` spod pogody, gdy diagnostyka jest wyłączona. Pozostaje sama ikona IMGW oraz odczuwalna temperatura (`ODCZ.`), jeśli jest włączona.
- Diagnostyka nadal pokazuje źródło lokalizacji po świadomym włączeniu, a podgląd ikony wciąż ma napis TEST.
- Ikona termometru dla mrozu i ikona IMGW mają dwa niezależne miejsca; oba mogą pojawić się równocześnie, jeśli temperatura < próg (domyślnie 0°C) i jest odpowiednie ostrzeżenie.
- Weryfikacja najnowszego powiatu GUGiK (24h, zgodność kodu i współrzędnych) pozwala nie odrzucać prawidłowego ostrzeżenia wskutek utraty GPS podczas wymiany danych (`D7/D8`). Jest traktowana jako ostatnia znana lokalizacja, nie jako bieżący GPS.
- Odświeżanie lokalizacji w tarczy wykorzystuje tę samą informację pogodową Garmin, która jest już pobrana do wyświetlenia temperatury; unikamy podwójnego zapytania Weather w jednej klatce.
- Rozdzielono kod G3 na nowe diagnostyki: G8 (Weather ma pozycję, lecz brak czasu jej obserwacji), G9 (Weather zbyt stare), G10 (wyjątek podczas dostępu do Weather); brak odczytu GPS nie jest przemilczany.

**Ograniczenie systemowe**: jeśli Garmin zwraca null dla Activity.currentLocation i brak jest użytecznej pozycji Garmin Weather oraz ostatniego powiatu, tarcza nie może sama włączyć GPS. Automat bez zapisanej lokalizacji nie jest gwarantowany. Dla prawdziwie automatycznego powiatu potrzebny jest dostępny odczyt współrzędnych.

## Instalacja
1. Wgraj `SolarRings7X_v3_21_5_SOURCE.zip` do głównego katalogu repozytorium.
2. Wgraj `SolarRings7X_v3_21_5_BUILD.yml` do `.github/workflows/`.
3. Uruchom workflow ręcznie w Actions.
4. Na zegarku: podgląd ikony TEST = Wyłącz, IMGW ikonki = Włącz, diagnostyka = Wyłącz, odczuwalna = Włącz. W trybie ręcznym podaj TERYT, w automatycznym 0.
