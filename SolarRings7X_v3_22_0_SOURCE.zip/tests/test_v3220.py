"""Regression checks for separate GPS and weather-station provenance.
These checks are static/behavioral; SDK build and real watch fix need CI/device.
"""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parents[1]
face = (root/'source/SolarRings7X.mc').read_text()
service = (root/'source/ImgwService.mc').read_text()

class GpsPriorityV3220(unittest.TestCase):
    def test_actual_gps_is_persisted_separately(self):
        self.assertIn('function rememberImgwActivityPosition(lat, lon, quality)', face)
        self.assertIn('Storage.setValue("imgwGpsFixV3220", [lat, lon, now, quality])', face)
        self.assertIn('function restoreImgwGpsCache()', face)
        self.assertIn('Storage.setValue("imgwLocV318", [lat, lon, fix[2], 5])', face)
    def test_gps_backup_has_priority_over_weather(self):
        block = face.split('function captureImgwLocation(weatherData) {',1)[1].split('// Called when the user returns',1)[0]
        self.assertLess(block.index('if (restoreImgwGpsCache()) { return; }'),
                        block.index('var wx = weatherData;'))
        self.assertIn('if (rememberImgwActivityPosition(', block)
        self.assertIn('if (quality >= 2 && quality <= 4) { return; }', block)
    def test_unreliable_quality_cannot_override_good_recent_gps(self):
        block = face.split('function rememberImgwActivityPosition',1)[1].split('function restoreImgwGpsCache',1)[0]
        self.assertIn('if (quality < 2 && oldValid && old[3] >= 2) { return false; }',block)
        self.assertIn('if (source == 5) { update = false; }',block)
    def test_weather_station_does_not_overwrite_verified_gps_county(self):
        self.assertIn('var countyKey = _source == 3 ?',service)
        self.assertIn('"imgwWeatherCountyV3220" : "imgwLastCountyV3213"',service)
        self.assertIn('var cacheKey = d[8] == 3 ?',face)
        self.assertIn('"imgwWeatherCountyV3220" :',face)
        fallback = service.split('function tryLastCountyWhenGpsMissing()',1)[1].split('function onTemporalEvent()',1)[0]
        self.assertIn('Storage.getValue("imgwLastCountyV3213")',fallback)
        self.assertNotIn('imgwWeatherCountyV3220',fallback)
    def test_observation_timestamp_not_gugik_http_timestamp(self):
        self.assertIn('evidenceTime = sourceLoc[2];',service)
        self.assertIn('Storage.setValue(countyKey,',service)
        self.assertIn('[_county, _lat, _lon, evidenceTime, _source]',service)
    def test_ttl_and_source_diagnostics(self):
        self.assertIn('if (age < 0 || age > 86400) { return false; }',face)
        self.assertIn('(loc[3] == 5 ? 86400 : 21600)',face)
        self.assertIn('(loc.size() >= 4 && loc[3] == 5 ? 86400 : 21600)',service)
        self.assertIn('"T1 KGPS "',face)
        self.assertIn('gpsLine = "T1v20 "',face)
    def test_no_disallowed_position_acquisition(self):
        self.assertNotIn('Position.enableLocationEvents(',face)
        self.assertNotIn('Position.getInfo(',face)
        self.assertNotIn('Position.enableLocationEvents(',service)
    def test_ui_and_resources_preserved(self):
        self.assertIn('lowerLabel = "ODCZ. " + weather.feelsLikeTemperature',face)
        self.assertIn('imgwAlert(dc, hasThermometer ? 144 : 124, 224',face)
        for xml in (root/'resources').rglob('*.xml'): ET.parse(xml)
        el=ET.parse(root/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(el.attrib['version'],'3.22.0')

if __name__=='__main__': unittest.main()
