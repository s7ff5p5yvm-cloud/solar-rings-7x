from pathlib import Path
import unittest
from xml.etree import ElementTree as ET
r=Path(__file__).resolve().parents[1]
f=(r/'source/SolarRings7X.mc').read_text()
b=(r/'source/ImgwService.mc').read_text()
c=(r/'source/Config.mc').read_text()
w=f.split('function drawWeather(dc, monitor, weather) {',1)[1].split('function drawBattery',1)[0]
class Test3216(unittest.TestCase):
 def test_manual_banner_suppressed_even_when_diagnostics_enabled(self):
  self.assertIn('diag.find(" ALERT") != null',w)
  self.assertIn('diag.find(" BRAK?") != null',w)
  self.assertIn('diag.find(": OK 0") != null',w)
  self.assertIn('diag = null;',w)
  self.assertIn('lowerLabel = "ODCZ. " + weather.feelsLikeTemperature',w)
  a=f.split('function activeImgwAlert(snapshot) {',1)[1].split('function imgwDiagnosticLine',1)[0]
  self.assertNotIn('srSetting("imgwDiagnosticsV3193", false)',a)
 def test_error_not_hidden(self):
  scope=w.split('var diag = isTemp ?',1)[1].split('if (iconPreview)',1)[0]
  self.assertNotIn('find(": D")',scope)
  self.assertNotIn('find("GPS?")',scope)
 def test_gps_source_quality_and_age(self):
  self.assertIn('currentLocationAccuracy',f)
  self.assertIn('if (quality == 0 || quality == 1)',f)
  self.assertIn('imgwGpsReport(12)',f)
  self.assertIn('var weatherStamp = wx.observationTime.value()',f)
  self.assertIn('now - weatherStamp',f)
  self.assertIn('weatherAge > 7200',f)
  self.assertIn('"T1 BRAK G"',f)
  self.assertIn('"T1 A"',f)
  self.assertIn('"T1 P "',f)
  self.assertIn('"T1 K "',f)
 def test_distinct_severity_palette(self):
  self.assertIn('var color = Gfx.COLOR_YELLOW;',f)
  self.assertIn('if (level == 2) { color = 0x00FFFF; }',f)
  self.assertIn('else if (level >= 3) { color = Gfx.COLOR_RED; }',f)
 def test_body_battery_yellow_vs_red(self):
  st=f.split('function statusIconColor',1)[1].split('function drawIcon',1)[0]
  self.assertIn('if (percent <= 10) { return Gfx.COLOR_RED; }',st)
  self.assertIn('if (percent <= bodyLow) { return Gfx.COLOR_YELLOW; }',st)
  self.assertIn('if (value == 3) { return Gfx.COLOR_ORANGE; }',c)
 def test_both_temperature_warnings_still_draw(self):
  self.assertIn('if (hasThermometer) { temperatureMarker(dc, weather, 124, 224); }',w)
  self.assertIn('imgwAlert(dc, hasThermometer ? 144 : 124, 224',w)
 def test_xml_and_version(self):
  for p in (r/'resources').rglob('*.xml'):ET.parse(p)
  self.assertIn('version="3.22.0"',(r/'manifest.xml').read_text())
if __name__=='__main__': unittest.main()
