# Solar Rings 7X v3.21.6 — GPS i kontrast ostrzeżeń

## Zmiany
- W pełnym trybie IMGW (Test 4) wynik **prawidłowo zweryfikowanego** pobrania nie zastępuje już temperatury odczuwalnej wielkim napisem „RĘCZNY 1205 ALERT!” / „OSTATNI…” / „IMGW 1261: OK”. Działa to **także wtedy, gdy diagnostyka pozostała włączona**. Błędy nadal mogą pojawić się w miejscu podpisu, by można było je sprawdzić.
- Przy włączonych ikonach ostrzeżenie pokazuje **samą ikonę**. Podgląd ikon TEST nadal jest celowo oznaczony napisem TEST.
- IMGW stopień 1 = **żółty**, 2 = **jasny turkus / cyjan**, 3 = **czerwony**. Są to kolory podwyższonego kontrastu, **nie oficjalny schemat kolorów IMGW** (który zwykle oznacza 2. stopień pomarańczowym).
- Body Battery: niski poziom (<= konfiguracja, standardowo 20%) = **żółty**, krytyczny (<=10%) = **czerwony**. Pozostałe ustawienia barw bez zmian.
- Test 1 pokazuje źródło pozycji: `T1 A2/A3/A4` (Garmin Activity podaje jakość pozycji), `T1 P` (obserwacja Garmin Weather), `T1 S` (start aktywności), `T1 K` (cache), `T1 O` (ostatnio ustalony powiat), `T1 BRAK G...` (przyczyna; G12 = stara pozycja GPS, G13 = GPS niedostępny). `A1` = ostatnia znana pozycja, **nie nowy GPS**. Podawany wiek oznacza wiek zapisu w tarczy lub obserwacji pogodowej, **nie czas uzyskania fixa satelitarnego**.
- Przy jakości GPS `0/1` nie odnawiamy znacznika czasu pozycji (unikanie pozornej świeżości). Pozycja Weather korzysta z **rzeczywistego czasu obserwacji**, do 2 godzin. Pamięć ostatnio potwierdzonego powiatu pozostaje awaryjnym źródłem ostrzeżeń, nie jest oznaczana jako aktualny GPS.

## Instalacja
Wgraj `SolarRings7X_v3_21_6_SOURCE.zip` do głównego katalogu repozytorium, a `SolarRings7X_v3_21_6_BUILD.yml` do `.github/workflows/`. Uruchom workflow `Build Solar Rings 7X v3.21.6` i zainstaluj wygenerowany `.iq`.

## Testy na Fenixie
1. Test barw: IMGW podgląd ikony `Oblodzenie` i stopień `1`, następnie `2`, następnie `3`. Po każdej zmianie zapisz ustawienia; powinna zmienić się tylko barwa ikony.
2. Normalny widok: IMGW włączone, **Test 4**, ikony włączone, podgląd wyłączony, ręczny TERYT `1205` tylko na potrzeby alertu; zachowaj diagnostykę włączoną, aby upewnić się, że komunikat „RĘCZNY … ALERT” **nie wraca** i nie zakrywa `ODCZ.`. Po sprawdzeniu przywróć TERYT `0`.
3. GPS: diagnostyka włączona, TERYT `0`, **Test 1**. Odczytaj napis `T1 ...`; dla `T1 A2/A3/A4` mamy pozycję Activity o jakości GPS wskazanej przez Garmin, a nie niepodważalny dowód świeżego fixa. `T1 P/S/K/O` oznacza źródła zapasowe. Następnie wróć do Test 4.
4. Finalne korzystanie: diagnostykę wyłącz, Test 4, TERYT `0`, podgląd wyłącz.

## Granice rozwiązania
Connect IQ nie udostępnia tarczy bezpośredniego uruchamiania GPS. `Activity.currentLocation` może być `null` także po aktywności GPS; wtedy używamy ostrożnych źródeł zapasowych. Testy Pythona i parsowania XML **nie są kompilacją** SDK ani testem urządzenia.
