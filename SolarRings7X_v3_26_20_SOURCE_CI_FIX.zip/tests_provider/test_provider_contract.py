"""Source contracts + reference cases. These do NOT execute Garmin Monkey C."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re
import unittest

R = Path(__file__).resolve().parents[1]
B = Path('/mnt/data/audit_architecture_32432')  # Optional local baseline

def source(name): return (R/'source'/name).read_text()

def properties(root):
    return {x.get('id'):(x.get('type'), (x.text or '').strip())
            for x in ET.parse(root/'resources/settings/properties.xml').getroot()}

class ProviderContracts(unittest.TestCase):
    def test_xml_files_are_well_formed(self):
        for f in ['manifest.xml','resources/settings/properties.xml',
                  'resources/settings/settings.xml','resources/strings.xml']:
            with self.subTest(f=f): ET.parse(R/f)

    def test_original_application_id_preserved(self):
        app = ET.parse(R/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(app.get('version'),'3.26.20')

    def test_original_properties_unchanged(self):
        if not (B/'resources/settings/properties.xml').exists():
            self.skipTest('Baseline not installed')
        old, new = properties(B), properties(R)
        self.assertEqual(len(old),74)
        self.assertEqual(len(new),82)
        self.assertEqual({k:new[k] for k in old},old)

    def test_new_settings_and_defaults(self):
        p=properties(R)
        self.assertEqual(p['srProviderV326'],('number','0'))
        self.assertEqual(p['srOpenKeyV326'],('string',''))
        self.assertEqual(p['srOwmMinutesV326'],('number','5'))
        self.assertEqual(p['srOwmAirV326'],('boolean','true'))
        self.assertEqual(p['srOwmAqiMinV326'],('number','4'))
        self.assertEqual(p['srPrecipModeV3263'],('number','1'))
        self.assertEqual(p['srOwmGustV3263'],('number','15'))
        self.assertEqual(p['srOwm15MinV3264'],('boolean','true'))

    def test_all_properties_have_menu_or_are_legacy_historical(self):
        settings=ET.parse(R/'resources/settings/settings.xml').getroot()
        keys=[x.get('propertyKey','').replace('@Properties.','') for x in settings]
        self.assertEqual(len(keys),len(set(keys)))
        for k in ('srProviderV326','srOpenKeyV326','srOwmMinutesV326',
                  'srOwmAirV326','srOwmAqiMinV326',
                  'srPrecipModeV3263','srOwmGustV3263', 'srOwm15MinV3264'):
            self.assertIn(k,keys)

    def test_two_providers_no_fusion(self):
        s=source('SolarOpenData.mc')
        self.assertIn('srProviderV326',s)
        self.assertIn('srSetting("srProviderV326", 0) == 1',s)
        self.assertNotIn('fusionModeV325',source('SolarRings7X.mc'))

    def test_one_foreground_weather_snapshot_for_all_fields(self):
        s=source('SolarRings7X.mc')
        self.assertIn('_cachedWeather = srOwmVisibleCurrent()',s)
        self.assertIn('_cachedWeather = Weather.getCurrentConditions()',s)
        self.assertIn('var w = getCachedConditions()',s)
        self.assertIn('outerProgressRing(dc, monitor, w',s)
        self.assertIn('drawWeather(dc, monitor, w)',s)
        self.assertIn('drawWeatherAge(dc, w)',s)
        self.assertIn('drawAlertCenter(dc, w)',s)
        self.assertIn('readField(id, monitor, weather)',s)

    def test_openweather_only_no_fallback_weather(self):
        s=source('SolarOpenData.mc')
        self.assertIn('if (!srUseOpenWeather() || !srOwmKeyReady()) { return null; }',s)
        self.assertNotIn('Weather.getCurrentConditions()',s)
        self.assertIn('if (d == null) { return null; }',s)

    def test_4_0_current_is_one_item_array(self):
        s=source('SolarOpenNetwork.mc')
        self.assertIn('var currentRows = data["data"]',s)
        self.assertIn('currentRows.size() > 0',s)
        self.assertIn('d = currentRows[0]',s)
        self.assertIn('dictionary(d) && num(d["dt"])',s)

    def test_4_0_forecast_is_array_and_aqi_is_list(self):
        s=source('SolarOpenNetwork.mc')
        self.assertIn('"timeline/1h"',s) if '"timeline/1h"' in s else self.assertIn('onecall/timeline/1h',s)
        self.assertIn('var records = data["data"]',s)
        self.assertIn('var air = data["list"]',s)
        self.assertIn('"srOCurrV326"',s)
        self.assertIn('"srOHoursV326"',s)

    def test_wind_threshold_same_numeric_for_both(self):
        g=source('GarminWeatherWarnings.mc')
        o=source('SolarOpenWarnings.mc')
        for s in (g,o):
            self.assertIn('validMeasure(wind, 0, 120)',s)
            self.assertIn('wind >= srSetting("gwWindV332", 10)',s)
        self.assertIn('validMeasure(gust, 0, 150)',o)
        self.assertIn('srOwmGustV3263',o)
        self.assertNotIn('wind == null && (code == 771',o)

    def test_fog_visibility_threshold_consistent(self):
        g=source('GarminWeatherWarnings.mc')
        o=source('SolarOpenWarnings.mc')
        for s in (g,o): self.assertIn('visibility <= srSetting("gwFogMetersV332", 500)',s)
        self.assertIn('lowVisibility || code == 741',o)
        self.assertIn('lowVisibility || c == Weather.CONDITION_FOG',g)

    def test_no_comparison_glyphs_or_extra_current_weather_api(self):
        s=source('SolarRings7X.mc')
        self.assertNotIn('SolarFusionMatcher',s)
        self.assertNotIn('drawFusionMarker',s)
        self.assertNotIn('srFCompare',s)

    def test_classifiers_are_separate_from_icons(self):
        self.assertIn('class SolarOpenWarnings extends GarminWeatherWarnings',source('SolarOpenWarnings.mc'))
        self.assertIn('GarminWeatherWarnings.allWarnings(null)',source('SolarOpenWarnings.mc'))
        s=source('SolarRings7X.mc')
        self.assertIn('drawGarminWarningIcon(dc, x, 228, tag)',s)
        self.assertIn('hasForecastUnderline',s)
        self.assertIn('drawAlertGlyph(dc, 45, -1)',s)

    def test_forecast_horizon_does_not_exceed_requested_hours(self):
        s=source('SolarOpenWarnings.mc')
        self.assertIn('h[0] > now + horizon * 3600',s)
        self.assertIn('h[0] <= now',s)
        self.assertIn('futureKinds[z] + 16',s)

    def test_only_one_http_request_per_background_event(self):
        s=source('SolarOpenNetwork.mc')
        self.assertEqual(s.count('Comm.makeWebRequest('),1)
        self.assertIn('Bg.registerForTemporalEvent(',s)
        self.assertIn('if (!Sys.getDeviceSettings().phoneConnected)',s)
        self.assertIn('if (_unsafe) { seconds = 6 * 3600; }',s)

    def test_no_active_gps_request(self):
        for p in (R/'source').glob('*.mc'):
            self.assertNotIn('Position.enableLocationEvents(',p.read_text().split('// Use last existing')[0] if p.name=='SolarOpenData.mc' else p.read_text().split('// Use last existing')[0])

    def test_aqi_is_explicit_and_optional(self):
        s=source('SolarOpenWarnings.mc')
        self.assertIn('srOwmAirV326',s)
        self.assertIn('srOwmAqiMinV326',s)
        self.assertIn('addAlert(_lastKinds, 12 + (now - air[3] > 2700 ? 64 : 0))',s)
        self.assertIn('now - air[3] <= 90 * 60',s)

    def test_weather_missing_is_not_replaced_with_garmin(self):
        s=source('SolarOpenData.mc')
        self.assertIn('highTemperature = daily == null ? null : daily[5]',s)
        self.assertIn('lowTemperature = daily == null ? null : daily[4]',s)
        self.assertIn('function srOwmDailySnapshot()',s)
        self.assertIn('return null',s)

    def test_daily_temperature_uses_owm_daily_timeline(self):
        n=source('SolarOpenNetwork.mc')
        d=source('SolarOpenData.mc')
        self.assertIn('onecall/timeline/1day',n)
        self.assertIn('var days = data["data"]',n)
        self.assertIn('temps["min"]',n)
        self.assertIn('temps["max"]',n)
        self.assertIn('currentDay = ((_now + tz) / 86400).toNumber()',n)
        self.assertIn('if (localDay != d[3]) { return null; }',d)
        self.assertIn('srOwmWrite("srODayV326", null)',d)

    def test_sun_fields_never_fall_back_to_garmin_when_owm_selected(self):
        s=source('FieldData.mc')
        self.assertIn('if (srUseOpenWeather())',s)
        self.assertIn('return "--:--"',s)
        self.assertIn('return null;\n    }\n    var now = Time.now();',s)

    def test_garmin_sdk_watchface_location_is_cached_only(self):
        d=source('SolarOpenData.mc')
        self.assertIn('activityInfo.currentLocation',d)
        self.assertNotIn('var info = Position.getInfo()',d)
        self.assertNotIn('Position.enableLocationEvents()',d)

    def test_callback_loss_has_conservative_watchdog(self):
        s=source('SolarOpenNetwork.mc')
        self.assertIn('if (!write(nextKey, nextEpoch))',s)
        self.assertIn('new Time.Duration(15 * 60)',s)
        self.assertIn('method(:onReceive)',s)

    def test_api_key_rotation_resets_schedule(self):
        s=source('SolarOpenData.mc')
        self.assertIn('key.hashCode()',s)
        self.assertIn('srOKeyHashV326',s)
        self.assertIn('if (modeChanged || keyChanged)',s)

    def test_diagnostics_respect_selected_provider(self):
        s=source('SolarRings7X.mc')
        self.assertIn('srUseOpenWeather() ? srOwmForecastSnapshot()',s)
        self.assertIn('diagnosticsSource = "TEST 15: OWM 15M"',s)

    def test_no_imgw_or_other_provider(self):
        src='\n'.join(p.read_text().lower() for p in (R/'source').glob('*.mc'))
        self.assertNotIn('warningsmeteo',src)
        self.assertNotIn('open-meteo.com',src)

    def test_location_metadata_not_meteorology(self):
        s=source('SolarOpenData.mc')
        self.assertIn('Activity.getActivityInfo()',s)
        self.assertNotIn('var info = Position.getInfo()',s)
        self.assertIn('srOwmUpdateLocation(garmin)',s)
        self.assertIn('srOwmSamePlace(d, loc)',s)

    def test_provider_change_refreshes_warning_cache(self):
        s=source('SolarRings7X.mc')
        self.assertIn('srOwmProviderChanged()',s)
        self.assertIn('rebuildWeatherWarnings()',s)
        # Since v3.26.20, the settings callback only signals an update.
        # Weather warnings are refreshed later; costly full-cache resets are forbidden.
        cb=s.split('function onSettingsChanged()',1)[1].split('function markSettingsChanged()',1)[0]
        self.assertIn('_face.markSettingsChanged()',cb)
        self.assertNotIn('_face.resetPerformanceCaches()',cb)
        refresh=s.split('function refreshChangedSettings()',1)[1].split('function rebuildWeatherWarnings()',1)[0]
        self.assertIn('if (open != _srSelectedProvider)',refresh)
        self.assertIn('rebuildWeatherWarnings()',refresh)
        self.assertIn('_weatherWarnings.reset()',refresh)

if __name__ == '__main__': unittest.main()
