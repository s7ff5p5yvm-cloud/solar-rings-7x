# Solar Rings v3.26.20 — poprawka testów CI (bez zmiany kodu tarczy)

## Problem w GitHub Actions
Etap `Verify version, weather tests and XML` kończył się kodem 1 po 7 błędach testów źródłowych. Były to nieaktualne oczekiwania odziedziczone z 3.26.13:
- pięć sprawdzeń wersji manifestu `3.26.13` zamiast `3.26.20`;
- domyślna częstotliwość OWM `30` zamiast `5` minut (jednocześnie w tym samym teście AQI `false` zamiast `true`);
- sprawdzenie wywołania `_face.resetPerformanceCaches()` w callbacku ustawień, usuniętego celowo w v3.26.20 w celu zmniejszenia ryzyka błędów pamięci.

## Zmiany
Zmodyfikowano jedynie sześć plików `tests_provider/test_*.py` oraz dodano ten raport. **Pliki źródłowe `.mc`, XML, `manifest.xml`, `check_version.py` i `BUILD.yml` pozostają identyczne bajtowo z poprzednią paczką 3.26.20.**

## Zakres weryfikacji
Testy wykonują kontrolę tekstu źródłowego i pomocniczych modeli Python; nie zastępują kompilacji SDK Monkey C ani testowania zadań pogodowych na zegarku. Aktualna paczka nie naprawia ewentualnych błędów runtime. Po udanej kompilacji trzeba przeprowadzić test ustawień (pierścień i temperatura odczuwalna), pobierania OWM i logów CIQ.
