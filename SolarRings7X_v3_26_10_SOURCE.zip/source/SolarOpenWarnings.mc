using Toybox.Time as Time;

// OWM conditions -> EXACTLY the packed tags of GarminWeatherWarnings.
// Thus the v3.24.32 glyphs, colors, cyan underline and StormGuard are reused.
// Codes are NEVER equated numerically with Garmin condition constants.
class SolarOpenWarnings extends GarminWeatherWarnings {
    function initialize() { GarminWeatherWarnings.initialize(); }

    function kindsFor(code, wind, temp, visibility, uv, pop, rainRate, snowRate, gust, forecast) {
        var k = [];
        // Shared units: m/s, Celsius, metres, UV. OWM additionally provides
        // GUSTS; the Garmin Weather API has no corresponding hourly gust value.
        var extremeWind = code == 771 || code == 781;
        var fastWind = validMeasure(wind, 0, 120) &&
                       wind >= srSetting("gwWindV332", 10);
        var fastGust = validMeasure(gust, 0, 150) &&
                       gust >= srSetting("srOwmGustV3263", 15);
        if (srSetting("gwWindOnV332", true) && !extremeWind &&
            (fastWind || fastGust)) { addAlert(k, 1); }
        if (srSetting("gwUvOnV332", false) && validMeasure(uv, 0, 30) &&
            uv >= srSetting("gwUvV332", 7)) { addAlert(k, 9); }
        // Unsupported code cannot create a weather-category warning, but a
        // valid visibility measurement still indicates reduced visibility.
        if (code == null || srOwmMappedCondition(code) == null) {
            if (srSetting("gwFogOnV332", true) &&
                validMeasure(visibility, 0, 100000) &&
                visibility <= srSetting("gwFogMetersV332", 500)) {
                addAlert(k, 6);
            }
            return k;
        }
        var storm = (code >= 200 && code <= 232); // validated above
        var rain = (code >= 300 && code <= 321) ||
                   (code >= 500 && code <= 504) ||
                   (code >= 520 && code <= 531);
        var snow = code >= 600 && code <= 622;
        var mix = code == 611 || code == 612 || code == 613 ||
                  code == 615 || code == 616;
        var freezing = code == 511;
        // A squall or tornado is an explicitly named extreme phenomenon,
        // NOT evidence that the numerical wind-speed threshold was exceeded.
        if (srSetting("gwWindOnV332", true) && extremeWind) { addAlert(k, 13); }
        if (srSetting("gwStormOnV332", true) && storm) { addAlert(k, 4); }
        if (srSetting("gwFreezeOnV332", true) && freezing) { addAlert(k, 5); }
        if (srSetting("gwAirOnV332", true) &&
            (code == 711 || code == 731 || code == 751 ||
             code == 761 || code == 762)) { addAlert(k, 10); }
        // 741 is an explicit fog report even when the visibility measurement
        // disagrees. Independently flag very poor visibility of any cause.
        var lowVisibility = validMeasure(visibility, 0, 100000) &&
            visibility <= srSetting("gwFogMetersV332", 500);
        if (srSetting("gwFogOnV332", true) &&
            (lowVisibility || code == 741)) { addAlert(k, 6); }
        // Forecast POP is the chance of ANY precipitation. Unlike v3.26.2,
        // use it to filter rain/snow/mix forecasts in BOTH weather providers.
        // Present conditions always bypass POP. Missing POP is NOT 0%.
        // Severe weather (storms/freezing rain/tornado) does NOT use POP as
        // a proxy for probability of lightning or other harmful events.
        var rainAllowed = !forecast || forecastChanceMatches(pop,
            srSetting("gwRainChanceV332", 30));
        var snowAllowed = !forecast || forecastChanceMatches(pop,
            srSetting("gwSnowChanceV332", 40));
        // Mix is one glyph. In custom mode choose the lower of ENABLED rain
        // and snow thresholds, as in Garmin's existing mixed-category logic.
        var mixedLimit = 100;
        if (srSetting("gwRainOnV332", true)) {
            mixedLimit = srSetting("gwRainChanceV332", 30);
        }
        if (srSetting("gwSnowOnV332", true)) {
            var snowLimit = srSetting("gwSnowChanceV332", 40);
            if (snowLimit < mixedLimit) { mixedLimit = snowLimit; }
        }
        var mixAllowed = !forecast || forecastChanceMatches(pop, mixedLimit);
        if (mix) {
            var mixOn = (srSetting("gwRainOnV332", true) &&
                         !srSetting("gwRainHeavyV332", false)) ||
                        (srSetting("gwSnowOnV332", true) &&
                         !srSetting("gwSnowHeavyV332", false));
            if (mixOn && mixAllowed) { addAlert(k, 11); }
        } else {
            if (srSetting("gwRainOnV332", true) && rain && rainAllowed) {
                var heavyR = code == 502 || code == 503 || code == 504 ||
                             code == 522; // 531 = ragged, not heavy
                // Either an explicit heavy code OR a measured >=8mm/h rate.
                // Never demote a heavy code solely due to inconsistent rate.
                heavyR = heavyR || (validMeasure(rainRate, 0, 500) &&
                                    rainRate >= 8);
                if (!srSetting("gwRainHeavyV332", false) || heavyR) { addAlert(k, 2); }
            }
            if (srSetting("gwSnowOnV332", true) && snow && snowAllowed) {
                var heavyS = code == 602 || code == 622;
                if (!srSetting("gwSnowHeavyV332", false) || heavyS) { addAlert(k, 3); }
            }
        }
        // Road ice is an estimate, not a measured road-surface condition.
        // Avoid duplicated "freezing rain + ice" for the same hazard.
        if (srSetting("gwIceOnV332", true) && !freezing &&
            validMeasure(temp, -100, 80) &&
            temp <= srSetting("gwIceTempV332", 1) &&
            (rain || snow || mix) &&
            (!forecast || iceChanceMatches(pop))) {
            addAlert(k, 7);
        }
        // No confirmed hail code in standard OWM weather IDs: don't invent it.
        // General POP is not a thunderstorm or hail probability.
        return k;
    }

    function allWarnings(current) {
        var preview = srSetting("gwPreviewV332", 0);
        if (preview > 0 && preview <= 14) {
            // Reuse exactly the original v3.24 demonstration states.
            return GarminWeatherWarnings.allWarnings(null);
        }
        var weatherEnabled = srSetting("gwOnV332", true);
        if (!weatherEnabled && !srSetting("srOwmAirV326", false)) {
            reset();
            return [];
        }
        var now = Time.now().value();
        var period = srSetting("gwIntervalV332", 15);
        if (period < 5) { period = 5; }
        if (period > 60) { period = 60; }
        if (_lastCheck > 0 && now >= _lastCheck &&
            now - _lastCheck < period * 60) { return _lastKinds; }
        _lastCheck = now;
        _lastKinds = [];
        var d = srOwmCurrentSnapshot();
        if (weatherEnabled && d != null) {
            var elapsed = now - d[3];
            if (elapsed >= -300 && elapsed <= 5400) {
                var currentKinds = kindsFor(d[11],d[6],d[4],d[9],d[8],
                                            d[16],d[17],d[18],d[15],false);
                for (var i = 0; i < currentKinds.size(); i++) {
                    addAlert(_lastKinds, currentKinds[i] + (elapsed > 2700 ? 64 : 0));
                }
            }
        }
        if (weatherEnabled && srSetting("gwForecastV332", true)) {
            var hourly = srOwmForecastSnapshot();
            if (hourly != null) {
                var horizon = srSetting("gwHorizonV332", 1);
                if (horizon < 1) { horizon = 1; }
                if (horizon > 3) { horizon = 3; }
                for (var j = 0; j < hourly.size(); j++) {
                    var h = hourly[j];
                    if (h == null || !(h instanceof Toybox.Lang.Array) ||
                        h.size() < 10 || !srOwmNumber(h[0]) ||
                        h[0] <= now || h[0] > now + horizon * 3600) { continue; }
                    var futureKinds = kindsFor(h[1],h[2],h[3],h[8],h[4],
                                                h[5],h[6],h[7],h[9],true);
                    for (var z = 0; z < futureKinds.size(); z++) {
                        addAlert(_lastKinds, futureKinds[z] + 16);
                    }
                }
            }
        }
        // AQI is optional, independent of Garmin condition codes, and lower
        // priority than every weather warning in the same 3-cell group.
        if (srSetting("srOwmAirV326", false)) {
            var air = srOwmRead("srOAirV326");
            if (air != null && air instanceof Toybox.Lang.Array && air.size() == 5 &&
                srOwmSamePlace(air, srOwmRead("srOLocV326")) &&
                srOwmNumber(air[3]) && air[3] <= now + 300 &&
                now - air[3] <= 90 * 60 && srOwmNumber(air[4]) &&
                air[4] >= srSetting("srOwmAqiMinV326", 4)) {
                addAlert(_lastKinds, 12);
            }
        }
        return orderAlerts(_lastKinds);
    }
}
