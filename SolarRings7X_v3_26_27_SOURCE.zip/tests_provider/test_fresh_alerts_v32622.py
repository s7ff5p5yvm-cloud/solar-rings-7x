import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
W=(ROOT/'source/SolarOpenWarnings.mc').read_text()
N=(ROOT/'source/SolarOpenNetwork.mc').read_text()
F=(ROOT/'source/SolarRings7X.mc').read_text()
R=(ROOT/'resources/settings/properties.xml').read_text()

class FreshAlerts32622(unittest.TestCase):
    def test_current_precipitation_uses_current_codes_only(self):
        self.assertNotIn('recentPrecipitation(',W)
        self.assertNotIn('addAlert(out, 66)',W)
        self.assertNotIn('addAlert(out, 67)',W)
        self.assertNotIn('addAlert(out, 75)',W)
        self.assertIn('var currentKinds = kindsFor(',W)
        self.assertIn('(forecast && measuredRain && !freezing)',W)
        self.assertIn('(forecast && measuredSnow)',W)
    def test_forward_looking_alerts_intact(self):
        self.assertIn('var futureKinds = kindsFor(',W)
        self.assertIn('addAlert(_lastKinds, futureKinds[z] + 16);',W)
        for code in [2,3,4,5,6,7,10,11,13]:
            self.assertIn('addAlert(k, '+str(code)+')',W)
    def test_max_safe_background_cadence_unchanged(self):
        self.assertIn('id="srOwmMinutesV326" type="number">5<',R)
        self.assertIn('id="gwIntervalV332" type="number">5<',R)
        self.assertIn('return _interval == 5 ? 10 * 60 : _interval * 60;',N)
        self.assertIn('return _interval == 5 ? 10 * 60 : _interval * 120;',N)
        self.assertIn('if (seconds < 300) { seconds = 300; }',N)
        self.assertEqual(N.count('Comm.makeWebRequest('),1)
        self.assertIn('onBackgroundData(data)',F)
        self.assertIn('_face.resetWeatherWarningCache();',F)
        self.assertIn('Ui.requestUpdate();',F)
    def test_original_safe_positions_and_no_stormguard(self):
        self.assertIn('var centers = [68, 91, 114];',F)
        self.assertIn('if (fixedCount > 3) { fixedCount = 2; }',F)
        self.assertNotIn('new StormGuard()',F)
        self.assertIn('dc.setClip(103, 217, 22, 26);',F)
    def test_version_and_identity(self):
        app=ET.parse(ROOT/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(app.get('version'),'3.26.27')

if __name__=='__main__': unittest.main()
