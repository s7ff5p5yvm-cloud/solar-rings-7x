import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1]
UI=(P/'source/SolarRings7X.mc').read_text()
CFG=(P/'source/Config.mc').read_text()
NW=(P/'source/SolarOpenNetwork.mc').read_text()
OD=(P/'source/SolarOpenData.mc').read_text()
OW=(P/'source/SolarOpenWarnings.mc').read_text()
PR={v.get('id'):(v.text or '').strip() for v in ET.parse(P/'resources/settings/properties.xml').getroot()}

class RestoreStableSettings32620(unittest.TestCase):
    def test_callback_is_nonallocating(self):
        cb=UI.split('function onSettingsChanged()',1)[1].split('\n    }',1)[0]
        for expensive in ('rebuildWeatherWarnings(', 'resetPerformanceCaches(', 'srOwmProviderChanged(', 'new ', 'Storage.setValue(', 'Properties.setValue('):
            self.assertNotIn(expensive,cb)
        self.assertIn('_face.markSettingsChanged()',cb)
        self.assertIn('srResetSettingsCache()',cb)
    def test_never_show_hold_screen(self):
        self.assertIn('refreshChangedSettings();',UI)
        self.assertNotIn('ODSWIEZANIE USTAWIEN',UI)
        self.assertNotIn('freeMemory >= 30000',UI)
        self.assertNotIn('onUpdate(dc)',CFG)
    def test_provider_rebuilt_only_on_actual_change(self):
        sub=UI.split('function refreshChangedSettings()',1)[1].split('function rebuildWeatherWarnings()',1)[0]
        self.assertIn('open != _srSelectedProvider',sub)
        self.assertIn('srOwmProviderChanged()',sub)
        self.assertIn('if (_weatherWarnings != null)',sub)
    def test_background_refresh_never_resets_entire_view(self):
        sub=UI.split('function onBackgroundData(data)',1)[1].split('function onSettingsChanged()',1)[0]
        self.assertIn('_face.invalidateWeatherOnly()',sub)
        self.assertNotIn('_face.resetPerformanceCaches()',sub)
    def test_refresh_defaults_and_aqi(self):
        self.assertEqual(PR['srOwmMinutesV326'],'5')
        self.assertEqual(PR['gwIntervalV332'],'5')
        self.assertEqual(PR['gwHorizonV332'],'3')
        self.assertEqual(PR['srOwmAirV326'],'true')
        self.assertEqual(PR['srOwmAqiMinV326'],'4')
    def test_bounded_json_and_circuit_breaker(self):
        self.assertIn('q["cnt"] = "12"',NW)
        self.assertIn('q["cnt"] = "2"',NW)
        self.assertIn('srOShortPausedV3264',NW)
        self.assertIn('if (used >= 700)',NW)
        self.assertEqual(NW.count('Comm.makeWebRequest('),1)
    def test_full_warnings_model(self):
        for name in ('gwWindOnV332','gwStormOnV332','gwFreezeOnV332','gwRainOnV332','gwSnowOnV332','gwFogOnV332','gwIceOnV332','srOwmAirV326'):
            self.assertIn(name,OW)
        self.assertIn('forecastChanceMatches(pop,',OW)
        self.assertIn('h[0] > now + horizon * 3600',OW)
        self.assertIn('srOwmForecastStepSeconds()',OD+OW)
    def test_no_new_keys_or_changed_garmin_id(self):
        app=ET.parse(P/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.get('version'),'3.26.27')
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertIn('gwPreviewV332',CFG)

if __name__=='__main__': unittest.main()
