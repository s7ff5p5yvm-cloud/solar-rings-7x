"""Regression: Garmin Lang.String.substring REQUIRES two arguments.
Root cause of repeated CIQ `Not Enough Arguments Error` in v3.26.25.
"""
import re
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class SubstringArityTests(unittest.TestCase):
    def test_all_monkeyc_substring_calls_supply_two_arguments(self):
        seen=0
        for source in (ROOT/'source').glob('*.mc'):
            content=source.read_text()
            for match in re.finditer(r'\.substring\s*\(',content):
                # Parse parentheses, including nested length() expressions.
                ix=match.end()
                depth=0
                commas=0
                while ix<len(content):
                    ch=content[ix]
                    if ch=='(':
                        depth+=1
                    elif ch==')':
                        if depth==0: break
                        depth-=1
                    elif ch==',' and depth==0:
                        commas+=1
                    ix+=1
                self.assertLess(ix,len(content),source.name+' unterminated substring call')
                self.assertEqual(commas,1, f'{source.name}: substring requires 2 arguments: {content[match.start():ix+1]}')
                seen+=1
        self.assertGreaterEqual(seen,9)

    def test_date_uses_explicit_end_index(self):
        face=(ROOT/'source/SolarRings7X.mc').read_text()
        self.assertIn('dateLabel.substring(splitAt + 1, dateLabel.length())',face)
        self.assertNotIn('dateLabel.substring(splitAt + 1);',face)

if __name__ == '__main__': unittest.main()
