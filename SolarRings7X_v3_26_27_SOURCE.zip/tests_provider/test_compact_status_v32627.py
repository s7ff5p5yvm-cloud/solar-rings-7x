"""Contracts for final centered clock and single-line BT + observation age.
Source-level geometry checks; Garmin hardware rendering still required.
"""
from pathlib import Path
import re
import unittest
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()

class CompactStatusTests(unittest.TestCase):
    def test_clock_pairs_are_bold_and_closer_together(self):
        clock=FACE.split('function drawClock(dc, clock) {')[1].split('// Mini digits',1)[0]
        self.assertIn('var pairW = 72;', clock)
        for coords in ('59', '60', '138', '139'):
            self.assertIn('dc.drawText('+coords+', yy, font,',clock)
        self.assertIn('dc.drawText(98, yy, font, ":"',clock)
        self.assertNotIn('dc.drawText(55, yy, font, hourText',clock)
        self.assertNotIn('dc.drawText(142, yy, font, minuteText',clock)
        self.assertIn('fitScaled(dc, hourText, 59, top',clock)
        self.assertIn('fitScaled(dc, minuteText, 138, top',clock)

    def test_date_does_not_overlap_shared_status_row(self):
        date=FACE.split('function drawDate(dc, dayLabel, dateLabel) {')[1].split('// Connection status',1)[0]
        self.assertIn('dayLabel, 226, 71, 82, 20',date)  # max y91
        self.assertIn('dayNumber, 203, 92, 40, 26',date) # max y118
        self.assertIn('monthText, 244, 92, 42, 26',date)
        self.assertIn('dateLabel.substring(splitAt + 1, dateLabel.length())',date)
        self.assertNotIn('dayNumber, 193, 103, 30, 29',date)

    def test_bluetooth_age_adjacent_and_bounded_for_double_digits(self):
        phone=FACE.split('function drawPhoneBluetooth(dc) {')[1].split('// Observation age supplied',1)[0]
        age=FACE.split('function drawWeatherAge(dc, current) {')[1].split('// Native 1px separators',1)[0]
        self.assertIn('dc.drawLine(194, 119, 194, 133)',phone)
        self.assertIn('dc.drawLine(189, 133, 199, 119)',phone)
        self.assertIn('drawSized(dc, ageLabel, 239, 119, 70, 15',age)
        self.assertIn('drawPhoneBluetooth(dc);',age)
        self.assertIn('ageLabel = minutes.toString() + "m";',age)
        self.assertIn('ageLabel = hours.toString() + "h" + remainingMinutes.toString() + "m";',age)
        # x of age is center-35 .. center+35 => 204..274.
        bt_x=(189,199)
        age_x=(239-70//2,239+70//2)
        self.assertGreaterEqual(age_x[0]-bt_x[1],4)
        self.assertLessEqual(age_x[1],274)
        self.assertEqual((119+15),134)
        self.assertLess(134,135) # rule below date section

    def test_preserve_weather_and_sleep_core_exactly(self):
        prev=Path('/mnt/data/SolarRings7X_v3_26_26_RECOVERY_SOURCE/source')
        for name in ('SolarOpenNetwork.mc','SolarOpenData.mc','SolarOpenWarnings.mc',
                     'WeatherGeocode.mc','SolarWeatherCodes.mc','GarminWeatherWarnings.mc',
                     'FieldData.mc','Config.mc'):
            older=prev/name
            if older.exists():
                self.assertEqual((ROOT/'source'/name).read_bytes(),older.read_bytes(),name)

if __name__=='__main__': unittest.main()
