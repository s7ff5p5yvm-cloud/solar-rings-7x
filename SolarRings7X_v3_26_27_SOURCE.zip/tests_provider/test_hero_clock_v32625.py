"""Static contracts for the 3.26.27 hero clock geometry.
These do not replace compiling with Garmin Monkey C and device testing.
"""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT / 'source/SolarRings7X.mc').read_text()

class HeroClockTests(unittest.TestCase):
    def test_pairwise_clock_fitting_is_really_larger(self):
        clock = FACE.split('function drawClock(dc, clock) {')[1].split('// Mini digits',1)[0]
        self.assertIn('var slotH = 60;', clock)
        self.assertIn('var pairW = 72;', clock)
        self.assertIn('var requested = 94;', clock)
        self.assertIn('dc.getTextDimensions("88", probe)', clock)
        self.assertIn('dc.drawText(59, yy, font, hourText', clock)
        self.assertIn('dc.drawText(138, yy, font, minuteText', clock)
        self.assertIn('fitScaled(dc, hourText', clock)
    def test_date_can_scale_independently(self):
        date = FACE.split('function drawDate(dc, dayLabel, dateLabel) {')[1].split('// Connection status',1)[0]
        self.assertIn('dateLabel.substring(0, splitAt)',date)
        self.assertIn('dateLabel.substring(splitAt + 1, dateLabel.length())',date)
        self.assertIn('dayNumber, 203, 92, 40, 26',date)
        self.assertIn('monthText, 244, 92, 42, 26',date)
    def test_no_cross_lane_overflow(self):
        # Clock ends x=178; date begins at x=178; no theoretical overlap
        # only at the bounding boxes, never the measured text extent.
        self.assertIn('drawText(138, yy, font, minuteText', FACE)
        self.assertIn('drawSized(dc, ageLabel, 239, 119, 70, 15',FACE)
        self.assertIn('dc.drawLine(194, 119, 194, 133);',FACE)
        self.assertIn('rule(dc, 70);',FACE)
        self.assertIn('rule(dc, 135);',FACE)
        self.assertIn('var centers = [68, 91, 114];',FACE)
    def test_moon_lane_and_city_remain_fitted(self):
        moon = FACE.split('function drawMoonPanel(dc, weather) {')[1].split('function topSlot(',1)[0]
        self.assertIn('drawLunarDisk(dc, 52, 150, 12)', moon)
        self.assertIn('drawSized(dc, location, 188, 136, 126, 25',moon)
        self.assertIn('fieldPixels("moonFontV38", "fontWeatherV31", 27, 2)', moon)
    def test_weather_warnings_unmodified(self):
        src=(ROOT/'source/SolarOpenWarnings.mc').read_bytes()
        previous=Path('/mnt/data/solar32624_geo_diag_final/source/SolarOpenWarnings.mc')
        if previous.exists():
            self.assertEqual(src, previous.read_bytes())
        self.assertIn('rule(dc, 215);', FACE)
        self.assertIn('rule(dc, 250);', FACE)

if __name__ == '__main__': unittest.main()
