using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Position as Position;
using Toybox.Activity as Activity;
using Toybox.Lang as Lang;
using Toybox.Time as Time;
using Toybox.Weather as Weather;

// One source for ALL meteorological fields. Garmin is the default.
// Neither class below starts GPS. Garmin/position metadata is used solely
// to locate the OWM request; weather measurements never fall back to Garmin.
function srUseOpenWeather() {
    return srSetting("srProviderV326", 0) == 1;
}
function srOwmKeyReady() {
    var key = srSetting("srOpenKeyV326", "");
    return key != null && key instanceof Lang.String && key.length() >= 8;
}
function srOwmNumber(v) {
    return v != null && (v instanceof Lang.Number || v instanceof Lang.Long ||
                          v instanceof Lang.Float || v instanceof Lang.Double);
}
function srOwmRead(key) {
    try { return App.Storage.getValue(key); } catch (e) { return null; }
}
function srOwmWrite(key, data) {
    try {
        App.Storage.setValue(key, data);
        return true;
    } catch (e) { return false; }
}
function srOwmCoordsValid(a) {
    return a != null && a instanceof Lang.Array && a.size() >= 2 &&
           srOwmNumber(a[0]) && srOwmNumber(a[1]) &&
           a[0] >= -90 && a[0] <= 90 && a[1] >= -180 && a[1] <= 180;
}
function srOwmSamePlace(a, b) {
    return srOwmCoordsValid(a) && srOwmCoordsValid(b) &&
           a[0] > b[0] - 0.025d && a[0] < b[0] + 0.025d &&
           a[1] > b[1] - 0.035d && a[1] < b[1] + 0.035d;
}

// A unified view of weather for the EXISTING readField(), drawWeather(),
// weatherSymbol(), temperatureMarker(), age display and moon-city panel.
// Snapshot layout: lat,lon,fetchUTC,observationUTC,temp,feels,wind,humidity,
// uv,visibility,clouds,code,pressure,sunriseUTC,sunsetUTC,gust,pop%,rain,snow.
// Missing fields remain null: NEVER use Garmin values as substitutes.
class SolarOpenConditions {
    var temperature;
    var feelsLikeTemperature;
    var windSpeed;
    var relativeHumidity;
    var uvIndex;
    var visibility;
    var cloudCover;
    var precipitationChance;
    var highTemperature;
    var lowTemperature;
    var condition;
    var observationTime;
    var observationLocationPosition;
    var observationLocationName;
    var sunriseUtc;
    var sunsetUtc;

    function initialize(data, forecast, daily) {
        temperature = data[4];
        feelsLikeTemperature = data[5];
        windSpeed = data[6];
        relativeHumidity = data[7];
        uvIndex = data[8];
        visibility = data[9];
        cloudCover = data[10];
        condition = srOwmCondition(data[11]);
        precipitationChance = data[16];
        // -1 is an invalid OWM POP sentinel, never show -1% on the dial.
        if (precipitationChance != null && precipitationChance < 0) {
            precipitationChance = null;
        }
        // Current endpoint may omit POP; use nearest OWM forecast if VALID,
        // never Garmin precipitationChance. This field is informational only.
        if (precipitationChance == null && forecast != null &&
            forecast.size() > 0 && forecast[0] != null &&
            forecast[0].size() > 5 && forecast[0][5] != null &&
            srOwmNumber(forecast[0][5]) && forecast[0][5] >= 0) {
            precipitationChance = forecast[0][5];
        }
        highTemperature = daily == null ? null : daily[5];
        lowTemperature = daily == null ? null : daily[4];
        sunriseUtc = data[13];
        sunsetUtc = data[14];
        observationTime = new Time.Moment(data[3].toNumber());
        observationLocationPosition = new Position.Location({
            :latitude => data[0], :longitude => data[1], :format => :degrees
        });
        observationLocationName = null;
        // Full-day min/max are read only from OWM's 1day endpoint.
        // Hourly maximum/minimum is never mislabeled as an all-day extreme.
    }
}

// Code-to-icon translation only. Warnings have an independent OWM rule engine.
function srOwmCondition(id) {
    return srOwmMappedCondition(id);
}

function srOwmCurrentSnapshot() {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return null; }
    var d = srOwmRead("srOCurrV326");
    var loc = srOwmRead("srOLocV326");
    var now = Time.now().value();
    if (d == null || !(d instanceof Lang.Array) || d.size() != 19 ||
        !srOwmCoordsValid(d) || !srOwmSamePlace(d, loc) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        d[3] > now + 300 || now - d[3] > 90 * 60 ||
        !srOwmNumber(d[4])) { return null; }
    return d;
}
function srOwmForecastSnapshot() {
    var now = Time.now().value();
    var enabled = srSetting("srOwm15MinV3264", true) == true;
    var paused = srOwmRead("srOShortPausedV3264");
    var f = null;
    if (enabled && (!srOwmNumber(paused) || paused <= now)) {
        f = srOwmRead("srOShortV3264");
        // Expired short timeline must not conceal an available hourly one.
        if (f == null || !(f instanceof Lang.Array) || f.size() != 4 ||
            !srOwmNumber(f[2]) || f[2] > now + 300 ||
            now - f[2] > 120 * 60) { f = null; }
    }
    if (f == null) { f = srOwmRead("srOHoursV326"); }
    var loc = srOwmRead("srOLocV326");
    if (f == null || !(f instanceof Lang.Array) || f.size() != 4 ||
        !srOwmSamePlace(f, loc) || !srOwmNumber(f[2]) ||
        f[2] > now + 300 || now - f[2] > 120 * 60 ||
        !(f[3] instanceof Lang.Array)) { return null; }
    return f[3];
}
function srOwmDailySnapshot() {
    var d = srOwmRead("srODayV326");
    var now = Time.now().value();
    if (d == null || !(d instanceof Lang.Array) || d.size() != 7 ||
        !srOwmSamePlace(d, srOwmRead("srOLocV326")) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        !srOwmNumber(d[4]) || !srOwmNumber(d[5]) ||
        !srOwmNumber(d[6]) || d[2] > now + 300 ||
        now - d[2] > 36 * 3600) { return null; }
    var localDay = ((now + d[6]) / 86400).toNumber();
    if (localDay != d[3]) { return null; }
    return d;
}
function srOwmVisibleCurrent() {
    var d = srOwmCurrentSnapshot();
    if (d == null) { return null; }
    try { return new SolarOpenConditions(d, srOwmForecastSnapshot(), srOwmDailySnapshot()); }
    catch (e) { return null; }
}

// Only one temporal background event exists. Called seldom: initial view,
// selected setting changed, or location changed. An existing event is reused.
function srOwmArmIfNeeded() {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return; }
    if (!srOwmCoordsValid(srOwmRead("srOLocV326"))) { return; }
    try {
        if (Bg.getTemporalEventRegisteredTime() != null) { return; }
        Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
    } catch (e) { }
}

// Use observation coordinates embedded in Garmin's cached weather response.
// If absent, the watch face can use only a cached Activity position (if
// available); Position.getInfo() is NOT used by watch faces. No GPS started.
// The position is metadata only, never a Garmin meteorological reading.
function srOwmUpdateLocation(garmin) {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return; }
    var coords = null;
    var stamp = 0;
    var now = Time.now().value();
    try {
        if (garmin != null && garmin.observationTime != null &&
            garmin.observationLocationPosition != null) {
            stamp = garmin.observationTime.value();
            coords = garmin.observationLocationPosition.toDegrees();
        }
    } catch (e) { coords = null; }
    if (coords == null || stamp <= 0 || now - stamp > 3 * 3600 || stamp > now + 300) {
        // Activity currentLocation is a last-known location only, not an
        // instantaneous GPS fix. Never let it supersede a valid recorded
        // Garmin weather location from another time or trigger active GPS.
        coords = null;
        var known = srOwmRead("srOLocV326");
        if (!srOwmCoordsValid(known)) {
            try {
                var activityInfo = Activity.getActivityInfo();
                if (activityInfo != null && activityInfo.currentLocation != null) {
                    coords = activityInfo.currentLocation.toDegrees();
                    stamp = now;
                }
            } catch (e) { coords = null; }
        }
    }
    if (!srOwmCoordsValid(coords) || stamp <= 0 ||
        stamp > now + 300 || now - stamp > 3 * 3600) { return; }
    var previous = srOwmRead("srOLocV326");
    if (srOwmCoordsValid(previous) && previous.size() >= 3 &&
        srOwmNumber(previous[2]) && previous[2] > stamp) { return; }
    var changed = !srOwmSamePlace(previous, coords);
    // Refresh the same-place fix no more than hourly, so a stationary
    // watch never expires after 12h and storage writes remain bounded.
    if (changed || previous == null || previous.size() < 3 ||
        (srOwmNumber(previous[2]) && stamp - previous[2] >= 3600)) {
        if (!srOwmWrite("srOLocV326", [coords[0], coords[1], stamp])) { return; }
        if (changed) {
            // New location: never draw old-city weather; replace stored data.
            srOwmWrite("srOCurrV326", null);
            srOwmWrite("srOHoursV326", null);
            srOwmWrite("srOShortV3264", null);
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srODayV326", null);
            srOwmWrite("srOAirV326", null);
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextDV326", 0);
            srOwmWrite("srONextAV326", 0);
        }
    }
    if (changed) {
        // A new city should not wait on a far-future scheduled OS event.
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
        } catch (e) { }
    } else { srOwmArmIfNeeded(); }
}

// Settings changes do not invalidate OWM measurements, only refresh the
// schedule when the provider or API key actually changes. We store a hash
// of the key, never a duplicate key in app Storage.
function srOwmProviderChanged() {
    var mode = srUseOpenWeather() ? 1 : 0;
    var oldMode = srOwmRead("srOLastModeV326");
    var key = srSetting("srOpenKeyV326", "");
    var keyStamp = key instanceof Lang.String ? key.hashCode() : 0;
    var oldKeyStamp = srOwmRead("srOKeyHashV326");
    var refresh = srSetting("srOwmMinutesV326", 30);
    if (refresh != 15 && refresh != 30 && refresh != 60) { refresh = 30; }
    var oldRefresh = srOwmRead("srORefreshV3263");
    var shortMode = srSetting("srOwm15MinV3264", true) == true;
    var oldShortMode = srOwmRead("srOShortEnabledV3264");
    var shortChanged = mode == 1 &&
        (oldShortMode == null || oldShortMode != shortMode);
    var modeChanged = oldMode == null || oldMode != mode;
    var keyChanged = mode == 1 && (oldKeyStamp == null || oldKeyStamp != keyStamp);
    var refreshChanged = mode == 1 && oldRefresh != refresh;
    if (modeChanged || keyChanged || refreshChanged || shortChanged) {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        srOwmWrite("srOLastModeV326", mode);
        srOwmWrite("srOKeyHashV326", keyStamp);
        srOwmWrite("srORefreshV3263", refresh);
        srOwmWrite("srOShortEnabledV3264", shortMode);
        if (shortChanged || keyChanged || modeChanged) {
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srOShortV3264", null);
        }
        if (mode == 0) {
            srOwmWrite("srGEventDue", 0);
        } else {
            // Changing cadence must affect CURRENT/HOURLY immediately;
            // retain fresh cached data and unrelated DAILY/AQI deadlines.
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            if (modeChanged || keyChanged) {
                srOwmWrite("srONextDV326", 0);
                srOwmWrite("srONextAV326", 0);
            }
        }
    }
    // Do not leave an old OWM timer armed after removing the API key.
    if (mode == 1 && !srOwmKeyReady()) {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        return;
    }
    srOwmArmIfNeeded();
}
