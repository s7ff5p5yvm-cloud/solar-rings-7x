import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
class TestResponseDiagnostics(unittest.TestCase):
    def test_restores_request_phase(self):
        self.assertIn('function restoreRequestContext()',NET)
        self.assertIn('if (_kind == "" && !restoreRequestContext())',NET)
        self.assertIn('"srOReqCtxV3267"',NET)
    def test_status_keeps_phase(self):
        self.assertIn('p = ctx[1]',NET)
        self.assertIn('write("srODiagV3266", [Time.now().value(), p, code]);',NET)
    def test_json_schema_stale_write_exception_separate(self):
        for c in ['-151','-152','-153','-154','-155','-19']:
            self.assertIn(c,NET)
            self.assertIn(c,FACE)
    def test_key_does_not_leak(self):
        self.assertNotIn('write("srOReqCtxV3267", [_now, phase(), _key',NET)
        self.assertNotIn('[_now, phase(), _key]',NET)
    def test_no_additional_network_requests(self):
        self.assertEqual(NET.count('Comm.makeWebRequest('),1)
    def test_release_version(self):
        self.assertIn('version="3.26.7"',(ROOT/'manifest.xml').read_text())
if __name__=='__main__':unittest.main()
