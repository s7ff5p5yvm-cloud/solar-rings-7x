#!/usr/bin/env python3
"""Static compatibility, configuration and geometry checks for v3.11.1.
Not a substitute for Monkey C compiler or device tests.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
s=(r/'source/SolarRings7X.mc').read_text()
guard=(r/'source/StormGuard.mc').read_text()
props=ET.parse(r/'resources/settings/properties.xml').getroot()
settings=ET.parse(r/'resources/settings/settings.xml').getroot()
strings=ET.parse(r/'resources/strings.xml').getroot()
manifest=ET.parse(r/'manifest.xml').getroot()
app=manifest.find('{http://www.garmin.com/xml/connectiq}application')
assert app.attrib['id']=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
assert app.attrib['version']=='3.11.1'
ids={x.attrib['id'] for x in props}
assert len(ids)==len(list(props))==38
assert len(list(settings))==38
strids={x.attrib['id'] for x in strings}
for item in settings:
    key=item.attrib['propertyKey'].split('.')[-1]
    assert key in ids, key
    assert item.attrib['title'].split('.')[-1] in strids
    for opt in item.findall('.//listEntry'):
        assert opt.text.split('.')[-1] in strids
assert len({x.attrib['propertyKey'] for x in settings})==38
for key in ('stormFastV310','stormFastDropV310','stormOnV3','stormDropV3','stormAltitudeV3',
            'fontClockV31','fontDateV31','moonPanelV38','moonFontV38',
            'capsuleStepsModeV39'):
    assert key in ids
for token in ('topSlot(dc, 73,','topSlot(dc, 134,','topSlot(dc, 195,',
              'capsule(dc, 32, 64,','capsule(dc, 99, 83,', 'capsule(dc, 185, 64,',
              'drawClock(dc, clock);','drawDate(dc, days[date.day_of_week - 1]',
              'drawMoonPanel(dc);','stormBolt(dc, 46, 147)',
              'if (_storm.warning())','capsuleTrack(dc, left, top, width, d[2], col)',
              'stepGoal - steps', 'weatherSymbol(dc, 74, 235, weather)'):
    assert token in s, token
assert 'stormBolt(dc, 250, 192)' not in s
for token in ('pressureTrend(3600, 3000,','pressureTrend(10800, 9000,',
              'new Time.Duration(windowSeconds)','stableElevation(windowSeconds, minimumSeconds, now)',
              '(oldestPa - newestPa) / 100.0', 'if (now - newestAt > 900'):
    assert token in guard, token
# Display 280x280. Outer progress ring r=131 centered at (140,140).
boxes=[(32,167,96,211),(99,167,182,211),(185,167,249,211)]
for i,(l,t,rr,b) in enumerate(boxes):
    assert 0<=l<rr<280 and 0<=t<b<280
    assert rr-l>=64 and b-t==44
    assert ((l+rr)/2.-140.)**2+((t+b)/2.-140.)**2 < 131**2
    if i: assert boxes[i-1][2]<l
# Capsule outline y=167..211; icon is left of value, bar stays y=204..206.
# The global separator is at y=215: at least a 4px safety margin.
assert 167 + 37 == 204 and 204 + 2 < 211 < 215
assert 'var iconX = left + 17' in s
assert 'drawIcon(dc, iconX, 185, id, col)' in s
assert 'drawSized(dc, value, valueCenter, 181, valueW, 21,' in s
assert 'by = top + 37' in s
assert 'var valueW = width - 35' in s
for w in [64,83]:
    icon_center=17
    # Generic symbol width ~22px stays inside capsule left subregion.
    assert icon_center-11>2 and icon_center+11<30
    assert (30 + (w - 35)) < w
assert 'RobotoCondensedBold' in s
assert 'var slotW = 156;' in s and 'var slotH = 52;' in s
assert 'requested = 42' in s and 'requested = 49' in s and 'requested = 56' in s
for v in [77,9999,10000,12345,25000,99999]:
    assert len(str(v))<=5
for steps,goal in [(0,10000),(3000,10000),(10000,10000),(12000,10000)]:
    p=max(0,min(1,steps/goal)); width=83-20
    assert 0 <= int(p*width) <=width
# For the storm sensor readings, old-new pressure in Pa: a positive hPa drop.
for before,now,expected in [(101300,100900,4),(101300,101100,2),(101300,101300,0)]:
    assert (before-now)/100==expected
print('PASS: v3.11.1 id, 38 settings, 3 non-overlapping capsules, storm bolt, two windows and 5-digit values')
