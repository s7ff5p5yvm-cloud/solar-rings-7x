# Solar Rings 7X v3.11.1 — aktualizacja godziny i kapsul

Dla Garmin Fenix 7X Pro Solar. Zachowany identyfikator aplikacji i 38 ustawien w Connect IQ.

Wersja v3.11.1:
- Godzina: RobotoCondensedBold, mocniejszy kontur, trzy rzeczywiste rozmiary: mala/srednia/duza. Tekst jest mierzony i dopasowywany do szerokosci 156px i wysokosci 52px miedzy liniami.
- Data: bez zmian.
- Trzy kapsuly: ikonka znajduje sie z lewej, wartosc z prawej, pasek postepu osobno na dole (204..206 px), nie na linii oddzielajacej pogodę.
- Puls, pogoda, ksiezyc, ustawienia oraz trend burzowy: zachowane.

Instrukcja: przeslij ZIP bez rozpakowywania do glownego katalogu repozytorium, a plik `SolarRings7X_v3_11_1_BUILD.yml` wklej do `.github/workflows/build-v3.yml`, uruchom Build w GitHub Actions. Dostepny bedzie plik PRG i IQ.

Testy: lokalne statyczne i XML; kompilacja Garmin SDK i wyglad na zegarku nie byly zweryfikowane.
