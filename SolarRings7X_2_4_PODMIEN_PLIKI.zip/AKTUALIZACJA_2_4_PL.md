# Solar Rings 7X v2.4.0

Poprawki: ikony i cyfry wewnątrz pierścieni 2×2, zmniejszony promień pierścieni, oddzielona linia pogody i baterii, usunięty podpis fazy Księżyca powodujący kolizję. Nie zmieniono identyfikatora aplikacji, ani 16 definicji ustawień Connect IQ.

**UWAGA**: wersja nie została uruchomiona ani skompilowana z Garmin SDK w tym środowisku. Sprawdź build na GitHubie. Ustawienia na iPhonie mogą nie być dostępne dla ręcznie skopiowanego pliku PRG — zainstaluj wydanie beta przez Connect IQ, jeśli chcesz je przetestować.
