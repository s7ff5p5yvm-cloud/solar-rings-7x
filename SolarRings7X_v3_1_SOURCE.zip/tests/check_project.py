#!/usr/bin/env python3
"""Static Garmin watch face resource + layout regression checks."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
props=ET.parse(root/'resources/settings/properties.xml').getroot()
settings=ET.parse(root/'resources/settings/settings.xml').getroot()
strings=ET.parse(root/'resources/strings.xml').getroot()
manifest=ET.parse(root/'manifest.xml').getroot()
prop_names={p.get('id') for p in props.findall('property')}
string_names={s.get('id') for s in strings.findall('string')}
assert len(prop_names)==21 and len(settings.findall('setting'))==21
assert len(string_names)==len(strings.findall('string'))
for setting in settings.findall('setting'):
    assert setting.get('propertyKey','').split('.')[-1] in prop_names
    assert setting.get('title','').split('.')[-1] in string_names
    cfg=setting.find('settingConfig')
    assert cfg is not None and cfg.get('type') in ('list', 'boolean')
    for entry in cfg.findall('listEntry'):
        assert entry.text.split('.')[-1] in string_names
app=list(manifest)[0]
assert app.get('version')=='3.1.0'
assert app.get('id')=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
face=(root/'source/SolarRings7X.mc').read_text()
assert face.count('topSlot(dc,')==4
assert face.count('ring(dc,')==4
assert 'outerProgressRing(dc, monitor, w, clock)' in face
assert 'fontWeatherV31' in face and 'fontDateV31' in face
assert 'stormBolt(dc, 246, 129)' in face
# all major areas are separated on 280 x 280 watch screen
ring_y=171; radius=33
assert ring_y-radius > 121 and ring_y+radius < 208
for x in [55,140,225]:
    assert x-radius>10 and x+radius<270
assert 208 < 210 < 235 < 255 < 257 < 258 + 20 <=280
field=(root/'source/FieldData.mc').read_text()
assert 'function weatherSymbol(' in face
assert 'weatherSymbol(dc, 79, 233, weather)' in face
for t in ('CONDITION_CLEAR','CONDITION_RAIN','CONDITION_SNOW','CONDITION_FOG','CONDITION_THUNDERSTORMS'):
    assert t in face
assert 'function recentHeartRate()' in field and 'Monitor.getHeartRateHistory' in field
assert 'elapsed <= 180' in field
print('PASS: 3 rings, 21 mobile settings, automatic weather icons, fresh HR sampling, geometry')
