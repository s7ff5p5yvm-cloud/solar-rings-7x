using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;

class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    function getInitialView() { return [new SolarRingsFaceV3()]; }
    function onSettingsChanged() { Ui.requestUpdate(); }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
    }

    // Fit measured Garmin fonts into a reserved rectangle.
    // User scale is a preference, NEVER permission to draw across a boundary.
    function fitScaled(dc, value, x, top, width, height, color, number, scale) {
        if (value == null) { return; }
        var str = value.toString();
        if (str.length() == 0 || width <= 0 || height <= 0) { return; }
        var numeric = number;
        if (numeric) {
            for (var k = 0; k < str.length(); k++) {
                if ("0123456789:".find(str.substring(k,k+1)) == null) {
                    numeric = false;
                    break;
                }
            }
        }
        var fonts;
        if (numeric) {
            if (scale >= 2) {
                fonts = [Gfx.FONT_NUMBER_THAI_HOT, Gfx.FONT_NUMBER_HOT,
                         Gfx.FONT_NUMBER_MEDIUM, Gfx.FONT_NUMBER_MILD,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_MEDIUM, Gfx.FONT_NUMBER_MILD,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale >= 2) {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL, Gfx.FONT_TINY,
                         Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }
        var chosen = null;
        var fontH = 0;
        for (var j = 0; j < fonts.size(); j++) {
            var size = dc.getTextDimensions(str, fonts[j]);
            if (size[0] <= width && size[1] <= height) {
                chosen = fonts[j];
                fontH = size[1];
                break;
            }
        }
        if (chosen == null) {
            chosen = Gfx.FONT_XTINY;
            // Keep 5-digit steps and other numerical results intact.
            if (!numeric) {
                while (str.length() > 1 && dc.getTextWidthInPixels(str, chosen) > width) {
                    str = str.substring(0, str.length()-1);
                }
            }
            fontH = dc.getFontHeight(chosen);
        }
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.drawText(x, top + (height-fontH)/2, chosen, str,
                    Gfx.TEXT_JUSTIFY_CENTER);
    }

    // Legacy helper for slot text; all new scaled labels use fitScaled.
    function fit(dc, value, x, top, width, height, color, number) {
        fitScaled(dc, value, x, top, width, height, color, number, 1);
    }

    

    function rule(dc, y) {
        dc.setColor(0x555555, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(30, y, 250, y);
    }

    function sunIcon(dc, x, y, settingSun) {
        dc.setColor(settingSun ? Gfx.COLOR_YELLOW : Gfx.COLOR_ORANGE,
                    Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 5, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 9, y, x + 9, y);
        dc.drawLine(x, y - 9, x, y - 6);
        dc.setPenWidth(1);
    }

    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 2, 4);
        dc.fillCircle(x + 4, y - 2, 4);
        dc.fillRectangle(x - 5, y, 10, 4);
        dc.drawLine(x - 7, y + 2, x, y + 9);
        dc.drawLine(x, y + 9, x + 7, y + 2);
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, 7);
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x + 4, y - 2, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // independent pressure-warning bolt, they describe present weather.
    function weatherSymbol(dc, x, y, weather) {
        if (weather == null || weather.condition == null) {
            // Missing weather: neutral outline, no invented condition.
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.drawLine(x, y - 4, x, y + 1);
            dc.drawCircle(x, y + 5, 1);
            dc.setPenWidth(1);
            return;
        }
        var c = weather.condition;
        // Pure sunshine.
        if (c == Weather.CONDITION_CLEAR || c == Weather.CONDITION_FAIR ||
            c == Weather.CONDITION_MOSTLY_CLEAR) {
            dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y - 2, 10);
            dc.drawLine(x, y - 19, x, y - 15);
            dc.drawLine(x, y + 11, x, y + 16);
            dc.drawLine(x - 18, y - 2, x - 14, y - 2);
            dc.drawLine(x + 14, y - 2, x + 18, y - 2);
            dc.drawLine(x - 13, y - 15, x - 10, y - 12);
            dc.drawLine(x + 10, y + 8, x + 13, y + 11);
            dc.drawLine(x + 12, y - 15, x + 9, y - 12);
            dc.drawLine(x - 9, y + 8, x - 12, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Cloud with some sun.
        if (c == Weather.CONDITION_PARTLY_CLOUDY ||
            c == Weather.CONDITION_PARTLY_CLEAR ||
            c == Weather.CONDITION_THIN_CLOUDS) {
            cloud(dc, x, y);
            return;
        }
        // Cloud and precipitation.
        if (c == Weather.CONDITION_RAIN || c == Weather.CONDITION_LIGHT_RAIN ||
            c == Weather.CONDITION_HEAVY_RAIN || c == Weather.CONDITION_DRIZZLE ||
            c == Weather.CONDITION_SCATTERED_SHOWERS || c == Weather.CONDITION_SHOWERS ||
            c == Weather.CONDITION_LIGHT_SHOWERS || c == Weather.CONDITION_HEAVY_SHOWERS ||
            c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN ||
            c == Weather.CONDITION_UNKNOWN_PRECIPITATION) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(0x00AAFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 12, x - 13, y + 18);
            dc.drawLine(x, y + 12, x - 3, y + 18);
            dc.drawLine(x + 10, y + 12, x + 7, y + 18);
            dc.setPenWidth(1);
            return;
        }
        // Snow / wintry conditions.
        if (c == Weather.CONDITION_SNOW || c == Weather.CONDITION_LIGHT_SNOW ||
            c == Weather.CONDITION_HEAVY_SNOW || c == Weather.CONDITION_FLURRIES ||
            c == Weather.CONDITION_CHANCE_OF_SNOW || c == Weather.CONDITION_WINTRY_MIX ||
            c == Weather.CONDITION_RAIN_SNOW || c == Weather.CONDITION_ICE_SNOW ||
            c == Weather.CONDITION_LIGHT_RAIN_SNOW || c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
            c == Weather.CONDITION_FREEZING_RAIN || c == Weather.CONDITION_SLEET ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 11, x - 10, y + 19);
            dc.drawLine(x - 14, y + 15, x - 6, y + 15);
            dc.drawLine(x + 7, y + 11, x + 7, y + 19);
            dc.drawLine(x + 3, y + 15, x + 11, y + 15);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_THUNDERSTORMS ||
            c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
            c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS ||
            c == Weather.CONDITION_TROPICAL_STORM) {
            simpleCloud(dc, x, y - 6);
            stormBolt(dc, x + 2, y + 13);
            return;
        }
        if (c == Weather.CONDITION_FOG || c == Weather.CONDITION_MIST ||
            c == Weather.CONDITION_HAZY || c == Weather.CONDITION_HAZE) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 20, y - 9, x + 16, y - 9);
            dc.drawLine(x - 16, y - 2, x + 20, y - 2);
            dc.drawLine(x - 20, y + 5, x + 15, y + 5);
            dc.drawLine(x - 13, y + 12, x + 20, y + 12);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_WINDY || c == Weather.CONDITION_SQUALL) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 22, y - 5, x + 12, y - 5);
            dc.drawLine(x - 12, y + 3, x + 19, y + 3);
            dc.drawLine(x - 19, y + 11, x + 10, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Overcast / unclassified present weather.
        simpleCloud(dc, x, y);
    }

    function simpleCloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 11, y + 2, 8);
        dc.fillCircle(x + 1, y - 4, 11);
        dc.fillCircle(x + 14, y + 3, 8);
        dc.fillRectangle(x - 17, y + 3, 38, 9);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3 || id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { stopwatch(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }

    function topSlot(dc, x, id, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, x, 82, id, 0x00AAFF);
        fitScaled(dc, d[1], x, 94, 78, 24, Gfx.COLOR_WHITE,
                  false, srSetting("fontTopV31", 1));
    }

    

    function ring(dc, x, id, colorCode, monitor, weather) {
        if (id == 0) { return; }
        var data = readField(id, monitor, weather);
        var y = 171;
        var radius = 33; // smaller rings: more room for the clock and weather
        var col = srColor(colorCode);
        dc.setPenWidth(5);
        dc.setColor(0x484848, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        var ratio = data[2];
        if (ratio == null) {
            dc.setPenWidth(2);
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            dc.drawCircle(x, y, radius);
        } else {
            var progress = ratio.toFloat();
            if (progress < 0) { progress = 0.0; }
            if (progress > 1) { progress = 1.0; }
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            if (progress >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (progress > 0.004) {
                var end = 90 - (progress * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
        drawIcon(dc, x, 154, id, col);
        var displayed = data[1];
        // Keep 10 000–99 999 steps as exact values. Only 6+ digit
        // counters are abbreviated when they cannot fit in a circle.
        if (displayed.length() > 5 && id == 2) {
            var val = monitor.steps;
            if (val != null && val >= 100000) {
                displayed = compact(val);
            }
        }
        fitScaled(dc, displayed, x, 169, 61, 27, Gfx.COLOR_WHITE,
                  true, srSetting("fontRingV31", 2));
    }

    

    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var size = srSetting("fontWeatherV31", 2);
        if (id == 16) {
            // Reference layout: large partly-cloudy pictogram on left,
            // temperature large on first line, condition on second.
            weatherSymbol(dc, 79, 233, weather);
            fitScaled(dc, d[1], 176, 210, 133, 27,
                      Gfx.COLOR_WHITE, false, size);
            fitScaled(dc, conditionText(weather), 176, 235, 142, 20,
                      Gfx.COLOR_LT_GRAY, false, size);
        } else {
            drawIcon(dc, 76, 234, id, 0x00AAFF);
            fitScaled(dc, d[1], 176, 211, 140, 26,
                      Gfx.COLOR_WHITE, false, size);
            fitScaled(dc, d[0], 176, 235, 140, 20,
                      Gfx.COLOR_LT_GRAY, false, size);
        }
    }

    

    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var value = d[1];
        drawIcon(dc, 110, 265, id, Gfx.COLOR_GREEN);
        fitScaled(dc, value, 159, 258, 85, 20, Gfx.COLOR_WHITE,
                  false, srSetting("fontWeatherV31", 2));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = readField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 135;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function onUpdate(dc) {
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var clock = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND","PN","WT","SR","CZ","PT","SB"];
        var months = ["STY","LUT","MAR","KWI","MAJ","CZE","LIP","SIE","WRZ","PAZ","LIS","GRU"];
        var monitor = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }

        // Outside ring first, leaving foreground text fully opaque.
        outerProgressRing(dc, monitor, w, clock);

        // Increased clock; date moved LEFT and drawn in a wider slot.
        fitScaled(dc, twoDigits(clock.hour) + ":" + twoDigits(clock.min),
                  112, 6, 168, 60, Gfx.COLOR_WHITE, true,
                  srSetting("fontClockV31", 2));
        fitScaled(dc, days[date.day_of_week - 1],
                  209, 16, 60, 25, Gfx.COLOR_WHITE, false,
                  srSetting("fontDateV31", 2));
        fitScaled(dc, date.day.toString() + " " + months[date.month - 1],
                  209, 40, 75, 24, Gfx.COLOR_LT_GRAY, false,
                  srSetting("fontDateV31", 2));
        rule(dc, 68);

        topSlot(dc, 57, srSetting("slotTop1V3", 14), monitor, w);
        topSlot(dc, 140, srSetting("slotTop2V3", 34), monitor, w);
        topSlot(dc, 223, srSetting("slotTop3V3", 15), monitor, w);
        rule(dc, 121);
        ring(dc, 55, srSetting("slotRing1V3", 1),
             srSetting("colorRing1V3", 0), monitor, w);
        ring(dc, 140, srSetting("slotRing2V3", 2),
             srSetting("colorRing2V3", 2), monitor, w);
        ring(dc, 225, srSetting("slotRing3V3", 3),
             srSetting("colorRing3V3", 6), monitor, w);
        rule(dc, 208);
        drawWeather(dc, monitor, w);
        // Divider between weather and footer; no collisions.
        rule(dc, 257);
        drawBattery(dc, monitor, w);
        // Warning only after actual pressure trend check, never as battery icon.
        if (_storm.warning()) { stormBolt(dc, 246, 129); }
    }

    
}
