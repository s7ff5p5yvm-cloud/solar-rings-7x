# Solar Rings 7X 3.1.0 – poprawka czytelności MIP

Oparta na działającej wersji 3.0.0. Zachowuje ten sam identyfikator aplikacji i nazwy 14 dotychczasowych ustawień Connect IQ.

## Zmiany
- Zmniejszone 3 pierścienie do promienia 33 px; nadal dokładne pięciocyfrowe kroki.
- Powiększona godzina i data przesunięta w lewo; osobny suwak wielkości (mały / średni / duży).
- Większa ikona częściowego zachmurzenia, temperatura i pełny opis pogody w dwóch liniach, tak jak na zdjęciu wzorcowym.
- Rozmiary czcionek wybierane z Connect IQ: godzina, data, górne pola, kółka i pogoda.
- Zewnętrzny wąski pierścień wokół tarczy: pora dnia (24 h), stres, kroki, Body Battery, bateria lub minuty intensywne; można go wyłączyć i zmienić kolor.
- Opcjonalna ikona burzy pojawia się jako **żółta błyskawica przy prawej krawędzi nad pierścieniami (około godz. 2)**, TYLKO po wykryciu szybkiego spadku ciśnienia (domyślnie >=4 hPa/3 h) oraz niewielkich zmian wysokości (<20 m). Domyślnie wyłączona. To wskaźnik orientacyjny, nie oficjalny alert.
- Konfiguracja 8 pól pozostała identyczna z wersją 3.0.

## Test i instalacja
Wgraj SolarRings7X_v3_1_SOURCE.zip do głównego katalogu GitHub. Podmień zawartość `.github/workflows/build-v3.yml` plikiem `SolarRings7X_v3_1_BUILD.yml`. Uruchom workflow, pobierz `.IQ` z artefaktów i użyj **Upload New Version** dla istniejącej aplikacji beta Garmin Connect IQ. Po instalacji bety przez Connect IQ ustawienia są dostępne na iPhonie.

Testy w paczce są **statyczne**. Wymagane są jeszcze kompilacja Garmin SDK i test na zegarku. Nie rozpakowuj ZIP-a źródłowego do korzenia repozytorium.

## Pogoda i tętno (wersja 3.1)
- Symbol pogody zmienia się na podstawie `Weather.getCurrentConditions().condition`: słońce, zachmurzenie, opady, śnieg, mgła, wiatr, burza. Brak danych: neutralny znak.
- Ostrzeżenie barometryczne jest **oddzielne** od zwykłej ikony pogody. Żółta błyskawica po prawej stronie nad kółkami pokazuje się tylko, gdy filtr spadku ciśnienia zostanie spełniony i ostrzeżenia są włączone w Connect IQ.
- Tętno: najnowsza poprawna próbka z `ActivityMonitor.getHeartRateHistory`, a następnie z `SensorHistory` (maksymalnie 3 minuty). Starszej wartości nie pokazujemy jako bieżącej. Garmin MIP aktualizuje tarczę zwykle raz na minutę, więc wskazanie może się nadal różnić od widgetu na żywo.
