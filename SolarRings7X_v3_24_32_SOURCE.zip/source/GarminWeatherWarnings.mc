using Toybox.Weather as Weather;
using Toybox.Time as Time;

// Read-only Garmin Weather rule engine. This deliberately does NOT call
// network, GPS, background tasks or persistent storage.
// The watch controls when weather is updated; our interval only throttles
// re-evaluation of the already-cached values.
class GarminWeatherWarnings {
    var _lastCheck;
    // Packed warning tags: kind 1..11, +16 forecast-only,
    // +32 fresh observation and forecast, +64 old observation (45..90m),
    // +96 old observation and forecast. No new weather reads or timers.
    // A phenomenon always occupies a single alert-center slot.
    var _lastKinds;

    function initialize() {
        _lastCheck = 0;
        _lastKinds = [];
    }

    // Kinds: 1 wind, 2 rain, 3 snow, 4 thunder, 5 freezing rain,
    // 6 fog, 7 ice risk, 8 hail, 9 UV, 10 atmospheric dust/smoke,
    // 11 mixed winter precipitation. A list keeps ALL active warnings.
    // Forecast data stays cached: only the displayed icon rotates every 5 s.
    function warning(current) {
        // Run demonstration modes before the master weather-alert switch.
        // A TEST is always visible, even with real alerts OFF and without
        // current Garmin weather data or hourly forecast availability.
        var preview = srSetting("gwPreviewV332", 0);
        if (preview > 0 && preview <= 9) {
            _lastKinds = [preview];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 10) {
            // RED thunderstorm NOW and CYAN forecast wind: two adjacent cells.
            _lastKinds = [4, 17];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 11) {
            // Same thunderstorm now and later: ONE red icon with cyan bar.
            _lastKinds = [];
            addAlert(_lastKinds, 20); // forecast storm
            addAlert(_lastKinds, 4);  // combined into tag 36
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 12) {
            // One forecast-only thunderstorm: BLUE icon never rotates.
            _lastKinds = [20];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 13) {
            // Two current + one forecast condition, all visible simultaneously.
            _lastKinds = [5, 4, 17];
            _lastCheck = 0;
            return rotatingWarning();
        }
        if (preview == 14) {
            // Three distinct phenomena, each NOW + FORECAST: 3 icons.
            // Pressure StormGuard remains separately first if enabled.
            _lastKinds = [36, 34, 33]; // thunder, rain, wind
            _lastCheck = 0;
            return rotatingWarning();
        }
        // The main switch controls only real-weather warning evaluation.
        // TEST 1..14 above deliberately bypasses it.
        if (!srSetting("gwOnV332", true)) {
            reset();
            return 0;
        }
        var now = Time.now().value();
        var interval = srSetting("gwIntervalV332", 15);
        if (interval < 5) { interval = 5; }
        if (interval > 60) { interval = 60; }
        if (_lastCheck == 0 || now < _lastCheck ||
            now - _lastCheck >= interval * 60) {
            _lastCheck = now;
            _lastKinds = [];
            try { _lastKinds = evaluate(current, now); } catch (e) {
                _lastKinds = [];
            }
        }
        return rotatingWarning();
    }

    // Same rules and throttle as warning(), but expose every active icon.
    // Returns a read-only-by-convention short cached list; caller must not
    // mutate it. Same phenomenon merges both sources into one tag.
    function allWarnings(current) {
        warning(current);
        return _lastKinds;
    }

    // Does NOT touch Garmin Weather or settings. Safe for onPartialUpdate().
    // Every five seconds it selects the next warning in priority order.
    function rotatingWarning() {
        var count = _lastKinds.size();
        if (count == 0) { return 0; }
        if (count == 1) { return _lastKinds[0]; }
        var phase = (Time.now().value() / 5).toNumber();
        return _lastKinds[phase % count];
    }

    function reset() {
        _lastCheck = 0;
        _lastKinds = [];
    }

    function priority(tag) {
        var k = baseKind(tag);
        if (k == 5) { return 90; } // freezing rain
        if (k == 8) { return 85; } // hail
        if (k == 11) { return 82; } // sleet/wintry mix
        if (k == 4) { return 80; } // thunder
        if (k == 7) { return 75; } // black ice risk
        if (k == 1) { return 65; } // high wind
        if (k == 3) { return 60; } // snow
        if (k == 2) { return 55; } // rain
        if (k == 6) { return 50; } // fog
        if (k == 10) { return 55; } // dust/smoke/ash/sandstorm
        if (k == 9) { return 40; } // UV
        return 0;
    }

    function baseKind(tag) {
        if (tag > 96) { return tag - 96; }
        if (tag > 64) { return tag - 64; }
        if (tag > 32) { return tag - 32; }
        if (tag > 16) { return tag - 16; }
        return tag;
    }

    function isNow(tag) {
        return tag <= 16 || tag > 32;
    }

    function isFuture(tag) {
        return (tag > 16 && tag <= 48) || tag > 96;
    }

    function isOld(tag) {
        return (tag > 64 && tag <= 80) || tag > 96;
    }

    // Merge same weather phenomenon without dropping forecast information.
    // Fresh observation wins over a stale observation for a single kind.
    function addAlert(items, tag) {
        var kind = baseKind(tag);
        for (var i = 0; i < items.size(); i++) {
            if (baseKind(items[i]) == kind) {
                var before = items[i];
                var hasNow = isNow(before) || isNow(tag);
                var hasFuture = isFuture(before) || isFuture(tag);
                var fresh = (isNow(before) && !isOld(before)) ||
                            (isNow(tag) && !isOld(tag));
                if (hasNow && hasFuture) {
                    items[i] = fresh ? kind + 32 : kind + 96;
                } else if (hasNow) {
                    items[i] = fresh ? kind : kind + 64;
                } else { items[i] = kind + 16; }
                return items;
            }
        }
        items.add(tag);
        return items;
    }

    function mergeAlerts(items, other, isForecast) {
        for (var i = 0; i < other.size(); i++) {
            var tag = other[i];
            if (isForecast) { tag += 16; }
            addAlert(items, tag);
        }
        return items;
    }

    // Priority only controls the cycle order; never drops other hazards.
    function orderAlerts(items) {
        for (var i = 0; i < items.size(); i++) {
            for (var j = i + 1; j < items.size(); j++) {
                if (priority(items[j]) > priority(items[i])) {
                    var tmp = items[i];
                    items[i] = items[j];
                    items[j] = tmp;
                }
            }
        }
        return items;
    }

    // Garmin precipitationChance is GENERAL probability of precipitation,
    // NOT storm/hail/freezing-rain probability. The provider may report 0%
    // while its weather condition explicitly forecasts rain (observed on the
    // user's Fenix). Treat explicit categories as actual forecast categories,
    // without claiming a numeric probability. Ambiguous CHANCE_OF_* codes
    // must pass the user's threshold and a non-null probability.
    function forecastChanceMatches(chance, minimum, explicitCategory) {
        if (explicitCategory) { return true; }
        return chance != null && chance >= minimum;
    }

    // One weather condition is classified into action-oriented categories.
    // Ordinary clouds, fair weather and UNKNOWN are intentionally ignored.
    // Mixed precipitation is represented by ONE icon, not rain + snow clones.
    // No allocation of weather arrays other than the short warning list.
    function classify(c, chance, wind, temp, visibility, uv, isForecast) {
        if (c == null && wind == null && uv == null && visibility == null) {
            return [];
        }
        var k = [];
        var rainEnabled = srSetting("gwRainOnV332", true);
        var snowEnabled = srSetting("gwSnowOnV332", true);
        var windy = c == Weather.CONDITION_SQUALL ||
                    c == Weather.CONDITION_TORNADO ||
                    c == Weather.CONDITION_HURRICANE ||
                    c == Weather.CONDITION_TROPICAL_STORM;
        if (srSetting("gwWindOnV332", true) &&
            (windy || (wind != null && wind >= srSetting("gwWindV332", 10)))) {
            addAlert(k, 1);
        }
        if (c == null) {
            if (srSetting("gwUvOnV332", false) && uv != null &&
                uv >= srSetting("gwUvV332", 7)) { addAlert(k, 9); }
            return k;
        }

        // Thunderstorm forecast is a category, NOT a percentage of lightning.
        var stormUncertain = c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS;
        if (srSetting("gwStormOnV332", true) &&
            (c == Weather.CONDITION_THUNDERSTORMS ||
             c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
             stormUncertain) &&
            (!stormUncertain || (isForecast && forecastChanceMatches(chance,
                 srSetting("gwStormChanceV332", 30), false)))) {
            addAlert(k, 4);
        }

        // Mixed precipitation (wintry mix, rain/snow, sleet, ice/snow) is
        // distinct from freezing rain. Explicit categories outrank stale 0%.
        var mixedUncertain = c == Weather.CONDITION_CHANCE_OF_RAIN_SNOW ||
                             c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW;
        var mixedExplicit = c == Weather.CONDITION_WINTRY_MIX ||
                            c == Weather.CONDITION_LIGHT_RAIN_SNOW ||
                            c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
                            c == Weather.CONDITION_RAIN_SNOW ||
                            c == Weather.CONDITION_SLEET ||
                            c == Weather.CONDITION_ICE_SNOW;
        if ((rainEnabled || snowEnabled) && (mixedExplicit || mixedUncertain)) {
            var mixedLimit = 100;
            if (rainEnabled) { mixedLimit = srSetting("gwRainChanceV332", 30); }
            if (snowEnabled) {
                var snowLimit = srSetting("gwSnowChanceV332", 40);
                if (snowLimit < mixedLimit) { mixedLimit = snowLimit; }
            }
            // "Only heavy" mode skips light/mild mixed precipitation.
            var heavyMixed = c == Weather.CONDITION_HEAVY_RAIN_SNOW;
            var mixAllowed = (rainEnabled && !srSetting("gwRainHeavyV332", false)) ||
                             (snowEnabled && !srSetting("gwSnowHeavyV332", false)) ||
                             heavyMixed;
            if (mixAllowed && (mixedExplicit ||
                (isForecast && forecastChanceMatches(chance, mixedLimit, false)))) {
                addAlert(k, 11);
            }
        }

        if (srSetting("gwFreezeOnV332", true) &&
            c == Weather.CONDITION_FREEZING_RAIN) { addAlert(k, 5); }
        if (srSetting("gwHailOnV332", true) &&
            c == Weather.CONDITION_HAIL) { addAlert(k, 8); }

        var rainUncertain = c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
                            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN;
        var rainExplicit = c == Weather.CONDITION_RAIN ||
                           c == Weather.CONDITION_LIGHT_RAIN ||
                           c == Weather.CONDITION_HEAVY_RAIN ||
                           c == Weather.CONDITION_SHOWERS ||
                           c == Weather.CONDITION_LIGHT_SHOWERS ||
                           c == Weather.CONDITION_HEAVY_SHOWERS ||
                           c == Weather.CONDITION_SCATTERED_SHOWERS ||
                           c == Weather.CONDITION_DRIZZLE;
        if (rainEnabled && (rainExplicit || rainUncertain)) {
            var heavyRain = c == Weather.CONDITION_HEAVY_RAIN ||
                            c == Weather.CONDITION_HEAVY_SHOWERS;
            if ((!srSetting("gwRainHeavyV332", false) || heavyRain) &&
                (rainExplicit || (isForecast && forecastChanceMatches(chance,
                  srSetting("gwRainChanceV332", 30), false)))) {
                addAlert(k, 2);
            }
        }
        var snowUncertain = c == Weather.CONDITION_CHANCE_OF_SNOW ||
                            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW;
        var snowExplicit = c == Weather.CONDITION_SNOW ||
                           c == Weather.CONDITION_LIGHT_SNOW ||
                           c == Weather.CONDITION_HEAVY_SNOW ||
                           c == Weather.CONDITION_FLURRIES;
        if (snowEnabled && (snowExplicit || snowUncertain)) {
            if ((!srSetting("gwSnowHeavyV332", false) ||
                  c == Weather.CONDITION_HEAVY_SNOW) &&
                (snowExplicit || (isForecast && forecastChanceMatches(chance,
                  srSetting("gwSnowChanceV332", 40), false)))) {
                addAlert(k, 3);
            }
        }

        // FOG is explicit. MIST/HAZE are not automatically dense fog;
        // require measured visibility <= configured threshold for current.
        var lowVisibility = visibility != null &&
                            visibility <= srSetting("gwFogMetersV332", 500);
        if (srSetting("gwFogOnV332", true) &&
            (c == Weather.CONDITION_FOG ||
             (!isForecast && lowVisibility &&
              (c == Weather.CONDITION_MIST ||
               c == Weather.CONDITION_HAZY ||
               c == Weather.CONDITION_HAZE)))) {
            addAlert(k, 6);
        }
        // Atmospheric hazards distinct from meteorological fog. No claim
        // that these are road-visibility measurements or an air quality index.
        if (srSetting("gwAirOnV332", true) &&
            (c == Weather.CONDITION_DUST || c == Weather.CONDITION_SMOKE ||
             c == Weather.CONDITION_SAND || c == Weather.CONDITION_SANDSTORM ||
             c == Weather.CONDITION_VOLCANIC_ASH)) {
            addAlert(k, 10);
        }
        if (srSetting("gwIceOnV332", true)) {
            var icyWeather = c == Weather.CONDITION_ICE;
            var wetWeather = rainExplicit || snowExplicit || mixedExplicit ||
                             c == Weather.CONDITION_FREEZING_RAIN;
            // Ice risk is an estimate from air temperature AND wet weather,
            // NOT a sensor measurement of road pavement.
            if (icyWeather || (wetWeather && temp != null &&
                 temp <= srSetting("gwIceTempV332", 1))) {
                addAlert(k, 7);
            } else if (isForecast && mixedUncertain && temp != null &&
                       temp <= srSetting("gwIceTempV332", 1) &&
                       chance != null &&
                       chance >= srSetting("gwIceChanceV332", 50)) {
                addAlert(k, 7);
            }
        }
        if (srSetting("gwUvOnV332", false) && uv != null &&
            uv >= srSetting("gwUvV332", 7)) { addAlert(k, 9); }
        return k;
    }

    function evaluate(current, now) {
        var matched = [];
        if (current != null && current.observationTime != null) {
            var secondsOld = now - current.observationTime.value();
            // <=45 min: fresh RED. 45..90 min: faded observation glyph.
            // >90 min: no "now" claim. Forecast source stays independent.
            if (secondsOld >= -300 && secondsOld <= 5400) {
                var observed = classify(current.condition,
                        current.precipitationChance, current.windSpeed,
                        current.temperature, current.visibility,
                        current.uvIndex, false);
                if (secondsOld <= 2700) {
                    matched = mergeAlerts(matched, observed, false);
                } else {
                    for (var o = 0; o < observed.size(); o++) {
                        addAlert(matched, observed[o] + 64);
                    }
                }
            }
        }
        if (!srSetting("gwForecastV332", true)) { return orderAlerts(matched); }
        var hourly = null;
        try { hourly = Weather.getHourlyForecast(); } catch (e) { return orderAlerts(matched); }
        if (hourly == null) { return orderAlerts(matched); }
        // HourlyForecast.forecastTime is the time a prediction is valid.
        // Include at most the current hour and only the requested future
        // horizon. A forecast for the current hour is still a prediction
        // (CYAN), never an observed condition (RED).
        // Never retain the array on the watch face between refresh checks.
        var horizon = srSetting("gwHorizonV332", 1);
        if (horizon < 1) { horizon = 1; }
        if (horizon > 3) { horizon = 3; }
        var count = hourly.size();
        if (count > 8) { count = 8; }
        for (var i = 0; i < count; i++) {
            try {
                var h = hourly[i];
                if (h == null || h.forecastTime == null) { continue; }
                var dt = h.forecastTime.value() - now;
                if (dt <= -3600 || dt > horizon * 3600) { continue; }
                matched = mergeAlerts(matched, classify(h.condition,
                        h.precipitationChance, h.windSpeed, h.temperature,
                        null, h.uvIndex, true), true);
            } catch (e) { /* Broken record must not crash the watch face. */ }
        }
        return orderAlerts(matched);
    }
}
