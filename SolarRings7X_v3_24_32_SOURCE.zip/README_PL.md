# Solar Rings 7X v3.24.32 — kompletna klasyfikacja Garmin Weather

Wersja dla Garmin Fenix 7X Pro Solar, wydanie testowe wymagające kompilacji
Garmin Connect IQ SDK w GitHub Actions i testu na zegarku. ID aplikacji nie zmienia się.

## Najważniejsze zmiany
- **Wskaźnik aktualności**: aktualna obserwacja do 45 min → czerwona ikona;
  od 45 do 90 min → przygaszona ikona (to ostatnia obserwacja, nie pomiar na żywo);
  powyżej 90 min → brak ikony „teraz”. Prognoza nadal może być pokazywana
  turkusowo niezależnie od wieku obserwacji.
- **Kod warunków ważniejszy od sprzecznego 0%**: jednoznaczny deszcz, śnieg,
  przelotny deszcz, burza, grad i marznące opady są kwalifikowane jako
  prognozowane nawet przy 0% ogólnego prawdopodobieństwa opadów.
  Przykład: C11 P0 to przelotne opady z kodu Garmina, a nie pewność opadów.
- **Niepewne kategorie** (np. „możliwe przelotne opady”) nadal wymagają
  niepustego `precipitationChance` >= ustawionego progu. Procent dotyczy
  ogólnych opadów; nie jest osobnym prawdopodobieństwem piorunów lub gradu.
- **Opady mieszane** dostają jedną odrębną ikonę (rodzaj 11): deszcz ze śniegiem,
  marznące granulki / sleet, wintry mix. Nie są utożsamiane z marznącym deszczem.
- **Zjawiska związane z pyłem i dymem** mają odrębną ikonę (rodzaj 10)
  i ustawienie włącz/wyłącz. Widzialność z mgły nie jest utożsamiana z dymem.
- **Wiatr**: próg prędkości 10 m/s, dodatkowo bezpośrednie kody szkwałów,
  huraganu, tornada i burzy tropikalnej. Kategorie „wietrznie” bez pomiaru
  prędkości nie muszą oznaczać silnego wiatru.
- **Mgła**: jednoznaczny FOG lub aktualne MIST/HAZE przy widzialności <=500 m.
  Brak samych danych o widzialności w prognozie nie uprawnia do twierdzenia
  że będzie gęsta mgła, z wyjątkiem kodu FOG.
- **Ryzyko oblodzenia**: kod ICE lub opady przy temperaturze powietrza <=+1°C;
  jest to heurystyka, nie pomiar stanu nawierzchni.
- Układ: pole 1 wyłącznie StormGuard, pola 2–4 Garmin Weather; kombinacja
  „teraz i prognoza” = ikona bieżąca z turkusowym paskiem.
- TEST 14 (paski) i TEST 15 (dane godzinowe) pozostają dostępne; font
  testu 15 został zmniejszony, żeby wiersze nie nachodziły na siebie.

## Nowe ustawienia domyślne Connect IQ

| Parametr | Domyślnie | Edytowalne |
|---|---|---|
| Alerty Garmin Weather | Włączone | Tak |
| Analiza zapamiętanych danych | Co 15 minut | Tak, 5/15/30/60 min |
| Prognoza godzinowa | Włączona | Tak |
| Horyzont prognozy | 1 godzina | Tak, 1/2/3 h |
| Deszcz | Włączony, także lekki | Tak |
| Deszcz: „możliwe” | 30% | Tak |
| Śnieg | Włączony, także lekki | Tak |
| Śnieg: „możliwe” | 40% | Tak |
| Burza: „możliwa” | 30% | Tak |
| Silny wiatr | 10 m/s | Tak |
| Mgła | 500 m | Tak |
| Oblodzenie: temperatura | +1°C | Tak |
| Marznący deszcz / grad | Włączone | Tak, włączniki |
| Zjawiska pył/dym/pył wulkaniczny | Włączone | Tak |
| UV | Wyłączone | Tak |

Dawne ustawienia procentowe gradu i deszczu marznącego usunięto z panelu,
ponieważ Garmin Weather nie udostępnia osobnego procentu tych zjawisk.

**Uwaga przy aktualizacji:** Klucze wyłącznie ustawień pogodowych mają nowy
sufiks `V332`. Nowe wartości domyślne zaczną obowiązywać po aktualizacji,
także jeśli starsza wersja tarczy zapamiętała inne ustawienia pogodowe.
Po aktualizacji możesz je ponownie zmieniać ręcznie w Connect IQ.
Pozostałe ustawienia tarczy, w tym osobny StormGuard, nie są resetowane.

## Bateria
Nowa klasyfikacja używa tych samych odczytów Garmin Weather co wersja 3.24.31.
Nie dodaje GPS, połączeń internetowych, zadań w tle ani częstszego odświeżania.
Czasowo sterowana analiza co 15 min pozostaje. Łączenie różnych wskazań
w jeden tag zapobiega zbędnemu przerysowywaniu. Dodatkowy kod i ikony mogą
jednak nieznacznie wpłynąć na pracę urządzenia, więc pomiar baterii należy
wykonać osobno po aktualizacji.

## Instalacja
1. Umieść `SolarRings7X_v3_24_32_SOURCE.zip` w głównym katalogu repozytorium.
2. W `.github/workflows/` zastąp aktywny workflow wersją
   `SolarRings7X_v3_24_32_BUILD.yml` z kompletnej paczki (tylko jeden aktywny
   workflow wydania, by nie budować przypadkiem starego archiwum).
3. Uruchom GitHub Actions > Build Solar Rings 7X v3.24.32 > Run workflow.
4. Pobierz artefakt `SolarRings7X_weather_v32432`, zainstaluj plik
   `SolarRings7X_v32432.prg` na Fenixie 7X Pro Solar.
5. Po instalacji sprawdź ustawienia Garmin Connect IQ, TEST 14 i TEST 15,
   a następnie wyłącz tryb testowy do normalnego używania.

Przed instalacją zachowaj działającą poprzednią wersję tarczy.

## Weryfikacja
Przeszły testy źródłowe Python i walidacja XML. Nie uruchamiano w tej sesji
kompilatora Garmin Monkey C ani symulatora; poprawność kompilacji i działania
na zegarku trzeba sprawdzić w GitHub Actions i na urządzeniu.
