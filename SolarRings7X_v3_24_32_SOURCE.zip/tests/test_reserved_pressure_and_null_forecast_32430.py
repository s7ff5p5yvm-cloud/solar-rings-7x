"""v3.24.32 audit: reference policy and source invariants.

These Python tests inspect Monkey C and independently check intended branch logic.
They do not execute Garmin SDK or prove Garmin Weather returns any specific data.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ENGINE = (ROOT/'source/GarminWeatherWarnings.mc').read_text()
FACE = (ROOT/'source/SolarRings7X.mc').read_text()


def accept_forecast(chance, minimum, explicit):
    return True if explicit else (chance is not None and chance >= minimum)

class WeatherStripAndReservedSlot32430(unittest.TestCase):
    def test_probability_limits_apply_only_to_ambiguous_categories(self):
        for chance in (None,0,10,60):
            self.assertTrue(accept_forecast(chance,30,True))
        self.assertFalse(accept_forecast(0,30,False))
        self.assertFalse(accept_forecast(None,30,False))
        self.assertFalse(accept_forecast(29,30,False))
        self.assertTrue(accept_forecast(30,30,False))
        self.assertIn('if (explicitCategory) { return true; }',ENGINE)
        self.assertIn('return chance != null && chance >= minimum;',ENGINE)

    def test_explicit_hazards_ignore_inconsistent_0_percent(self):
        for key in ('gwRainChanceV332','gwSnowChanceV332','gwStormChanceV332'):
            self.assertIn('srSetting("'+key+'",',ENGINE)
        for key in ('gwFreezeChanceV332','gwHailChanceV332'):
            self.assertNotIn(key,ENGINE)
        self.assertIn('c == Weather.CONDITION_FREEZING_RAIN',ENGINE)
        self.assertIn('c == Weather.CONDITION_HAIL',ENGINE)
        self.assertIn('chance != null &&',ENGINE)

    def test_only_pressure_uses_first_slot_even_when_pressure_inactive(self):
        center=FACE.split('function drawAlertCenter(dc, weather) {',1)[1].split('// Battery footer',1)[0]
        self.assertIn('if (pressureActive)',center)
        self.assertIn('pressureActive = true;',center)
        self.assertNotIn('active[0]',center)
        self.assertIn('drawAlertGlyph(dc, 45, -1);',center)
        self.assertIn('var centers = [68, 91, 114];',center)
        self.assertNotIn('var centers = [45, 68, 91, 114];',center)
        self.assertIn('drawAlertGlyph(dc, centers[j], active[weatherStart + j]);',center)
        self.assertIn('var weatherCount = active.size() - weatherStart;',center)

    def test_three_weather_icons_visible_without_stormguard(self):
        face=FACE.split('function drawAlertCenter(dc, weather) {',1)[1].split('// Battery footer',1)[0]
        self.assertIn('if (staticCount > 3) { staticCount = 2; }',face)
        self.assertIn('if (weatherCount > 3)',face)
        self.assertIn('for (var k = 2; k < weatherCount; k++)',face)
        self.assertIn('drawAlertGlyph(dc, 114, _alertLastDrawn);',face)
        self.assertIn('dc.setClip(103, 217, 22, 26)',FACE)

    def test_no_extra_weather_reads_or_gps_requests(self):
        self.assertEqual(FACE.count('Weather.getCurrentConditions()'),1)
        self.assertEqual(ENGINE.count('Weather.getHourlyForecast()'),1)
        self.assertNotIn('makeWebRequest(',ENGINE)
        self.assertNotIn('Position.getInfo(',ENGINE)
        self.assertIn('now - _lastCheck >= interval * 60',ENGINE)

    def test_bar_test_mode_14_kept_and_cyan_underlines_in_bounds(self):
        self.assertIn('_lastKinds = [36, 34, 33];',ENGINE)
        self.assertIn('dc.fillRectangle(x - 8, y + 11, 16, 2);',FACE)
        for x in (68,91,114):
            self.assertGreater(x-8,45)
            self.assertLess(x+8,133)
        self.assertLessEqual(228+12,217+26-1)

if __name__ == '__main__': unittest.main()
