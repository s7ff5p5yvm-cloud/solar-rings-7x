"""Watch-face layout regression checks for the weather lower panel.
These are static/layout checks, not Garmin emulator pixel snapshots.
"""
import re
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
PROPS=ET.parse(ROOT/'resources/settings/properties.xml').getroot()

class TemperatureLayout3249(unittest.TestCase):
    def test_badge_geometry_allows_the_temperature_to_fit(self):
        self.assertIn('drawWeatherTemperature(dc, shownTemp, 148, 227)', FACE)
        self.assertIn('drawAlertCenter(dc, w)', FACE)
        self.assertIn('drawWeatherTemperature(dc, shownTemp, 148, 227)', FACE)
        self.assertEqual(227-148,79)
        self.assertGreaterEqual(148-(140+4),3)
    def test_icons_shifted_left_as_requested(self):
        self.assertIn('temperatureMarker(dc, weather, 142, 224)',FACE)
        self.assertIn('drawGarminWarningIcon(dc, x, 228, tag)',FACE)
        self.assertIn('drawAlertGlyph(dc, 114, kind)',FACE)
        self.assertIn('dc.setClip(103, 217, 22, 26)',FACE)
        self.assertIn('dc.fillRectangle(103, 217, 22, 26)',FACE)
    def test_lower_label_also_shifted_slightly_left(self):
        self.assertIn('drawSized(dc, lowerLabel, lowerCenter, 234, 105, 16, lowerColor, false,', FACE)
    def test_temperature_alerts_and_settings_are_preserved(self):
        self.assertIn('var hot = srSetting("tempHotV312", 30);',FACE)
        self.assertIn('var cold = srSetting("tempColdV312", 0);',FACE)
        self.assertIn('temp > hot',FACE)
        self.assertIn('temp < cold',FACE)
        defaults={p.attrib['id']:p.text for p in PROPS}
        self.assertEqual(defaults['tempHotV312'],'30')
        self.assertEqual(defaults['tempColdV312'],'0')
    def test_warning_controls_are_preserved(self):
        for setting in ['gwPreviewV332','gwOnV332','gwIntervalV332','gwHorizonV332','showFeelsLikeV319']:
            self.assertIsNotNone(PROPS.find(".//property[@id='%s']" % setting))

if __name__ == '__main__': unittest.main()
