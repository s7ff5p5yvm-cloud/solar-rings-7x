"""Connect IQ weather policy v3.24.32: source-level regression checks.
Python does not execute Monkey C; the GitHub build checks Monkey C syntax.
"""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
ENGINE=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
PROPS=ET.parse(ROOT/'resources/settings/properties.xml').getroot()
SETTINGS=ET.parse(ROOT/'resources/settings/settings.xml').getroot()
STRINGS=ET.parse(ROOT/'resources/strings.xml').getroot()

class GarminWeatherRules(unittest.TestCase):
 def test_settings_one_to_one_and_labels(self):
  ids=[v.attrib['id'] for v in PROPS]
  self.assertEqual(len(ids),len(set(ids)))
  labels={v.attrib['id'] for v in STRINGS}
  settings=[v.attrib['propertyKey'].split('.')[-1] for v in SETTINGS]
  self.assertEqual(len(settings),len(set(settings)))
  self.assertTrue(set(settings)<=set(ids))
  for v in SETTINGS:
   self.assertIn(v.attrib['title'].split('.')[-1],labels)
   for option in v.iter('listEntry'):
    self.assertIn(option.text.split('.')[-1],labels)

 def test_versioned_default_settings_take_effect_on_upgrade(self):
  defaults={v.attrib['id']:v.text for v in PROPS}
  want={'gwOnV332':'true','gwIntervalV332':'15','gwForecastV332':'true',
        'gwHorizonV332':'1','gwPreviewV332':'0','gwRainChanceV332':'30',
        'gwSnowChanceV332':'40','gwStormChanceV332':'30',
        'gwRainHeavyV332':'false','gwSnowHeavyV332':'false',
        'gwWindV332':'10','gwFogMetersV332':'500','gwIceTempV332':'1',
        'gwUvOnV332':'false','gwAirOnV332':'true'}
  for key,value in want.items():
   self.assertEqual(defaults[key],value,key)
  self.assertNotIn('gwOnV324',defaults)
  for key in ('gwRainChanceV332','gwSnowChanceV332','gwStormChanceV332',
              'gwIntervalV332','gwHorizonV332'):
   vals=[e.attrib['value'] for setting in SETTINGS
         if setting.attrib['propertyKey'].endswith('.'+key)
         for e in setting.iter('listEntry')]
   self.assertIn(defaults[key],vals,key)
  for removed in ('gwFreezeChanceV332','gwHailChanceV332'):
   self.assertNotIn(removed,defaults,'dead probability control')

 def test_throttle_and_one_provider_read(self):
  self.assertIn('now - _lastCheck >= interval * 60',ENGINE)
  self.assertEqual(ENGINE.count('Weather.getHourlyForecast()'),1)
  self.assertEqual(FACE.count('Weather.getCurrentConditions()'),1)
  self.assertIn('now - _lastCheck < 300',(ROOT/'source/StormGuard.mc').read_text())
  self.assertEqual((ROOT/'source/StormGuard.mc').read_text().count('History.getPressureHistory('),1)

 def test_explicit_category_not_blocked_by_zero_probability(self):
  self.assertIn('if (explicitCategory) { return true; }',ENGINE)
  self.assertIn('return chance != null && chance >= minimum;',ENGINE)
  self.assertIn('c == Weather.CONDITION_SCATTERED_SHOWERS',ENGINE)
  self.assertIn('c == Weather.CONDITION_SHOWERS',ENGINE)
  self.assertIn('c == Weather.CONDITION_CHANCE_OF_SHOWERS',ENGINE)
  self.assertIn('if (rainEnabled && (rainExplicit || rainUncertain))',ENGINE)
  self.assertIn('(rainExplicit || (isForecast && forecastChanceMatches(chance,',ENGINE)
  self.assertIn('if (snowEnabled && (snowExplicit || snowUncertain))',ENGINE)

 def test_ambiguity_prevents_false_current_alerts(self):
  self.assertIn('(!stormUncertain || (isForecast && forecastChanceMatches(chance,',ENGINE)
  self.assertIn('(isForecast && forecastChanceMatches(chance, mixedLimit, false))',ENGINE)
  self.assertIn('chance != null && chance >= minimum',ENGINE)

 def test_all_warning_glyphs_present(self):
  for i in range(1,12): self.assertIn('kind == %d'%i,FACE)
  for i in range(1,12): self.assertIn('k == %d'%i,ENGINE)
  self.assertIn('dc.fillRectangle(x - 8, y + 11, 16, 2)',FACE)
  self.assertIn('var centers = [68, 91, 114];',FACE)
  self.assertIn('drawAlertGlyph(dc, 45, -1);',FACE)

 def test_observation_fresh_and_stale(self):
  self.assertIn('secondsOld <= 2700',ENGINE)
  self.assertIn('secondsOld <= 5400',ENGINE)
  self.assertIn('addAlert(matched, observed[o] + 64)',ENGINE)
  self.assertIn('color = Gfx.COLOR_LT_GRAY;',FACE)
  self.assertIn('items[i] = fresh ? kind + 32 : kind + 96;',ENGINE)
  self.assertIn('items[i] = fresh ? kind : kind + 64;',ENGINE)

 def test_full_54_condition_coverage_policy(self):
  # All actionable distinct codes must be handled, and non-hazard codes
  # intentionally have no branch; this is a source-level coverage check.
  active={3:'RAIN',4:'SNOW',6:'THUNDERSTORMS',7:'WINTRY_MIX',
   8:'FOG',10:'HAIL',11:'SCATTERED_SHOWERS',12:'SCATTERED_THUNDERSTORMS',
   14:'LIGHT_RAIN',15:'HEAVY_RAIN',16:'LIGHT_SNOW',17:'HEAVY_SNOW',
   18:'LIGHT_RAIN_SNOW',19:'HEAVY_RAIN_SNOW',21:'RAIN_SNOW',
   24:'LIGHT_SHOWERS',25:'SHOWERS',26:'HEAVY_SHOWERS',
   27:'CHANCE_OF_SHOWERS',28:'CHANCE_OF_THUNDERSTORMS',
   29:'MIST',30:'DUST',31:'DRIZZLE',32:'TORNADO',33:'SMOKE',34:'ICE',
   35:'SAND',36:'SQUALL',37:'SANDSTORM',38:'VOLCANIC_ASH',
   39:'HAZE',41:'HURRICANE',42:'TROPICAL_STORM',43:'CHANCE_OF_SNOW',
   44:'CHANCE_OF_RAIN_SNOW',45:'CLOUDY_CHANCE_OF_RAIN',
   46:'CLOUDY_CHANCE_OF_SNOW',47:'CLOUDY_CHANCE_OF_RAIN_SNOW',
   48:'FLURRIES',49:'FREEZING_RAIN',50:'SLEET',51:'ICE_SNOW'}
  # WINDY (5) is non-urgent without the independent windSpeed >= 10 m/s.
  ignored={0,1,2,5,13,20,22,23,40,52,53}
  # HAZY (9) is specifically tied to measured visibility only.
  active[9]='HAZY'
  self.assertEqual(set(active)|ignored,set(range(54)))
  for code,name in active.items():
   self.assertIn('Weather.CONDITION_'+name,ENGINE,(code,name))
  self.assertIn('wind >= srSetting("gwWindV332", 10)',ENGINE)
  self.assertIn('c == Weather.CONDITION_ICE_SNOW',ENGINE)
  self.assertIn('c == Weather.CONDITION_SLEET',ENGINE)
  self.assertIn('c == Weather.CONDITION_VOLCANIC_ASH',ENGINE)

 def test_no_direct_network_gps_lookups_or_new_schedulers(self):
  for bad in ('makeWebRequest','Position.getInfo','registerForTemporalEvent','Communications'):
   self.assertNotIn(bad,ENGINE)
  self.assertIn('if (dt <= -3600 || dt > horizon * 3600)',ENGINE)
  self.assertIn('if (count > 8)',ENGINE)

if __name__=='__main__': unittest.main()
