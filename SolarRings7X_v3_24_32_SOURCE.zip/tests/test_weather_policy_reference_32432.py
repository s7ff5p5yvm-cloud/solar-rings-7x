"""Reference scenarios for weather-policy design.
Monkey C execution and weather-provider values remain device/SDK tests.
"""
from pathlib import Path
import unittest
from xml.etree import ElementTree as ET
R=Path(__file__).resolve().parents[1]
ENGINE=(R/'source/GarminWeatherWarnings.mc').read_text()
FACE=(R/'source/SolarRings7X.mc').read_text()

# Mirrors the published policy, not a Monkey C interpreter.
def accept(category_is_explicit, percent, threshold):
    return category_is_explicit or (percent is not None and percent >= threshold)

def presentation(age_minutes):
    if age_minutes < -5 or age_minutes > 90:
        return 'unknown'
    return 'fresh' if age_minutes <= 45 else 'stale'

def base(tag):
    for offset in (96,64,32,16):
        if tag>offset: return tag-offset
    return tag

def combine(a,b):
    def current(t): return t<=16 or t>32
    def future(t): return 16<t<=48 or t>96
    def stale(t): return 64<t<=80 or t>96
    k=base(a)
    assert k==base(b)
    now=current(a) or current(b)
    later=future(a) or future(b)
    fresh=(current(a) and not stale(a)) or (current(b) and not stale(b))
    return k+(32 if now and later and fresh else 96 if now and later else
              0 if now and fresh else 64 if now else 16)

class WeatherPolicy32432(unittest.TestCase):
    def test_user_real_scenario_scattered_showers_p_zero(self):
        self.assertTrue(accept(True,0,30))
        self.assertIn('c == Weather.CONDITION_SCATTERED_SHOWERS',ENGINE)
        self.assertIn('if (rainEnabled && (rainExplicit || rainUncertain))',ENGINE)

    def test_ambiguous_cloudy_chance_of_rain(self):
        self.assertFalse(accept(False,0,30))
        self.assertFalse(accept(False,None,30))
        self.assertFalse(accept(False,29,30))
        self.assertTrue(accept(False,30,30))
        self.assertIn('c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN',ENGINE)

    def test_future_thunderstorms_not_equated_to_precip_percent(self):
        self.assertTrue(accept(True,0,30))
        self.assertFalse(accept(False,0,30))
        self.assertIn('c == Weather.CONDITION_SCATTERED_THUNDERSTORMS',ENGINE)
        self.assertIn('c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS',ENGINE)

    def test_mixed_and_freezing_are_separate_icons(self):
        for condition in ('WINTRY_MIX','LIGHT_RAIN_SNOW','RAIN_SNOW','SLEET','ICE_SNOW'):
            self.assertIn('Weather.CONDITION_'+condition,ENGINE)
        self.assertIn('addAlert(k, 11);',ENGINE)
        self.assertIn('addAlert(k, 5);',ENGINE)
        self.assertIn('} else if (kind == 11)',FACE)

    def test_observation_transition_35_45_46_90_91(self):
        self.assertEqual(presentation(35),'fresh')
        self.assertEqual(presentation(45),'fresh')
        self.assertEqual(presentation(46),'stale')
        self.assertEqual(presentation(90),'stale')
        self.assertEqual(presentation(91),'unknown')
        self.assertIn('secondsOld <= 2700',ENGINE)
        self.assertIn('secondsOld <= 5400',ENGINE)

    def test_stale_forecast_bar_is_preserved(self):
        for kind in range(1,12):
            self.assertEqual(combine(kind+64,kind+16),kind+96)
            self.assertEqual(combine(kind+16,kind+64),kind+96)
            self.assertEqual(combine(kind+32,kind+64),kind+32)
        self.assertIn('if (alertTag > 96)',FACE)
        self.assertIn('hasForecastUnderline = true;',FACE)

    def test_default_forecast_is_enabled_and_one_hour(self):
        xml=ET.parse(R/'resources/settings/properties.xml').getroot()
        props={p.attrib['id']:p.text for p in xml}
        self.assertEqual(props['gwForecastV332'],'true')
        self.assertEqual(props['gwHorizonV332'],'1')
        self.assertEqual(props['gwOnV332'],'true')

    def test_classification_does_not_schedule_extra_tasks(self):
        self.assertEqual(ENGINE.count('Weather.getHourlyForecast()'),1)
        self.assertNotIn('makeWebRequest(',ENGINE)
        self.assertNotIn('registerForTemporalEvent(',ENGINE)
        self.assertNotIn('Position.getInfo(',ENGINE)
        self.assertIn('now - _lastCheck >= interval * 60',ENGINE)
        self.assertIn('function onPartialUpdate(dc)',FACE)

    def test_stormguard_preserved(self):
        src=(R/'source/StormGuard.mc').read_text()
        self.assertIn('now - _lastCheck < 300',src)
        self.assertEqual(src.count('History.getPressureHistory('),1)
        self.assertIn('stableElevation(3600, 3000, now)',src)
        self.assertIn('stableElevation(10800, 9000, now)',src)

if __name__ == '__main__': unittest.main()
