"""v3.24.29 combined-source alerts: structural checks and an independent
Python reference of packed-tag merging. Python does not execute Monkey C;
real compilation, rendering and sensor behavior still require Garmin SDK/device.
"""
from pathlib import Path
import itertools
import unittest
from xml.etree import ElementTree as ET

R = Path(__file__).resolve().parents[1]
ENGINE = (R / 'source/GarminWeatherWarnings.mc').read_text()
FACE = (R / 'source/SolarRings7X.mc').read_text()
SETTINGS = ET.parse(R / 'resources/settings/settings.xml').getroot()
STRINGS = ET.parse(R / 'resources/strings.xml').getroot()


def kind(tag):
    return tag - 96 if tag > 96 else tag - 64 if tag > 64 else tag - 32 if tag > 32 else tag - 16 if tag > 16 else tag

def has_current(tag): return tag <=16 or tag>32

def has_future(tag): return 16<tag<=48 or tag>96

def is_old(tag): return 64<tag<=80 or tag>96

def add(items, tag):
    k=kind(tag)
    for i, prev in enumerate(items):
        if kind(prev)==k:
            now=has_current(prev) or has_current(tag)
            future=has_future(prev) or has_future(tag)
            fresh=(has_current(prev) and not is_old(prev)) or (has_current(tag) and not is_old(tag))
            items[i]=k+(32 if now and future and fresh else 96 if now and future else 0 if now and fresh else 64 if now else 16)
            return items
    items.append(tag)
    return items

class CombinedWarnings32429(unittest.TestCase):
    def test_source_implements_packed_stale_and_forecast_states(self):
        for phrase in ('if (tag > 96) { return tag - 96; }',
                       'if (tag > 64) { return tag - 64; }',
                       'function isNow(tag)', 'function isFuture(tag)',
                       'function isOld(tag)',
                       'items[i] = fresh ? kind + 32 : kind + 96;',
                       'items[i] = fresh ? kind : kind + 64;',
                       'else { items[i] = kind + 16; }'):
            self.assertIn(phrase,ENGINE)

    def test_stale_observation_merge_commutative(self):
        for k in range(1,12):
            for tags in itertools.permutations([k+64,k+16]):
                out=[]
                for tag in tags: add(out,tag)
                self.assertEqual(out,[k+96])
            for tags in itertools.permutations([k,k+64,k+16]):
                out=[]
                for tag in tags: add(out,tag)
                self.assertEqual(out,[k+32])

    def test_merging_both_sources_independent_of_order(self):
        for k in range(1, 10):
            for tags in itertools.permutations([k, 16 + k]):
                result = []
                for tag in tags:
                    add(result, tag)
                self.assertEqual(result, [k + 32])

    def test_repeated_hours_do_not_create_extra_icons(self):
        for k in range(1, 10):
            items = []
            for tag in [k + 16, k + 16, k, k + 16, k, k + 16]:
                add(items, tag)
            self.assertEqual(items, [k + 32])

    def test_single_source_stays_single_source(self):
        for k in range(1, 10):
            self.assertEqual(add(add([], k), k), [k])
            self.assertEqual(add(add([], k + 16), k + 16), [k + 16])

    def test_seven_conditions_fit_four_cells(self):
        # StormGuard occupies one separate cell; thunder, rain and wind each
        # get ONE combined weather glyph, even when now and later are active.
        weather = []
        for tag in [4, 20, 2, 18, 1, 17]:
            add(weather, tag)
        self.assertEqual(weather, [36, 34, 33])
        self.assertEqual(len([-1] + weather), 4)

    def test_icon_colors_and_cyan_underline_placement(self):
        self.assertIn('if (alertTag > 96)', FACE)
        self.assertIn('hasForecastUnderline = true;', FACE)
        self.assertIn('else if (alertTag > 16)', FACE)
        self.assertIn('color = 0x00FFFF;', FACE)
        self.assertIn('dc.fillRectangle(x - 8, y + 11, 16, 2);', FACE)
        self.assertIn('dc.setColor(0x00FFFF, Gfx.COLOR_TRANSPARENT);', FACE)
        self.assertIn('if (hasForecastUnderline)', FACE)

    def test_partial_clip_includes_stripe_and_clears_old_stripe(self):
        self.assertIn('dc.setClip(103, 217, 22, 26);', FACE)
        self.assertIn('dc.fillRectangle(103, 217, 22, 26);', FACE)
        # Center y=228 => bar y=239..240; clip ends at y=242.
        self.assertLessEqual(228 + 12, 217 + 26 - 1)
        self.assertIn('if (_alertOverflow == null || _alertOverflow.size() <= 1)', FACE)

    def test_one_slot_per_distinct_weather_kind_and_storm_first(self):
        center = FACE.split('function drawAlertCenter(', 1)[1].split('// Battery footer', 1)[0]
        self.assertLess(center.index('active.add(-1)'), center.index('active.add(warnings[i])'))
        self.assertIn('var centers = [68, 91, 114];', center)
        self.assertIn('if (staticCount > 3) { staticCount = 2; }', center)

    def test_preview_for_three_combined_icons_and_legacy_preview(self):
        ids = [int(entry.attrib['value']) for entry in SETTINGS.iter('listEntry')
               if entry.attrib.get('value') in ('11','12','14')]
        self.assertIn(14, ids)
        self.assertIn('_lastKinds = [36, 34, 33];', ENGINE)
        self.assertIn('addAlert(_lastKinds, 20); // forecast storm', ENGINE)
        self.assertIn('addAlert(_lastKinds, 4);  // combined into tag 36', ENGINE)
        labels = {node.attrib['id']:node.text for node in STRINGS.iter('string')}
        self.assertIn('turkusowym paskiem', labels['gw_gwPreviewV324_11'])
        self.assertIn('3 podwójne', labels['gw_gwPreviewV324_14'])

    def test_no_new_sensors_network_or_background_work(self):
        for forbidden in ('Communications', 'makeWebRequest',
                          'Position.getInfo', 'registerForTemporalEvent'):
            self.assertNotIn(forbidden, ENGINE)
        self.assertIn('Weather.getHourlyForecast()', ENGINE)
        self.assertIn('now - _lastCheck >= interval * 60', ENGINE)
        self.assertEqual(FACE.count('Weather.getCurrentConditions()'), 1)
        self.assertIn('now - _lastCheck < 300', (R/'source/StormGuard.mc').read_text())

if __name__ == '__main__':
    unittest.main()
