# Solar Rings 7X 3.19.7 — czytelne błędy GUGiK / IMGW

Tarcza 3.19.6 pozostawała stabilna w testach 0, 1, 2. W etapie 3 na zegarku
wystąpił status `T3 R76K`, ponieważ kod maskował błędy HTTP/formatu odpowiedzi.
W tej wersji diagnostyka wyświetla konkretną przyczynę:

- `T3 1261 OK` — przykład poprawnego odczytu kodu powiatu (kod tylko przykładowy).
- `T3 HTTP-1002` — przykład niedozwolonego formatu HTTP w Connect IQ.
- `T3 HTTP-300` — przykład przekroczonego czasu żądania.
- `T3 HTTP403` — przykład odpowiedzi HTTP 403.
- `T3 FORMAT` — serwer odpowiedział HTTP 200, lecz treść nie pasuje do formatu ULDK.
- `T3 CZEKA RxxK` — brak jeszcze wyniku.
- `T4 OK0 1261` — przykład prawidłowo pobranej odpowiedzi bez ostrzeżeń.
- `T4 ALERT 1261` — przykład ostrzeżenia dla powiatu.

Komunikaty `HTTP` oraz `FORMAT` nie są sukcesem. W razie błędu należy przesłać
zdjęcie dokładnego kodu. Pozostałe funkcje tarczy są bez zmian.

Uwaga: testy statyczne w paczce nie zastępują kompilacji w Garmin SDK ani
sprawdzenia na fizycznym zegarku.
