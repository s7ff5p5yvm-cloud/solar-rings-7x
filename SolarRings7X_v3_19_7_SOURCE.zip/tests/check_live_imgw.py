#!/usr/bin/env python3
"""Live availability/schema probe of IMGW and GUGiK from GitHub Actions.

Proves that the official endpoints answer from CI. It cannot prove that the
watch completed its own background requests, which is what diagnostic mode
is for. Network failure is reported clearly and does not block the build.
"""
import json
import urllib.request
import urllib.parse

URL_IMGW = 'https://meteo.imgw.pl/api/meteo/messages/v1/osmet/latest/osmet-teryt'
URL_ULDK = 'https://uldk.gugik.gov.pl/?' + urllib.parse.urlencode({
    'request': 'GetCountyByXY',
    'xy': '19.9370,50.0614,4326',  # fixed test point in Kraków, not user location
    'result': 'teryt',
})

def download(url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent': 'SolarRings7X-CI/1.0'}), timeout=18) as response:
        return response.read()

def main():
    failures = []
    try:
        obj = json.loads(download(URL_IMGW))
        assert isinstance(obj, dict) and isinstance(obj.get('warnings'), dict) and isinstance(obj.get('teryt'), dict)
        print(f"PASS IMGW: {len(obj['warnings'])} warning records, {len(obj['teryt'])} county assignments")
    except Exception as exc:
        failures.append(f'IMGW live probe FAILED: {type(exc).__name__}: {exc}')
    try:
        text = download(URL_ULDK).decode('utf-8').strip()
        assert text.startswith('0\n'), repr(text[:80])
        code = text.split('\n',1)[1][:4]
        assert code.isdigit() and len(code)==4, repr(text[:80])
        print(f'PASS ULDK: example Krakow point mapped to county TERYT {code}')
    except Exception as exc:
        failures.append(f'ULDK live probe FAILED: {type(exc).__name__}: {exc}')
    for failure in failures:
        print(failure)
    if failures:
        raise SystemExit(1)
    print('PASS: both public service endpoints answered. Device still needs diagnostic-mode confirmation.')

if __name__ == '__main__':
    main()
