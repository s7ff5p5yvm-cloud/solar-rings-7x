#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parent.parent
face=(p/'source/SolarRings7X.mc').read_text()
svc=(p/'source/ImgwService.mc').read_text()
assert 'var _httpStatus;' in svc
assert 'networkDetail = (code == 6 || code == 8)' in svc
assert 'if (responseCode != 200) { _httpStatus = responseCode; stop(6); return; }' in svc
assert 'if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }' in svc
assert 'shortStatus = "T" + dStage.toString() + " HTTP" + response[1].toString();' in face
assert 'shortStatus = "T3 " + response[0].toString() + " OK";' in face
assert 'shortStatus = "T" + dStage.toString() + " FORMAT";' in face
print('PASS: explicit HTTP response diagnostics, county mapping and format error on face')
