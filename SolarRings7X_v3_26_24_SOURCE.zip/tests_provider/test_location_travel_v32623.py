"""v3.26.23 minimal location-change safety contracts. These are NOT on-device tests."""
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=(ROOT/'source/SolarOpenData.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
MANIFEST=(ROOT/'manifest.xml').read_text()
NETWORK=(ROOT/'source/SolarOpenNetwork.mc').read_text()
SETTINGS=(ROOT/'resources/settings/properties.xml').read_text()

class LocationTravel32623(unittest.TestCase):
    def test_fresh_fix_not_active_tracking(self):
        fn=DATA.split('function srOwmUpdateLocation(garmin)')[1].split('// Settings changes')[0]
        self.assertIn('Position.getInfo()',fn)
        self.assertIn('Position.QUALITY_USABLE',fn)
        self.assertIn('gpsInfo.when.value()',fn)
        self.assertIn('now - gpsStamp <= 12 * 60',fn)
        self.assertNotIn('Position.enableLocationEvents(',DATA)
        self.assertIn('id="Positioning"',MANIFEST)
    def test_weather_is_fallback_and_activity_not_preferred(self):
        fn=DATA.split('function srOwmUpdateLocation(garmin)')[1].split('// Settings changes')[0]
        self.assertTrue(fn.index('if (gpsCoords != null)') < fn.index('else if (weatherCoords != null') < fn.index('else if (activityCoords != null)'))
        self.assertIn('now - weatherStamp <= 3 * 3600',fn)
        self.assertIn('now - weatherStamp <= 24 * 3600',fn)
        self.assertIn('weatherStamp == 0',fn)
        self.assertIn('now - lastGpsStamp <= 2 * 3600',fn)
        self.assertIn('weatherStamp < lastGpsStamp',fn)
    def test_change_invalidates_old_city_and_immediate_due(self):
        fn=DATA.split('function srOwmUpdateLocation(garmin)')[1].split('// Settings changes')[0]
        for key in ['srOCurrV326','srOHoursV326','srOShortV3264','srODayV326','srOAirV326']:
            self.assertIn('srOwmWrite("'+key+'", null);',fn)
        for key in ['srONextCV326','srONextFV326','srONextDV326','srONextAV326']:
            self.assertIn('srOwmWrite("'+key+'", 0);',fn)
        self.assertIn('Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)))',fn)
        self.assertIn('if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }',NETWORK)
    def test_schedule_preserved(self):
        self.assertIn('now - _lastOpenLocationPoll >= 5 * 60',FACE)
        self.assertEqual(NETWORK.count('Comm.makeWebRequest('),1)
        self.assertIn('return _interval == 5 ? 10 * 60 : _interval * 60;',NETWORK)
        self.assertIn('id="srOwmMinutesV326" type="number">5<',SETTINGS)
    def test_previous_alerts_and_identity_remain(self):
        self.assertIn('var centers = [68, 91, 114];',FACE)
        self.assertNotIn('new StormGuard()',FACE)
        self.assertIn('version="3.26.24"',MANIFEST)
        self.assertIn('D1F8E1A4B7FC45BD91E8F0A0959041BF',MANIFEST)

if __name__=='__main__': unittest.main()
