from pathlib import Path
import math
import re
import unittest
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT / 'source' / 'SolarRings7X.mc').read_text()
FIELDS = (ROOT / 'source' / 'FieldData.mc').read_text()
WARNINGS = (ROOT / 'source' / 'GarminWeatherWarnings.mc').read_text()

class Performance32420(unittest.TestCase):
    def test_fast_fonts_keep_original_coordinates_and_double_stroke(self):
        segment = FACE.split('function drawClock(dc, clock)')[1].split('// Mini digits')[0]
        self.assertIn('var cx = 97;', segment)
        self.assertIn('var slotW = 164;', segment)
        self.assertIn('var slotH = 52;', segment)
        self.assertIn('dc.drawText(cx, yy, chosenFont, value, Gfx.TEXT_JUSTIFY_CENTER)', segment)
        self.assertIn('dc.drawText(cx + 1, yy, chosenFont, value, Gfx.TEXT_JUSTIFY_CENTER)', segment)
        self.assertIn('var low = 32;', segment)
        self.assertNotIn('for (var px = requested; px >= 32; px--)', segment)
    def test_font_fit_preserves_exact_max_size_and_native_fallback(self):
        segment=FACE.split('function drawSized(')[1].split('function fit(dc,')[0]
        self.assertIn('var requestedFont = vectorFontFor(sizePixels, digits)',segment)
        self.assertIn('var low = 10;',segment)
        self.assertIn('dim[0] <= width && dim[1] <= height',segment)
        self.assertIn('fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale)',segment)
        # Mathematical simulation: binary search produces the same maximal
        # fitting size as the old descending 1px loop for monotonic glyph sizes.
        for requested in (14, 19, 23, 32, 48, 64):
            for largest_fit in range(9,requested+1):
                original=next((p for p in range(requested,9,-1) if p<=largest_fit),None)
                chosen=requested if requested<=largest_fit else None
                if chosen is None:
                    low,high=10,requested-1
                    while low<=high:
                        mid=(low+high)//2
                        if mid<=largest_fit:
                            chosen=mid
                            low=mid+1
                        else:high=mid-1
                self.assertEqual(chosen,original)
    def test_history_cache_does_not_serve_live_pulse(self):
        self.assertIn('now - cached[0] < 30',FIELDS)
        self.assertIn('History.getBodyBatteryHistory(opt)',FIELDS)
        self.assertIn('History.getStressHistory(opt)',FIELDS)
        self.assertIn('function recentHeartRate()', FIELDS)
        self.assertIn('Activity.getActivityInfo()',FIELDS)
        self.assertNotIn('sampleValue(1)', FIELDS.split('function recentHeartRate()')[1].split('function sunClock')[0])
    def test_solar_cache_invalidates_at_day_change_and_weather_update(self):
        src=FIELDS.split('function sunClock(isRise, w)')[1].split('// Upcoming solar event.')[0]
        self.assertIn('day.year * 10000 + day.month * 100 + day.day',src)
        self.assertIn('cached[2] == observation',src)
        self.assertIn('nowSeconds - cached[0] < 90',src)
        self.assertIn('Weather.getSunrise(location, now)',src)
        self.assertIn('Weather.getSunset(location, now)',src)
        # Dynamic next-event code remains independent of cached sunrise text.
        self.assertIn('function nextSunEvent(w)',FIELDS)
    def test_fixed_moon_geometry_matches_original_sqrt(self):
        m=re.search(r'var _srMoonExtents12 = \[([^]]+)\];',FACE)
        self.assertIsNotNone(m)
        nums=[float(v.strip()) for v in m.group(1).split(',')]
        self.assertEqual(len(nums),25)
        for row,value in zip(range(-12,13),nums):
            self.assertAlmostEqual(value,math.sqrt(144-row*row),places=12)
        self.assertIn('Math.cos(2.0 * Math.PI * phase)',FACE)
    def test_preserved_user_features(self):
        for fragment in (
            'var remainingSteps = monitor.stepGoal - doneSteps;',
            'System.getSystemStats().charging',
            'chargingBatteryIcon(dc, 117, 261, Gfx.COLOR_GREEN)',
            'System.getDeviceSettings().phoneConnected',
            'drawPhoneBluetooth(dc);',
            'drawWeatherAge(dc, w);',
            'function onPartialUpdate(dc)',
            'drawGarminWarningIcon(dc, 123, 227, warning)',
            'drawMoonPanel(dc);',
        ):
            self.assertIn(fragment,FACE)
        self.assertIn('Weather.getHourlyForecast()',WARNINGS)
        self.assertIn('var phase = (Time.now().value() / 5).toNumber()',WARNINGS)
        manifest=ET.parse(ROOT/'manifest.xml').getroot()
        app=manifest.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.24.20')

if __name__=='__main__':unittest.main()
