# Solar Rings 7X v3.12 — czytelnosc i inteligentne oznaczenia

Dla Garmin Fenix 7X Pro Solar. Ten sam ID aplikacji, 41 ustawien Connect IQ.

Zmiany:
- Zegar pogrubiony RobotoCondensedBold, wiekszy docelowy rozmiar (46/54/62 px + dotychczasowy dodatek) oraz szersza przestrzen 164px; data bez zmian.
- Wszystkie dane z delikatnie podniesionymi docelowymi rozmiarami czcionek (+1-2px), z automatycznym ograniczeniem jesli nie mieszcza sie w swoich polach.
- Trzy kapsuly: ikony po lewej, liczby wyzej (174..196), grubszy pasek 3px na y=199..202, odsuniety od dolnej krawedzi.
- Po osiagnieciu 100% celu krokow pasek staje sie zielony, a po jego prawej stronie pojawia sie mala zielona fajka, ktora nie zaslania paska. Dziala przy przypisaniu krokow do dowolnej kapsuly.
- Przy pogodowej temperaturze: pomaranczowe sloneczko powyzej 30°C, niebieska sniezynka ponizej 0°C. W pozostalych sytuacjach nie ma ikonki.
- Ikony i progi temperatury mozna ustawic w Connect IQ (wlacz/wylacz, prog goraca, prog zimna).
- Wszystkie dotychczasowe opcje, w tym ostrzezenie burzowe przy ksiezycu, zachowane.

Instalacja: umiesc SolarRings7X_v3_12_SOURCE.zip w katalogu glownym repozytorium, a SolarRings7X_v3_12_BUILD.yml w .github/workflows/build-v3.yml. Uruchom workflow.

Weryfikacja: statyczne testy geometrii, XML i archiwum. Nie zastępuje uruchomienia kompilatora SDK ani sprawdzenia na fizycznym zegarku.
