#!/usr/bin/env python3
"""Static project, geometry and settings tests. NOT a Garmin SDK compile test."""
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
s=(r/'source/SolarRings7X.mc').read_text()
f=(r/'source/FieldData.mc').read_text()
g=(r/'source/StormGuard.mc').read_text()
props=ET.parse(r/'resources/settings/properties.xml').getroot()
settings=ET.parse(r/'resources/settings/settings.xml').getroot()
strings=ET.parse(r/'resources/strings.xml').getroot()
manifest=ET.parse(r/'manifest.xml').getroot()
app=manifest.find('{http://www.garmin.com/xml/connectiq}application')
assert app.attrib['id']=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
assert app.attrib['version']=='3.12.0'
ids={x.attrib['id'] for x in props}
assert len(ids)==len(list(props))==41
assert len(list(settings))==41
strids={x.attrib['id'] for x in strings}
assert len(strids)==len(list(strings))
assert len({x.attrib['propertyKey'] for x in settings})==41
for item in settings:
    key=item.attrib['propertyKey'].split('.')[-1]
    assert key in ids,key
    assert item.attrib['title'].split('.')[-1] in strids
    for opt in item.findall('.//listEntry'):
        assert opt.text.split('.')[-1] in strids
for key in ('stormFastV310','stormFastDropV310','stormOnV3','stormDropV3','stormAltitudeV3',
            'fontClockV31','fontDateV31','moonPanelV38','moonFontV38','capsuleStepsModeV39',
            'tempAlertsV312','tempHotV312','tempColdV312'):
    assert key in ids
for token in ('topSlot(dc, 73,','topSlot(dc, 134,','topSlot(dc, 195,',
              'capsule(dc, 32, 64,','capsule(dc, 99, 83,','capsule(dc, 185, 64,',
              'drawClock(dc, clock);','drawDate(dc, days[date.day_of_week - 1]',
              'drawMoonPanel(dc);','stormBolt(dc, 46, 147)',
              'stepGoal - steps', 'weatherSymbol(dc, 74, 235, weather)',
              'temperatureMarker(dc, weather, 124, 224);',
              'if (monitor.steps != null && monitor.stepGoal != null &&',
              'monitor.stepGoal > 0 && monitor.steps >= monitor.stepGoal)',
              'capsuleTrack(dc, left, top, width, d[2], col, stepsComplete);',
              'dc.setColor(stepsComplete ? Gfx.COLOR_GREEN : color',
              'if (temp > hot)', 'else if (temp < cold)',
              'var slotW = 164;', 'var slotH = 52;'):
    assert token in s,token
assert 'stormBolt(dc, 250, 192)' not in s
assert 'temperatureMarker(dc, weather, 124, 224)' in s
assert 'var requested = 62;' in s
assert 'var cx = 97;' in s
assert 'RobotoCondensedBold' in s
assert 'if (id == 16)' in s
assert 'if (id == 18) { temperatureMarker(' in s
# Event at exact 100%, but not before. No goal is not an achieved goal.
for steps,goal,expected in [(0,10000,False),(9999,10000,False),(10000,10000,True),
                            (15000,10000,True),(42,0,False),(42,None,False)]:
    complete=(goal is not None and goal>0 and steps>=goal)
    assert complete==expected
# x-coordinate separation and clear vertical lanes on the 280x280 display.
for left,width in [(32,64),(99,83),(185,64)]:
    top=167; right=left+width; bottom=top+44
    assert right<=249 and bottom==211
    icon_xmin=left+17-11; icon_xmax=left+17+11
    value_xmin=left+30
    assert icon_xmin>left+2 and icon_xmax<value_xmin
    assert 170<=182-12 and 182+11 < 199
    value_top=174; value_bottom=value_top+22
    progress_top=top+32; progress_bottom=progress_top+3
    assert value_bottom < progress_top and progress_bottom<bottom-2
    assert bottom<215
    bar_start=left+10; bar_end=right-10
    assert bar_start>left+4 and bar_end<right-4
    check_bar_end=bar_end-10
    check_min=right-19; check_max=right-11
    assert check_bar_end < check_min <= check_max < right-4
    assert progress_top-2 > value_bottom
# Dedicated temperature alert x: [117..131], temp slot x [138..224].
assert 109+2 <124-7 and 124+7<181-86//2
for temp,hot,cold,expected in [(31,30,0,'hot'),(30,30,0,None),(-1,30,0,'cold'),
                               (0,30,0,None),(9,30,0,None),(36,35,-5,'hot')]:
    result='hot' if temp>hot else 'cold' if temp<cold else None
    assert result==expected
for token in ('pressureTrend(3600, 3000,','pressureTrend(10800, 9000,',
              'stableElevation(windowSeconds, minimumSeconds, now)'):
    assert token in g
print('PASS: 3.12.0 app id, 41 settings, geometry, 100% check, temperature markers, storm trend')
