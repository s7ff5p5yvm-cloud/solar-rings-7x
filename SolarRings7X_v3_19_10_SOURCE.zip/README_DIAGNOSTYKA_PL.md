## Naprawa testu GitHub Actions (v3.19.10)

W workflow v3.19.9 krok "Live upstream IMGW + county geocoding check" zwracał błąd
`UnicodeDecodeError: invalid start byte 0x8b` przy próbie odczytu IMGW.
To typowy objaw nierozpakowanej odpowiedzi gzip (podpis `1f 8b`).
Teraz skrypt: żąda nieskompresowanej odpowiedzi, ale też rozpakowuje gzip
rozpoznany po nagłówku lub sygnaturze i *dopiero potem* parsuje JSON.
Dodano test offline `check_live_transport.py` na kompresję i błędne dane.

Ta zmiana naprawia test sieciowy w GitHub Actions. Kod pobierania IMGW i GUGiK
na zegarku jest pozostawiony bez zmian; `T3 F5-X` nadal wymaga osobnej
weryfikacji na urządzeniu. W `manifest.xml` poprawiono wersję aplikacji z
3.19.8 (przeoczenie w v3.19.9) na 3.19.10.

# Solar Rings 7X v3.19.10 — test odpowiedzi GUGiK

Poprzedni wynik na zegarku: **T3 F5** (odpowiedź HTTP 200, ale pierwszy wiersz ULDK nie miał statusu powodzenia `0`).

W tej wersji:
- zapytanie GetCountyByXY ma jawny adres URL zgodny z dokumentacją ULDK;
- parser toleruje spacje/CR wokół statusu, ale nigdy nie uznaje błędnego statusu za sukces;
- jeśli pierwszy wiersz jest niepoprawny, tarcza pokaże krótki fragment tego wiersza (`T3 F5-1`, `T3 F5--1`, `T3 F5-html` itp.);
- nie zmieniono pobierania GPS ani interwału IMGW.

## Test na zegarku
1. Zainstaluj nową wersję.
2. IMGW włączone, diagnostyka włączona, **Test 3 – GUGiK**, odświeżanie co 5 minut.
3. Poczekaj na wynik i odczytaj dokładny napis.
4. `T3 #### OK`: GUGiK poprawnie ustalił 4-cyfrowy kod powiatu. Dopiero wtedy test 4.
5. `T3 F5-X`: serwer zwraca status inny niż `0`. Przepisz X. Nie interpretuj tego jako braku ostrzeżeń.

`T3 F5-X` to kod diagnostyczny, nie kod powiatu. Kompilacja Garmin SDK i działanie na zegarku muszą zostać potwierdzone osobno.
