#!/usr/bin/env python3
"""Python model of ULDK status parsing; NOT Monkey C runtime execution."""
from pathlib import Path

def parse(raw):
    if raw is None: return None,'1'
    if not isinstance(raw,str): return None,'2'
    if len(raw)<2: return None,'3'
    if '\n' not in raw: return None,'4'
    head,rest=raw.split('\n',1)
    head=''.join(c for c in head if c not in ' \r\t')
    if head!='0':
        preview=''.join(c for c in head if c in '0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')[:4]
        return None,'F5-'+(preview or '?')
    rest=rest.lstrip('\r\n \t')
    if len(rest)<4:return None,'6'
    code=rest[:4]
    if not code.isascii() or not code.isdigit() or (len(rest)>4 and rest[4].isdigit()):return None,'7'
    return code,'0'
for value,exp in [
    ('0\n1261',('1261','0')),('0\r\n1261\r\n',('1261','0')),
    (' 0 \r\n  1261',('1261','0')),('1\n',(None,'F5-1')),
    ('1\nerror',(None,'F5-1')),('-1\nerror',(None,'F5--1')),
    ('<html>\nmessage',(None,'F5-html')),
    ('0\n126123',(None,'7')),(None,(None,'1')),('',(None,'3')),
    ('0\n12',(None,'6')),('garbled',(None,'4')),({},(None,'2')),
]:
    assert parse(value)==exp,(value,parse(value),exp)
svc=(Path(__file__).resolve().parents[1]/'source/ImgwService.mc').read_text()
face=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
assert 'var url = "https://uldk.gugik.gov.pl/?request=GetCountyByXY&xy="' in svc
assert 'Comm.makeWebRequest(url, null,' in svc
assert 'if (status != "0") {' in svc
assert '_httpStatus = preview.length() > 0 ? "F5-" + preview : "F5-?";' in svc
assert 'shortStatus = "T3 " + (reason.find("F5-") == 0 ? reason : "F" + reason);' in face
print('PASS: ULDK strict success and first-line error previews, URL assembly')
