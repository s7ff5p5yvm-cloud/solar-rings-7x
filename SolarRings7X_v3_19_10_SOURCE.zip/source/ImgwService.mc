using Toybox.System as Sys;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Application.Storage as Storage;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Application.Properties as Props;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as PersistedContent;

// IMGW beta: county TERYT from GUGiK ULDK (two HTTPS requests per refresh).
// Background service cannot enable GPS. The face stores a recent GPS fix.
// Privacy: coordinates are sent to GUGiK for geocoding; IMGW receives no coords.
(:background)
class ImgwServiceV318 extends Sys.ServiceDelegate {
    var _county;
    var _lat;
    var _lon;
    // HTTP error (code 6/8) or exact GUGiK payload validation reason (code 7).
    var _httpStatus;

    function initialize() {
        ServiceDelegate.initialize();
        _county = null;
        _lat = 0.0;
        _lon = 0.0;
        _httpStatus = 0;
    }

    // Missing or stale location/network => no warning, not a false all-clear.
    // Status: 1 active alert, 2 verified no alert, 3 no GPS, 4 stale GPS,
    // 5 outside Poland, 6 county HTTP, 7 county format,
    // 8 IMGW HTTP, 9 IMGW format, 10 local processing error.
    function stop(code) {
        var county = _county == null ? "" : _county;
        var networkDetail = (code == 6 || code == 7 || code == 8) ? _httpStatus : 0;
        Bg.exit([county, networkDetail, 0, Time.now().value(), _lat, _lon, code]);
    }

    function onTemporalEvent() {
        try {
            if (Props.getValue("imgwOnV317") != true) { stop(10); return; }
            var stage = Props.getValue("imgwTestStageV3194");
            if (stage == null) { stage = 0; }
            // Isolate the scheduler itself. No GPS, no network, no JSON.
            if (stage == 2) {
                Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 11]);
                return;
            }
            if (stage != 3 && stage != 4) { stop(10); return; }
            var loc = Storage.getValue("imgwLocV318");
            if (loc == null || !(loc instanceof Lang.Array) || loc.size() < 3) { stop(3); return; }
            var age = Time.now().value() - loc[2];
            if (age < 0 || age > 21600) { stop(4); return; } // max 6-hour-old GPS fix
            _lat = loc[0].toFloat();
            _lon = loc[1].toFloat();
            if (_lat < 49.0 || _lat > 55.1 || _lon < 14.0 || _lon > 24.3) { stop(5); return; }
            // Official ULDK. WKT EPSG:4326 order is longitude,latitude.
            var coords = _lon.format("%.5f") + "," + _lat.format("%.5f") + ",4326";
            // Use the documented ULDK GET URL directly. A fixed set of
            // parameter names and validated numeric coordinates means no
            // query dictionary transformation is needed here.
            var url = "https://uldk.gugik.gov.pl/?request=GetCountyByXY&xy="
                + coords + "&result=teryt";
            Comm.makeWebRequest(url, null,
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN },
                method(:onCountyResponse));
        } catch (e) { stop(10); }
    }

    // GUGiK ULDK uses a plain text status line and a TERYT value on
    // the following line. Validate strictly, but accept LF or CRLF and
    // harmless whitespace before the TERYT code.
    // Diagnostic reason on code 7 (FORMAT):
    // F1 empty; F2 non-string; F3 too short; F4 no newline;
    // F5-X unexpected first line (X is a safe, short preview);
    // F6 missing code; F7 non-digit code.
    // Do not interpret any nonzero ULDK service status as successful.
    function parseCounty(raw) {
        _httpStatus = 0;
        if (raw == null) { _httpStatus = 1; return null; }
        if (!(raw instanceof Lang.String)) { _httpStatus = 2; return null; }
        if (raw.length() < 2) { _httpStatus = 3; return null; }
        var nl = raw.find("\n");
        if (nl == null) { _httpStatus = 4; return null; }
        var header = raw.substring(0, nl);
        // Accept harmless ASCII whitespace around the status, but require
        // the complete first line to be exactly 0 afterwards.
        var status = "";
        for (var h = 0; h < header.length(); h++) {
            var c = header.substring(h, h + 1);
            if (c != " " && c != "\t" && c != "\r") { status += c; }
        }
        if (status != "0") {
            // Preserve a tiny, ASCII-only sample of the server's first line.
            // This exposes e.g. status 1/-1 or HTML errors directly on the
            // watch, without logging coordinates or showing a false OK.
            var preview = "";
            for (var k = 0; k < status.length() && preview.length() < 4; k++) {
                var x = status.substring(k, k + 1);
                if ("0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".find(x) != null) {
                    preview += x;
                }
            }
            _httpStatus = preview.length() > 0 ? "F5-" + preview : "F5-?";
            return null;
        }
        var pos = nl + 1;
        while (pos < raw.length()) {
            var ch = raw.substring(pos, pos + 1);
            if (ch != "\r" && ch != "\n" && ch != " " && ch != "\t") { break; }
            pos++;
        }
        if (pos + 4 > raw.length()) { _httpStatus = 6; return null; }
        var code = raw.substring(pos, pos + 4);
        for (var i = 0; i < 4; i++) {
            if ("0123456789".find(code.substring(i, i + 1)) == null) {
                _httpStatus = 7;
                return null;
            }
        }
        // Check the following character so malformed 5+-digit IDs are
        // not silently mapped to the wrong district.
        if (pos + 4 < raw.length() &&
            "0123456789".find(raw.substring(pos + 4, pos + 5)) != null) {
            _httpStatus = 7;
            return null;
        }
        return code;
    }

    function onCountyResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { _httpStatus = responseCode; stop(6); return; }
            _county = parseCounty(payload);
            if (_county == null) { stop(7); return; }
            if (Props.getValue("imgwTestStageV3194") == 3) {
                // GUGiK verified. End before contacting IMGW.
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 12]);
                return;
            }
            // The original IMGW /warningsmeteo returns a top-level JSON
            // ARRAY. Garmin makeWebRequest only accepts top-level JSON OBJECTS.
            // Use IMGW's official OSMET-Teryt map (object with warnings/teryt).
            Comm.makeWebRequest("https://meteo.imgw.pl/api/meteo/messages/v1/osmet/latest/osmet-teryt", null,
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
                method(:onWarningsResponse));
        } catch (e) { stop(10); }
    }

    function dateOrdinal(t) {
        if (t == null || !(t instanceof Lang.String) || t.length() < 16) { return -1; }
        try {
            var y = t.substring(0, 4).toNumber();
            var m = t.substring(5, 7).toNumber();
            var d = t.substring(8, 10).toNumber();
            var h = t.substring(11, 13).toNumber();
            var min = t.substring(14, 16).toNumber();
            return (((y * 13 + m) * 32 + d) * 24 + h) * 60 + min;
        } catch (e) { }
        return -1;
    }

    // IMGW's published timestamps use Poland local time.
    function localOrdinal() {
        var d = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        return (((d.year * 13 + d.month) * 32 + d.day) * 24 + d.hour) * 60 + d.min;
    }

    // 1 storm, 2 wind, 3 rain, 4 snow, 5 ice, 6 freezing rain,
    // 7 heat, 8 cold, 9 ground frost, 10 fog, 11 snowdrift, 12 thaw,
    // 13 unknown. Categories intentionally independent of warning severity.
    function phenomenon(n) {
        if (n == null) { return 13; }
        var t = n.toString();
        if (t.find("burz") != null || t.find("Burz") != null) { return 1; }
        if (t.find("Zawieje") != null || t.find("zawieje") != null ||
            t.find("zamiecie") != null || t.find("Zamiecie") != null) { return 11; }
        if (t.find("wiatr") != null || t.find("Wiatr") != null ||
            t.find("sztorm") != null || t.find("Sztorm") != null) { return 2; }
        if (t.find("marzn") != null || t.find("Marzn") != null ||
            t.find("marzną") != null || t.find("Marzną") != null ||
            t.find("Gołoled") != null || t.find("gołoled") != null) { return 6; }
        if (t.find("Oblodzen") != null || t.find("oblodzen") != null) { return 5; }
        if (t.find("śnieg") != null || t.find("śniegu") != null ||
            t.find("Śnieg") != null || t.find("śnież") != null) { return 4; }
        if (t.find("deszcz") != null || t.find("Deszcz") != null ||
            t.find("opad") != null || t.find("Opad") != null) { return 3; }
        if (t.find("Przymrozk") != null || t.find("przymrozk") != null) { return 9; }
        if (t.find("Roztop") != null || t.find("roztop") != null) { return 12; }
        if (t.find("Upa") != null || t.find("upa") != null) { return 7; }
        if (t.find("mróz") != null || t.find("Mroz") != null ||
            t.find("mroz") != null) { return 8; }
        if (t.find("mgł") != null || t.find("Mgł") != null ||
            t.find("mgl") != null) { return 10; }
        return 13;
    }

    // Official OSMET-Teryt response is a JSON OBJECT; Garmin does not
    // support top-level arrays for HTTP_RESPONSE_CONTENT_TYPE_JSON.
    // The web callback must have exactly the SDK-approved signature.
    function onWarningsResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
        if (payload == null) { stop(9); return; }
        try { processWarnings(payload); }
        catch (e) { stop(10); }
    }

    // Official IMGW response format:
    // {"warnings":{"warningId": {"PhenomenonName":"...", "Level":"2",
    //   "ValidFrom":"yyyy-mm-dd hh:mm", "ValidTo":"..."}},
    //  "teryt":{"1261":["warningId", ...]}, "program": {...}}
    // We only inspect warnings assigned to the exact county returned by GUGiK.
    function processWarnings(body as Lang.Object) as Void {
        try {
            if (!(body instanceof Lang.Dictionary)) { stop(9); return; }
            var warnings = body["warnings"];
            var countyMap = body["teryt"];
            if (warnings == null || !(warnings instanceof Lang.Dictionary) ||
                countyMap == null || !(countyMap instanceof Lang.Dictionary)) {
                stop(9); return;
            }
            var ids = countyMap[_county];
            // "No alerts" is valid only when the map is absent or a valid list;
            // malformed county data must never become a false all-clear.
            if (ids != null && !(ids instanceof Lang.Array)) { stop(9); return; }
            var bestLevel = 0;
            var bestType = 0;
            var now = localOrdinal();
            if (ids != null && ids instanceof Lang.Array) {
                // Bound the loop to avoid pathological input overloading worker.
                var maxItems = ids.size();
                if (maxItems > 25) { stop(9); return; }
                for (var i = 0; i < maxItems; i++) {
                    if (ids[i] == null) { stop(9); return; }
                    var warning = warnings[ids[i].toString()];
                    if (warning == null || !(warning instanceof Lang.Dictionary)) {
                        stop(9); return;
                    }
                    var start = dateOrdinal(warning["ValidFrom"]);
                    var end = dateOrdinal(warning["ValidTo"]);
                    if (start < 0 || end < 0) { stop(9); return; }
                    if (now < start || now > end) { continue; }
                    var level = 0;
                    try { level = warning["Level"].toNumber(); } catch (e) { }
                    if (level < 1 || level > 3) { stop(9); return; }
                    var kind = phenomenon(warning["PhenomenonName"]);
                    if (level > bestLevel || (level == bestLevel &&
                        (bestType == 0 || kind < bestType))) {
                        bestLevel = level;
                        bestType = kind;
                    }
                }
            }
            Bg.exit([_county, bestLevel, bestType, Time.now().value(), _lat, _lon, bestLevel > 0 ? 1 : 2]);
        } catch (e) { stop(10); }
    }
}
