# Solar Rings 7X 3.26.44 — hotfix Photon na stabilnej 3.26.37

**Baza: 3.26.37.** Tylko geolokalizacja; brak Open-Meteo i zmian w wyglądzie godziny, separatorów, zegara, progach alertów i prognozach.

- OWM nie odkłada już Photon bez końca przy kolejnych terminach bieżącej pogody: po pierwszym pobranym CURRENT geokoder może dostać pojedyncze wybudzenie tła.
- Garmin i OWM: Photon `/reverse`, promień 5 km, maksimum 3 zwrócone obiekty, wybrany prawidłowy `place`.
- Globalny odstęp 15 min między próbami; błędy 10/20/30/60 min (HTTP 429: co najmniej 60 min), bez historycznej blokady 3-24 h.
- Gdy BLE jest odłączony, nie wysyłamy żądania i nie zwiększamy licznika błędów serwera.
- Jednorazowo czyścimy tylko stare blokady Photon, pozostawiając dotychczasowe ustawienia i wyniki pogody.
- Garmin zapisuje nazwę miasta już w callbacku usługi tła; awaryjne `~` sprawdzane lokalnie ponownie co 5 min, nawet gdy zabrakło powiadomienia foreground; brak połączeń HTTP z renderera.
- Nadal jedno zapytanie HTTP w wybudzeniu background; bez osobnego timera dla OWM.

**Ograniczenia:** statyczne testy i audyt różnic nie zastąpią kompilacji Connect IQ SDK oraz weryfikacji na zegarku.
