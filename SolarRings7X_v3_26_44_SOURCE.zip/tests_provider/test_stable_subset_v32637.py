from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT/'source/SolarRings7X.mc').read_text()
NET = (ROOT/'source/SolarOpenNetwork.mc').read_text()
DATA = (ROOT/'source/FieldData.mc').read_text()

class StableSubset(unittest.TestCase):
    def test_owm_uses_coordinate_specific_photon_name(self):
        self.assertIn('var remote = remoteCityForWeatherPosition(latitude, longitude);', FACE)
        self.assertIn('var remoteStored = remoteCityForWeatherPosition(storedLoc[0], storedLoc[1]);',FACE)
        self.assertIn('if (srUseOpenWeather()) { return null; }',FACE)
        self.assertIn('"~" + srWeatherCityFromDegrees',FACE)
        self.assertIn('!same(_loc, value("srOLocV326"))', NET)
        self.assertIn('"https://photon.komoot.io/reverse"', NET)
        self.assertIn('"srGResult", [_loc[0], _loc[1], city.toUpper()]',NET)
    def test_no_extra_timer_and_weather_priority(self):
        self.assertIn('if (cityLookupDue() &&', NET)
        stage = NET.split('if (cityLookupDue() &&',1)[1].split('if (kindIs(""))',1)[0]
        self.assertIn('value("srOCurrV326") != null',stage)
        self.assertIn('startCityLookup();',stage)
        self.assertIn('function startCityLookup()',NET)
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
        self.assertIn('finish(city != null);',NET)
        self.assertIn('_face.clearLocationDisplayCache();',FACE)
    def test_capsules_clear_rules(self):
        self.assertIn('var top = 171;',FACE)
        self.assertIn('dc.drawRoundedRectangle(left, top, width, 39, 18);',FACE)
        self.assertIn('var by = top + 27;',FACE)
        self.assertIn('drawIcon(dc, iconX, 184, id,',FACE)
    def test_real_fractional_battery_no_fabrication(self):
        self.assertIn('function srBatteryPercentText(x)', DATA)
        self.assertIn('return srFieldReuse(id, "BAT", srBatteryPercentText(x),',DATA)
        self.assertIn('return whole.toString() + "%";',DATA)
    def test_no_openmeteo_provider(self):
        self.assertNotIn('meteo.open-meteo.com',NET)
        self.assertNotIn('open-meteo.com',NET)
if __name__ == '__main__': unittest.main()
