"""Source-level regression gates; not a Garmin SDK execution test."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
GEO=(ROOT/'source/WeatherGeocode.mc').read_text()
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()

class PhotonHotfix32644(unittest.TestCase):
    def test_photon_used_by_both_without_openmeteo(self):
        self.assertIn('"https://photon.komoot.io/reverse"',GEO)
        self.assertIn('"https://photon.komoot.io/reverse"',NET)
        self.assertNotIn('open-meteo.com', NET)
        self.assertIn('return srSetting("srProviderV326", 0) == 1;',DATA)
    def test_extended_radius_and_bounded_response(self):
        for s in [GEO,NET]:
            self.assertIn('"radius" => "5"',s)
            self.assertIn('"limit" => "3"',s)
            self.assertIn('i < 3;',s)
            self.assertIn('tag.equals("place")',s)
    def test_no_multi_hour_fail_lockout(self):
        for s in [GEO,NET]:
            self.assertIn('if (code == 429) { minutes = 60; }',s)
            self.assertIn('failures == 3',s)
            self.assertNotIn('3 * 3600',s[s.find('function retryLater('):s.find('function retryPhoneMissing(')] if s is GEO else s[s.find('function cityRetry('):s.find('function onCityReceive(')])
        self.assertIn('storedNumber("srGLastTry", 0) + 15 * 60',GEO)
        self.assertIn('_now - last < 15 * 60',NET)
    def test_owm_city_not_starved_by_current(self):
        self.assertIn('if (cityLookupDue() &&',NET)
        self.assertIn('!kindIs("current") || value("srOCurrV326") != null',NET)
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
    def test_no_http_without_ble(self):
        ix=NET.index('function startCityLookup()')
        self.assertLess(NET.index('if (!Sys.getDeviceSettings().phoneConnected)',ix),NET.index('Comm.makeWebRequest("https://photon',ix))
    def test_result_survives_lost_foreground_callback(self):
        self.assertIn('App.Storage.setValue("srGResult", [_requestedLat, _requestedLon, city]);',GEO)
        self.assertIn('Time.now().value() + (remote != null ? 24 * 3600 : 5 * 60)',FACE)
        self.assertIn('Time.now().value() + (remoteStored != null ? 24 * 3600 : 5 * 60)',FACE)
    def test_one_time_migration_does_not_delete_weather(self):
        self.assertIn('srGPolicyV32644',FACE)
        block=FACE.split('if (App.Storage.getValue("srGPolicyV32644") != 1)',1)[1].split('return [_face]',1)[0]
        self.assertNotIn('srOCurrV326',block)
        self.assertNotIn('srGResult',block)
        self.assertNotIn('App.Properties.setValue',block)

if __name__ == '__main__': unittest.main()
