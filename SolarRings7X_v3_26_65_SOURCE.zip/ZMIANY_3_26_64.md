# Solar Rings 7X v3.26.64 — Photon wyłącznie do lokalizacji

- Pogoda i ostrzeżenia tylko z Garmin Weather, TERAZ i 1–3 h nadal analizowane co 5 minut.
- Photon `https://photon.komoot.io/reverse` służy tylko do rozpoznawania nazwy miejscowości na podstawie współrzędnych pogodowych Garmina.
- Przywrócono **Communications** w manifeście; Positioning i Background pozostają.
- Poprawka historyczna: **nie wysyłamy parametru `lang=pl` ani `language=pl`**, który wcześniej skutkował HTTP 400.
- Bez dodatkowego timera: Photon dzieli z pogodą istniejące zadanie pięciominutowe.
- Warunek zapytania: tylko gdy poprzednio zapamiętana nazwa nie pasuje do aktualnych współrzędnych; minimalny odstęp 15 minut i maksymalnie 3 nieudane ponowienia dla jednej lokalizacji.
- Odpowiedź 2 rekordy maksymalnie, bez pobierania ogromnych danych i bez zapisywania surowego JSON.
- Wyświetlanie: nazwa Photon → nazwa Garmin → przybliżenie offline (z `~`), w razie braku położenia BRAK LOK.
- Nie uruchamiamy GPS ani nie odpytujemy OpenWeather. Przy zmianie miejsca współrzędne pochodzą z Garmin Weather, mogą być opóźnione.
- TEST 21 pokazuje status `PHOTON ST ... HTTP ...`, TEST 15 i 22 zachowane.
- UWAGA: status kompilacji Monkey C i zużycie baterii potwierdzamy dopiero po buildzie GitHub i 24h na zegarku.
