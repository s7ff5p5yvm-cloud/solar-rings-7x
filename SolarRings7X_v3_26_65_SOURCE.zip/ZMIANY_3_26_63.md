# Solar Rings 7X v3.26.63 — przywrócenie lokalizacji i wschodu/zachodu

**Przyczyna:** w v3.26.60–3.26.62 usunięto uprawnienie `Positioning`
z `manifest.xml`. Garmin Connect IQ zwraca w takim przypadku `null`
dla `Weather.CurrentConditions.observationLocationName` oraz
`observationLocationPosition`, nawet jeśli temperatura i warunki pogodowe
są dostępne. W `Activity.Info.currentLocation` także może brakować danych.
Skutkiem były równoczesne `BRAK LOK.` i `--:--` w polach słonecznych.

**Naprawa:** przywrócono `iq:uses-permission id="Positioning"`
bez włączania GPS, Photona, OWM czy HTTP. Obecny kod używa lokalizacji
z danych Garmin Weather; gdy Garmin nie udostępni nazwy stacji,
wykorzystuje posiadane współrzędne i offline przybliżenie miasta.
Wschód/zachód oblicza z tych samych współrzędnych, z awaryjnym odczytem
ostatniej dostępnej lokalizacji aktywności.

Pozostała logika tarczy jest nietknięta: ostrzeżenia TERAZ i 1–3 h co
5 minut, kolory, ustawienia, bufory baterii, ikony oraz obsługa
Connect IQ. Wersja ma ten sam identyfikator aplikacji.

Przeprowadzono testy statyczne i sprawdzenie XML oraz SHA256 paczki.
Kompilacja Monkey C i rzeczywisty test na zegarku pozostają wymagane.
Garmin może nadal nie udostępniać nazwy lub współrzędnych, jeśli ich
nie ma w danych pogodowych; wtedy `Positioning` jest warunkiem koniecznym,
lecz nie gwarantuje nieprzerwanej dostępności pozycji.
