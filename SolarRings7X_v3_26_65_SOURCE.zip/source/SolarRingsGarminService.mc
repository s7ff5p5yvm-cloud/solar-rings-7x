using Toybox.Weather as Weather;
using Toybox.Time as Time;
using Toybox.Application as App;
using Toybox.Application.Properties as Props;
using Toybox.Background as Bg;
using Toybox.System as System;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;

// Lightweight, shared location comparison. Coordinates are not rounded to
// a fake city; ~0.8 km threshold only avoids pointless reverse requests.
(:background)
function srPhotonSameRegion(a, b) {
    if (!(a instanceof Lang.Array) || !(b instanceof Lang.Array) ||
        a.size() < 2 || b.size() < 2 ||
        a[0] == null || a[1] == null || b[0] == null || b[1] == null) {
        return false;
    }
    return a[0] < b[0] + 0.007d && a[0] > b[0] - 0.007d &&
           a[1] < b[1] + 0.010d && a[1] > b[1] - 0.010d;
}

// ONE 5-minute Garmin background service. No second timers, no weather HTTP.
(:background)
class SolarRingsGarminService extends System.ServiceDelegate {
    var _requested;
    var _forecastUpdated;
    var _wide;

    function initialize() {
        ServiceDelegate.initialize();
        _requested = null;
        _forecastUpdated = false;
        _wide = false;
    }

    function saved(key) {
        try { return App.Storage.getValue(key); } catch (e) { return null; }
    }

    function note(stage, code) {
        // Never persist raw coordinates or complete HTTP JSON in diagnostics.
        try { App.Storage.setValue("srPhotonDiagV32664",
            [Time.now().value(), stage, code]); } catch (e) { }
    }

    // Fetch ONLY already-cached Garmin hourly data; no requests to weather API.
    function readGarminForecast() {
        try {
            if (Props.getValue("gwOnV332") == false ||
                Props.getValue("gwForecastV332") == false) { return; }
            var forecast = Weather.getHourlyForecast();
            if (forecast == null) { return; }
            var now = Time.now().value();
            var compact = [];
            for (var i = 0; i < forecast.size() && compact.size() < 3; i++) {
                var h = forecast[i];
                if (h == null || h.forecastTime == null) { continue; }
                var epoch = h.forecastTime.value();
                if (epoch > now && epoch <= now + 10800) {
                    compact.add([epoch, h.condition, h.precipitationChance,
                                 h.windSpeed, h.temperature]);
                }
            }
            App.Storage.setValue("srGarminForecastV32659", [now, compact]);
            _forecastUpdated = true;
        } catch (e) {
            // A missing/large system forecast never kills the watch face.
        }
    }

    function onTemporalEvent() {
        // Weather still has its exact 5-minute check on EVERY wake; Photon
        // is strictly conditional and shares the same background invocation.
        readGarminForecast();
        if (!tryPhotonOnChange()) {
            Bg.exit(_forecastUpdated ? 1 : null);
        }
    }

    function tryPhotonOnChange() {
        try {
            var target = saved("srPhotonTargetV32664");
            if (!(target instanceof Lang.Array) || target.size() < 2) {
                return false;
            }
            var answer = saved("srPhotonResultV32664");
            if (answer instanceof Lang.Array && answer.size() == 3 &&
                srPhotonSameRegion(answer, target) &&
                answer[2] instanceof Lang.String) {
                // SUCCESS + same coordinates: ZERO more network requests.
                return false;
            }
            // After three unsuccessful bounded retries at one location,
            // do not keep querying forever. A changed location resets this.
            var lastLocation = saved("srPhotonAttemptLocV32664");
            if (srPhotonSameRegion(lastLocation, target)) {
                var failures = saved("srPhotonFailV32664");
                if (failures != null && failures >= 3) { return false; }
            }
            var now = Time.now().value();
            var deadline = saved("srPhotonNextAtV32664");
            if (deadline != null && deadline > now && deadline <= now + 86400) {
                return false;
            }
            if (!System.getDeviceSettings().phoneConnected) {
                // No HTTP, no retry counter, resume on future 5-min wake.
                return false;
            }
            // A 15-minute global cap for Photon ONLY; Garmin forecast is
            // independent, refreshed even when Photon is waiting on network.
            var previous = saved("srPhotonLastTryV32664");
            if (previous != null && previous <= now && now - previous < 900) {
                return false;
            }
            _requested = [target[0], target[1]];
            var lastPlace = saved("srPhotonAttemptLocV32664");
            if (!srPhotonSameRegion(lastPlace, _requested)) {
                App.Storage.setValue("srPhotonAttemptLocV32664", _requested);
                App.Storage.setValue("srPhotonWideV32664", 0);
                App.Storage.setValue("srPhotonFailV32664", 0);
            }
            _wide = saved("srPhotonWideV32664") == 1;
            App.Storage.setValue("srPhotonLastTryV32664", now);
            var query = {
                "lat" => _requested[0].format("%.4f"),
                "lon" => _requested[1].format("%.4f"),
                "limit" => "2",
                "radius" => _wide ? "15" : "10"
            };
            if (!_wide) { query["osm_tag"] = "place"; }
            // CRITICAL v3.26.49 fix: DO NOT supply lang=pl / language=pl.
            // Public Photon previously rejected the unsupported language (400).
            note(10, 0);
            Comm.makeWebRequest("https://photon.komoot.io/reverse", query, {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            }, method(:onPhotonReply));
            return true;
        } catch (e) {
            note(29, -1);
            scheduleRetry(30);
            return false;
        }
    }

    function scheduleRetry(minutes) {
        try { App.Storage.setValue("srPhotonNextAtV32664",
            Time.now().value() + minutes * 60); } catch (e) { }
    }

    // Typed full callback union required by Connect IQ 9.3 compiler.
    function onPhotonReply(code as Lang.Number,
        data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        var stage = 23;
        var city = null;
        try {
            if (code < 0) { stage = 27; }
            else if (code != 200) { stage = 21; }
            else if (!(data instanceof Lang.Dictionary)) { stage = 22; }
            else {
                var items = data["features"];
                if (items instanceof Lang.Array) {
                    var n = items.size();
                    if (n > 2) { n = 2; }
                    for (var i = 0; i < n; i++) {
                        if (!(items[i] instanceof Lang.Dictionary)) { continue; }
                        var feature = items[i] as Lang.Dictionary;
                        var props = feature["properties"];
                        if (!(props instanceof Lang.Dictionary)) { continue; }
                        // A place result's own name is more precise than its
                        // administrative parent city (e.g. Wieliczka/Kraków).
                        var osm = props["osm_key"];
                        if (osm instanceof Lang.String && osm.equals("place")) {
                            city = props["name"];
                        }
                        if (!(city instanceof Lang.String) || city.length() < 2) {
                            city = props["city"];
                        }
                        if (city instanceof Lang.String && city.length() >= 2 &&
                            city.length() <= 42) { break; }
                        city = null;
                    }
                }
            }
        } catch (e) { stage = 29; city = null; }
        if (city != null && _requested != null) {
            try {
                var currentTarget = saved("srPhotonTargetV32664");
                // Delayed response must NOT replace name for new coordinates.
                if (srPhotonSameRegion(currentTarget, _requested)) {
                    App.Storage.setValue("srPhotonResultV32664",
                        [_requested[0], _requested[1], city.toUpper()]);
                    App.Storage.setValue("srPhotonNextAtV32664", 0);
                    App.Storage.setValue("srPhotonWideV32664", 0);
                    App.Storage.setValue("srPhotonFailV32664", 0);
                    note(20, code);
                    Bg.exit(2);
                    return;
                }
                // Movement while request in flight: allow immediate next wake.
                App.Storage.setValue("srPhotonNextAtV32664", 0);
                stage = 24;
            } catch (e) { stage = 25; }
        }
        if (stage == 24) {
            note(stage, code);
            Bg.exit(_forecastUpdated ? 1 : null);
            return;
        }
        if (code == 200 && stage == 23 && !_wide) {
            // Once try a broader but still bounded response if place tag has
            // no features in this location. Never take a road's own name.
            try { App.Storage.setValue("srPhotonWideV32664", 1); } catch (e) { }
            scheduleRetry(15);
        } else {
            var count = saved("srPhotonFailV32664");
            if (count == null || count < 0) { count = 0; }
            if (count < 3) { count += 1; }
            try { App.Storage.setValue("srPhotonFailV32664", count); } catch (e) { }
            // Limited retries ONLY while city unresolved, never on success.
            // Respect 429 and outages: don't hammer public Photon.
            if (code == 429) { scheduleRetry(120); }
            else { scheduleRetry(count == 1 ? 15 : (count == 2 ? 30 : 60)); }
        }
        note(stage, code);
        Bg.exit(_forecastUpdated ? 1 : null);
    }
}
