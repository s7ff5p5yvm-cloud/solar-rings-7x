import hashlib
import unittest
from pathlib import Path
P=Path(__file__).resolve().parent.parent
class ReleaseRegression(unittest.TestCase):
    def test_version_manifest(self):
        self.assertIn('version="3.26.65"',(P/'manifest.xml').read_text())
    def test_no_unneeded_icon_helpers(self):
        s=(P/'source/SolarRings7X.mc').read_text()
        self.assertNotIn('function simpleCloud(',s)
        self.assertNotIn('function stormBolt(',s)
        self.assertNotIn('GODZINOWA ZADANIE BG 30M',s)
    def test_solar_cache_and_5min_warn(self):
        solar=(P/'source/FieldData.mc').read_text()
        app=(P/'source/SolarRings7X.mc').read_text()
        self.assertIn('nowSeconds - cached[0] < 600)',solar)
        self.assertIn('Time.Duration(300)',app)
if __name__ == '__main__': unittest.main()
