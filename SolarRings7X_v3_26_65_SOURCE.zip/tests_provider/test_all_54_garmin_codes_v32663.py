import re,unittest
from pathlib import Path
P=Path(__file__).resolve().parent.parent
OFFICIAL=['CLEAR', 'PARTLY_CLOUDY', 'MOSTLY_CLOUDY', 'RAIN', 'SNOW', 'WINDY', 'THUNDERSTORMS', 'WINTRY_MIX', 'FOG', 'HAZY', 'HAIL', 'SCATTERED_SHOWERS', 'SCATTERED_THUNDERSTORMS', 'UNKNOWN_PRECIPITATION', 'LIGHT_RAIN', 'HEAVY_RAIN', 'LIGHT_SNOW', 'HEAVY_SNOW', 'LIGHT_RAIN_SNOW', 'HEAVY_RAIN_SNOW', 'CLOUDY', 'RAIN_SNOW', 'PARTLY_CLEAR', 'MOSTLY_CLEAR', 'LIGHT_SHOWERS', 'SHOWERS', 'HEAVY_SHOWERS', 'CHANCE_OF_SHOWERS', 'CHANCE_OF_THUNDERSTORMS', 'MIST', 'DUST', 'DRIZZLE', 'TORNADO', 'SMOKE', 'ICE', 'SAND', 'SQUALL', 'SANDSTORM', 'VOLCANIC_ASH', 'HAZE', 'FAIR', 'HURRICANE', 'TROPICAL_STORM', 'CHANCE_OF_SNOW', 'CHANCE_OF_RAIN_SNOW', 'CLOUDY_CHANCE_OF_RAIN', 'CLOUDY_CHANCE_OF_SNOW', 'CLOUDY_CHANCE_OF_RAIN_SNOW', 'FLURRIES', 'FREEZING_RAIN', 'SLEET', 'ICE_SNOW', 'THIN_CLOUDS', 'UNKNOWN']
class Garmin54CodeAudit(unittest.TestCase):
    def test_every_official_code_in_display_group(self):
        src=(P/'source/SolarWeatherCodes.mc').read_text()
        found=set(re.findall(r'Weather.CONDITION_([A-Z_]+)',src))
        self.assertEqual(set(OFFICIAL),found)
        self.assertEqual(54,len(OFFICIAL))
        self.assertIn('return -1;',src)
    def test_risky_codes_classified_and_severe_pop_bypass(self):
        src=(P/'source/GarminWeatherWarnings.mc').read_text()
        for key in ('HEAVY_RAIN','HEAVY_SHOWERS','HEAVY_SNOW',
                    'HEAVY_RAIN_SNOW','THUNDERSTORMS','SCATTERED_THUNDERSTORMS',
                    'CHANCE_OF_THUNDERSTORMS','FOG','HAIL','FREEZING_RAIN',
                    'ICE','WINDY','SQUALL','TORNADO','HURRICANE',
                    'TROPICAL_STORM'):
            self.assertIn('Weather.CONDITION_'+key,src,key)
        self.assertIn('!isForecast || rainExplicit ||',src)
        self.assertIn('!isForecast || snowExplicit ||',src)
        self.assertIn('!isForecast || mixedExplicit ||',src)
        self.assertIn('(isForecast && stormUncertain)',src)
        self.assertIn('validMeasure(visibility, 0, 100000)',src)
        self.assertIn('if (c != null && srGarminDisplayGroup(c) < 0)',src)
    def test_forecast_payload_minimal(self):
        src=(P/'source/SolarRingsGarminService.mc').read_text()
        self.assertEqual(1,src.count('Weather.getHourlyForecast()'))
        self.assertIn('compact.size() < 3',src)
        self.assertNotIn('h.visibility',src)
        self.assertNotIn('h.windGust',src)
    def test_no_warning_for_unknown_precipitation_by_default(self):
        src=(P/'source/GarminWeatherWarnings.mc').read_text()
        self.assertNotIn('c == Weather.CONDITION_UNKNOWN_PRECIPITATION',src)
        for harmless in ('MIST','HAZY','HAZE'):
            self.assertNotIn('c == Weather.CONDITION_'+harmless,src)
if __name__=='__main__':unittest.main()
