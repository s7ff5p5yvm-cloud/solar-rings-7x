import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent.parent
class RefreshContract(unittest.TestCase):
 def test_background_frequency(self):
  s=(P/'source/SolarRings7X.mc').read_text()
  self.assertIn('Time.Duration(300)',s)
  self.assertIn('old.value() != 300',s)
  self.assertNotIn('Time.Duration(900)',s)
 def test_current_warning_frequency(self):
  s=(P/'source/GarminWeatherWarnings.mc').read_text()
  self.assertIn('now - _lastCheck >= 300',s)
  self.assertNotIn('gwIntervalV332',s)
 def test_settings_consistent(self):
  sett=(P/'resources/settings/settings.xml').read_text()
  prop=(P/'resources/settings/properties.xml').read_text()
  self.assertNotIn('gwIntervalV332',sett+prop)
  self.assertIn('gwForecastV332',sett+prop)
 def test_no_duplicate_background_read(self):
  count=sum(x.read_text().count('Weather.getHourlyForecast()') for x in (P/'source').glob('*.mc'))
  self.assertEqual(count,1)
if __name__=='__main__':unittest.main()
