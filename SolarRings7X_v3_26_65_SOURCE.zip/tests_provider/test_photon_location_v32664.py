import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
P = Path(__file__).resolve().parent.parent
M=(P/'source/SolarRings7X.mc').read_text()
S=(P/'source/SolarRingsGarminService.mc').read_text()
A=(P/'manifest.xml').read_text()
class PhotonSafety(unittest.TestCase):
    def test_manifest(self):
        root=ET.fromstring(A)
        iq='{http://www.garmin.com/xml/connectiq}'
        perms=[x.get('id') for x in root.findall('.//'+iq+'uses-permission')]
        for p in ('Positioning','Communications','Background'):
            self.assertEqual(1, perms.count(p))
    def test_existing_5m_forecast_unchanged(self):
        self.assertIn('new Time.Duration(300)',M)
        self.assertEqual(1,S.count('Weather.getHourlyForecast()'))
        self.assertIn('readGarminForecast();', S)
        self.assertEqual(1,S.count('Comm.makeWebRequest('))
        self.assertNotIn('Bg.registerForTemporalEvent(', S)
    def test_photon_corrected_request(self):
        self.assertIn('https://photon.komoot.io/reverse',S)
        self.assertIn('query["osm_tag"] = "place"',S)
        self.assertIn('"limit" => "2"',S)
        # language=pl was once HTTP 400; no language request key.
        self.assertNotIn('"lang" =>',S)
        self.assertNotIn('"language" =>',S)
        self.assertIn('onPhotonReply(code as Lang.Number',S)
    def test_only_on_changed_location(self):
        self.assertIn('srPhotonTargetV32664',M)
        self.assertIn('srPhotonSameRegion(previous, ll)',M)
        self.assertIn('srPhotonSameRegion(answer, target)',S)
        self.assertIn('srPhotonLastTryV32664',S)
        self.assertIn('failures >= 3',S)
        self.assertIn('System.getDeviceSettings().phoneConnected',S)
        self.assertIn('srPhotonSameRegion(currentTarget, _requested)',S)
        self.assertIn('Bg.exit(2)',S)
        self.assertIn('invalidatePhotonDisplay()',M)
    def test_weather_independent_and_old_modules_absent(self):
        self.assertNotIn('SolarOpenNetwork', '\n'.join(x.name for x in (P/'source').glob('*.mc')))
        self.assertNotIn('api.openweathermap.org',S)
        self.assertNotIn('WeatherGuard',S)
    def test_location_fallbacks(self):
        self.assertIn('weather.observationLocationName',M)
        self.assertIn('srWeatherCityFromDegrees(',M)
        self.assertIn('srPhotonResultV32664',M)
        self.assertIn('updatePhotonTarget(w);',M)
if __name__=='__main__': unittest.main()
