import unittest
from pathlib import Path
import struct
ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'source/SolarRings7X.mc').read_text(encoding='utf-8')
SERVICE=(ROOT/'source/SolarRingsGarminService.mc').read_text(encoding='utf-8')
class PhotonCompileGuards(unittest.TestCase):
    def test_field_exists_and_is_initialized(self):
        self.assertIn('var _photonTargetCheckAt;',MAIN)
        self.assertIn('_photonTargetCheckAt = 0;',MAIN)
        self.assertIn('now - _photonTargetCheckAt < 55',MAIN)
    def test_stray_guard_removed(self):
        self.assertNotIn('skipPhotonForSettings',MAIN)
        self.assertEqual(1, MAIN.count('updatePhotonTarget(w);'))
        self.assertIn('if (!srSetting("moonPanelV38", true) || weather == null)', MAIN)
    def test_no_new_network_polling(self):
        self.assertEqual(1, SERVICE.count('Comm.makeWebRequest('))
        self.assertEqual(1, SERVICE.count('Weather.getHourlyForecast()'))
        self.assertIn('new Time.Duration(300)', MAIN)
        self.assertNotIn('Bg.registerForTemporalEvent(',SERVICE)
    def test_app_identity_and_photon_storage_compatibility(self):
        manifest=(ROOT/'manifest.xml').read_text()
        self.assertIn('version="3.26.65"',manifest)
        self.assertIn('D1F8E1A4B7FC45BD91E8F0A0959041BF',manifest)
        self.assertIn('srPhotonTargetV32664',MAIN)
        self.assertIn('srPhotonResultV32664',MAIN)
        self.assertNotIn('"lang" =>',SERVICE)
        self.assertNotIn('"language" =>',SERVICE)
    def test_icon_size(self):
        png=(ROOT/'resources/drawables/launcher_icon.png').read_bytes()
        self.assertEqual((40,40),struct.unpack('>II',png[16:24]))
if __name__=='__main__': unittest.main()
