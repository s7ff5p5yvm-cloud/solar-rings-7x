# Solar Rings v3.26.65 — poprawka błędu kompilacji Photona

W poprzedniej paczce v3.26.64 GitHub `monkeyc` zgłosił brakujące symbole `_photonTargetCheckAt` (2 użycia) i `skipPhotonForSettings` (1 użycie).

- Zadeklarowano i inicjalizowano do 0 pole `_photonTargetCheckAt`, zachowując ograniczenie odczytu współrzędnych do jednego sprawdzenia na minutę.
- Usunięto pozostały po refaktoryzacji niezdefiniowany `skipPhotonForSettings`; `updatePhotonTarget(w)` samo filtruje przypadek wyłączonej lokalizacji i brak danych.
- Dodano 5 testów regresyjnych, które wychwytują te konkretne brakujące symbole.
- Dopasowano launcher icon do rozmiaru 40x40, wskazanego w ostrzeżeniu kompilatora fenix7xpro.
- Nie zmieniono logiki ostrzeżeń, interwału 5 min, ustawień ani kluczy pamięci Photona `V32664` (zachowanie wcześniej rozpoznanych miast).

**Status:** testy statyczne i walidacja archiwów mogą przejść lokalnie. Kompilację Monkey C musi potwierdzić GitHub Actions.
