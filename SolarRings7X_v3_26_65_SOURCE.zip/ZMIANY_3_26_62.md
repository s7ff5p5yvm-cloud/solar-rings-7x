# Solar Rings 7X v3.26.62 — kontrola przed kompilacją

Poprawiono krytyczny błąd workflow: weryfikacja manifestu musi sprawdzać 3.26.62,
a nie 3.26.60. W v3.26.61 powodowało to błędne zatrzymanie budowania.

Optymalizacje bez zmiany sposobu wyświetlania:
- zachowano analizę ostrzeżeń Garmin TERAZ oraz 1–3 h co 300 sekund;
- wydłużono cache godzin wschodu/zachodu z 90 s do 600 s, a najbliższego
  zdarzenia słonecznego ze 120 s do 600 s; każde z nich i tak unieważnia się
  przy zmianie daty lub znacznika czasu obserwacji, a następne zdarzenie
  także w chwili jego nadejścia;
- usunięto dwa nieużywane rysowniki (simpleCloud, stormBolt);
- zredukowano zbędną alokację listy trzech pozycji ikon podczas rysowania;
- poprawiono testową informację z BG 30M na BG 5M.

Celowo NIE ZMIENIANO identyfikatorów ustawień, logiki klas pogodowych,
kolorów ostrzeżeń ani harmonogramu 5 min. Nie dodano żadnego nowego
wybudzenia ani zapytania internetowego.

Testy Python oraz parsowanie XML to kontrole statyczne; pełny test
kompilacji Monkey C, pamięci i baterii wymaga GitHub/SDK oraz zegarka.
