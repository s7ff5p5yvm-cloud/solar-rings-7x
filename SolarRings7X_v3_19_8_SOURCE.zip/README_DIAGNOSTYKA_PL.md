# Solar Rings 7X v3.19.8 — wyjaśnienie błędu T3 FORMAT

W wersji 3.19.7 użytkownik potwierdził `T3 FORMAT` przy stabilnej tarczy.
HTTP 200 potwierdza transmisję, ale kod powiatu GUGiK nie został rozpoznany.

Zmiany:
- tolerancja LF/CRLF i spacji przed TERYT (bez przyjmowania błędnych numerów);
- błędy formatu są rozdzielone na powody widoczne na tarczy;
- pozostałe funkcje i diagnostyka etapowa są bez zmian.

## Test
Włącz IMGW, diagnostykę, etap 3 i odświeżanie co 5 minut.

- `T3 1261 OK`: przykład prawidłowego powiatu, następny krok test 4;
- `T3 F1`: odpowiedź pusta;
- `T3 F2`: Garmin zwrócił typ inny niż tekst;
- `T3 F3`: zbyt krótka odpowiedź;
- `T3 F4`: brak znaku nowej linii;
- `T3 F5`: pierwszy wiersz odpowiedzi jest inny niż 0;
- `T3 F6`: brak czterech znaków kodu;
- `T3 F7`: nieprawidłowe cyfry TERYT;
- `T3 HTTP...`: błąd transportowy lub HTTP;
- `T3 CZEKA`: zadanie jeszcze nie zakończone.

Jeżeli zobaczysz `T3 F...`, przepisz dokładny numer. Samo `R76K` nie oznacza
że pole GUGiK zostało przetworzone poprawnie. Nie włączaj etapu 4 przed sukcesem etapu 3.

Testy Python sprawdzają wyłącznie typowe kontrakty i kod źródłowy, NIE zastępują
kompilacji Garmin SDK i uruchomienia na fizycznym zegarku.
