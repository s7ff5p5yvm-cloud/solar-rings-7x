#!/usr/bin/env python3
"""Validate expected GUGiK ULDK text forms (Python contract model, not Monkey C runtime)."""
from pathlib import Path

def parse(text):
    if text is None: return None, 1
    if not isinstance(text,str): return None,2
    if len(text)<5: return None,3
    if '\n' not in text: return None,4
    head, rest=text.split('\n',1)
    if head not in ('0', '0\r'): return None,5
    rest=rest.lstrip('\r\n \t')
    if len(rest)<4:return None,6
    code=rest[:4]
    if not code.isascii() or not code.isdigit() or (len(rest)>4 and rest[4].isdigit()):return None,7
    return code,0
for value,exp in [('0\n1261',('1261',0)), ('0\r\n1261\r\n',('1261',0)),('0\n  1261',('1261',0)), ('1\n1261',(None,5)),('0\n126123',(None,7)),(None,(None,1)),('',(None,3)),('0\n12',(None,3)),('garbled',(None,4)), ({},(None,2))]:
    assert parse(value)==exp,(value,parse(value),exp)
svc=(Path(__file__).resolve().parents[1]/'source/ImgwService.mc').read_text()
face=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
assert 'function parseCounty(raw)' in svc
assert 'if (header != "0" && header != "0\\r")' in svc
assert 'var networkDetail = (code == 6 || code == 7 || code == 8)' in svc
assert 'shortStatus = "T3 F" + response[1].toString();' in face
print('PASS: GUGiK parser accepts LF/CRLF and rejects malformed TERYT, format reason reaches diagnostics')
