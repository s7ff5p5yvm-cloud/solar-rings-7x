"""Static integration checks for the experimental watchface hold-to-launch."""
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'source/SolarRings7X.mc').read_text()
DELEGATE = (ROOT / 'source/SolarRingsCompassShortcut.mc').read_text()

class Shortcut85(unittest.TestCase):
    def test_click_delegate_uses_resolvable_boolean(self):
        self.assertIn('using Toybox.Lang as Lang;', DELEGATE)
        self.assertIn('function onPress(event as Ui.ClickEvent) as Lang.Boolean', DELEGATE)
        self.assertNotIn(' as Boolean {', DELEGATE)

    def test_watch_face_identity(self):
        root = ET.parse(ROOT / 'manifest.xml').getroot()
        app = root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['id'], 'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(app.attrib['type'], 'watchface')
        self.assertEqual(app.attrib['version'], '3.26.85')
        self.assertIn('ComplicationSubscriber', (ROOT / 'manifest.xml').read_text())

    def test_watchface_delegate_wired(self):
        self.assertIn('return [_face, new SolarRingsCompassShortcut()];', MAIN)
        self.assertIn('extends Ui.WatchFaceDelegate', DELEGATE)
        self.assertIn('function onPress(', DELEGATE)

    def test_moon_hotspot_matches_actual_location(self):
        self.assertIn('drawLunarDisk(dc, 52, 149, 12);', MAIN)
        for clause in ['x < 22', 'x > 116', 'y < 127', 'y > 171']:
            self.assertIn(clause, DELEGATE)
        self.assertIn('moonPanelV38', DELEGATE)
        self.assertIn('moonCompassShortcutV32685', DELEGATE)

    def test_no_periodic_polling_or_subscription(self):
        self.assertIn('Complications.getComplications()', DELEGATE)
        self.assertIn('Complications.exitTo(entry.complicationId)', DELEGATE)
        self.assertNotIn('subscribeToUpdates', DELEGATE)
        self.assertNotIn('registerComplicationChangeCallback', DELEGATE)
        self.assertNotIn('Timer', DELEGATE)
        body = MAIN[MAIN.index('function onUpdate(dc)'):]
        self.assertNotIn('getComplications(', body)

    def test_exact_publisher_match_and_no_foreign_launch(self):
        self.assertIn('entry.longLabel.equals("Compass Pro 7X Link")', DELEGATE)
        self.assertIn('entry.shortLabel.equals("CP7X")', DELEGATE)
        self.assertIn('return false;', DELEGATE)

    def test_reversible_option_and_xml(self):
        xml = (ROOT / 'resources/settings/properties.xml').read_text()
        self.assertIn('<property id="moonCompassShortcutV32685" type="boolean">true</property>', xml)
        settings = (ROOT / 'resources/settings/settings.xml').read_text()
        self.assertIn('Properties.moonCompassShortcutV32685', settings)
        for f in ROOT.rglob('*.xml'): ET.parse(f)

if __name__ == '__main__': unittest.main()
