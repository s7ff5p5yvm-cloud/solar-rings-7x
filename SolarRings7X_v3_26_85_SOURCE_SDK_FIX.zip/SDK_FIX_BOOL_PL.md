# Solar Rings 3.26.85 – poprawka SDK

Przyczyna niepowodzenia Actions 45835996473: `SolarRingsCompassShortcut.mc:12: Cannot resolve type Boolean`.

Zmiana: import `Toybox.Lang as Lang` i deklaracja `onPress(...) as Lang.Boolean`.
Dodany test regresji. Wszystkie funkcje tarczy pozostają bez zmian.

Kompilacja w Garmin SDK i bezpośrednie otwieranie Compass Pro z księżyca muszą być jeszcze potwierdzone.
