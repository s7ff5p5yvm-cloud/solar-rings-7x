# Solar Rings 3.26.67 — duże ikony Garmin Weather

- Wykorzystano całą dostępną lewą część dolnego panelu (około x=46–117, y=216–248) zamiast małego symbolu po ostrzeżeniach.
- Wprowadzono lekkie, kolorowe ikony wektorowe: słońce, częściowe i pełne zachmurzenie, deszcz, śnieg, opady mieszane, burza, mgła, wiatr, silne zjawiska, pył/dym, lód, grad i marznący deszcz.
- Oddzielono FREEZING_RAIN od ICE, zachowując obsługę 54 kodów warunków Garmin.
- Wszystkie ikony są renderowane z aktualnych danych Garmin Weather; brak pobierania prognozy godzinowej i ostrzeżeń.
- Zachowano bez zmian Photona, odczyt pogody, 55-sekundowy cache, ustawienia i pozostałe pola tarczy.
- Brak nowych timerów, bitmap, zapytań internetowych lub tablic alokowanych przez ikonę.
- Ze względu na wysokość panelu (~35 px) ikonka jest maksymalnie rozciągnięta głównie na szerokość.

UWAGA: Nie wykonano kompilacji Monkey C ani testu na fizycznym zegarku. Kod do testów, nie gwarantowana wersja produkcyjna.
