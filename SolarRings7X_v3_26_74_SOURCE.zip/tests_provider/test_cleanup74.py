import re, unittest
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text()
B=(P/'source/SolarRingsGarminService.mc').read_text()
def body(src,name):
    start=re.search(r'function\s+'+name+r'\([^)]*\)\s*\{',src).end()
    level=1
    for i in range(start,len(src)):
        if src[i]=='{': level+=1
        elif src[i]=='}': level-=1
        if level==0:return src[start:i]
    raise AssertionError(name)
class Cleanup74(unittest.TestCase):
    def test_dead_code(self):
        self.assertNotIn('_srMoonExtents14',S)
        self.assertNotRegex(S,r'function\s+(cloud|fit)\(')
        self.assertEqual(set(re.findall(r'drawLunarDisk\([^;\n]*,\s*(\d+)\);',S)),{'7','12'})
        self.assertIn('r == 12 ? _srMoonExtents12',S)
        self.assertIn('r == 7 ? _srMoonExtents7',S)
        self.assertIn('function desiredPixels(',S)
    def test_resolution_fast_path(self):
        update=body(S,'updatePhotonTarget')
        self.assertIn('srPhotonSameRegion(_photonTargetCache, ll)',update)
        self.assertIn('srPhotonSameRegion(_photonResolvedLocation, ll)) { return; }',update)
        self.assertEqual(update.count('_photonResolvedLocation = srPhotonScheduleIfNeeded();'),2)
        self.assertIn('_photonResolvedLocation = null;\n            _photonTargetCache',update)
        self.assertIn('_photonResolvedLocation = null;',body(S,'resetPerformanceCaches'))
        self.assertIn('_photonResolvedLocation = null;',body(S,'invalidatePhotonDisplay'))
    def test_scheduler_returns_only_verified_answer(self):
        scheduler=body(B,'srPhotonScheduleIfNeeded')
        self.assertEqual(scheduler.count('return answer;'),1)
        self.assertIn('answer[2] instanceof Lang.String &&\n            srPhotonSameRegion(answer, target)',scheduler)
        self.assertIn('failures >= 3',scheduler)
        self.assertIn('phoneConnected',scheduler)
        self.assertIn('Bg.registerForTemporalEvent(now.add(new Time.Duration(',scheduler)
        self.assertIn('lastTry + 900',scheduler)
        self.assertNotRegex(scheduler,r'return\s*;')
    def test_location_display_cache(self):
        panel=body(S,'drawMoonPanel')
        self.assertIn('var answer = _photonResolvedLocation;',panel)
        self.assertIn('answer == null || !srPhotonSameRegion(answer, ll)',panel)
        self.assertIn('App.Storage.getValue("srPhotonResultV32664")',panel)
        self.assertIn('location = answer[2];',panel)
    def test_background_and_heart_rate_constraints(self):
        self.assertIn('using Toybox.PersistedContent as Persisted;',B)
        self.assertIn('or Persisted.Iterator) as Void',B)
        combined='\n'.join(f.read_text() for f in (P/'source').glob('*.mc'))
        self.assertEqual(re.findall(r'\(:background\)\s*(?:class|function)\s+(\w+)',combined).count('srPhotonSameRegion'),1)
        self.assertEqual(set(re.findall(r'\(:background\)\s*(?:class|function)\s+(\w+)',combined)),{'srPhotonSameRegion','SolarRings7XApp','SolarRingsGarminService'})
        self.assertNotIn('onPartialUpdate(',combined)
        self.assertNotIn('Weather.getHourlyForecast(',combined)
        self.assertIn('var hr = activity.currentHeartRate;',combined)
