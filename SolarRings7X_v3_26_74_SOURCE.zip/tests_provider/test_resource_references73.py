from pathlib import Path
import re, unittest, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent.parent
class ResourceReferences73(unittest.TestCase):
 def test_all_resource_references(self):
  kinds={'Strings':'string','Drawables':'bitmap','Properties':'property'}
  defs={k:{} for k in kinds}
  for f in (P/'resources').rglob('*.xml'):
   for el in ET.parse(f).iter():
    for kind, tag in kinds.items():
     if el.tag == tag and 'id' in el.attrib:
      key=el.attrib['id']
      self.assertNotIn(key,defs[kind],f'Duplicate {kind}.{key}')
      defs[kind][key]=el
      if kind=='Drawables':self.assertTrue((f.parent/el.attrib['filename']).is_file())
  for f in [P/'manifest.xml',*(P/'resources').rglob('*.xml'),*(P/'source').rglob('*.mc')]:
   for kind,key in re.findall(r'(?:@|Rez\.)(Strings|Drawables|Properties)\.([A-Za-z_][A-Za-z0-9_]*)',f.read_text(encoding='utf-8')):
    self.assertIn(key,defs[kind],f'{f.name}: missing {kind}.{key}')
  self.assertEqual(defs['Strings']['AppName'].text,'Solar Rings 7X')
 def test_manifest_identity(self):
  app=ET.parse(P/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
  self.assertEqual(app.attrib['id'],'D1F8E1A4B7FC45BD91E8F0A0959041BF')
  self.assertEqual(app.attrib['name'],'@Strings.AppName')
  self.assertEqual(app.attrib['version'],'3.26.74')
