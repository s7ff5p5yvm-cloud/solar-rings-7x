# Test baterii v3.26.69 — porównanie z v3.26.65

Nie przerywaj trwającego testu starej wersji. Po instalacji 3.26.69 zanotuj datę, godzinę i procent baterii, a następnie stan po 24 oraz 48 godzinach. Zachowaj takie same ustawienia GPS, Bluetooth, nadgarstka, powiadomień, podświetlenia i aktywności, na ile to możliwe.

Punkt odniesienia: v3.26.65 zużyła 5,8 punktu procentowego w pierwszych 24 h (20–21.11.2026, 99,8% -> 94%). Nie ma gwarancji, że nowa grafika obniży zużycie; mierzymy rzeczywistą różnicę.

Odczyt bieżącego tętna pozostaje niebuforowany. Odświeżanie ekranu zależy od możliwości Garmin Connect IQ.
