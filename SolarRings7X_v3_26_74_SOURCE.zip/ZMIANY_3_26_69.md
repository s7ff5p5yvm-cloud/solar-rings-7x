# Solar Rings v3.26.69 — komplet ikon Premium MIP

Wersja bazuje na v3.26.68, bez zmiany identyfikatora aplikacji, pól danych, zapisanych ustawień ani działania czujników.

## Wszystkie 35 wybieralnych pól

- 1 tętno — pełne serce; 2 kroki — dwa ślady; 3 Body Battery — postać w łukach energii.
- 4 minuty intensywne / tydzień — stoper z dwoma akcentami; 5 minuty / dzień — stoper.
- 6 kalorie — płomień; 7 dystans — trasa z punktami; 8 piętra w górę — schody i strzałka w górę; 9 piętra w dół — schody i strzałka w dół.
- 10 stres — linia wykresu w kręgu; 11 SpO2 — kropla; 12 oddech — płuca; 13 regeneracja — strzałka kołowa.
- 14 wschód — słońce i strzałka w górę; 15 zachód — słońce i strzałka w dół; 16 pogoda — słońce za chmurą.
- 17 bateria zegarka — akumulator; 18 temperatura — termometr; 19 odczuwalna — termometr i powietrze; 20 wilgotność — kropla; 21 wiatr — smugi.
- 22 ciśnienie — barometr; 23 wysokość — góry; 24 cel kroków — tarcza ze śladami; 25 cel minut — tarcza z zegarem.
- 26 temperatura maksimum — termometr i strzałka w górę; 27 minimum — termometr i strzałka w dół; 28 pasek ruchu — sylwetka w ruchu; 29 UV — słońce; 30 opady % — chmura i krople.
- 31 czas — zegar; 32 data — kalendarz; 33 zachmurzenie — chmura; 34 Księżyc — faza; 35 następny wschód/zachód — właściwy symbol słoneczny.
- 0 Puste — pozostaje bez ikony.

## Wyświetlacz i bateria

- Wąskie kapsuły: ikony mieszczą się w ok. 20 x 20 px; dla wschodu/zachodu w górnym rzędzie pozostaje szersza wersja.
- Zero nowych fontów, bitmap, tablic, timerów, żądań pogodowych i zadań w tle.
- `Activity.getActivityInfo().currentHeartRate` nadal odczytuje bieżący puls przy odświeżeniu tarczy.
- Duża pogoda bieżąca z Garmin Weather, Photon tylko po zmianie lokalizacji, kolory i układ pozostają bez zmian.

**Ważne:** testy statyczne nie dowodzą bezbłędnej kompilacji Monkey C ani wyglądu na ekranie. Przed publikacją wymagany zielony build GitHub Actions i test zegarka.
