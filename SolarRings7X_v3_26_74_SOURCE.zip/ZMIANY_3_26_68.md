# Solar Rings v3.26.68 — Premium MIP Icons + Battery Care

- Premium Duotone: wschód i zachód, serce, ślady stóp, stoper, akumulator zegarka, postać Body Battery w łukach energii.
- Data: dzień tygodnia turkusowy, dzień/miesiąc jasno-lodowy; godzina i wartości pozostają wyraźnie białe.
- Duża bieżąca ikona pogodowa z v3.26.67 zachowana (bez ostrzeżeń/prognozy 1–3 h).
- Lżejsze rysowanie: wyłącznie stałe prymitywy graficzne, bez bitmap lub tablic tworzonych dla ikon.
- Optymalizacja: Gregorian.info tylko raz na minutę, a nie przy każdym odświeżeniu aktywnej tarczy.
- **Tętno bez zmian:** na każdej klatce `Activity.getActivityInfo().currentHeartRate` (odświeżanie zależy od ograniczeń Connect IQ). Bez bufora i bez danych historycznych zastępujących puls.
- Bez nowych timerów, zewnętrznego dostawcy pogody, WeatherGuard i cyklicznej prognozy godzinowej. Photon nadal tylko przy zmianie lokalizacji.
- Nie zmieniono identyfikatorów ustawień ani układu 280x280.

Wersja źródłowa do kompilacji GitHub. Nie przetestowano kompilacji Monkey C ani na urządzeniu.
