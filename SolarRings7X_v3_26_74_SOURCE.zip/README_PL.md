# Solar Rings v3.26.74 — Full Premium MIP Icons + maintenance

Kompletny zestaw ikon dla wszystkich 35 wybieralnych pól w Garmin Fenix 7X Pro Solar (fenix7xpro / fenix7xpronowifi). Nie zmieniono identyfikatora Connect IQ ani kluczy ustawień.

**Pogoda:** tylko bieżące warunki Garmin, bez WeatherGuard i bez pięciominutowego sprawdzania prognozy. Duża ikona pogody z v3.26.67 pozostaje zachowana. **Photon** służy tylko do nazwy lokalizacji i nie uruchamia cyklicznego pobierania.

**Tętno:** aktualna wartość z `Activity.getActivityInfo().currentHeartRate` przy każdym pełnym odświeżeniu tarczy, bez dodatkowego cache. Rzeczywisty rytm renderowania zależy od Garmin.

**Grafika:** pełna rodzina Premium Duotone, bez fontów/bitmap do symboli i bez tworzenia obiektów przez sam rysownik ikony. Każdy symbol ma własny kształt; dla wąskich kapsuł mały wariant wschodu/zachodu. Kolory daty, duża biała godzina, separatory, rozmiary i układ są zachowane.

Instrukcja: wgrać SOURCE.zip do katalogu głównego GitHub i BUILD.yml do .github/workflows, uruchomić GitHub Actions, opublikować IQ przez Developer Portal po zielonym buildzie. Na zegarku najpierw sprawdzić zapis ustawień i wszystkie kombinacje pól, potem rozpocząć osobny test baterii.

**Status:** przygotowana do kompilacji i testu. Nieprzetestowana lokalnie w Monkey C ani na fizycznym zegarku.

**v3.26.74:** usunięto martwy kod grafiki i zbędne sprawdzanie harmonogramu Photona po potwierdzonym sukcesie dla aktualnej lokalizacji. Zachowano AppName, ustawienia i identyfikator aplikacji.
