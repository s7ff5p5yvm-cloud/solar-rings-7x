# Solar Rings v3.26.73 — poprawka kompilacji

Przywrócono brakujący zasób tekstowy AppName (Solar Rings 7X), wymagany przez manifest. Dodano test odwołań do zasobów tekstowych, graficznych i właściwości oraz tożsamości aplikacji. Kod Monkey C, ustawienia i ikony nie zmieniono względem v3.26.72. Kompilacja Monkey C wymaga potwierdzenia w GitHub Actions.
