using Toybox.Weather as Weather;

// Official Garmin Condition enum 0..53, all values explicitly covered.
// Group is for the general weather pictogram and description only.
// Describes the CURRENT condition only; no warning thresholds or forecasts.
// 0 clear, 1 partly cloudy, 2 cloudy, 3 rain, 4 snow, 5 mixed,
// 6 thunder, 7 fog/haze, 8 wind, 9 extreme weather, 10 dust/smoke,
// 11 ice, 12 hail, 13 freezing rain; -1 unknown.
function srGarminDisplayGroup(code) {
    if (code == null) { return -1; }
    if (code == Weather.CONDITION_UNKNOWN) { return -1; }
    if (code == Weather.CONDITION_CLEAR ||
        code == Weather.CONDITION_MOSTLY_CLEAR ||
        code == Weather.CONDITION_FAIR) { return 0; }
    if (code == Weather.CONDITION_PARTLY_CLOUDY ||
        code == Weather.CONDITION_PARTLY_CLEAR ||
        code == Weather.CONDITION_THIN_CLOUDS) { return 1; }
    if (code == Weather.CONDITION_MOSTLY_CLOUDY ||
        code == Weather.CONDITION_CLOUDY) { return 2; }
    if (code == Weather.CONDITION_RAIN ||
        code == Weather.CONDITION_SCATTERED_SHOWERS ||
        code == Weather.CONDITION_UNKNOWN_PRECIPITATION ||
        code == Weather.CONDITION_LIGHT_RAIN ||
        code == Weather.CONDITION_HEAVY_RAIN ||
        code == Weather.CONDITION_LIGHT_SHOWERS ||
        code == Weather.CONDITION_SHOWERS ||
        code == Weather.CONDITION_HEAVY_SHOWERS ||
        code == Weather.CONDITION_CHANCE_OF_SHOWERS ||
        code == Weather.CONDITION_DRIZZLE ||
        code == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN) { return 3; }
    if (code == Weather.CONDITION_SNOW ||
        code == Weather.CONDITION_LIGHT_SNOW ||
        code == Weather.CONDITION_HEAVY_SNOW ||
        code == Weather.CONDITION_CHANCE_OF_SNOW ||
        code == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
        code == Weather.CONDITION_FLURRIES) { return 4; }
    if (code == Weather.CONDITION_WINTRY_MIX ||
        code == Weather.CONDITION_LIGHT_RAIN_SNOW ||
        code == Weather.CONDITION_HEAVY_RAIN_SNOW ||
        code == Weather.CONDITION_RAIN_SNOW ||
        code == Weather.CONDITION_CHANCE_OF_RAIN_SNOW ||
        code == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW ||
        code == Weather.CONDITION_SLEET ||
        code == Weather.CONDITION_ICE_SNOW) { return 5; }
    if (code == Weather.CONDITION_THUNDERSTORMS ||
        code == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
        code == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS) { return 6; }
    if (code == Weather.CONDITION_FOG ||
        code == Weather.CONDITION_HAZY ||
        code == Weather.CONDITION_MIST ||
        code == Weather.CONDITION_HAZE) { return 7; }
    if (code == Weather.CONDITION_WINDY ||
        code == Weather.CONDITION_SQUALL) { return 8; }
    if (code == Weather.CONDITION_TORNADO ||
        code == Weather.CONDITION_HURRICANE ||
        code == Weather.CONDITION_TROPICAL_STORM) { return 9; }
    if (code == Weather.CONDITION_DUST ||
        code == Weather.CONDITION_SMOKE ||
        code == Weather.CONDITION_SAND ||
        code == Weather.CONDITION_SANDSTORM ||
        code == Weather.CONDITION_VOLCANIC_ASH) { return 10; }
    if (code == Weather.CONDITION_ICE) { return 11; }
    if (code == Weather.CONDITION_FREEZING_RAIN) { return 13; }
    if (code == Weather.CONDITION_HAIL) { return 12; }
    return -1; // Unknown/future Garmin values: no guessed pictogram.
}
