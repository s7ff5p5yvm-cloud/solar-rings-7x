# Solar Rings v3.26.71 — Korekta kolorów pod 64-kolorowy MIP

## Dlaczego?
Fenix 7X Pro Solar posiada 64-kolorowy wyświetlacz MIP (RGB 2 bity na kanał). Bardzo podobne jasne kolory projektu v3.26.70 mogą na urządzeniu zlać się z bielą, mimo odmiennych kodów RGB zapisanych w źródłach. Zmieniono tylko 9 stałych kolorystycznych.

## Wprowadzone korekty
- Data: jasny lodowy cyjan 0xAAFFFF (odróżnialny od białej godziny), dzień tygodnia 0x55AAFF.
- Wschód: bursztyn 0xFFAA55; zachód: wyrazista lawenda 0xAA55FF.
- Body Battery: łuki energii 0x5555FF (figura zachowuje dynamiczny kolor kapsuły).
- Duża ikona słońca: osobne kolory promieni 0xFFFF55, tarczy 0xFFAA00 i refleksu 0xFFFFAA.
- Chmury: refleks 0xAAFFFF, aby nie zlewał się z białą chmurą.

## Bez zmian (zamrożone)
- Wszystkie 35 pól, kształty i wymiary ikon, układ i separatory, termometry i ich progi, baterie oraz wielkość tekstów.
- Żadnych nowych timerów, bitmap, obliczeń, operacji sieciowych lub prognoz godzinowych.
- Tętno z Activity.currentHeartRate przy każdym odświeżeniu, Photon tylko przy zmianie lokalizacji, Garmin Weather tylko bieżące dane.

## Weryfikacja
Testy statyczne (łącznie z pięcioma nowymi testami palety), manifest/XML, ZIP/SHA. Bez lokalnego kompilatora Monkey C, testu na zegarku ani bezpośredniego pomiaru baterii. Wymagana zielona kompilacja Github Actions przed instalacją.
