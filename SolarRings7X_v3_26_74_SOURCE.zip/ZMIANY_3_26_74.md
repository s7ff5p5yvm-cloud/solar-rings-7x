# Solar Rings v3.26.74 — porządki i Photon

Baza v3.26.73 (z poprawnym zasobem AppName). Bez zmian wyglądu, kolorów, układu, ustawień, ID aplikacji i sposobu odczytu tętna.

- Usunięto nieużywaną tablicę `_srMoonExtents14` (29 elementów), wariant r=14 i nieużywane funkcje `cloud()` i `fit()`. Aktywne promienie 7 i 12 oraz `desiredPixels()` pozostają.
- Po potwierdzonym sukcesie Photona dla tej samej lokalizacji wynik jest przechowywany w pamięci tarczy, bez ponownego odczytu harmonogramu i magazynu przy każdym cyklu sprawdzania. Przy zmianie lokalizacji lub braku wyniku zachowano dotychczasową ścieżkę i ograniczenia ponowień. Wynik musi pasować do współrzędnych; callback unieważnia cache.
- Bez zmian importu PersistedContent, czcionek, progów wieku pogody i termometrów, wywołań czujnika tętna, adnotacji background i uprawnień. Bez onPartialUpdate, 1 Hz w uśpieniu, prognozy godzinowej i cyklicznego zadania pogodowego.

Weryfikacja: 45 testów statycznych, walidacja XML, integralności archiwum i etapów kontrolnych workflow. Brak lokalnego Monkey C i testu na fizycznym Fenixie. Oszczędności RAM/energii niezmierzone.
