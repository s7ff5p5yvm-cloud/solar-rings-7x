# Solar Rings v3.26.70 — Premium + termometr i bardziej zwarta bateria

## Poprawione
- Przywrócono niezależny **termometr temperatury** z osobnym przełącznikiem oraz progami zimna i upału (te same klucze `tempAlertsV312`, `tempColdV312`, `tempHotV312` jak w v3.26.65).
- Niebieski termometr przy temperaturze poniżej progu, czerwony powyżej, brak ikony przy temperaturze między progami lub po wyłączeniu. Przy starym odczycie (45–90 min) termometr neutralny szary, przy braku świeżych danych ukryty.
- Nowa wersja Premium Duotone termometru, tylko wewnątrz x=138..146, y=215..233, bez ryzyka zasłonięcia temperatury lub odczuwalnej.
- Przesunięto dolną ikonkę baterii / innego wybranego pola o 7 px w prawo, a liczbę o 2 px; przerwa przy najdłuższych wartościach ma minimum 2 px.
- Zachowano możliwość testowania zimna i gorąca przez `tempLayoutTestV32412`, także gdy termometr jest wyłączony w ustawieniach (tryb diagnostyczny).

## Bez zmian
- Duża ikona bieżącej pogody Garmin, bez ostrzeżeń z prognozy 1–3 h, bez pięciominutowego sprawdzania pogody i bez WeatherGuard.
- 35 ikon Premium MIP, tętno z bieżących odczytów, Photon uruchamiany tylko przy zmianie lokalizacji.
- Rozmieszczenie separatorów, rozmiar cyfry godziny, data, zegarek, prognoza bieżąca i połączenie Bluetooth.

## Ograniczenia
- Przesunięcie baterii porządkuje dolny pasek i zwiększa margines od lewej, ale **nie powiększa pionowo** osobnego panelu pogody y=216..248.
- 29 testów statycznych potwierdza spójność projektu. Wymagana rzeczywista kompilacja Monkey C (GitHub Actions) oraz ocena wyglądu na ekranie MIP.
