# Solar Rings v3.26.72 — Body Battery premium zgodne z przesłanym wzorem

## Co poprawiono
- Poprawiono wyłącznie ikonę Body Battery (`bodyBatteryIcon`): pełna, zwarta sylwetka z ramionami w górze, duża okrągła głowa, trzy odseparowane części niebieskiej aureoli energii, z przerwą w dolnej prawej części.
- W przeciwieństwie do v3.26.71 nie jest to cienki „patyczak” otoczony niemal pełnym okręgiem.
- Kolor figury nadal odpowiada wybranemu kolorowi pola / progowi niskiego Body Battery. Tło aureoli jest niezależnie niebieskie, jasny refleks głowy cyjanowy.
- Ikona mieści się w polu x −11..+9, y −10..+9; nie nachodzi na wartość w kapsule.
- Prosty rysunek z linii, koła i małego wypełnienia; bez bitmap i alokacji.

## Bez zmian
- Wszystkie inne ikony (w tym bateria zegarka), 64-kolorowa paleta MIP, pozycje i wielkości tekstu, pogoda Garmin tylko TERAZ, brak odpytywania prognozy godzinowej.
- Photon, termometry, ustawienia, odczyt tętna w czasie odświeżania tarczy i optymalizacje baterii.

## Weryfikacja
- Testy źródeł, manifestu, XML i pakowania. Brak lokalnego kompilatora Monkey C. Przed instalacją wymagana udana kompilacja w GitHub Actions oraz kontrola czytelności na MIP.
