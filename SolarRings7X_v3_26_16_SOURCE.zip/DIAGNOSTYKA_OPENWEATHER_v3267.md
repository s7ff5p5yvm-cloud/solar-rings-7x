# Solar Rings 7X v3.26.7 — uzupełnienie diagnostyki odpowiedzi OpenWeather

Zdjęcie TEST 15 z v3.26.6 pokazało `OWM LOK: ODPOWIEDZ` (kod -15 przy fazie 0), choć lokalizacja Kraków była widoczna. Kod -15 scalał kilka problemów. Nowa wersja zapisuje bezpieczne metadane aktywnego żądania (czas, fazę, współrzędne, interwał; **nigdy klucz ani odpowiedź JSON**) i odtwarza je w callbacku przy utracie kontekstu.

Kody:
- `OWM TERAZ: JSON` (-151) — HTTP 200, ale odpowiedź nie jest słownikiem JSON.
- `OWM TERAZ: FORMAT` (-152) — brak wymaganej struktury odpowiedzi.
- `OWM TERAZ: STARE DANE` (-153) — obecne dane nie mają prawidłowego czasu lub wartości.
- `OWM TERAZ: ZAPIS` (-154) — problem zapisu do App.Storage.
- `OWM TERAZ: WYJATEK` (-155) — błąd podczas przetwarzania.
- `OWM TERAZ: KONTEKST` (-19) — nie udało się odtworzyć metadanych żądania.

To poprawka diagnostyczna i odporności na utratę kontekstu; **nie jest jeszcze potwierdzeniem rozwiązania przyczyny z v3.26.6**. Wymagana kompilacja Garmin SDK i test na zegarku.
