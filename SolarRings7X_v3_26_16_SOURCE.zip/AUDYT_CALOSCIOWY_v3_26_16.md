# SOLAR RINGS v3.26.16 — audyt zintegrowanej wersji do testów

Data: 2026-11-17. Oryginalny cel urządzenia: Garmin Fenix 7X Pro Solar.

## Rzetelność i ograniczenia

To analiza kodu, kontrola XML/archiwów i testy źródłowe oraz symulacja harmonogramu w Pythonie. **Nie jest to kompilacja Monkey C ani test na fizycznym zegarku.** Nie gwarantuje 100% niezawodności, trafności lokalnych prognoz ani 10-dniowej pracy baterii. W razie błędów środowiska nie wolno twierdzić, że udało się pobrać dane. Źródła pogody i SensorHistory bywają niekompletne.

## Zintegrowane źródła

| Wejście | Częstotliwość docelowa | Jak może generować ostrzeżenia |
| --- | --- | --- |
| OWM One Call 4.0 `current` | 10 min | Kody bieżących zjawisk, wiatr, porywy, UV, mgła, temperatura, ciśnienie |
| One Call 4.0 `timeline/1min` | 30 min | Ilość **przewidywanych** opadów co minutę — rodzaj opadu NIEZNANY |
| One Call 4.0 `timeline/15min` | 30 min | Prognoza kodów i prawdopodobieństw na najbliższą godzinę |
| One Call 4.0 `timeline/1h` | 60 min | Prognoza kodów i prawdopodobieństw aż do horyzontu 3h |
| One Call 4.0 `timeline/1day` | 12 h | Min./maks. dla bieżącej lokalnej daty |
| OpenWeather `air_pollution` | 60 min | AQI 1–5, próg domyślny 4 |
| `data.alerts` i `onecall/alert/{id}` | tylko po wykryciu nowego ID | Szczegóły oficjalnego ostrzeżenia, `event`/`tags`, czas ważności |
| Garmin SensorHistory | odczyt w trakcie aktualizacji tarczy, wynik cache 5 min | Niezależny trend ciśnienia 1h i 3h |

Model 5-minutowych okien Garmin wykonuje 1 żądanie HTTP na jedno uruchomienie, nie 7 jednoczesnych żądań. Pogoda bieżąca ma pierwszeństwo co 10 min. Mniej pilne źródła mają limit zaległości, aby nie zostały zagłodzone. W symulacji 24h przy ciągłym połączeniu: 144 bieżące, 48 minutowych, 44 15-minutowe, 23 godzinowe, 23 AQI, 2 dzienne = **284 żądania na dobę**. Dodatkowe szczegóły oficjalnych alertów, błędy, ponowienia i realne opóźnienia systemu mogą zmienić proporcje. Lokalny licznik uniemożliwia rezerwowanie ponad 700 własnych wywołań na dzień UTC. Nie ogranicza innego urządzenia lub programu korzystającego z tego samego API key. 1000 jest limitem zewnętrznej subskrypcji, którą należy osobno skonfigurować na koncie.

## Ostrzeżenia i interpretacja czasowa

- **Czerwone:** aktualnie zgłoszone zjawisko w świeżym kodzie warunków, a nie domniemanie z sumy `rain.1h`.
- **Szare:** starszy kod lub opady z ostatniej godziny bez dowodu na opad w aktualnej chwili.
- **Turkusowe:** zjawisko przewidywane w prognozie lub rodzaj zagrożenia rozpoznany z aktywnego urzędowego ostrzeżenia. Nie oznacza zaobserwowanego zjawiska.
- **Turkusowa kropla z chmurą:** prognoza opadów minutowych — **nie wiadomo, czy będą to deszcz, śnieg czy inne opady**, nie ma powodu przypisywać koloru RED.
- **Wykrzyknik:** urzędowy alert OpenWeather. Sam identyfikator bez szczegółów nie ujawnia rodzaju. Szczegóły urzędowego alertu pobierane są osobno, z obsługą `K-403` i jednorazową rezygnacją na dobę z przeciążającego ID.
- **Żółta błyskawica StormGuard:** trend spadku ciśnienia, nie potwierdzenie wyładowań. Błyskawica z `?`: zmiana wysokości barometrycznej nie pozwoliła pewnie odróżnić pogody od ruchu.
- **Błyskawica pogodowa OpenWeather:** kody burz lub forecast/alert szczegółowy wskazujący ryzyko burzy. To nie jest to samo co systemowy alarm ciśnienia Garmina.

Zachowane: deszcz, mżawka, śnieg, opady mieszane, burza, marznący deszcz, ryzyko oblodzenia, mgła/widzialność, wiatr/porywy, lokalne zjawiska ekstremalne, pył/dym, UV i AQI. OWM standardowe kody nie potwierdzają gradu niezależnie; szczegółowy oficjalny alert może oznaczać grad jako prognozowany. Nie utożsamiać powodzi z padającym deszczem.

## Domyślne ustawienia pierwszego uruchomienia

- Odświeżanie OWM: maksymalnie aktualne (5-minutowe sloty systemowe).
- Ostrzeżenia aktywne, ocena co 5 min, horyzont do 3 h, prognoza krótkoterminowa aktywna, AQI aktywne.
- Deszcz 30% i śnieg 40% dla prognozy; bez filtra „tylko intensywne”.
- Wiatr 10 m/s, porywy 15 m/s, widzialność 500 m, oblodzenie przy temperaturze do +1°C i opadach, UV ≥7, AQI ≥4.
- Minutowe opady: ≥0,20 mm/h prognozowane dla przynajmniej jednej minuty w następnych 30 min.
- StormGuard: spadek 2 hPa/1h albo 4 hPa/3h, filtr wysokości 20 m z dodatkową interpretacją niepewności i korelacją ciśnienia OWM.

Ustawienia aplikacji zmieniają się jeden raz, gdy nowa wersja startuje pierwszy raz. Klucz API, dostawca (Garmin/OWM), układ i dane zegarka zostają bez zmian. Późniejsze własne ustawienia użytkownika są respektowane.

## Zabezpieczenia

- Każde żądanie osobno i serwerowe `cnt` dla JSON prognoz; Garmin `-403` oznacza brak pamięci na odpowiedź, a nie HTTP 403.
- Przy niedostępnej prognozie 15-minutowej utrzymuje niezależną prognozę godzinową; pamięciochłonny endpoint jest wstrzymywany.
- Dla minutowej prognozy 30/12 rekordów po błędzie, pauza po powtarzającym się `-403`.
- Dla prognozy godzinowej 3/2 rekordy; daty i numerycznie ograniczone wartości są walidowane; nie zapisujemy pełnego JSON.
- Dla oficjalnego alertu opis może być bardzo duży: w pamięci trwałej przechowujemy tylko zwięzłe liczby. Gdy po API nie wraca odpowiedź albo wystąpi błąd, zachowujemy ogólne ostrzeżenie, nie zgadujemy zjawiska i nie wykonujemy niekończących się retry.
- Rozłączenie telefonu nie blokuje całego odświeżania na godzinę: próba ponowienia po pięciu minutach.
- Żadnego osobnego uruchamiania GPS, żadnych sieciowych odczytów podczas malowania tarczy.

## Uczciwe braki potwierdzenia

1. Obecna paczka **nie jest skompilowana kompilatorem Garmin**. GitHub Actions może wykryć błąd Monkey C, którego nie wykrywa test Pythona.
2. Nie było dostępu do działającego klucza użytkownika; nie sprawdzono realnych odpowiedzi i dokładnego rozmiaru JSON serwisów 1min, alert detail, daily.
3. Barometr Garmina i wysokość barometryczna nie są niezależnymi sensorami; wynik StormGuard jest tylko oszacowaniem i nie ma dostępu do wewnętrznego alarmu producenta.
4. OpenWeather nie jest lokalnym deszczomierzem ani radarem z obserwacją w czasie rzeczywistym; aktualizacje modelu nie oznaczają gwarantowanego wykrycia deszczu za oknem.
5. Tryb najszybszy zwiększa liczbę zadań i może skrócić pracę baterii; cel 10 dni wymaga faktycznych pomiarów.

## Potwierdzenie testów wydania

Testy Pythona obejmują regresję zachowanych funkcji, integralność zasobów, mapowania kodów i symulację harmonogramu. Weryfikacja samego wydania — wynik raportowany przy generowaniu ZIP. Po kompilacji konieczne ekrany TEST16, TEST20, TEST21 (StormGuard) i TEST22 (minuty/alerty).
