# Plan testowania v3.26.12 — Garmin Fenix 7X Pro Solar

1. Wgrać pliki `SolarRings7X_v3_26_12_SOURCE.zip` do katalogu głównego i `SolarRings7X_v3_26_12_BUILD.yml` do `.github/workflows/`.
2. Uruchomić workflow, sprawdzić **zielony** wynik obu kompilacji PRG oraz IQ. Jeśli błąd, nie instalować artefaktu.
3. Po instalacji zachować dostawcę OWM i klucz w ustawieniach (nie przesyłać go na czat, do zrzutów ani na GitHuba). Na początek pozostawić 15-minutową prognozę **wyłączoną**, odświeżanie **zrównoważone** i horyzont prognozy 1–3h wg preferencji.
4. Na normalnej tarczy sprawdzić temperaturę i miasto. Na TEST 16: `TERAZ K200` oraz `PROG K200`; w przypadku `PROG K-403` odnotować bez ponownego aktywowania GPS/klucza.
5. Na TEST 15 sprawdzić **surowy kod OWM K**, wiek obserwacji w minutach, ilości `R/S` za godzinę; przy kodzie chmur i dodatnim R/S spodziewać się **szarego** symbolu godzinnych opadów, nie czerwonego „teraz”. Dla kodu deszczu i świeżych danych spodziewać się czerwonej ikony.
6. Prognoza `P2`: po `K200` testować prawdopodobieństwa 0/20/40/60%, brak `pop`, oraz przejście w nowy przedział godzinowy; nie podawać procentów na podstawie wartości godzinnego deszczu.
7. Obserwować temperaturę, wiatr/porywy, mgłę, burze, mieszane/marznące opady, UV, AQI i osobny termometr według rzeczywistych odczytów. Brak realnego zjawiska nie jest dowodem błędu kodu.
8. **Bateria**: zapisać procent na początku i po 24 godzinach przy niezmienionych ustawieniach. Zestawić z analogicznym okresem Garmin Weather lub v3.26.10 — unikać porównania różnych aktywności, jasności i GPS.

Testy źródłowe nie gwarantują działania na zegarku. OWM może pokazać tylko zachmurzenie nawet podczas rzeczywistego deszczu, jeżeli nie udostępni poprawnego kodu ani ilości opadów.
