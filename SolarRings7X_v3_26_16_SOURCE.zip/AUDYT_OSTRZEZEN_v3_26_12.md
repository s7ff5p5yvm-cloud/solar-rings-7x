# Solar Rings v3.26.12 — audyt ostrzeżeń i czasu obserwacji

**Baza:** v3.26.11. **Powód aktualizacji:** przy opadach za oknem dostawca OWM przekazał kategorię zachmurzenia, więc tarcza nie wyświetliła ostrzeżenia. Niezależnie prognoza godzinowa zgłaszała Garmin `NETWORK_RESPONSE_OUT_OF_MEMORY` (`K-403 P2`).

## 1. Zjawiska: gdzie jest zgodność, a gdzie ograniczenia dostawcy

| Zjawisko | Garmin Weather | OpenWeather 4.0 | Reguła i ograniczenie |
|---|---|---|---|
| Deszcz | Jawny lub warunkowy kod, szansa prognozy | Kody 3xx, 5xx oraz `rain.1h` | Kod aktualny = czerwony; dodatnia ilość godzinowa bez kodu = SZARY historyczny sygnał; prognoza = turkusowy, procent wg progu |
| Śnieg | Jawny lub warunkowy kod | Kody 6xx, `snow.1h` | Analogicznie, ilość z godziny nie dowodzi trwania opadów w chwili wyświetlenia |
| Deszcz ze śniegiem | Odrębne kody | 611–616 lub oba rodzaje opadów | Jedna ikona mieszana; nie dublować deszcz+śnieg |
| Burza | Jawna lub możliwa burza | Kody 200–232 | Bez filtrowania przez ogólny `pop`, bo `pop` nie jest szansą burzy |
| Opady marznące | Jawny kod | 511 | Osobna ikona; `pop` nie udaje szansy zamarzania; unikać wtórnej ikony deszczu |
| Grad | Jawny kod | Brak jednoznacznego standardowego kodu | Nie zgadywać gradu na podstawie samej burzy |
| Wiatr | Wiatr m/s lub jawny kod | Wiatr m/s i porywy m/s, 771/781 | Progi jednostek m/s niezależne od procentów opadów |
| Mgła/widzialność | Kod mgły lub widzialność | 741 lub widzialność w metrach | Kod mgły zawsze; niska widzialność po progu |
| Oblodzenie | Szacowane przy chłodzie i opadach/kodzie lodu | Szacowane przy temp. i opadach | To **ryzyko**, nie pomiar nawierzchni; próg % niezależny |
| Pył, dym, piasek | Jawne kody | 711, 731, 751, 761, 762 | Odrębny typ bez progu deszczowego |
| UV | Wartość indeksu | `uvi` | Wartość z progiem, niezależna od prognozy opadów |
| Jakość powietrza | Nie jako OWM AQI | Air Pollution AQI 1–5 | Osobne ustawienie; wynik po 45 minutach oznaczony szaro, po 90 minutach wygasa |
| Temperatura | Ciepło/zimno osobnym termometrem | `temp`, nie mieszana z opadami | Termometr szary po 45 min wieku obserwacji, znika po 90 min |
| StormGuard | Historia ciśnienia i stabilność wysokości | Taki sam lokalny algorytm | Nie zależy od dostawcy i nie zwiększa liczby zapytań API |

Mapowanie 109 kodów z poprzedniej wersji pozostawiono. Niektóre funkcje mają mniejszą szczegółowość u jednego dostawcy — brak informacji nie może być uzupełniany wymyślonym wynikiem.

## 2. Reguły czasu — jawnie rozdzielone

- **NOW (czerwień):** rozpoznany bieżący kod zjawiska, obserwacja najwyżej 45 minut stara. Obserwacja 45–90 minut stara ma szarą ikonę; starsza nie dostaje ostrzeżenia.
- **OSTATNIA GODZINA (szarość):** brak jawnego kodu opadu, lecz dodatni `rain.1h` lub `snow.1h` >= 0,1 mm/h w świeżej obserwacji (0–45 minut). To informacja o godzinnych opadach, **nie dowód deszczu w tej sekundzie**.
- **PROGNOZA (turkus):** kod opadów albo dodatnia prognozowana intensywność opadów. Jeśli `pop` jest prawidłowy, obowiązuje próg (standardowo 40%, w trybie własnym osobne); brak `pop` nie oznacza zera. `pop` bez typu opadów lub natężenia nie tworzy rodzaju ostrzeżenia.
- **Bieżący przedział prognozy:** `dt` może odnosić się do rozpoczętego już przedziału godzinowego/15-minutowego. Taki zapis jest nadal prognozą, nie pomiarem, i pozostaje TURKUSOWY. Odrzucamy zbyt stare sloty.
- **Obecny + prognoza:** jedno ostrzeżenie z dodatkowym turkusowym oznaczeniem; nadal zachowujemy rotację co 5 sekund dla nadmiarowych różnych zjawisk.

## 3. Pamięć i bateria

- Nie ma nowych endpointów, regularnych żądań, timerów ani aktywnego GPS. `TEST 15` odczytuje wyłącznie zapisane dane i działa tylko po wybraniu.
- Tryb zrównoważony: bieżące warunki co 30 min, prognoza co 60 min, dzienne co 12 h, AQI co 60 min (gdy włączone). Szacunkowo 48+24+2+24 = **98** prób/dobę z AQI, bez zmian miejsca i nieudanych retry; bez AQI ok. **74**.
- 15-minutowa prognoza pozostaje opcjonalna, domyślnie zaleca się wyłączenie do czasu ustąpienia `K-403 P2`. Zmiana źródła prognozy nie dodaje drugiego równoległego endpointu.
- OWM One Call 4.0 `cnt=4` rekordy/h (ew. jedna próba `cnt=2` po -403) i `cnt=12` dla kwadransowych pozostały z v3.26.11. **Skuteczność redukcji danych w rzeczywistym API i pamięci Garmin jest niepotwierdzona.**
- Kontrola reguł w pamięci zegarka nie oznacza automatycznego odpytania sieci. Ikony po nowej odpowiedzi powinny być przeliczane dzięki już istniejącemu `onBackgroundData()`.

## 4. Granice weryfikacji

**Wykonane:** audyt źródeł `.mc`, XML, ustawień, macierzy kodów; testy Python (również nieaktualne testy zastąpione kontraktami zgodnymi z nową semantyką), integralność ZIP.

**Nie wykonane:** kompilacja Garmin Monkey C SDK, symulacja wykonania Monkey C, test RAM zegarka, autoryzowane wywołania z kluczem API, faktyczny test pogodowy. Nie można twierdzić, że wszystkie ostrzeżenia działają w 100% na sprzęcie.

**Warunek do instalacji:** zielony GitHub Actions dla obu wariantów Fenix 7X Pro oraz pakietu IQ. Następnie test `P1 K200`, `P2 K200` na TEST 16, źródło K (raw ID) i `R/S` na TEST 15 oraz dobowy pomiar baterii. Jeśli API nie poda ani kodu opadów, ani ich ilości, żadna lokalna heurystyka nie zagwarantuje rozpoznania faktycznie padającego deszczu.
