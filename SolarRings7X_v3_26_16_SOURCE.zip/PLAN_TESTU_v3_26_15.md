# Plan testu Solar Rings v3.26.15

Po poprawnej kompilacji i instalacji (OpenWeather, 5-minutowy cykl, 15-minutowa prognoza włączona):

1. **0 min**: sprawdź, czy tarcza działa, lokalizacja jest właściwa i jest łączność z telefonem. Zapisz baterię.
2. **15–20 min**: `TEST 16`, `TEST 20` i zdjęcie zwykłej tarczy. `TERAZ K200` oznacza sukces bieżącej pogody. Pierwsza prognoza godzinowa musi zadziałać, zanim będą dostępne próby 15-minutowe.
3. **60–90 min**: `TEST 16`, `TEST 17`, `TEST 20`. `P2 K200` potwierdza ostatnią udaną prognozę. W `TEST 17` sprawdź, czy wariant `PROG15` otrzymał rekordy. `K-403` oznacza problem pamięci, nie HTTP 403.
4. **Przy rzeczywistych zjawiskach**: `TEST 15` i zwykła tarcza. Kolory: czerwony = rozpoznane bieżące zjawisko; szary = starsze lub godzinne opady bez potwierdzenia teraz; turkusowy = prognoza. Żadne ostrzeżenie nie zastępuje ostrzeżeń publicznych.
5. **Bateria**: TEST wyłączony po zdjęciach, sprawdź po 24 i 48–72 godzinach; cel 10 dni wymaga potwierdzenia empirycznego.

**Uwaga:** W v3.26.15 ekran TEST 20 `NEXT F` uwzględnia następny termin pobrania prognozy 15-minutowej, nie tylko godzinowej. Po aktualizacji trwa jednorazowy reset formatów starych prognoz.
