# Solar Rings v3.26.11 — test pamięci OpenWeather

**Powód zmiany**: po wyłączeniu 15-minutowej prognozy Garmin nadal zgłosił `K-403 P2` (`NETWORK_RESPONSE_OUT_OF_MEMORY`) na prognozie godzinowej. Brak `P1` wskazywał, że stary termin pobierania temperatury nie został jeszcze zrealizowany.

## Co zmieniono
- Ograniczanie liczby rekordów na serwerze poprzez parametr `cnt` (4 dla godziny, 12 dla kwadransa, 2 dla dnia).
- Jeśli prognoza godzinowa nadal otrzyma `-403`, pojedyncza próba z `cnt=2` po 10 minutach; później normalne 6h wyciszenie.
- Jednorazowe zerowanie terminów po aktualizacji wersji tak, żeby pierwsze zadanie pobierało `P1` (temperaturę).

## Co zbadać po instalacji
1. Czy widoczna jest temperatura na tarczy?
2. TEST 16 — status `TERAZ` i `PROG`.
3. TEST 20 — `ETAP`, `OSTATNI K... P...`, `WIEK`.

Jeżeli `P1` otrzyma `K200`, ale `P2` nadal `K-403`, to problem dotyczy rozmiaru prognozy lub ograniczeń pamięci przy jej dekodowaniu. Jeżeli nawet `P1` otrzyma `-403`, problem jest szerszy niż długość prognozy i wymaga redukcji zapotrzebowania na pamięć zadania albo lekkiego serwera pośredniczącego.

**Uwaga:** testy Python sprawdzają źródła, ale nie symulują pamięci Garmin. Kompilację SDK i test rzeczywistego API wykonuje się później.
