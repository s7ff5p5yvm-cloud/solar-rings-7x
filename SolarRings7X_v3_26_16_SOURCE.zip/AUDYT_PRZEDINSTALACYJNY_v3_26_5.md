# Solar Rings 7X v3.26.5 — audyt przedinstalacyjny

## Zakres i werdykt

**WYNIK: warunkowy.** Poprawki logiczne zostały naniesione na v3.26.4. Nie wykonano kompilacji Monkey C, testu pamięci Connect IQ ani pomiaru baterii na zegarku. Nie można w dobrej wierze zadeklarować 100% niezawodności.

## Potwierdzone usterki v3.26.4 i naprawy

1. Próg `gwIceChanceV332` był w Garmin nadpisywany przez tryb ogólny 40%, a w OWM ignorowany przy ryzyku lodu. Teraz `iceChanceMatches()` stosuje własny próg w obydwu dostawcach dla prognozy. Jawny kod ICE i FREEZING_RAIN nie podlegają temu filtrowi.
2. Marker `srOShortAttemptV3264` usuwano przy wejściu do callbacku przed walidacją JSON. Po zatrzymaniu przez błąd pamięci nie było sygnału o niedokończonym zadaniu. Teraz czyszczenie następuje dopiero po pomyślnym zapisie, a `fail()` czyści marker przy kontrolowanym niepowodzeniu.
3. Rotacja nadmiarowych ikon odbywała się co 60 s, mimo wcześniejszych ustaleń 5 s. Zmieniono oba miejsca na 5 s.

## Pozostałe ograniczenia i ryzyka

- OpenWeather 4.0 `timeline/15min` potrafi zwrócić 50 pełnych rekordów JSON. Ograniczenie zapisu do 12 nie redukuje pamięci wymaganej przez callback. Fallback po awarii pomaga, ale nie gwarantuje odzyskania, jeśli proces tła nie będzie mógł wystartować.
- Prognoza 15-minutowa jest opcjonalna. Bieżące warunki i prognoza są aktualizowane niezależnie, w wybranych interwałach 15/30, 30/60, 60/120 min. Connect IQ może opóźniać uruchomienia.
- OWM nie ma oficjalnego jednoznacznego kodu gradu w standardowej tabeli ID: brak automatycznego odpowiednika Garmin `HAIL`.
- OWM i Garmin mają inne zasoby danych. Garmin nie zapewnia godzinowych porywów, OWM nie dostarcza bezpośredniego czujnika gołoledzi. Estymacja śliskości nie jest potwierdzeniem stanu drogi.
- Bez dodatkowych żądań do endpointu alertów 4.0 tarcza nie analizuje szczegółów oficjalnych alertów (`alerts` to ID). Nie jest to substytut oficjalnych komunikatów.
- Opis „mgła” może obejmować również silnie ograniczoną widzialność o innej przyczynie.
- Tryb „czuły” dopuszcza 0% przy kodzie rozpoznanego zjawiska, ponieważ oznacza „kieruj się kodem”.
- Niezależne testy Python są statyczne albo symulacyjne i nie są wykonaniem kodu Monkey C. Starszy zestaw testów zawiera twarde asercje wersji 3.24.32. Ich niepowodzenia nie mogą być automatycznie uznane za nieważne.

## Proponowane testy urządzenia

1. Zbudować w Garmin SDK oba modele urządzenia i sprawdzić logi kompilatora oraz pakiet IQ.
2. Uruchomić prognozę 15 minut najpierw w trybie zrównoważonym 30/60, horyzont 3h; w TEST 15 odczytać `OWM 15M`.
3. Jeśli błąd lub zawieszenie: sprawdzić po 15–30 min `OWM FALLBACK` i aktualność godzinowej prognozy.
4. Zweryfikować progi: rain/snow 0%, null, 20%, 40%, 80%; ICE 30/50/80%; burzę i opady marznące niezależnie od POP; wiatr i porywy oraz mgłę.
5. Porównać zużycie baterii i świeżość danych przez 24–48h.

Źródła: https://m.openweathermap.org/api/one-call-4 ; https://developer.garmin.com/connect-iq/api-docs/Toybox/Weather.html

## Wyniki audytu statycznego — 17.11.2026

| Zakres | Wynik |
|---|---|
| Nowe testy kontraktowe i modele danych | **63 PASS, 1 SKIP** (64 uruchomione) |
| Archiwalne testy z v3.24.32 | **140 PASS, 21 FAIL** (161 uruchomionych) |
| Zmiana względem v3.26.4 (archiwalne testy) | Poprawa o 2 testy rotacji ikon |
| Przyczyny 21 starych FAIL | 11 wymaga sztywnej wersji 3.24.32; 6 liczy 2 tekstowe wystąpienia odczytu pogody mimo wykluczających się gałęzi; 2 wymaga starego cache 64 zamiast 96; 1 wymaga kodu MIST bezpośrednio w silniku alertów (obecnie MIST sygnalizuje tylko ograniczoną widoczność przy wyniku poniżej progu); 1 wymaga kodu prognozy w głównym pliku tarczy, choć jest w wydzielonym silniku |
| Garmin SDK kompilator i symulator | **BRAK — NIE POTWIERDZONO** |
| Test RAM i bateria 7X Pro Solar | **BRAK — NIE POTWIERDZONO** |
| API użytkownika / realne ostrzeżenia | **BRAK — NIE POTWIERDZONO** |

## Macierz logiki ostrzeżeń (statyczna, nie test sprzętowy)

| Typ | Garmin Weather | OpenWeather 4.0 | Filtr |
|---|---|---|---|
| Deszcz | RAIN / SHOWERS / CHANCE_OF_SHOWERS / DRIZZLE | 300–321, 500–504, 520–531 | Dla przyszłości kod + POP (brak POP => tak); obecne bez POP |
| Śnieg | SNOW / CHANCE_OF_SNOW / FLURRIES | 600–602, 620–622 | Jak dla deszczu |
| Mieszane | WINTRY_MIX / RAIN_SNOW / SLEET i odmiany | 611–613, 615–616 | Jeden symbol, nie duplikat deszcz + śnieg |
| Burza | THUNDERSTORMS / CHANCE_OF_THUNDERSTORMS | 200–232 | POP innych opadów nie filtruje burzy |
| Opady marznące | FREEZING_RAIN | 511 | Własny alert, nie filtrowany POP |
| Grad | HAIL | Brak standardowego kodu | Tylko rozpoznane |
| Wiatr | windSpeed / WINDY bez wyniku / ekstremalny kod | wiatr, porywy, 771/781 | Osobne progi m/s dla prędkości i porywów OWM |
| Mgła / zła widzialność | FOG / widzialność m | 741 / widzialność m | Jawny kod lub odczyt poniżej ustawionego progu |
| Ryzyko lodu | ICE lub temp + mokry kod | temp + kod opadów | Odrębny próg szansy `gwIceChanceV332` przy prognozie. Nie jest to pomiar powierzchni |
| Pył/dym/piasek/popiół | kody atmosferyczne | 711, 731, 751, 761, 762 | Rozpoznany kod i przełącznik |
| UV | uvIndex | uvi | Osobny próg, domyślnie wyłączone |
| AQI | Nieobsługiwane jako część Garmin Weather | Osobne API 2.5 air_pollution | Osobny próg 3/4/5, domyślnie wyłączone |
| Temperatura | termometr | termometr | Niezależnie od alertów opadowych |
| Spadek ciśnienia | SensorHistory / StormGuard | SensorHistory / StormGuard | Osobna analiza trendu ciśnienia, nie OWM |

**Werdykt końcowy:** **NIE 100%.** Przygotowano poprawiony projekt i testy logiczne; do instalacji konieczny jest co najmniej poprawny build SDK i kontrola plików wynikowych. 15-minutową prognozę należy potraktować jako funkcję eksperymentalną aż do testu rzeczywistego zużycia pamięci.

## Wyniki audytu statycznego — 17.11.2026

| Zakres | Wynik |
|---|---|
| Nowe testy kontraktowe i modele danych | **63 PASS, 1 SKIP** (64 uruchomione) |
| Archiwalne testy z v3.24.32 | **140 PASS, 21 FAIL** (161 uruchomionych) |
| Zmiana względem v3.26.4 (archiwalne testy) | Poprawa o 2 testy rotacji ikon |
| Przyczyny 21 starych FAIL | 11 wymaga sztywnej wersji 3.24.32; 6 liczy 2 tekstowe wystąpienia odczytu pogody mimo wykluczających się gałęzi; 2 wymaga starego cache 64 zamiast 96; 1 wymaga kodu MIST bezpośrednio w silniku alertów (obecnie MIST sygnalizuje tylko ograniczoną widoczność przy wyniku poniżej progu); 1 wymaga kodu prognozy w głównym pliku tarczy, choć jest w wydzielonym silniku |
| Garmin SDK kompilator i symulator | **BRAK — NIE POTWIERDZONO** |
| Test RAM i bateria 7X Pro Solar | **BRAK — NIE POTWIERDZONO** |
| API użytkownika / realne ostrzeżenia | **BRAK — NIE POTWIERDZONO** |

## Macierz logiki ostrzeżeń (statyczna, nie test sprzętowy)

| Typ | Garmin Weather | OpenWeather 4.0 | Filtr |
|---|---|---|---|
| Deszcz | RAIN / SHOWERS / CHANCE_OF_SHOWERS / DRIZZLE | 300–321, 500–504, 520–531 | Dla przyszłości kod + POP (brak POP => tak); obecne bez POP |
| Śnieg | SNOW / CHANCE_OF_SNOW / FLURRIES | 600–602, 620–622 | Jak dla deszczu |
| Mieszane | WINTRY_MIX / RAIN_SNOW / SLEET i odmiany | 611–613, 615–616 | Jeden symbol, nie duplikat deszcz + śnieg |
| Burza | THUNDERSTORMS / CHANCE_OF_THUNDERSTORMS | 200–232 | POP innych opadów nie filtruje burzy |
| Opady marznące | FREEZING_RAIN | 511 | Własny alert, nie filtrowany POP |
| Grad | HAIL | Brak standardowego kodu | Tylko rozpoznane |
| Wiatr | windSpeed / WINDY bez wyniku / ekstremalny kod | wiatr, porywy, 771/781 | Osobne progi m/s dla prędkości i porywów OWM |
| Mgła / zła widzialność | FOG / widzialność m | 741 / widzialność m | Jawny kod lub odczyt poniżej ustawionego progu |
| Ryzyko lodu | ICE lub temp + mokry kod | temp + kod opadów | Odrębny próg szansy `gwIceChanceV332` przy prognozie. Nie jest to pomiar powierzchni |
| Pył/dym/piasek/popiół | kody atmosferyczne | 711, 731, 751, 761, 762 | Rozpoznany kod i przełącznik |
| UV | uvIndex | uvi | Osobny próg, domyślnie wyłączone |
| AQI | Nieobsługiwane jako część Garmin Weather | Osobne API 2.5 air_pollution | Osobny próg 3/4/5, domyślnie wyłączone |
| Temperatura | termometr | termometr | Niezależnie od alertów opadowych |
| Spadek ciśnienia | SensorHistory / StormGuard | SensorHistory / StormGuard | Osobna analiza trendu ciśnienia, nie OWM |

**Werdykt końcowy:** **NIE 100%.** Przygotowano poprawiony projekt i testy logiczne; do instalacji konieczny jest co najmniej poprawny build SDK i kontrola plików wynikowych. 15-minutową prognozę należy potraktować jako funkcję eksperymentalną aż do testu rzeczywistego zużycia pamięci.

## Wyniki audytu statycznego — 17.11.2026

| Zakres | Wynik |
|---|---|
| Nowe testy kontraktowe i modele danych | **63 PASS, 1 SKIP** (64 uruchomione) |
| Archiwalne testy z v3.24.32 | **140 PASS, 21 FAIL** (161 uruchomionych) |
| Zmiana względem v3.26.4 (archiwalne testy) | Poprawa o 2 testy rotacji ikon |
| Przyczyny 21 starych FAIL | 11 wymaga sztywnej wersji 3.24.32; 6 liczy 2 tekstowe wystąpienia odczytu pogody mimo wykluczających się gałęzi; 2 wymaga starego cache 64 zamiast 96; 2 wymaga starej lokalizacji fragmentu klasyfikacji |
| Garmin SDK kompilator i symulator | **BRAK — NIE POTWIERDZONO** |
| Test RAM i bateria 7X Pro Solar | **BRAK — NIE POTWIERDZONO** |
| API użytkownika / realne ostrzeżenia | **BRAK — NIE POTWIERDZONO** |

## Macierz logiki ostrzeżeń (statyczna, nie test sprzętowy)

| Typ | Garmin Weather | OpenWeather 4.0 | Filtr |
|---|---|---|---|
| Deszcz | RAIN / SHOWERS / CHANCE_OF_SHOWERS / DRIZZLE | 300–321, 500–504, 520–531 | Dla przyszłości kod + POP (brak POP => tak); obecne bez POP |
| Śnieg | SNOW / CHANCE_OF_SNOW / FLURRIES | 600–602, 620–622 | Jak dla deszczu |
| Mieszane | WINTRY_MIX / RAIN_SNOW / SLEET i odmiany | 611–613, 615–616 | Jeden symbol, nie duplikat deszcz + śnieg |
| Burza | THUNDERSTORMS / CHANCE_OF_THUNDERSTORMS | 200–232 | POP innych opadów nie filtruje burzy |
| Opady marznące | FREEZING_RAIN | 511 | Własny alert, nie filtrowany POP |
| Grad | HAIL | Brak standardowego kodu | Tylko rozpoznane |
| Wiatr | windSpeed / WINDY bez wyniku / ekstremalny kod | wiatr, porywy, 771/781 | Osobne progi m/s dla prędkości i porywów OWM |
| Mgła / zła widzialność | FOG / widzialność m | 741 / widzialność m | Jawny kod lub odczyt poniżej ustawionego progu |
| Ryzyko lodu | ICE lub temp + mokry kod | temp + kod opadów | Odrębny próg szansy `gwIceChanceV332` przy prognozie. Nie jest to pomiar powierzchni |
| Pył/dym/piasek/popiół | kody atmosferyczne | 711, 731, 751, 761, 762 | Rozpoznany kod i przełącznik |
| UV | uvIndex | uvi | Osobny próg, domyślnie wyłączone |
| AQI | Nieobsługiwane jako część Garmin Weather | Osobne API 2.5 air_pollution | Osobny próg 3/4/5, domyślnie wyłączone |
| Temperatura | termometr | termometr | Niezależnie od alertów opadowych |
| Spadek ciśnienia | SensorHistory / StormGuard | SensorHistory / StormGuard | Osobna analiza trendu ciśnienia, nie OWM |

**Werdykt końcowy:** **NIE 100%.** Przygotowano poprawiony projekt i testy logiczne; do instalacji konieczny jest co najmniej poprawny build SDK i kontrola plików wynikowych. 15-minutową prognozę należy potraktować jako funkcję eksperymentalną aż do testu rzeczywistego zużycia pamięci.
