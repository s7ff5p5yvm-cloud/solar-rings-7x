# Solar Rings 7X v3.26.9 — naprawa i diagnostyka OpenWeather

## Cel i stan

W v3.26.8 na zegarku potwierdzono: klucz wpisany, lokalizacja dostępna, telefon połączony, timer BG zarejestrowany i uruchomiony, ale brak wpisów per endpoint i brak cache. Był ślad `SYSTEM K-152 ET30`, który **sam nie wskazuje jednoznacznie**, którego żądania dotyczył. Nie mamy prywatnej odpowiedzi użytkownika ani autoryzowanego dostępu do jego API, zatem nie można zagwarantować naprawy przed testem na Garminie.

## Poprawki i zabezpieczenia

- **Ślad startu BG:** `srODGateV3269` przechowuje wyłącznie liczby: czas, etap, identyfikator wybranego endpointu, pozostałe sekundy do terminów pobierania bieżącej pogody i prognozy. Nie zawiera API key, współrzędnych, URL ani odpowiedzi.
- **Przechwytywanie wyjątku:** `runSafely()` rejestruje błąd `-230`, także jeżeli wystąpi przed uruchomieniem sieci; wznawia próbę po 10 minutach.
- **Czasowe blokady ze starej wersji:** po aktualizacji do v3.26.9 zerowane są raz terminy `NEXT`, żeby stara nieudana próba nie blokowała diagnostyki nowych zapytań. Ustawienia użytkownika pozostają bez zmian.
- **Walidacja current:** parser korzysta z pierwszego rekordu `data[0]` po sprawdzeniu jego typu i wartości `dt` / `temp`, także jeśli API zwróci więcej niż jeden rekord. Nie akceptuje pustych lub nieprawidłowych danych.
- **Brak bezimiennego błędu `FORMAT`:** zamiast początkowego kodu `-152` używany jest `-214` dla nieobsłużonej ścieżki; inne błędy (`-202..-213`, HTTP, zapis) pozostają rozdzielone.
- Nadal: osobne statusy TERAZ/PROG/DZIEŃ/AQI, watchdog dla 15-min prognozy, fallback do godzinowej, brak dodatkowych regularnych żądań.

## TEST 20 — ślad wykonywania

Nowy ekran `TEST 20: OpenWeather - dlaczego zadanie nie pobrało pogody` w Connect IQ → ustawienia Solar Rings → Podgląd ikon (TEST).

`ETAP Gxx`:

| Kod | Znaczenie |
|---|---|
| G10 | Wejście w zadanie BG |
| G11 | Wybrany dostawca nie jest OpenWeather |
| G12 | Brak czytelnego klucza (nie oznacza odpowiedzi HTTP 401) |
| G13 | Brak lub przeterminowana lokalizacja |
| G14 | Nic nie jest aktualnie wymagalne — timer powinien uruchomić kolejne żądanie później |
| G15 | Telefon odłączony w momencie próby |
| G16 | Wybrano endpoint (`P1` teraz, `P2` prognoza, `P3` dzień, `P4` AQI) |
| G17 | Kontekst zapytania zapisany |
| G18 | Próba przekazana do `makeWebRequest` |
| G19 | Callback z sieci został wywołany |
| G21 | Dane zapisane pomyślnie |
| G90 | Nieobsłużony wyjątek w procedurze startu BG (status `K-230`) |
| G91 | Nie udało się utworzyć serwisu pogodowego (`K-231`) |

`NEXT C/F` pokazuje odległość terminów aktualizacji aktualnej pogody i prognozy w minutach; dodatnia wartość = przyszły termin, ujemna = termin minął. `OSTATNI K` jest wynikiem ostatniej próby, a `ZADANIE P` odczytuje ostatni trwały kontekst zapytania. Jeśli diagnostyka zatrzyma się na G18 bez G19 i pojawi się błąd komunikacji lub brak callbacku, podejrzewamy transport, limit pamięci albo przerwane zadanie; sam zapis G18 nie dowodzi dotarcia HTTP do serwera.

## Kolejność testów na zegarku

1. Na GitHub umieść `SolarRings7X_v3_26_9_SOURCE.zip` w katalogu głównym i `SolarRings7X_v3_26_9_BUILD.yml` w `.github/workflows/`.
2. Zbuduj przez Actions; **na urządzenie instaluj wyłącznie wynikowy PRG/IQ**, nie źródłowy ZIP.
3. Pozostaw OpenWeather, aktywny klucz i połączony telefon. Nie zmieniaj konfiguracji i nie uruchamiaj kolejnego GPS.
4. Po uruchomieniu BG sprawdź **TEST 20**, następnie **TEST 16 i TEST 17**. Jeśli TEST 20 pokazuje G19, podaj kod z TEST 16/17; jeśli G14, potrzebny jest zapis NEXT C/F.
5. Jeśli rezultat to `K200` a danych nie widać, sprawdź TEST 19 CACHE. Jeśli `K-230`, problem jest w logice startu zadania i nie należy w pierwszej kolejności zmieniać API key.
6. Po sprawdzeniu wyłącz ekran testowy (`Podgląd ikon = 0`).

## Ważne ograniczenia

Kompilacja Connect IQ SDK, bezpośrednie połączenie z API z kluczem użytkownika i test na jego Fenixie nie zostały przeprowadzone w tym środowisku. Statyczne testy źródłowe nie gwarantują zgodności typów Monkey C ani stabilności pamięci BG. OpenWeather 4.0 zwraca JSON `data` dla current oraz timeline — jednak rzeczywistą postać zwróconą Garminowi ustalimy dopiero w TEST 17. W razie dużej odpowiedzi może nastąpić błąd pamięci zanim program otrzyma callback.
