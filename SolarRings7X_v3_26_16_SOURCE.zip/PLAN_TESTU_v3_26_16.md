# Solar Rings v3.26.16 — plan testu na Fenix 7X Pro Solar

1. Rozpakuj zewnętrzny ZIP. W repozytorium GitHub umieść `SolarRings7X_v3_26_16_SOURCE.zip` w katalogu głównym, `SolarRings7X_v3_26_16_BUILD.yml` w `.github/workflows/`.
2. Uruchom workflow v3.26.16. Instaluj PRG wyłącznie po zielonej kompilacji.
3. W Garmin Connect IQ sprawdź, że wciąż wybrany jest OWM i klucz API jest zapisany; nie ujawniaj klucza na zdjęciach. Tryb „Maksymalna aktualność”, 15-minutowa prognoza włączona, testów nie pozostawiaj włączonych przez cały dzień.
4. Po pierwszych 15–20 minutach: TEST16 (P1 TERAZ K200). Następnie ok. 60–90 minut: TEST16 (P5 MINUTA, P2 PROG, P4 AQI), TEST20 (faktyczne godziny ostatnich zadań i G21/K200).
5. TEST21 natychmiast po systemowym alarmie burzowym lub rozbieżności: `SPADEK 1H`, `SPADEK 3H` w dziesiątych hPa, wysokość i status K3–K9. `K8` oznacza niepewność źródła trendu. Systemowy alarm Garmina może mieć własną metodę liczenia: brak ikonki nie jest sam w sobie dowodem awarii.
6. TEST22 podczas opadów albo ostrzeżeń urzędowych: `MINUTY SA/BRAK`, `DETAIL K...`, `SZCZEGOLY TYP...`. Brak ID jest naturalny, gdy nie ma urzędowych ostrzeżeń.
7. Gdy użytkownik widzi deszcz, sprawdź TEST15 (`C...`, dane opadu) i rzeczywistą ikonę. Zwróć uwagę na rozdzielenie **teraz** / **opad w ostatniej godzinie** / **przewidywany opad**.
8. Po 24h zanotuj baterię, po 48–72h oceń zużycie i stabilność. Nie zmieniaj w trakcie profilu, aby pomiar był porównywalny.

## Kody diagnostyczne
- `K200`: udany zapis, `K100`: rozpoczęte zapytanie; `K-403`: Garmin zabrakło pamięci dla odpowiedzi sieciowej (nie jest to HTTP 403).
- P1 bieżąca, P2 prognoza 15min lub 1h, P3 prognoza dzienna, P4 AQI, P5 prognoza minutowa, P6 szczegóły urzędowego alertu.
- G90/91 na dole TEST20 są legendą, nie oznaczają błędu, o ile `ETAP G90/91` nie jest rzeczywistą wartością.

Nie trzeba oczekiwać nowego urzędowego alertu ani realnej burzy do stwierdzenia, że kod skompilował się poprawnie. Jednak trafność ostrzeżeń, niewystępowanie błędów pamięci i działanie StormGuard mogą być potwierdzone tylko przez rzeczywiste zdarzenia i dane.
