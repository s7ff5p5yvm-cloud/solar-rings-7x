using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Position as Position;
using Toybox.Activity as Activity;
using Toybox.Lang as Lang;
using Toybox.Time as Time;
using Toybox.Weather as Weather;

// One source for ALL meteorological fields. Garmin is the default.
// Neither class below starts GPS. Garmin/position metadata is used solely
// to locate the OWM request; weather measurements never fall back to Garmin.
function srUseOpenWeather() {
    return srSetting("srProviderV326", 0) == 1;
}
function srOwmKeyReady() {
    var key = srSetting("srOpenKeyV326", "");
    return key != null && key instanceof Lang.String && key.length() >= 8;
}
function srOwmNumber(v) {
    return v != null && (v instanceof Lang.Number || v instanceof Lang.Long ||
                          v instanceof Lang.Float || v instanceof Lang.Double);
}
function srOwmRead(key) {
    try { return App.Storage.getValue(key); } catch (e) { return null; }
}
function srOwmWrite(key, data) {
    try {
        App.Storage.setValue(key, data);
        return true;
    } catch (e) { return false; }
}
function srOwmCoordsValid(a) {
    return a != null && a instanceof Lang.Array && a.size() >= 2 &&
           srOwmNumber(a[0]) && srOwmNumber(a[1]) &&
           a[0] >= -90 && a[0] <= 90 && a[1] >= -180 && a[1] <= 180;
}
function srOwmSamePlace(a, b) {
    return srOwmCoordsValid(a) && srOwmCoordsValid(b) &&
           a[0] > b[0] - 0.025d && a[0] < b[0] + 0.025d &&
           a[1] > b[1] - 0.035d && a[1] < b[1] + 0.035d;
}

// A unified view of weather for the EXISTING readField(), drawWeather(),
// weatherSymbol(), temperatureMarker(), age display and moon-city panel.
// Snapshot layout: lat,lon,fetchUTC,observationUTC,temp,feels,wind,humidity,
// uv,visibility,clouds,code,pressure,sunriseUTC,sunsetUTC,gust,pop%,rain,snow.
// Missing fields remain null: NEVER use Garmin values as substitutes.
class SolarOpenConditions {
    var temperature;
    var feelsLikeTemperature;
    var windSpeed;
    var relativeHumidity;
    var uvIndex;
    var visibility;
    var cloudCover;
    var precipitationChance;
    var highTemperature;
    var lowTemperature;
    var condition;
    var observationTime;
    var observationLocationPosition;
    var observationLocationName;
    var sunriseUtc;
    var sunsetUtc;

    function initialize(data, forecast, daily) {
        temperature = data[4];
        feelsLikeTemperature = data[5];
        windSpeed = data[6];
        relativeHumidity = data[7];
        uvIndex = data[8];
        visibility = data[9];
        cloudCover = data[10];
        condition = srOwmCondition(data[11]);
        precipitationChance = data[16];
        // -1 is an invalid OWM POP sentinel, never show -1% on the dial.
        if (precipitationChance != null && precipitationChance < 0) {
            precipitationChance = null;
        }
        // Current endpoint may omit POP; use nearest OWM forecast if VALID,
        // never Garmin precipitationChance. This field is informational only.
        if (precipitationChance == null && forecast != null &&
            forecast.size() > 0 && forecast[0] != null &&
            forecast[0].size() > 5 && forecast[0][5] != null &&
            srOwmNumber(forecast[0][5]) && forecast[0][5] >= 0) {
            precipitationChance = forecast[0][5];
        }
        highTemperature = daily == null ? null : daily[5];
        lowTemperature = daily == null ? null : daily[4];
        sunriseUtc = data[13];
        sunsetUtc = data[14];
        observationTime = new Time.Moment(data[3].toNumber());
        observationLocationPosition = new Position.Location({
            :latitude => data[0], :longitude => data[1], :format => :degrees
        });
        observationLocationName = null;
        // Full-day min/max are read only from OWM's 1day endpoint.
        // Hourly maximum/minimum is never mislabeled as an all-day extreme.
    }
}

// Code-to-icon translation only. Warnings have an independent OWM rule engine.
function srOwmCondition(id) {
    return srOwmMappedCondition(id);
}

function srOwmCurrentSnapshot() {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return null; }
    var d = srOwmRead("srOCurrV326");
    var loc = srOwmRead("srOLocV326");
    var now = Time.now().value();
    if (d == null || !(d instanceof Lang.Array) || d.size() != 19 ||
        !srOwmCoordsValid(d) || !srOwmSamePlace(d, loc) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        d[3] > now + 300 || now - d[3] > 90 * 60 ||
        !srOwmNumber(d[4])) { return null; }
    return d;
}
// Keep the short-range 15-minute forecast AND the longer 1-hour forecast.
// Array elements are compact stored rows, not full JSON. An eleventh field
// records each row's individual bucket duration (900 or 3600 seconds).
function srOwmForecastSnapshot() {
    var now = Time.now().value();
    var loc = srOwmRead("srOLocV326");
    var shortData = srOwmRead("srOShortV3264");
    var paused = srOwmRead("srOShortPausedV3264");
    if (srSetting("srOwm15MinV3264", true) == true &&
        (!srOwmNumber(paused) || paused <= now)) {
        if (!(shortData instanceof Lang.Array) || shortData.size() != 4 ||
            !srOwmSamePlace(shortData, loc) || !srOwmNumber(shortData[2]) ||
            shortData[2] > now + 300 || now - shortData[2] > 45 * 60 ||
            !(shortData[3] instanceof Lang.Array)) { shortData = null; }
    } else { shortData = null; }
    var hourly = srOwmRead("srOHoursV326");
    var hourAge = srSetting("srOwmMinutesV326", 30) == 5 ? 100 * 60 : 120 * 60;
    if (!(hourly instanceof Lang.Array) || hourly.size() != 4 ||
        !srOwmSamePlace(hourly, loc) || !srOwmNumber(hourly[2]) ||
        hourly[2] > now + 300 || now - hourly[2] > hourAge ||
        !(hourly[3] instanceof Lang.Array)) { hourly = null; }
    if (shortData == null && hourly == null) { return null; }
    if (shortData == null) { return hourly[3]; }
    if (hourly == null) { return shortData[3]; }
    // At most 12 short + 5 hourly entries. Prefer the high-resolution
    // timeline for the face's nearest precipitation probability, while still
    // retaining hourly coverage in the warning evaluator for later hours.
    var result = [];
    var shortRows = shortData[3] as Lang.Array;
    var hourlyRows = hourly[3] as Lang.Array;
    for (var i = 0; i < shortRows.size() && result.size() < 12; i++) {
        result.add(shortRows[i]);
    }
    for (var j = 0; j < hourlyRows.size() && result.size() < 17; j++) {
        result.add(hourlyRows[j]);
    }
    return result;
}

// The selected forecast resolution affects how long a timeline bucket
// remains relevant. This reads local storage ONLY when warnings are checked,
// not on every clock redraw and never creates an API request.
function srOwmForecastStepSeconds() {
    if (srSetting("srOwm15MinV3264", true) != true) { return 3600; }
    var now = Time.now().value();
    var maxAge = srSetting("srOwmMinutesV326", 30) == 5 ? 45 * 60 : 120 * 60;
    var paused = srOwmRead("srOShortPausedV3264");
    if (srOwmNumber(paused) && paused > now) { return 3600; }
    var s = srOwmRead("srOShortV3264");
    if (s instanceof Lang.Array && s.size() == 4 &&
        srOwmSamePlace(s, srOwmRead("srOLocV326")) &&
        srOwmNumber(s[2]) && s[2] <= now + 300 &&
        now - s[2] <= maxAge && s[3] instanceof Lang.Array) { return 900; }
    return 3600;
}

// The minute-step data is a prediction of total precipitation in mm/h,
// NOT a current observation and NOT a rain/snow type classifier.
// Cached rows [dt,precipitation] are always bounded by the BG parser.
function srOwmMinuteSnapshot() {
    var d = srOwmRead("srOMinuteV32616");
    var now = Time.now().value();
    if (!(d instanceof Lang.Array) || d.size() != 4 ||
        !srOwmSamePlace(d, srOwmRead("srOLocV326")) ||
        !srOwmNumber(d[2]) || d[2] > now + 300 ||
        now - d[2] > 45 * 60 || !(d[3] instanceof Lang.Array)) {
        return null;
    }
    return d[3];
}

// Metadata from 4.0 data.alerts are IDENTIFIERS, not event details.
// A neutral official-alert glyph is allowed, but never an invented thunder,
// hail or flood classification, and never once the source becomes stale.
function srOwmOfficialFlag(key, limitSeconds, bucketSeconds) {
    var a = srOwmRead(key);
    var now = Time.now().value();
    if (!(a instanceof Lang.Array) || a.size() != 4 ||
        !srOwmSamePlace(a, srOwmRead("srOLocV326")) ||
        !srOwmNumber(a[2]) || !srOwmNumber(a[3]) ||
        a[2] > now + 300 || now - a[2] > limitSeconds ||
        a[3] <= 0 || a[3] <= now - bucketSeconds ||
        a[3] > now + 3 * 3600) { return false; }
    return true;
}
function srOwmDailySnapshot() {
    var d = srOwmRead("srODayV326");
    var now = Time.now().value();
    if (d == null || !(d instanceof Lang.Array) || d.size() != 7 ||
        !srOwmSamePlace(d, srOwmRead("srOLocV326")) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        !srOwmNumber(d[4]) || !srOwmNumber(d[5]) ||
        !srOwmNumber(d[6]) || d[2] > now + 300 ||
        now - d[2] > 36 * 3600) { return null; }
    var localDay = ((now + d[6]) / 86400).toNumber();
    if (localDay != d[3]) { return null; }
    return d;
}
function srOwmVisibleCurrent() {
    var d = srOwmCurrentSnapshot();
    if (d == null) { return null; }
    try { return new SolarOpenConditions(d, srOwmForecastSnapshot(), srOwmDailySnapshot()); }
    catch (e) { return null; }
}

// Only one temporal background event exists. Called seldom: initial view,
// selected setting changed, or location changed. An existing event is reused.
function srOwmArmIfNeeded() {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return; }
    var loc = srOwmRead("srOLocV326");
    var now = Time.now().value();
    if (!srOwmCoordsValid(loc) || loc.size() < 3 ||
        !srOwmNumber(loc[2]) || loc[2] > now + 300 ||
        now - loc[2] > 48 * 3600) {
        srOwmWrite("srODiagV3266", [now, 0, -10]);
        return;
    }
    try {
        if (Bg.getTemporalEventRegisteredTime() != null) { return; }
        Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
    } catch (e) { srOwmWrite("srODiagV3266", [now, 0, -18]); }
}

// OWM needs the last known geographical position, not a fresh Garmin
// WEATHER observation. Weather.observationTime is the age of meteorological
// measurements and is not proof that the position itself is unavailable.
// No active GPS is started by this watch face.
function srOwmUpdateLocation(garmin) {
    if (!srUseOpenWeather() || !srOwmKeyReady()) { return; }
    var now = Time.now().value();
    var weatherCoords = null;
    var weatherStamp = 0;
    try {
        if (garmin != null && garmin.observationLocationPosition != null) {
            weatherCoords = garmin.observationLocationPosition.toDegrees();
            if (garmin.observationTime != null) {
                weatherStamp = garmin.observationTime.value();
            }
        }
    } catch (e) { weatherCoords = null; }
    if (!srOwmCoordsValid(weatherCoords)) { weatherCoords = null; }
    // Activity.Info.currentLocation is a LAST-KNOWN GPS position and may
    // remain available after finishing an activity. It has no reliable fix
    // timestamp; never claim it is a fresh active GPS measurement.
    var activityCoords = null;
    try {
        var activityInfo = Activity.getActivityInfo();
        if (activityInfo != null && activityInfo.currentLocation != null) {
            activityCoords = activityInfo.currentLocation.toDegrees();
        }
    } catch (e) { activityCoords = null; }
    if (!srOwmCoordsValid(activityCoords)) { activityCoords = null; }

    var coords = null;
    // Prefer Garmin Weather's geographically anchored location when its
    // observation is recent. If the observation is old, a recorded activity
    // is a better fallback for the device's location after a GPS walk.
    if (weatherCoords != null && weatherStamp > 0 &&
        weatherStamp <= now + 300 && now - weatherStamp <= 3 * 3600) {
        coords = weatherCoords;
    } else if (activityCoords != null) {
        coords = activityCoords;
    } else if (weatherCoords != null &&
        ((weatherStamp > 0 && weatherStamp <= now + 300 &&
          now - weatherStamp <= 24 * 3600) || weatherStamp == 0)) {
        // Some Garmin firmware returns coordinates without an observation
        // time. Treat them as approximate last-known metadata, not as
        // confirmation of a fresh GPS fix.
        coords = weatherCoords;
    }
    if (coords == null) {
        // A stored position can still drive OWM while its timestamp is valid;
        // don't suppress refreshes simply because Garmin Weather's hourly
        // measurement is older than three hours.
        srOwmArmIfNeeded();
        return;
    }
    var previous = srOwmRead("srOLocV326");
    var changed = !srOwmSamePlace(previous, coords);
    // Store once per hour while stationary, but update immediately on travel.
    // Stamp indicates *last availability to the watch face*, not GPS fix age.
    if (changed || !(previous instanceof Lang.Array) || previous.size() < 3 ||
        !srOwmNumber(previous[2]) || now < previous[2] ||
        now - previous[2] >= 3600) {
        if (!srOwmWrite("srOLocV326", [coords[0], coords[1], now])) { return; }
        if (changed) {
            // Prevent a previous city's weather being shown after moving.
            srOwmWrite("srOCurrV326", null);
            srOwmWrite("srOHoursV326", null);
            srOwmWrite("srOShortV3264", null);
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srODayV326", null);
            srOwmWrite("srOAirV326", null);
            srOwmWrite("srOMinuteV32616", null);
            srOwmWrite("srOBaroHistoryV32616", null);
            srOwmWrite("srOAlertNowV32616", null);
            srOwmWrite("srOAlertShortV32616", null);
            srOwmWrite("srOAlertHoursV32616", null);
            srOwmWrite("srOAlertMinuteV32616", null);
            srOwmWrite("srOAlertPendingV32616", null);
            srOwmWrite("srOAlertSeenV32616", null);
            srOwmWrite("srOAlertAttemptV32616", 0);
            srOwmWrite("srOAlertDetailV32616", null);
            srOwmWrite("srONextAlertV32616", 0);
            srOwmWrite("srONextMV32616", 0);
            srOwmWrite("srOMinutePausedV32616", 0);
            srOwmWrite("srOMinuteAttemptV32616", 0);
            srOwmWrite("srOMinuteTinyV32616", 0);
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextSV32615", 0);
            srOwmWrite("srONextDV326", 0);
            srOwmWrite("srONextAV326", 0);
            srOwmWrite("srODiagV3266", [now, 0, 0]);
        }
    }
    if (changed) {
        try { Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60))); }
        catch (e) { srOwmWrite("srODiagV3266", [now, 0, -18]); }
    } else { srOwmArmIfNeeded(); }
}

// Compact official-alert detail, fetched independently when IDs are present.
// Existence of an active warning is not evidence of a thunderstorm happening
// now. The classified kind is always presented as a FORECAST / warning.
function srOwmOfficialDetailKind() {
    var d = srOwmRead("srOAlertDetailV32616");
    var now = Time.now().value();
    if (!(d instanceof Lang.Array) || d.size() != 6 ||
        !srOwmSamePlace(d, srOwmRead("srOLocV326")) ||
        !srOwmNumber(d[2]) || !srOwmNumber(d[3]) ||
        !srOwmNumber(d[4]) || !srOwmNumber(d[5]) ||
        d[2] > now + 300 || now - d[2] > 6 * 3600 ||
        d[3] > now + 3 * 3600 || d[4] < now ||
        d[5] < 1 || d[5] > 13) { return 0; }
    return d[5];
}

// Settings changes do not invalidate OWM measurements, only refresh the
// schedule when the provider or API key actually changes. We store a hash
// of the key, never a duplicate key in app Storage.
function srOwmProviderChanged() {
    var mode = srUseOpenWeather() ? 1 : 0;
    var oldMode = srOwmRead("srOLastModeV326");
    var key = srSetting("srOpenKeyV326", "");
    var keyStamp = key instanceof Lang.String ? key.hashCode() : 0;
    var oldKeyStamp = srOwmRead("srOKeyHashV326");
    // A new diagnostics schema must never display old, misleading errors.
    // Reset it once per release and again on a provider/credential change.
    var diagVersion = srOwmRead("srODVersionV32616");
    var resetDiag = diagVersion != 32616;
    var refresh = srSetting("srOwmMinutesV326", 30);
    if (refresh != 5 && refresh != 15 && refresh != 30 && refresh != 60) { refresh = 30; }
    var oldRefresh = srOwmRead("srORefreshV3263");
    var shortMode = srSetting("srOwm15MinV3264", true) == true;
    var oldShortMode = srOwmRead("srOShortEnabledV3264");
    var shortChanged = mode == 1 &&
        (oldShortMode == null || oldShortMode != shortMode);
    var modeChanged = oldMode == null || oldMode != mode;
    var keyChanged = mode == 1 && (oldKeyStamp == null || oldKeyStamp != keyStamp);
    var refreshChanged = mode == 1 && oldRefresh != refresh;
    if (resetDiag || modeChanged || keyChanged) {
        var diagNames = ["srODNowV3268", "srODForecastV3268",
                         "srODDailyV3268", "srODAirV3268",
                         "srODMinuteV32616", "srODAlertV32616", "srODSystemV3268", "srODHistoryV3268"];
        for (var x = 0; x < diagNames.size(); x++) {
            srOwmWrite(diagNames[x], null);
        }
        srOwmWrite("srODWakeV3268", 0);
        srOwmWrite("srODGateV3269", null);
        srOwmWrite("srODVersionV32616", 32616);
        // A fresh release MUST get one chance to fetch now, even if an old
        // version left a future retry deadline after FORMAT/timeout errors.
        if (mode == 1 && resetDiag) {
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextSV32615", 0);
            srOwmWrite("srONextDV326", 0);
            srOwmWrite("srONextAV326", 0);
            srOwmWrite("srOReqCtxV3267", null);
            srOwmWrite("srOHourlyTinyV32611", 0);
            // The compact timeline format gained a per-row bucket field.
            // Invalidate old v3.26.14 forecast rows once, not the provider,
            // API key or valid current weather snapshot.
            srOwmWrite("srOHoursV326", null);
            srOwmWrite("srOShortV3264", null);
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srOMinuteV32616", null);
            srOwmWrite("srOAlertPendingV32616", null);
            srOwmWrite("srOAlertSeenV32616", null);
            srOwmWrite("srOAlertAttemptV32616", 0);
            srOwmWrite("srOAlertDetailV32616", null);
            srOwmWrite("srONextAlertV32616", 0);
            srOwmWrite("srONextMV32616", 0);
            srOwmWrite("srOMinutePausedV32616", 0);
            srOwmWrite("srOMinuteAttemptV32616", 0);
            srOwmWrite("srOMinuteTinyV32616", 0);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
        }
    }
    if (modeChanged || keyChanged || refreshChanged || shortChanged) {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        srOwmWrite("srOLastModeV326", mode);
        srOwmWrite("srOKeyHashV326", keyStamp);
        srOwmWrite("srORefreshV3263", refresh);
        srOwmWrite("srOShortEnabledV3264", shortMode);
        if (shortChanged || keyChanged || modeChanged) {
            srOwmWrite("srOShortPausedV3264", 0);
            srOwmWrite("srOShortAttemptV3264", 0);
            srOwmWrite("srOShortV3264", null);
        }
        if (keyChanged) {
            // New credentials must not display a previous key's weather.
            srOwmWrite("srOCurrV326", null);
            srOwmWrite("srOHoursV326", null);
            srOwmWrite("srODayV326", null);
            srOwmWrite("srOAirV326", null);
            srOwmWrite("srOMinuteV32616", null);
            srOwmWrite("srOBaroHistoryV32616", null);
            srOwmWrite("srOAlertNowV32616", null);
            srOwmWrite("srOAlertShortV32616", null);
            srOwmWrite("srOAlertHoursV32616", null);
            srOwmWrite("srOAlertMinuteV32616", null);
            srOwmWrite("srOAlertPendingV32616", null);
            srOwmWrite("srOAlertSeenV32616", null);
            srOwmWrite("srOAlertAttemptV32616", 0);
            srOwmWrite("srOAlertDetailV32616", null);
            srOwmWrite("srONextAlertV32616", 0);
        }
        if (mode == 1) {
            srOwmWrite("srODiagV3266", [Time.now().value(), 0, 0]);
        }
        if (mode == 0) {
            srOwmWrite("srGEventDue", 0);
        } else {
            // Changing cadence must affect CURRENT/HOURLY immediately;
            // retain fresh cached data and unrelated DAILY/AQI deadlines.
            srOwmWrite("srONextCV326", 0);
            srOwmWrite("srONextFV326", 0);
            srOwmWrite("srONextSV32615", 0);
            srOwmWrite("srONextMV32616", 0);
            if (modeChanged || keyChanged) {
                srOwmWrite("srONextDV326", 0);
                srOwmWrite("srONextAV326", 0);
            }
        }
    }
    // Do not leave an old OWM timer armed after removing the API key.
    if (mode == 1 && !srOwmKeyReady()) {
        srOwmWrite("srODiagV3266", [Time.now().value(), 0, -11]);
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        return;
    }
    srOwmArmIfNeeded();
}
