using Toybox.Application.Properties as Props;
using Toybox.Graphics as Gfx;
using Toybox.Application.Storage as Storage;

// Cache ONLY persisted settings; dynamic device data is never cached here.
// All entries are invalidated on AppBase.onSettingsChanged().
// A 96-entry cap covers the original settings plus provider selections while bounding RAM.
var _srSettingCache = {};
var _srSettingCacheSize = 0;

function srResetSettingsCache() {
    _srSettingCache = {};
    _srSettingCacheSize = 0;
}

// Mobile app settings. All default keys are defined in resources/settings/properties.xml.
// Deliberately use NEW keys so stale v2.x settings cannot unexpectedly override
// the new three-ring layout. All 8 visible slots are selectable from the phone.
function srSetting(key, fallback) {
    // Version 3.18: font controls removed from Connect IQ settings because
    // they were not reliable on the MIP screen. Preserve the accepted layout
    // and ignore values persisted by previous versions of the phone app.
    if (key.equals("fontClockV31") || key.equals("fontDateV31") ||
        key.equals("fontTopV31") || key.equals("fontRingV31") ||
        key.equals("fontWeatherV31")) { return 2; }
    if (key.equals("fontFaceV36")) { return 0; }
    if (key.equals("fontExtraV36")) { return 1; }
    if (key.equals("sizeTopLeftV37") || key.equals("sizeTopMidV37") ||
        key.equals("sizeTopRightV37") || key.equals("sizeRingLeftV37") ||
        key.equals("sizeRingMidV37") || key.equals("sizeRingRightV37") ||
        key.equals("sizeWeatherValueV37") || key.equals("sizeWeatherLabelV37") ||
        key.equals("sizeFooterV37") || key.equals("moonFontV38")) { return -1; }
    var cached = _srSettingCache[key];
    if (cached != null) { return cached; }
    try {
        var value = Props.getValue(key);
        if (value != null) {
            if (_srSettingCacheSize < 96) {
                _srSettingCache[key] = value;
                _srSettingCacheSize += 1;
            }
            return value;
        }
    } catch (e) { }
    return fallback;
}

function srColor(value) {
    if (value == 0) { return Gfx.COLOR_RED; }
    if (value == 1) { return Gfx.COLOR_GREEN; }
    if (value == 2) { return Gfx.COLOR_BLUE; }
    if (value == 3) { return Gfx.COLOR_ORANGE; }
    if (value == 4) { return Gfx.COLOR_YELLOW; }
    if (value == 5) { return Gfx.COLOR_WHITE; }
    return 0x00FFFF;
}

// One-time opt-in release profile for v3.26.15. Runs ONLY in the watch-face
// foreground, never in the background service. The API key and user's
// selected weather provider are deliberately untouched. Subsequent edits in
// Connect IQ are respected because this marker is persistent.
function srApplyOptimizedWeatherDefaults32615() {
    try {
        if (Storage.getValue("srOptimal32615") == 1) { return; }
        Props.setValue("gwOnV332", true);
        Props.setValue("gwIntervalV332", 5);
        Props.setValue("gwForecastV332", true);
        Props.setValue("gwHorizonV332", 3);
        Props.setValue("gwWindOnV332", true);
        Props.setValue("gwWindV332", 10);
        Props.setValue("gwStormOnV332", true);
        Props.setValue("gwRainOnV332", true);
        Props.setValue("gwRainChanceV332", 30);
        Props.setValue("gwSnowOnV332", true);
        Props.setValue("gwSnowChanceV332", 40);
        Props.setValue("gwFreezeOnV332", true);
        Props.setValue("gwFogOnV332", true);
        Props.setValue("gwFogMetersV332", 500);
        Props.setValue("gwIceOnV332", true);
        Props.setValue("gwIceTempV332", 1);
        Props.setValue("gwIceChanceV332", 50);
        Props.setValue("gwHailOnV332", true);
        Props.setValue("gwUvOnV332", true);
        Props.setValue("gwUvV332", 7);
        Props.setValue("gwRainHeavyV332", false);
        Props.setValue("gwSnowHeavyV332", false);
        Props.setValue("gwAirOnV332", true);
        Props.setValue("srPrecipModeV3263", 2);
        Props.setValue("srOwmMinutesV326", 5);
        Props.setValue("srOwm15MinV3264", true);
        Props.setValue("srOwmAirV326", true);
        Props.setValue("srOwmAqiMinV326", 4);
        Props.setValue("srOwmGustV3263", 15);
        Storage.setValue("srOptimal32615", 1);
        srResetSettingsCache();
    } catch (e) { /* Keep the last good user setting on write failure. */ }
}

// 3.26.16: one-time best-observation profile. Only the weather controls
// change; do not touch the existing API token, provider, rings or layout.
// A one-time marker ensures later user's Connect IQ edits are respected.
function srApplyOptimizedWeatherDefaults32616() {
    try {
        if (Storage.getValue("srOptimal32616") == 1) { return; }
        Props.setValue("stormOnV3", true);
        Props.setValue("stormFastV310", true);
        Props.setValue("stormFastDropV310", 2);
        Props.setValue("stormDropV3", 4);
        Props.setValue("stormAltitudeV3", 20);
        Props.setValue("gwOnV332", true);
        Props.setValue("gwIntervalV332", 5);
        Props.setValue("gwForecastV332", true);
        Props.setValue("gwHorizonV332", 3);
        Props.setValue("gwWindOnV332", true);
        Props.setValue("gwWindV332", 10);
        Props.setValue("gwStormOnV332", true);
        Props.setValue("gwRainOnV332", true);
        Props.setValue("gwRainChanceV332", 30);
        Props.setValue("gwSnowOnV332", true);
        Props.setValue("gwSnowChanceV332", 40);
        Props.setValue("gwFreezeOnV332", true);
        Props.setValue("gwFogOnV332", true);
        Props.setValue("gwFogMetersV332", 500);
        Props.setValue("gwIceOnV332", true);
        Props.setValue("gwIceTempV332", 1);
        Props.setValue("gwIceChanceV332", 50);
        Props.setValue("gwHailOnV332", true);
        Props.setValue("gwUvOnV332", true);
        Props.setValue("gwUvV332", 7);
        Props.setValue("gwRainHeavyV332", false);
        Props.setValue("gwSnowHeavyV332", false);
        Props.setValue("gwAirOnV332", true);
        Props.setValue("srPrecipModeV3263", 2);
        Props.setValue("srOwmMinutesV326", 5);
        Props.setValue("srOwm15MinV3264", true);
        Props.setValue("srOwmAirV326", true);
        Props.setValue("srOwmAqiMinV326", 4);
        Props.setValue("srOwmGustV3263", 15);
        Props.setValue("srNowcastThresholdV32616", 20);
        Storage.setValue("srOptimal32616", 1);
        srResetSettingsCache();
    } catch (e) { /* Keep previously valid values if Connect IQ refuses writes. */ }
}
