using Toybox.SensorHistory as History;
using Toybox.Time as Time;
using Toybox.Lang as Lang;

// Independent barometric pressure-TREND signal, NOT a confirmed thunderstorm.
// The device's barometric elevation is NOT independent of pressure: a fall in
// pressure can itself raise the barometric elevation. Distinguish three states:
// 0 no alert, 1 tentative pressure trend (amber marked '?'), 2 corroborated.
// Recent independent OpenWeather sea-level pressure may corroborate a trend,
// but can never be mistaken for the watch's physical pressure sensor.
class StormGuard {
    var _lastCheck;
    var _lastResult;
    var _lastState;
    var _lastDrop1;
    var _lastDrop3;
    var _lastAltitude;
    var _lastExternal;

    function initialize() {
        _lastCheck = 0;
        _lastResult = 0;
        _lastState = 0;
        _lastDrop1 = -1;
        _lastDrop3 = -1;
        _lastAltitude = -1;
        _lastExternal = -1;
    }

    // 0=none, 1=uncertain barometric change, 2=elevation-stable or verified
    // by a separate, recent OWM sea-level pressure trend.
    function warningLevel() {
        if (!srSetting("stormOnV3", true)) { _lastResult = 0; _lastState = 1; return 0; }
        var now = Time.now().value();
        if (_lastCheck != 0 && now >= _lastCheck && now - _lastCheck < 300) {
            return _lastResult;
        }
        _lastCheck = now;
        _lastResult = evaluate();
        return _lastResult;
    }

    function warning() { return warningLevel() > 0; }

    // Diagnostic only; no extra sensors or API calls.
    function diagnostic() {
        return [_lastState, _lastDrop1, _lastDrop3,
                _lastAltitude, _lastExternal, _lastResult];
    }

    function evaluate() {
        _lastDrop1 = -1;
        _lastDrop3 = -1;
        _lastAltitude = -1;
        _lastExternal = -1;
        _lastState = 2;
        try {
            var now = Time.now().value();
            var fastEnabled = srSetting("stormFastV310", true);
            var iter = History.getPressureHistory({
                :period => new Time.Duration(10800),
                :order => History.ORDER_NEWEST_FIRST
            });
            if (iter == null) { return 0; }
            var newestPa = null;
            var newestAt = null;
            var oldestPa1 = null;
            var oldestAt1 = null;
            var oldestPa3 = null;
            var oldestAt3 = null;
            var n1 = 0;
            var n3 = 0;
            var sample = iter.next();
            while (sample != null && n3 < 400) {
                if (sample.data != null && sample.when != null) {
                    var at = sample.when.value();
                    var pa = sample.data.toFloat();
                    if (pa > 30000 && pa < 115000 && at <= now + 300) {
                        if (newestPa == null) { newestPa = pa; newestAt = at; }
                        oldestPa3 = pa;
                        oldestAt3 = at;
                        n3++;
                        if (fastEnabled && at >= now - 3600) {
                            oldestPa1 = pa;
                            oldestAt1 = at;
                            n1++;
                        }
                    }
                }
                sample = iter.next();
            }
            if (newestAt == null || now - newestAt > 900) {
                _lastState = 3; return 0;
            }
            if (n1 >= 2) { _lastDrop1 = ((oldestPa1 - newestPa) / 100.0 * 10).toNumber(); }
            if (n3 >= 2) { _lastDrop3 = ((oldestPa3 - newestPa) / 100.0 * 10).toNumber(); }
            var candidate1 = fastEnabled && n1 >= 5 &&
                newestAt - oldestAt1 >= 3000 &&
                _lastDrop1 >= srSetting("stormFastDropV310", 2) * 10;
            var candidate3 = n3 >= 5 && newestAt - oldestAt3 >= 9000 &&
                _lastDrop3 >= srSetting("stormDropV3", 4) * 10;
            if (!candidate1 && !candidate3) { _lastState = 4; return 0; }
            // The 1-hour path has priority; try the 3-hour path independently.
            var tentative = 0;
            if (candidate1) {
                var d1 = _lastDrop1.toFloat() / 10.0;
                if (stableElevation(3600, 3000, now)) {
                    _lastState = 6; return 2;
                }
                if (externalCorroboration(3600, 3000, d1, now)) {
                    _lastState = 7; return 2;
                }
                if (ambiguousPressureAltitude(d1)) { tentative = 1; }
            }
            if (candidate3) {
                var d3 = _lastDrop3.toFloat() / 10.0;
                if (stableElevation(10800, 9000, now)) {
                    _lastState = 6; return 2;
                }
                if (externalCorroboration(10800, 9000, d3, now)) {
                    _lastState = 7; return 2;
                }
                if (ambiguousPressureAltitude(d3)) { tentative = 1; }
            }
            _lastState = tentative == 1 ? 8 : 5;
            return tentative;
        } catch (e) { _lastState = 9; return 0; }
    }

    // Only a valid elevation history and small full-window range count as
    // independent confirmation of apparent stationarity. A missing history
    // must not be silently treated as zero elevation change.
    function stableElevation(windowSeconds, minimumSeconds, now) {
        try {
            var iter = History.getElevationHistory({
                :period => new Time.Duration(windowSeconds),
                :order => History.ORDER_NEWEST_FIRST
            });
            if (iter == null) { return false; }
            var item = iter.next();
            var minAlt = 100000.0;
            var maxAlt = -100000.0;
            var newestAt = null;
            var oldestAt = null;
            var n = 0;
            while (item != null && n < 400) {
                if (item.data != null && item.when != null) {
                    var at = item.when.value();
                    var altitude = item.data.toFloat();
                    if (at <= now + 300 && altitude > -1000 && altitude < 12000) {
                        if (altitude < minAlt) { minAlt = altitude; }
                        if (altitude > maxAlt) { maxAlt = altitude; }
                        if (newestAt == null) { newestAt = at; }
                        oldestAt = at;
                        n++;
                    }
                }
                item = iter.next();
            }
            if (n < 5 || newestAt == null || oldestAt == null ||
                now - newestAt > 900 || newestAt - oldestAt < minimumSeconds) {
                return false;
            }
            _lastAltitude = (maxAlt - minAlt).toNumber();
            return maxAlt - minAlt < srSetting("stormAltitudeV3", 20);
        } catch (e) { return false; }
    }

    // A modest barometric altitude excursion is INDETERMINATE when a pressure
    // decline can itself explain it. Display an explicit tentative bolt,
    // not a confirmed storm, instead of silently suppressing the signal.
    // A large excursion remains rejected, to reduce stair/hill false alarms.
    function ambiguousPressureAltitude(dropHpa) {
        if (_lastAltitude < 0 || dropHpa <= 0 || dropHpa > 15) { return false; }
        return _lastAltitude <= srSetting("stormAltitudeV3", 20) + dropHpa * 9;
    }

    // Cross-check independent sea-level pressure values from One Call 4.0.
    // A history whose location or most recent sample is stale is never used.
    function externalCorroboration(windowSeconds, minimumSeconds, localDrop, now) {
        try {
            var history = srOwmRead("srOBaroHistoryV32616");
            var loc = srOwmRead("srOLocV326");
            if (!(history instanceof Lang.Array) || history.size() != 3 ||
                !srOwmSamePlace(history, loc) ||
                !(history[2] instanceof Lang.Array)) { return false; }
            var rows = history[2] as Lang.Array;
            var newestPressure = null;
            var newestTime = 0;
            var olderPressure = null;
            var olderTime = 0;
            for (var i = rows.size() - 1; i >= 0; i--) {
                var r = rows[i];
                if (!(r instanceof Lang.Array) || r.size() != 2 ||
                    !srOwmNumber(r[0]) || !srOwmNumber(r[1]) ||
                    r[0] > now + 300 || r[1] < 870 || r[1] > 1100) { continue; }
                if (newestPressure == null) {
                    newestPressure = r[1]; newestTime = r[0];
                }
                if (r[0] <= now - minimumSeconds && r[0] >= now - windowSeconds - 1200) {
                    olderPressure = r[1]; olderTime = r[0];
                    break;
                }
            }
            if (newestPressure == null || olderPressure == null ||
                now - newestTime > 1800 || newestTime - olderTime < minimumSeconds - 900) {
                return false;
            }
            _lastExternal = ((olderPressure - newestPressure) * 10).toNumber();
            var minIndependentDrop = localDrop * 0.35;
            if (minIndependentDrop < 0.6) { minIndependentDrop = 0.6; }
            return olderPressure - newestPressure >= minIndependentDrop;
        } catch (e) { return false; }
    }
}
