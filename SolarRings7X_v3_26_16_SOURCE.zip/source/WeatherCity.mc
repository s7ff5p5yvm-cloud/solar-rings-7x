// v3.24.25. Offline, approximate city labels for Garmin Weather positions.
// Deliberately NO Toybox.Position GPS request and NO Communications HTTP calls.
// Flat immutable lookup table: label, latitude, longitude. Only scanned when
// the weather observation's coordinates change by ~0.01 degree.
var _srWeatherCities = [
    "KRAKÓW", 50.0647d, 19.9450d,
    "WARSZAWA", 52.2297d, 21.0122d,
    "WROCŁAW", 51.1079d, 17.0385d,
    "POZNAŃ", 52.4064d, 16.9252d,
    "GDAŃSK", 54.3520d, 18.6466d,
    "GDYNIA", 54.5189d, 18.5305d,
    "SOPOT", 54.4416d, 18.5601d,
    "ŁÓDŹ", 51.7592d, 19.4559d,
    "KATOWICE", 50.2649d, 19.0238d,
    "SZCZECIN", 53.4285d, 14.5528d,
    "BYDGOSZCZ", 53.1235d, 18.0084d,
    "TORUŃ", 53.0138d, 18.5984d,
    "LUBLIN", 51.2465d, 22.5684d,
    "BIAŁYSTOK", 53.1325d, 23.1688d,
    "RZESZÓW", 50.0412d, 21.9991d,
    "KIELCE", 50.8661d, 20.6286d,
    "OLSZTYN", 53.7784d, 20.4801d,
    "OPOLE", 50.6751d, 17.9213d,
    "GORZÓW WLK.", 52.7368d, 15.2288d,
    "ZIELONA GÓRA", 51.9356d, 15.5062d,
    "GLIWICE", 50.2945d, 18.6714d,
    "ZABRZE", 50.3249d, 18.7857d,
    "TYCHY", 50.1372d, 18.9664d,
    "BIELSKO-BIAŁA", 49.8225d, 19.0469d,
    "CZĘSTOCHOWA", 50.8118d, 19.1203d,
    "ZAKOPANE", 49.2992d, 19.9496d,
    "NOWY TARG", 49.4775d, 20.0323d,
    "NOWY SĄCZ", 49.6218d, 20.6971d,
    "TARNÓW", 50.0121d, 20.9858d,
    "BOCHNIA", 49.9691d, 20.4306d,
    "LIMANOWA", 49.7063d, 20.4222d,
    "MYŚLENICE", 49.8333d, 19.9386d,
    "WADOWICE", 49.8828d, 19.4936d,
    "OŚWIĘCIM", 50.0381d, 19.2214d,
    "SUCHA BESK.", 49.7410d, 19.5882d,
    "ŻYWIEC", 49.6853d, 19.1924d,
    "CIESZYN", 49.7498d, 18.6320d,
    "RACIBÓRZ", 50.0919d, 18.2193d,
    "RYBNIK", 50.0971d, 18.5418d,
    "JASTRZĘBIE", 49.9506d, 18.5745d,
    "KROSNO", 49.6887d, 21.7706d,
    "SANOK", 49.5557d, 22.2056d,
    "PRZEMYŚL", 49.7830d, 22.7673d,
    "JAROSŁAW", 50.0162d, 22.6778d,
    "JASŁO", 49.7450d, 21.4725d,
    "STALOWA WOLA", 50.5829d, 22.0537d,
    "SANDOMIERZ", 50.6827d, 21.7487d,
    "OSTROWIEC", 50.9294d, 21.3853d,
    "SKARŻYSKO", 51.1133d, 20.8716d,
    "RADOM", 51.4027d, 21.1471d,
    "PUŁAWY", 51.4166d, 21.9694d,
    "ZAMOŚĆ", 50.7231d, 23.2519d,
    "CHEŁM", 51.1431d, 23.4712d,
    "BIAŁA PODL.", 52.0324d, 23.1165d,
    "SIEDLCE", 52.1676d, 22.2902d,
    "PŁOCK", 52.5468d, 19.7064d,
    "WŁOCŁAWEK", 52.6482d, 19.0678d,
    "GRUDZIĄDZ", 53.4837d, 18.7536d,
    "INOWROCŁAW", 52.7984d, 18.2632d,
    "PIŁA", 53.1512d, 16.7389d,
    "KONIN", 52.2230d, 18.2511d,
    "KALISZ", 51.7611d, 18.0910d,
    "OSTRÓW WLKP.", 51.6540d, 17.8069d,
    "GNIEZNO", 52.5348d, 17.5826d,
    "LESZNO", 51.8419d, 16.5741d,
    "JELENIA GÓRA", 50.9044d, 15.7197d,
    "WAŁBRZYCH", 50.7714d, 16.2843d,
    "LEGNICA", 51.2070d, 16.1619d,
    "LUBIN", 51.4009d, 16.2015d,
    "KŁODZKO", 50.4371d, 16.6614d,
    "ŚWIDNICA", 50.8438d, 16.4886d,
    "NYSA", 50.4746d, 17.3319d,
    "BRZEG", 50.8607d, 17.4671d,
    "OŁAWA", 50.9466d, 17.2926d,
    "ŚWINOUJŚCIE", 53.9105d, 14.2471d,
    "KOŁOBRZEG", 54.1755d, 15.5839d,
    "KOSZALIN", 54.1944d, 16.1722d,
    "SŁUPSK", 54.4641d, 17.0287d,
    "SŁAWNO", 54.3628d, 16.6794d,
    "ELBLĄG", 54.1522d, 19.4088d,
    "EŁK", 53.8282d, 22.3647d,
    "SUWAŁKI", 54.1116d, 22.9303d,
    "GIŻYCKO", 54.0381d, 21.7644d,
    "IŁAWA", 53.5960d, 19.5685d,
    "OSTRÓDA", 53.6964d, 19.9648d,
    "MALBORK", 54.0359d, 19.0266d,
    "TCZEW", 54.0919d, 18.7770d,
    "WEJHEROWO", 54.6057d, 18.2356d,
    "CHOJNICE", 53.6978d, 17.5570d,
    "SŁUBICE", 52.3503d, 14.5607d,
    "FRANKFURT", 50.1109d, 8.6821d,
    "BERLIN", 52.5200d, 13.4050d,
    "DREZNO", 51.0504d, 13.7373d,
    "LIPSK", 51.3397d, 12.3731d,
    "MONACHIUM", 48.1351d, 11.5820d,
    "HAMBURG", 53.5511d, 9.9937d,
    "KOLONIA", 50.9375d, 6.9603d,
    "DÜSSELDORF", 51.2277d, 6.7735d,
    "STUTTGART", 48.7758d, 9.1829d,
    "NORYMBERGA", 49.4521d, 11.0767d,
    "PRAGA", 50.0755d, 14.4378d,
    "BRNO", 49.1951d, 16.6068d,
    "OSTRAWA", 49.8209d, 18.2625d,
    "OŁOMUNIEC", 49.5938d, 17.2509d,
    "BRATYSŁAWA", 48.1486d, 17.1077d,
    "WIEDEŃ", 48.2082d, 16.3738d,
    "BUDAPESZT", 47.4979d, 19.0402d,
    "KOSZYCE", 48.7164d, 21.2611d,
    "POPRAD", 49.0511d, 20.2972d,
    "ŻYLINA", 49.2231d, 18.7394d,
    "TRENCZYN", 48.8945d, 18.0444d,
    "LIPT. MIKULASZ", 49.0845d, 19.6130d,
    "LONDYN", 51.5074d, -0.1278d,
    "PARYŻ", 48.8566d, 2.3522d,
    "RZYM", 41.9028d, 12.4964d
];

function srWeatherCityFromDegrees(lat, lon) {
    if (lat == null || lon == null || lat < -90.0d || lat > 90.0d ||
        lon < -180.0d || lon > 180.0d) { return "BRAK LOK."; }
    var best = 900.0d; // Maximum ~30 km from a listed city center.
    var nearest = null;
    // For Central Europe, longitude degrees are approximately 70 km.
    // This is a display approximation, not a station ID or GPS city lookup.
    for (var i = 0; i < _srWeatherCities.size(); i += 3) {
        var dy = (lat - _srWeatherCities[i + 1]) * 111.0d;
        var dx = (lon - _srWeatherCities[i + 2]) * 70.0d;
        var squared = dx * dx + dy * dy;
        if (squared < best) {
            best = squared;
            nearest = _srWeatherCities[i];
        }
    }
    if (nearest != null) { return nearest; }
    // Outside the offline city directory: show real approximate coordinates,
    // not a fabricated or stale city name. drawSized() fits this text.
    return lat.format("%.2f") + "," + lon.format("%.2f");
}
