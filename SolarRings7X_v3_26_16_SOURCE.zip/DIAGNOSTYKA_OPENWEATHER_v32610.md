# Solar Rings v3.26.10 — analiza K-214 P0 (17.11.2026)

## Dane z zegarka

- TEST 16: klucz OK, lokalizacja OK, telefon TAK, BG TAK, ostatnie uruchomienie 3 minuty, `SYSTEM K-214 ET30`; wszystkie endpointy bez prób.
- TEST 20: `ETAP G19 P0`, `OSTATNI K-214 P0`, `ZADANIE P0 4m`, `NEXT C29m F-29915487m`.

## Potwierdzony błąd w źródłach

W v3.26.9 `SolarOpenNetwork.mc` porównuje identyfikatory `_kind` do stringów poprzez `==`. W Monkey C takie porównanie nie gwarantuje równej treści, bo stringi są obiektami. `phase()` zwracało `0`, mimo że rodzaj zapytania powinien być `current` / `forecast` / `daily` / `air`. Ponieważ ścieżka URL miała domyślny fallback do AQI, nieznany rodzaj mógł wysłać niewłaściwe żądanie, a parser trafiał do `reason=-214` bez zapisu danych.

## Co zmieniono

1. Ujednolicenie wszystkich porównań `_kind` w silniku OpenWeather poprzez `kindIs(name)` z `Lang.String.equals()`.
2. `phase()==0` jest błędem przed wysłaniem żądania (kod -232) zamiast wysyłania żądania na domyślny endpoint.
3. Callback przywraca kontekst, jeśli `phase()==0` i rejestruje wynik ze zgodnym identyfikatorem P1/P2/P3/P4.
4. Porównanie nazw kluczy, geokodera, wiadomości BG i etykiet w pozostałych modułach jest oparte na `.equals()`.
5. Diagnostyka nie pokazuje ogromnych ujemnych minut dla nieustawionego terminu (`F--`).

## Oczekiwany wynik na Garminie

Po uruchomieniu w v3.26.10 TEST 20: `G19 P1` dla danych bieżących, a potem `G21 P1` po zapisie; TEST 16: `TERAZ K200`. Jeżeli API zwróci nieoczekiwane dane, P1 oraz TEST 17 wskażą konkretne brakujące pole lub kod HTTP. G19 nie jest jeszcze gwarancją HTTP 200.

Nie gwarantuje to naprawy każdego błędu. Ścieżka One Call 4.0 musi zostać skompilowana i sprawdzona w rzeczywistym środowisku.
