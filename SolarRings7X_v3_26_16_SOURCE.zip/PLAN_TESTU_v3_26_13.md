# Solar Rings v3.26.13 — test maksymalnej aktualności OpenWeather

## Co zmieniono
- Dodany czwarty tryb OpenWeather `Maksymalna aktualnosc` w ustawieniach częstotliwości.
- Usługa Garmin ma dostępny jeden slot sieciowy nie częściej niż co 5 minut. Przy ograniczeniu jednej operacji HTTP na przebudzenie tryb planuje aktualne warunki i prognozę średnio co 10–15 minut; nie każde źródło osobno co 5 minut.
- Prognoza dzienna zachowuje 12 godzin, AQI 60 minut, jeśli aktywne. Wybór najstarszego zaległego źródła zapobiega zagłodzeniu AQI i dni.
- OWM odświeża model zwykle co 10 minut, dlatego zapytania co 5 minut do każdego endpointu nie oznaczałyby dwóch różnych wyliczeń.
- W pojedynczym zegarku około 288 zaplanowanych wywołań/dobę; osłona 700 własnych prób/dobę, ale nie zastępuje kontowego limitu OpenWeather i nie kontroluje innych aplikacji na tym samym kluczu.

## Bezpieczna kolejność weryfikacji
1. Najpierw uruchomić GitHub Actions — kompilacje `.prg` i `.iq` muszą być zielone. Wersja źródeł: 3.26.13.
2. Po instalacji otworzyć Connect IQ → Solar Rings → ustawienia → odświeżanie → `Maksymalna aktualnosc`. Zachować w pierwszym teście prognozę 15-minutową wyłączoną, ponieważ wcześniej zgłaszała problemy pamięci (`-403`).
3. Pozostawić na pierwszych 60–90 minutach podgląd diagnostyczny `TEST 16` (wynik bieżących danych `P1` i prognozy `P2`) i `TEST 20` (etap). Przejrzeć status bez ujawniania klucza API.
4. Zanotować poziom baterii przy rozpoczęciu próby i po 24, 48 oraz 72 godzinach. Przy krótszym niż zakładane czasie pracy zrezygnować z maksymalnej aktualności na rzecz trybu 15/30 minut.
5. Nie oceniać prognozowanych ostrzeżeń jako działających, jeśli `P2` nadal zgłasza `K-403`; wymaga to osobnej naprawy odpowiedzi/pamięci.

## Ograniczenia
- Garmin może opóźniać wybudzenia. OWM nie gwarantuje zmiany danych co 10 minut.
- 10 dni na baterii jest celem pomiarowym, nie gwarancją.
- Po zmianie trybu stare terminy bieżącej pogody i prognozy są zerowane; dane w pamięci pozostają.
- Na pierwszym wdrożeniu nie wykonano kompilacji Garmin SDK ani rzeczywistych wywołań API z zegarka.
