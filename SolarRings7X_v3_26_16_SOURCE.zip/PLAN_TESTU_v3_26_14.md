# Solar Rings v3.26.14 — test jakości i aktualności

1. Skopiuj SOURCE.zip do głównego katalogu repozytorium i BUILD.yml do `.github/workflows/`. Uruchom GitHub Actions. Nie instaluj nieudanego PRG.
2. Po instalacji zobacz w Connect IQ nowe ustawienia: Maksymalna aktualność (cykl 5min), wszystkie ostrzeżenia włączone, horyzont 3h, odświeżanie oceny 5min, indywidualne progi deszcz 30%, śnieg 40%, wiatr 10m/s, porywy 15m/s, widzialność 500m, ryzyko oblodzenia 1°C / 50%, UV 7, AQI 4, silne-opady-only OFF. Klucz i dostawca pozostają nietknięte. Uwaga: migracja wykonuje się raz na pierwszym uruchomieniu tarczy.
3. Włączoną prognozę 15min najpierw testuje wyłącznie gdy w pamięci ma świeżą prognozę godzinową. Po pamięciowym K-403 przechodzi na godzinową na 24h.
4. Fotografuj TEST 16 i TEST 20 po około 20, 45 i 90 minutach pracy; zapisz P1 i P2 wraz z wiekiem i godziną. K200 po jednej próbie nie gwarantuje ciągłej stabilności.
5. TEST 15 przy rzeczywistych opadach: C-kod (obserwacja), R/S z ostatniej godziny i brak/current/future alert; czerwony=aktualny kod, szary=ostatnia godzina, turkusowy=prognoza.
6. Jeżeli przez >=45min nie ma aktualnych prognoz, tarcza w szybkim profilu nie powinna pokazywać ich jako świeżych, ale bieżąca temperatura może zachować ostatnią obserwację do 90min (oznaczoną wiekiem).
7. Porównaj spadek baterii po 24/48/72h. Cel 10 dni pracy jest założeniem do testu, nie dowiedzioną cechą.

**Limity:** OWM ma model co 10m, Garmin BG temporal min 5m; jedna operacja HTTP na wybudzenie, do ~288 planowanych slotów/dobę; lokalne ograniczenie 700 nie obejmuje innych urządzeń. `cnt` dla timelines jest sygnalizowane w przykładach odpowiedzi/paginacji OWM, ale rzeczywiste ograniczenie liczby rekordów musi zostać potwierdzone na fizycznym zegarku.
