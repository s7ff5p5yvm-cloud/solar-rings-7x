import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent.parent
N=(ROOT/'source/SolarOpenNetwork.mc').read_text()
D=(ROOT/'source/SolarOpenData.mc').read_text()
S=(ROOT/'resources/settings/settings.xml').read_text()
STR=(ROOT/'resources/strings.xml').read_text()

class FastRefresh32613(unittest.TestCase):
    def test_profile_visible(self):
        root=ET.fromstring(S)
        opt=next(i for i in root.iter('setting') if 'srOwmMinutesV326' in i.attrib.get('propertyKey',''))
        vals={int(i.attrib['value']) for i in opt.iter('listEntry')}
        self.assertEqual(vals,{5,15,30,60})
        self.assertIn('id="sr_open_5"',STR)
        self.assertIn('refresh != 5',D)
        self.assertIn('_interval != 5',N)
    def test_one_request_per_wakeup(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),1)
        self.assertIn('else if (nextF <= _now) { _kind = "forecast"; }',N)
        self.assertIn('nextA <= _now',N)
        self.assertIn('return _interval == 5 ? 10 * 60',N)
        self.assertIn('return _interval == 5 ? 60 * 60 : _interval * 120;',N)
    def test_quota_fail_closed(self):
        self.assertIn('used >= 700',N)
        self.assertIn('if (!reserveQuota())',N)
        self.assertIn('srOBudgetV32613',N)
    def test_existing_weather_parsing_retained(self):
        self.assertIn('== 1 ? "2" : "3";',N)
        self.assertIn('q["cnt"] = "4"',N)
        self.assertIn('srOHourlyTinyV32611',N)
        self.assertIn('if (_shortRequest)',N)

    def test_scheduler_model_one_day(self):
        # Model one request per 5-minute wake; 10m current + forecast
        # and 60m AQI and 12h daily deadlines, choosing oldest overdue.
        nxt={'current':0,'forecast':0,'daily':0,'air':0}
        last={k:[] for k in nxt}
        periods={'current':10,'forecast':10,'daily':720,'air':60}
        for t in range(0,24*60,5):
            due=[k for k in nxt if nxt[k] <= t]
            if not due: continue
            k=min(due,key=lambda x:nxt[x])
            last[k].append(t)
            nxt[k]=t+periods[k]
        self.assertLessEqual(sum(map(len,last.values())),288)
        self.assertGreaterEqual(len(last['current']),110)
        self.assertGreaterEqual(len(last['forecast']),110)
        self.assertGreaterEqual(len(last['air']),20)
        self.assertGreaterEqual(len(last['daily']),2)
        self.assertLessEqual(max(b-a for a,b in zip(last['current'],last['current'][1:])),20)
        self.assertLessEqual(max(b-a for a,b in zip(last['forecast'],last['forecast'][1:])),20)

if __name__=='__main__': unittest.main()
