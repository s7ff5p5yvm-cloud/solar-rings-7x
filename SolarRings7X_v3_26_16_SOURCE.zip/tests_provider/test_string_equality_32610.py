"""Regression audit for wrong P0/HTTP K-214 caused by String ==.
These are SOURCE checks, not a Monkey C emulator.
"""
from pathlib import Path
import re
import unittest
P=Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
FILES={p.name:p.read_text() for p in (P/'source').glob('*.mc')}

class TestStringEqualityFix(unittest.TestCase):
    def test_no_string_literal_reference_comparisons_anywhere(self):
        # Comparing a String with a literal using == is reference comparison in Monkey C.
        pat=re.compile(r'(?:==|!=)\s*"[^"]*"')
        for name,content in FILES.items():
            self.assertIsNone(pat.search(content), name)
    def test_phase_maps_all_four_kinds_by_contents(self):
        self.assertIn('function kindIs(name)', N)
        self.assertIn('_kind.equals(name)', N)
        for idx,name in enumerate(('current','forecast','daily','air'),1):
            self.assertIn(f'if (kindIs("{name}")) {{ return {idx}; }}', N)
    def test_no_silent_aqi_fallback_when_kind_unknown(self):
        self.assertIn('if (phase() == 0) { gate(16); status(-232); finish(false); return; }',N)
        self.assertIn('if (kindIs("air"))',N)
    def test_context_recovered_before_gate19(self):
        pos=N.index('function onReceive(')
        chunk=N[pos:]
        self.assertLess(chunk.index('if (phase() == 0) { restoreRequestContext(); }'),chunk.index('gate(19)'))
        self.assertIn('if (phase() == 0) {\n            status(-19);', chunk)
        self.assertIn('status(200);',chunk)
    def test_15min_route_selection_compares_values(self):
        self.assertIn('_shortRequest = _shortChoice',N)
        self.assertIn('data/4.0/onecall/current',N)
        self.assertIn('data/4.0/onecall/timeline/15min',N)
        self.assertIn('data/4.0/onecall/timeline/1h',N)
        self.assertIn('data/4.0/onecall/timeline/1day',N)
    def test_no_giant_negative_time_for_unset_deadline(self):
        self.assertIn('num(f) && f > 0',N)
        self.assertIn('trace[4] < 0 ? "--"', FILES['SolarRings7X.mc'])
    def test_setting_key_and_owm_callback_use_equals(self):
        self.assertIn('key.equals("fontClockV31")',FILES['Config.mc'])
        self.assertIn('data[0].equals("OWM")',FILES['SolarRings7X.mc'])
        self.assertIn('props["osm_key"].equals("place")',FILES['WeatherGeocode.mc'])

if __name__=='__main__': unittest.main()
