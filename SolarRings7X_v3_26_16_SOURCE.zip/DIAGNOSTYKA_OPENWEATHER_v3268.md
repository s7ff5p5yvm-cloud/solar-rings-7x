# Solar Rings 7X v3.26.8 — pełna diagnostyka OpenWeather

## Dlaczego ta wersja powstała

W wersji 3.26.7 zegarek wyświetlał `OWM LOK: FORMAT` bez bieżącej temperatury i prognozy. Takie oznaczenie nie pozwalało ustalić, który endpoint faktycznie zawiódł. Poprzednie zdjęcia potwierdzają, że wyświetlanie miasta **Kraków** działa, ale nie dowodzą poprawności żądań ani zapisu danych OpenWeather. Nie zmieniamy teraz klucza API, lokalizacji ani zasad ostrzeżeń; rozdzielamy przyczyny awarii.

## Co jest rejestrowane

Dla każdego z pięciu etapów (SYSTEM, TERAZ, PROG, DZIEŃ, AQI) ostatnia próba: czas, numer etapu, wynik, maska struktury odpowiedzi JSON, liczba rekordów, liczba rekordów wybranych, różnica czasu `dt` względem momentu żądania i wariant 15-minutowy. Osobno zapisujemy **ostatnie 6 zakończonych prób** i moment ostatniego uruchomienia zadania w tle. Dane są małe i limitowane. Zapis diagnostyczny jest **best effort**: jego niepowodzenie nie może zatrzymać pobierania pogody.

**Nigdy nie zapisujemy w diagnostyce:** klucza API, pełnego URL z kluczem, odpowiedzi JSON, opisu lokalizacji ani współrzędnych. Wszystkie ścieżki API i istniejące ustawienia są bez zmian; dodatkowe ekrany diagnostyczne nie wysyłają zapytań.

## Ekrany dostępne w Connect IQ → Solar Rings → Ustawienia → „Podgląd ikon / legenda (TEST)”

- **TEST 15:** wcześniejszy podgląd szczegółów godzinowych.
- **TEST 16 — STATUS:** widoczność klucza (tylko TAK/NIE), zapisanej lokalizacji, połączenia z telefonem, zarejestrowanego zadania w tle, wieku ostatniego uruchomienia oraz **ostatni wynik każdego endpointu**. `K100` = wysłano zapytanie, `K200` = pobrano i zapisano dane; inne liczby to kody błędów. `ET` to etap przetwarzania. `0m` = wynik zapisany mniej niż minutę temu.
- **TEST 17 — FORMAT:** techniczna kontrola JSON. `M` = maska pól, `N` = liczba otrzymanych rekordów, `U` = liczba wybranych rekordów, `W` = różnica wieku najstarszego/bieżącego rekordu w sekundach. W `PROG15` liczby dotyczą prognozy 15-minutowej; w `PROG` bez „15” — godzinowej. Maska jest sumą: **1** JSON-słownik, **2** tablica danych, **4** niepusta, **8** pierwszy rekord jako obiekt, **16** numeryczny `dt`, **32** temperatura, **64** kod pogody, **128** strefa czasowa, **256** sekcja AQI.
- **TEST 18 — HISTORIA:** ostatnie zakończone próby. `P0` = etap systemowy, `P1` = teraz, `P2` = prognoza, `P3` = dane dzienne, `P4` = jakość powietrza. `K` = wynik, `ET` = etap. Pokazuje także czas pozostający do przywrócenia 15-minutowej prognozy po fallbacku.
- **TEST 19 — CACHE:** informacja, które dane zostały zapisane (`TERAZ`, `15 MIN`, `1 H`, `DZIEN`, `AQI`), ich wiek i to, czy potrafimy z nich stworzyć model pogody `SNAP/MODEL`. Pozwala rozróżnić problem z pobraniem, przechowywaniem i wyświetleniem.

## Kody błędów

| Kod | Interpretacja |
|---|---|
| 100 | Zapytanie przygotowane i przekazane Connect IQ do wysłania |
| 200 | Poprawna odpowiedź, dane zapisane |
| 401 / 403 | Serwer odmówił dostępu; ważny jest **kod bez minusa** |
| 429 | Limit zapytań OpenWeather |
| -402 / -403 | Błędy komunikacji Garmin, m.in. wielkość odpowiedzi/pamięć (inne niż HTTP 403) |
| -10 / -11 / -12 | Brak lokalizacji / klucza / połączenia z telefonem |
| -17 / -18 / -19 | Timeout / błąd harmonogramu / utrata kontekstu żądania |
| -151 | HTTP 200, ale odpowiedź nie jest słownikiem JSON |
| -152 | Nieznany, nieobsłużony układ odpowiedzi |
| -153 | Dane bieżące poza dopuszczalnym przedziałem czasu |
| -154 | Nie udało się zapisać wynikowych danych pogodowych |
| -155 / -216 | Wyjątek parsera / wyjątek przy inspekcji struktury |
| -202 | Brak tablicy `data` lub `list` |
| -203 | Tablica istnieje, ale jest pusta |
| -204 | Pierwszy rekord nie jest obiektem |
| -205 / -206 | Brak numerycznego `dt` / `temp` (bieżąca pogoda) |
| -208 | Nie znaleziono żadnego rekordu prognozy w horyzoncie |
| -209 | Prognoza 15-minutowa zawiera rekordy, ale brak rozpoznanego kodu zjawiska |
| -210 / -211 | Brak pasującego dnia / nieprawidłowa strefa czasowa |
| -212 | Niepoprawna struktura AQI |
| -213 | Zmiana lokalizacji między wysłaniem i odebraniem żądania |
| -220 / -221 / -222 | Wyjątek uruchamiania zapytania / watchdog / ponowne zaplanowanie pracy |

Etapy `ET`: **10** zadanie w tle wystartowało; **20** żądanie przygotowane; **25** wywołano callback; **30** odebrano HTTP 200 i rozpoczęto kontrolę struktury; **60** próba zapisu danych; **70** sukces; **90** watchdog/harmonogram. Nie wszystkie kroki wymagają zapisu do pamięci: rejestrujemy ostatni stan i zakończone próby.

## Jak testować

1. W GitHub Actions zbuduj nowy ZIP; nie instaluj źródłowego `.zip` bez kompilacji.
2. Po instalacji wybierz **OpenWeatherMap** i pozostaw dotychczasowy klucz API. Nie uruchamiaj nowego spaceru GPS.
3. Po uruchomieniu/odświeżeniu zadania (zwykle co najmniej 5 min) sfotografuj **TEST 16, 17, 18 i 19**. Najważniejsze są **16 i 17**; zdjęcia nie zawierają klucza.
4. Po testach wyłącz podgląd (`0`), aby przywrócić normalną tarczę.

Nie przesyłaj klucza API ani pełnego zapytania z `appid`. Jeżeli TEST 16 pokaże `K200` dla `TERAZ`, a TEST 19 pokaże `SNAP TAK / MODEL NIE`, problem jest już wewnątrz tworzenia obiektu pogody, nie w komunikacji z API.

## Ograniczenia

Wersja 3.26.8 to **instrumentowana wersja diagnostyczna**, a nie gwarantowane rozwiązanie problemu. Nie wykonano kompilacji Monkey C ani wywołania API z kluczem użytkownika. W razie awarii procesu Connect IQ jeszcze przed wywołaniem callbacku szczegółów odpowiedzi nie da się odczytać — zostają timestamp uruchomienia, kod `100` i watchdog. Wtedy należy sprawdzić pamięć lub logi Garmin SDK. Prognoza 15-minutowa może zawierać do 50 rekordów już na poziomie odpowiedzi; ich przycinanie po odebraniu nie eliminuje ryzyka zajęcia pamięci podczas dekodowania.

Źródła: oficjalna dokumentacja OpenWeather One Call 4.0 (https://openweathermap.org/api/one-call-4), Garmin Connect IQ Communications (https://developer.garmin.com/connect-iq/api-docs/Toybox/Communications.html).
