# Solar Rings v3.26.15 — pełny przegląd i zakres testowy

**Stan:** gotowy kod źródłowy i workflow do kompilacji. Nie jest to gwarancja poprawności SDK, braku błędów na sprzęcie ani 10 dni baterii.

## 1. Harmonogram przy ustawieniu „Maksymalna aktualność”

- Garmin uruchamia pojedyncze zadanie w tle nie częściej niż co pięć minut.
- **Bieżące dane (`P1/current`)** mają najwyższy priorytet, termin **co 10 minut**.
- **Prognoza 15-minutowa (`P2/timeline/15min`)** jest dodatkowa, planowo **co 20 minut**; odpowiedź `cnt=4` ogranicza rozmiar danych. Startuje dopiero po poprawnym pierwszym pobraniu prognozy godzinowej.
- **Prognoza godzinowa (`P2/timeline/1h`)** pozostaje niezależna: **co 60 minut**, `cnt=3`, a w razie `K-403` jednorazowa próba `cnt=2`.
- **AQI** jest pobierane co 60 minut (jeżeli włączone), **prognoza dzienna** co 12 godzin (`cnt=1`).
- Żaden widok tarczy ani obliczenie ikony ostrzeżenia nie uruchamia dodatkowego zapytania HTTP.
- Jeden request na jeden cykl BG: maksymalnie **288 cykli** przy dokładnych pięciominutowych wybudzeniach, typowo mniej (plan: **266** przy całodobowej łączności, włączonym AQI i poprawnym API). Jest lokalny limit **700 prób/dzień**, pozostający margines poniżej darmowej puli 1000 One Call/dzień. Zewnętrzne aplikacje korzystające z tego samego klucza nie są objęte licznikiem.
- Wybudzenia Garmina mogą się opóźniać; plan jest celem, a nie gwarancją odczytu w konkretnej sekundzie.

## 2. Co poprawiono względem v3.26.14

1. Krótka prognoza 15-minutowa **nie wypiera** prognozy godzinowej — obie mają niezależne terminy pobrania i wspólnie są analizowane pod kątem najbliższych trzech godzin.
2. W danych każda prognoza zachowuje własną długość okresu (`900` lub `3600` sekund), a ostrzeżenia interpretują ją według właściwego czasu, nie wspólnego kroku dla wszystkich rekordów.
3. Bieżąca pogoda ma priorytet nad mniej pilnymi danymi. Założenie: jak najszybsze rozpoznawanie zmiany aktualnych warunków.
4. W profilu szybkim obserwacje starsze niż **20 minut** tracą status świeżego czerwonego ostrzeżenia; do 60 minut mogą być oznaczone jako nieaktualne, a potem nie tworzą ostrzeżenia „teraz”.
5. `TEST 20` uwzględnia także następny termin 15-minutowej prognozy. `TEST 16` wskazuje v32615.
6. Po pierwszym uruchomieniu v3.26.15 następuje jednorazowa migracja małych rekordów prognozy (nowy format z krokiem czasowym), reset terminów i błędów historycznych — bez naruszania klucza API ani wybranego dostawcy.
7. Zachowane mechanizmy: ograniczenie wielkości odpowiedzi przez `cnt`, wykrywanie braku pamięci `K-403`, 24-godzinne wstrzymanie 15-min po błędzie, mały fallback godzinowy, 5-minutowe ponowienie przy braku telefonu, nieprzeprowadzanie żądań bez aktualnej lokalizacji, kontrola starego czasu obserwacji, pojedyncza operacja sieciowa na usługę BG.

## 3. Kategorie i znaczenie ikon

| Zjawisko | Dane i decyzja | Zastrzeżenie |
|---|---|---|
| Deszcz, mżawka | Bieżący kod OWM lub prognozowany kod/ilość opadów przy progu POP | `rain.1h` bez kodu to **miniona godzina**: szary sygnał, nie czerwony „teraz” |
| Śnieg, opady mieszane | Kody OWM; oddzielny próg 40%; opady mieszane jedną ikoną | `snow.1h` nie potwierdza, że śnieży teraz |
| Burze | Kod burzy; nie utożsamiać ogólnego POP z prawdopodobieństwem piorunów | Bez kodu burzy nie zgadywać |
| Marznący deszcz | Kod `511` | Osobny od zwykłego deszczu i oblodzenia |
| Silny wiatr | Prędkość ≥10 m/s, poryw ≥15 m/s | Poryw i średni wiatr to dwie różne wielkości |
| Skrajny wiatr | Jawny kod szkwału lub tornada | Bez sugerowania konkretnej prędkości |
| Mgła/ograniczona widzialność | Kod `741` albo widzialność ≤500 m | Inne przyczyny słabej widzialności są możliwe |
| Szacowane oblodzenie | Temperatura ≤1°C i opad spełniający warunki | Nie jest to pomiar oblodzenia jezdni |
| Pył, dym, popiół | Rozpoznany kod aerozoli | Nie mylić z mgłą |
| UV | Wartość ≥7 | Liczba UV jest prognozą/estymacją dostawcy |
| AQI | OpenWeather AQI ≥4 | AQI 1–5, odświeżanie co godzinę, niezależne od mgły |
| Grad | Obsługiwany dla jawnego kodu Garmin | Standardowe OWM weather IDs nie dają odrębnego potwierdzonego kodu gradu |

Bieżące zjawisko z aktualnym kodem może mieć kolor czerwony; informacja o **poprzednim** jednogodzinnym opadzie jest szara; prognoza jest turkusowa. Brak danych nie jest automatycznie dowodem braku zagrożenia.

## 4. Ustawienia Connect IQ po nowej instalacji

Ustawienia inicjalizowane jednorazowo przy pierwszym wejściu na tarczę v3.26.15: alarmy ON, ocena co 5 minut na zapisanych danych, prognozy ON, horyzont 3 h, tryb niestandardowy opadów, deszcz 30%, śnieg 40%, bez filtra „tylko intensywne”, wiatr 10 m/s, porywy 15 m/s, widzialność ≤500 m, oblodzenie ≤1°C, próg szansy na lód 50%, UV od 7, AQI od 4, OpenWeather „Maksymalna aktualność” (5-minutowy cykl BG), prognoza 15-min ON i AQI ON.

**Niezmieniane:** klucz API, wybrany dostawca pogody, tarcza z danymi zdrowia i layout. Uwaga: ustawienia ostrzeżeń zostają automatycznie przypisane jeden raz na upgrade, również jeśli były przedtem ręcznie zmienione. Dalsze zmiany użytkownika nie są automatycznie nadpisywane.

## 5. Co świadomie nie jest „gotowe 100%”

- **One Call 4.0 `timeline/1min`**: daje prognozę *ilości* opadów co minutę, ale bez wystarczającej informacji, czy jest to deszcz czy śnieg, i nie potwierdza obserwacji „teraz”. Może zwracać 60 rekordów; nie został włączony automatycznie, ponieważ wcześniejszy Fenix już zgłaszał `NETWORK_RESPONSE_OUT_OF_MEMORY (-403)` dla większej odpowiedzi. Błędna czerwona ikona byłaby gorsza niż brak takiego źródła.
- **Oficjalne komunikaty ostrzegawcze One Call 4.0**: odpowiedzi zawierają identyfikatory `alerts`, ale nazwy zdarzeń, czas obowiązywania i typ trzeba pobierać dodatkowym endpointem `alert/{alert_id}`. Sama obecność identyfikatora nie pozwala poprawnie określić rodzaju zagrożenia; nie wyświetlamy zmyślonego gradu czy burzy. To odrębna niezaimplementowana funkcja.
- **Niedostępna kompilacja SDK i emulator**: 146 testów źródłowych (145 zaliczonych, jeden pominięty) nie są wykonaniem Monkey C na urządzeniu. Prawdziwe potwierdzenie wymaga zielonego GitHub Actions oraz testów zegarka.
- **Bateria 10 dni**: przy większej aktywności sieciowej nie ma na razie pomiaru; test 24–72 godzin po instalacji.

## 6. Test wieczorny

1. Po zielonej kompilacji i instalacji poczekaj 15–20 minut z połączonym telefonem i aktywnym OpenWeather; `TEST 16`: `TERAZ K200` i potem `PROG K200`.
2. Po 60–90 minutach ponów `TEST 16`, `TEST 17` i `TEST 20`; `TEST 17` rozróżnia prognozę 15-min (`PROG15`) od godzinowej (`PROG`).
3. W `TEST 15` sprawdzaj kod zjawiska, wiek obserwacji oraz `R/S` (opad za ostatnią godzinę). Porównaj ikonę tylko przy rzeczywistym zjawisku.
4. Po teście przywróć podgląd TEST=wyłączony. Zapisz poziom baterii po instalacji i po 24 h, a następnie po 48–72 h.
5. Przy `K-403` wykonaj zdjęcie TEST 16+17+20. Nie przeinstalowuj co kilka minut: zapisane dane i terminy mają znaczenie diagnostyczne.

## Źródła dokumentacji

- OpenWeather One Call 4.0: https://openweathermap.org/api/one-call-4
- Garmin Background Services: https://developer.garmin.com/connect-iq/articles/core-topics/Backgrounding.html
- Garmin tworzenie usługi w tle: https://developer.garmin.com/connect-iq/connect-iq-faq/how-do-i-create-a-connect-iq-background-service/
