"""Static geometry tests for dual icons plus negative two-digit temperatures."""
from pathlib import Path
import re, unittest, math
SRC=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
class WideTemperature3249(unittest.TestCase):
    def test_measured_width_and_stable_position(self):
        m=re.search(r'var tempX = hasMarkers \? (\d+) : (\d+);\s*var tempWidth = hasMarkers \? (\d+) : (\d+);',SRC)
        self.assertIsNotNone(m)
        center,no_markers,width,no_markers_width=map(int,m.groups())
        self.assertEqual((center,width),(187,80))
        self.assertEqual((no_markers,no_markers_width),(174,105))
        self.assertIn('var hasMarkers = hasThermometer || warning != 0;',SRC)
        self.assertGreaterEqual(center-width/2,147)
        self.assertGreaterEqual((center-width/2)-(140+4),3)
        self.assertLessEqual(center+width/2,227)
        self.assertIn('if (dim[0] <= width && dim[1] <= height)',SRC)
    def test_separate_icons_and_separator(self):
        self.assertIn('dc.drawLine(109, 220, 109, 245);',SRC)
        self.assertIn('drawGarminWarningIcon(dc, 120, 227, warning)',SRC)
        self.assertIn('temperatureMarker(dc, weather, warning != 0 ? 140 : 136, 227)',SRC)
        self.assertIn('dc.setClip(110, 216, 20, 22)',SRC)
        self.assertIn('drawGarminWarningIcon(dc, 120, 227, nextKind)',SRC)
        # Warning geometry occupies x111..129, leaving 2 px to x109 separator.
        self.assertGreaterEqual((120-9)-109,2)
    def test_right_edge_inside_circular_display_at_baseline(self):
        # conservative radius 131 centered on the 280px screen
        r=131; cy=140
        # temperature's top/height are 215/22; bottom-right usable edge at y237
        edge=140+math.sqrt(r*r-(237-cy)**2)
        self.assertGreaterEqual(edge,227)
if __name__=='__main__': unittest.main()
