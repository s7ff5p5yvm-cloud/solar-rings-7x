"""Watch-face layout regression checks for the weather lower panel.
These are static/layout checks, not Garmin emulator pixel snapshots.
"""
import re
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
PROPS=ET.parse(ROOT/'resources/settings/properties.xml').getroot()

class TemperatureLayout3249(unittest.TestCase):
    def test_badge_geometry_allows_the_temperature_to_fit(self):
        m=re.search(r'var tempX = hasMarkers \? (\d+) : (\d+);\s*var tempWidth = hasMarkers \? (\d+) : (\d+);', FACE)
        self.assertIsNotNone(m)
        center,old_center,width,old_width=map(int,m.groups())
        self.assertEqual((old_center,old_width),(174,105))
        self.assertEqual((center,width),(187,80))
        self.assertGreaterEqual(center-width/2,147)
        self.assertLessEqual(center+width/2,227)
        self.assertLessEqual(center,187)
        self.assertGreaterEqual(width,64)
    def test_icons_shifted_left_as_requested(self):
        self.assertIn('temperatureMarker(dc, weather, warning != 0 ? 140 : 136, 227)',FACE)
        self.assertIn('drawGarminWarningIcon(dc, 120, 227, warning)',FACE)
        self.assertIn('drawGarminWarningIcon(dc, 120, 227, nextKind)',FACE)
        self.assertIn('dc.setClip(110, 216, 20, 22)',FACE)
        self.assertIn('dc.fillRectangle(110, 216, 20, 22)',FACE)
    def test_lower_label_also_shifted_slightly_left(self):
        self.assertIn('drawSized(dc, lowerLabel, 166, 234, 105, 16, lowerColor, false,', FACE)
    def test_temperature_alerts_and_settings_are_preserved(self):
        self.assertIn('var hot = srSetting("tempHotV312", 30);',FACE)
        self.assertIn('var cold = srSetting("tempColdV312", 0);',FACE)
        self.assertIn('temp > hot',FACE)
        self.assertIn('temp < cold',FACE)
        defaults={p.attrib['id']:p.text for p in PROPS}
        self.assertEqual(defaults['tempHotV312'],'30')
        self.assertEqual(defaults['tempColdV312'],'0')
    def test_warning_controls_are_preserved(self):
        for setting in ['gwPreviewV324','gwOnV324','gwIntervalV324','gwHorizonV324','showFeelsLikeV319']:
            self.assertIsNotNone(PROPS.find(".//property[@id='%s']" % setting))

if __name__ == '__main__': unittest.main()
