"""Static geometry tests for dual icons plus negative two-digit temperatures."""
from pathlib import Path
import re, unittest, math
SRC=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
class WideTemperature3249(unittest.TestCase):
    def test_left_anchored_measured_temperature(self):
        self.assertIn('drawWeatherTemperature(dc, shownTemp, 148, 227)', SRC)
        self.assertIn('drawAlertCenter(dc, w)', SRC)
        self.assertIn('var actualTempCenter = drawWeatherTemperature(dc, shownTemp, 148, 227);', SRC)
        self.assertIn('dc.getTextDimensions(str, font)', SRC)
        self.assertIn('var center = left + (chosenDim[0] / 2).toNumber();', SRC)
        self.assertGreaterEqual(148-(140+4), 3)
        self.assertEqual(227-148, 79)
        self.assertIn('var lowerCenter = actualTempCenter;', SRC)
        self.assertIn('srSetting("tempLayoutTestV32412", 0)', SRC)
        self.assertIn('shownTemp = "-35°C"', SRC)
        self.assertIn('shownTemp = "-99°C"', SRC)
        self.assertIn('lowerLabel = "ODCZ. -45°C"', SRC)
        self.assertIn('lowerLabel = "ODCZ. -99°C"', SRC)
    def test_separate_icons_and_separator(self):
        self.assertIn('dc.drawLine(133, 219, 133, 245);',SRC)
        self.assertIn('drawGarminWarningIcon(dc, x, 228, tag)',SRC)
        self.assertIn('temperatureMarker(dc, weather, 142, 224)',SRC)
        self.assertIn('dc.setClip(103, 217, 22, 26)',SRC)
        self.assertIn('drawAlertGlyph(dc, 114, kind)',SRC)
        # Last 20px warning cell ends x=123, leaving 10px to divider x=133.
        self.assertGreaterEqual(133-(114+9),10)
    def test_right_edge_inside_circular_display_at_baseline(self):
        # conservative radius 131 centered on the 280px screen
        r=131; cy=140
        # temperature's top/height are 215/22; bottom-right usable edge at y237
        edge=140+math.sqrt(r*r-(237-cy)**2)
        self.assertGreaterEqual(edge,227)
if __name__=='__main__': unittest.main()
