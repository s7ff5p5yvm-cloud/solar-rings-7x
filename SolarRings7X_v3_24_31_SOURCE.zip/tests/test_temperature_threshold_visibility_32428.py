"""v3.24.29: threshold-only thermometer, no gray icon in normal range."""
import unittest
from pathlib import Path

FACE=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
PART=FACE.split('function temperatureMarker(dc, w, x, y) {',1)[1].split('function warningCloud(',1)[0]

class ThermometerThresholds32428(unittest.TestCase):
    def test_no_default_gray_icon_and_no_unconditional_draw(self):
        self.assertNotIn('Gfx.COLOR_LT_GRAY',PART)
        self.assertIn('else { return; }',PART)
        self.assertLess(PART.index('else { return; }'),PART.index('warningThermometer(dc, x, y, color);'))
        self.assertEqual(PART.count('warningThermometer(dc, x, y, color);'),1)
    def test_blue_only_below_and_red_only_above(self):
        self.assertIn('if (temp > hot) { color = Gfx.COLOR_RED; }',PART)
        self.assertIn('else if (temp < cold) { color = 0x00CCFF; }',PART)
        self.assertNotIn('temp >= hot',PART)
        self.assertNotIn('temp <= cold',PART)
    def test_disabled_and_missing_temperature_are_noops(self):
        self.assertIn('!srSetting("tempAlertsV312", true)', PART)
        self.assertIn('w == null', PART)
        self.assertIn('w.temperature == null) { return; }', PART)
    def test_layout_unchanged(self):
        self.assertIn('if (isTemp) { temperatureMarker(dc, weather, 142, 224); }',FACE)
        center=FACE.split('function drawAlertCenter(')[1].split('// Battery footer')[0]
        self.assertNotIn('temperatureMarker(',center)
    def test_boundary_contract(self):
        def simulated(temp,cold,hot,enabled=True):
            if not enabled or temp is None:return None
            if temp>hot:return 'red'
            if temp<cold:return 'blue'
            return None
        for temp,expected in ((-20,'blue'),(-1,'blue'),(0,None),(1,None),(30,None),(31,'red'),(40,'red')):
            self.assertEqual(simulated(temp,0,30),expected)
        self.assertEqual(simulated(1,2,25),'blue')
        self.assertEqual(simulated(26,2,25),'red')
        self.assertIsNone(simulated(-10,0,30,False))

if __name__=='__main__':unittest.main()
