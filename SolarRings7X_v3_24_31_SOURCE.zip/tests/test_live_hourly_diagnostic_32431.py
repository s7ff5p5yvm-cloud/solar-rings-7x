"""Source-level checks for temporary live hourly-diagnostics mode."""
from pathlib import Path
import xml.etree.ElementTree as ET
import unittest
R = Path(__file__).resolve().parents[1]
FACE = (R/'source/SolarRings7X.mc').read_text()
WARN = (R/'source/GarminWeatherWarnings.mc').read_text()
class Diagnostics(unittest.TestCase):
    def test_setting_15_and_no_override_of_normal_alerts(self):
        settings=(R/'resources/settings/settings.xml').read_text()
        self.assertIn('value="15">@Strings.gw_gwPreviewV324_15', settings)
        self.assertIn('if (srSetting("gwPreviewV324", 0) == 15)',FACE)
        self.assertIn('if (preview == 14)',WARN)
        self.assertIn('if (preview > 0 && preview <= 9)',WARN)
    def test_live_fields_and_classification(self):
        self.assertIn('Weather.getHourlyForecast()',FACE)
        self.assertIn('h.precipitationChance',FACE)
        self.assertIn('h.condition',FACE)
        self.assertIn('h.forecastTime.value() - now',FACE)
        self.assertIn('_weatherWarnings.classify(h.condition,',FACE)
        self.assertIn('reason = "TAK";',FACE)
        self.assertIn('reason = "POZA";',FACE)
        self.assertIn('if (alertEnabled && forecastEnabled)',FACE)
    def test_isolation_and_low_power(self):
        diag=FACE.split('function drawHourlyDiagnostics(dc, current) {',1)[1].split('function onUpdate(dc)',1)[0]
        self.assertIn('now - _debugHourlyAt >= 60',diag)
        self.assertIn('if (count > 8) { count = 8; }',diag)
        self.assertNotIn('makeWebRequest',diag)
        self.assertNotIn('Position.getInfo',diag)
        self.assertIn('return;',FACE.split('if (srSetting("gwPreviewV324", 0) == 15)',1)[1].split('var clock =',1)[0])
    def test_manifest_and_labels(self):
        ET.parse(R/'resources/settings/settings.xml')
        ET.parse(R/'resources/strings.xml')
        app=ET.parse(R/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.24.31')
