"""v3.24.31 audit: reference policy and source invariants.

These Python tests inspect Monkey C and independently check intended branch logic.
They do not execute Garmin SDK or prove Garmin Weather returns any specific data.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ENGINE = (ROOT/'source/GarminWeatherWarnings.mc').read_text()
FACE = (ROOT/'source/SolarRings7X.mc').read_text()


def accept_forecast(chance, minimum, explicit):
    return chance >= minimum if chance is not None else explicit


class WeatherStripAndReservedSlot32430(unittest.TestCase):
    def test_numeric_forecast_probability_still_respects_user_threshold(self):
        self.assertFalse(accept_forecast(59,60,True))
        self.assertTrue(accept_forecast(60,60,True))
        self.assertFalse(accept_forecast(20,60,True))
        self.assertTrue(accept_forecast(80,60,False))
        self.assertIn('if (chance != null) { return chance >= minimum; }',ENGINE)

    def test_no_numeric_probability_explicit_categories_allowed(self):
        self.assertTrue(accept_forecast(None,60,True))
        self.assertTrue(accept_forecast(None,50,True))
        self.assertFalse(accept_forecast(None,60,False))
        self.assertIn('srSetting("gwRainChanceV324", 60), !chanceOnlyRain',ENGINE)
        self.assertIn('srSetting("gwSnowChanceV324", 60), !chanceOnlySnow',ENGINE)
        self.assertIn('srSetting("gwStormChanceV324", 50), !stormOnlyChance',ENGINE)

    def test_source_uses_forecast_fallback_for_explicit_hazards(self):
        for key in ('gwRainChanceV324','gwSnowChanceV324','gwStormChanceV324',
                    'gwFreezeChanceV324','gwHailChanceV324'):
            self.assertIn('srSetting("'+key+'",',ENGINE)
        self.assertIn('function forecastChanceMatches(chance, minimum, explicitCategory)',ENGINE)
        # No fallback to chance-freezing rain/ice heuristics when only a
        # synthetic wet/low-temperature risk is inferred.
        self.assertIn('chance != null && p >= srSetting("gwIceChanceV324", 50)',ENGINE)

    def test_only_pressure_uses_first_slot_even_when_pressure_inactive(self):
        center=FACE.split('function drawAlertCenter(dc, weather) {',1)[1].split('// Battery footer',1)[0]
        self.assertIn('if (pressureActive)',center)
        self.assertIn('pressureActive = true;',center)
        self.assertNotIn('active[0]',center)
        self.assertIn('drawAlertGlyph(dc, 45, -1);',center)
        self.assertIn('var centers = [68, 91, 114];',center)
        self.assertNotIn('var centers = [45, 68, 91, 114];',center)
        self.assertIn('drawAlertGlyph(dc, centers[j], active[weatherStart + j]);',center)
        self.assertIn('var weatherCount = active.size() - weatherStart;',center)

    def test_three_weather_icons_visible_without_stormguard(self):
        face=FACE.split('function drawAlertCenter(dc, weather) {',1)[1].split('// Battery footer',1)[0]
        self.assertIn('if (staticCount > 3) { staticCount = 2; }',face)
        self.assertIn('if (weatherCount > 3)',face)
        self.assertIn('for (var k = 2; k < weatherCount; k++)',face)
        self.assertIn('drawAlertGlyph(dc, 114, _alertLastDrawn);',face)
        self.assertIn('dc.setClip(103, 217, 22, 26)',FACE)

    def test_no_extra_weather_reads_or_gps_requests(self):
        self.assertEqual(FACE.count('Weather.getCurrentConditions()'),1)
        self.assertEqual(ENGINE.count('Weather.getHourlyForecast()'),1)
        self.assertNotIn('makeWebRequest(',ENGINE)
        self.assertNotIn('Position.getInfo(',ENGINE)
        self.assertIn('now - _lastCheck >= interval * 60',ENGINE)

    def test_bar_test_mode_14_kept_and_cyan_underlines_in_bounds(self):
        self.assertIn('_lastKinds = [36, 34, 33];',ENGINE)
        self.assertIn('dc.fillRectangle(x - 8, y + 11, 16, 2);',FACE)
        for x in (68,91,114):
            self.assertGreater(x-8,45)
            self.assertLess(x+8,133)
        self.assertLessEqual(228+12,217+26-1)

if __name__ == '__main__': unittest.main()
