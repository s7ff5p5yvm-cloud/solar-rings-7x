"""Source contract for the HTTP callback type as reported by Garmin SDK 9.3.
These are source assertions; a complete Monkey C build is still required.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
GEO = (ROOT / 'source/WeatherGeocode.mc').read_text(encoding='utf-8')
JUNGLE = (ROOT / 'monkey.jungle').read_text(encoding='utf-8')

class WebCallbackRegression(unittest.TestCase):
    def test_callback_is_explicitly_typed_and_returns_void(self):
        self.assertIn('function onReceive(code as Lang.Number,', GEO)
        self.assertIn('data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {', GEO)
        self.assertNotIn('function onReceive(code, data)', GEO)

    def test_validates_json_dictionary_before_indexing(self):
        self.assertIn('!(data instanceof Lang.Dictionary)', GEO)
        self.assertIn('Comm.makeWebRequest(', GEO)
        self.assertIn('method(:onReceive)', GEO)

    def test_typechecking_remains_enabled(self):
        self.assertNotIn('project.typecheck=0', JUNGLE)

if __name__ == '__main__':
    unittest.main()
