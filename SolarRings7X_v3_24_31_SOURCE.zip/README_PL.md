# Solar Rings 7X v3.24.31 — TEST 15 (diagnoza rzeczywistych danych Garmin Weather)

## Dlaczego?
TEST 14 potwierdza wygląd ikon, nie to, czy godzinowa prognoza z Garmin Weather
rzeczywiście kwalifikuje się do turkusowego paska. Ten wariant dodaje
**TEST 15**, który pokazuje na ekranie surowe dane z Connect IQ.

W aplikacji Garmin Connect IQ wybierz: **Tryb testowy ostrzeżeń → TEST 15**.
Wyświetlony będzie ekran diagnostyczny, a nie zwykła tarcza:
- **TERAZ C... P...**: kod aktualnej pogody i procent opadów (`--` = brak).
- Wiersz np. **17:00 C3 P45 TAK**: czas, kod pogody (C3 = deszcz),
  procent opadów (P45 = 45%), kwalifikacja do ostrzeżenia deszczowego.
- **TAK** = dana godzina kwalifikuje się do deszczu; **NIE** = odrzucona
  przez logikę ostrzeżeń; **POZA** = poza ustawionym horyzontem.
- **OFF** = wyłączone ostrzeżenia lub prognozy. Linia `ALERT / PROG / MOC`
  pokazuje, czy włączone są alerty, prognoza i tryb tylko intensywnego deszczu.
- **BRAK DANYCH GODZINOWYCH** = API zwróciło null.
- **C--**, **P--** = Garmin Connect IQ nie udostępnia tego pola.
- Procent w wierszu jest wprost z API zegarka, a nie z internetu.

Zrób zdjęcie ekranu TEST 15 i przyślij do rozmowy, a przeanalizujemy dokładne
numery kodów `C`, prawdopodobieństwa `P` i kwalifikację `TAK/NIE/POZA`.

Po teście **WYŁĄCZ TRYB TESTOWY** — zwykłe wyświetlanie,
StormGuard i centrum ikon wrócą bez zmian.

## Bateria i kompatybilność
- TEST 15 odczytuje prognozę tylko włączony, maksymalnie raz na minutę.
- W normalnym trybie nie wykonuje żadnych dodatkowych zapytań i nie tworzy
  nowych timerów ani operacji GPS.
- Algorytm ostrzeżeń, StormGuard i lokalizacja pozostały bez zmian.
- Zmieniona tylko wersja 3.24.31 i dodatkowy ekran testowy.
- Kod wymaga kompilacji Garmin SDK w GitHub Actions i przetestowania na zegarku.

## Instalacja
Podmień w repozytorium plik `SolarRings7X_v3_24_31_SOURCE.zip` i aktywny
workflow plikiem `SolarRings7X_v3_24_31_BUILD.yml`.
Uruchom GitHub Actions; wynik będzie się nazywał `SolarRings7X_v32431.prg`.
