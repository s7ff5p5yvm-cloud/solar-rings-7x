using Toybox.SensorHistory as History;
using Toybox.Time as Time;

// Pressure-trend warning, NOT a certified meteorological alert.
// 5-minute evaluation interval and all user thresholds preserved.
// v3.24.24: one 3-hour pressure iterator supplies BOTH windows (1h, 3h).
// Valid-sample limits, age checks and height filtering remain unchanged.
class StormGuard {
    var _lastCheck;
    var _lastResult;

    function initialize() {
        _lastCheck = 0;
        _lastResult = false;
    }

    function warning() {
        if (!srSetting("stormOnV3", false)) { return false; }
        var now = Time.now().value();
        if (_lastCheck != 0 && now - _lastCheck < 300) { return _lastResult; }
        _lastCheck = now;
        _lastResult = evaluate();
        return _lastResult;
    }

    function evaluate() {
        try {
            var now = Time.now().value();
            var fastEnabled = srSetting("stormFastV310", true);
            var iter = History.getPressureHistory({
                :period => new Time.Duration(10800),
                :order => History.ORDER_NEWEST_FIRST
            });
            if (iter == null) { return false; }
            var newestPa = null;
            var newestAt = null;
            var oldestPa1 = null;
            var oldestAt1 = null;
            var oldestPa3 = null;
            var oldestAt3 = null;
            var n1 = 0;
            var n3 = 0;
            var sample = iter.next();
            // Both old independent iterators stopped after 400 VALID samples.
            while (sample != null && n3 < 400) {
                if (sample.data != null && sample.when != null) {
                    var at = sample.when.value();
                    var pa = sample.data.toFloat();
                    if (newestPa == null) {
                        newestPa = pa;
                        newestAt = at;
                    }
                    oldestPa3 = pa;
                    oldestAt3 = at;
                    n3++;
                    if (fastEnabled && at >= now - 3600 && n1 < 400) {
                        oldestPa1 = pa;
                        oldestAt1 = at;
                        n1++;
                    }
                }
                sample = iter.next();
            }
            if (newestAt == null || now - newestAt > 900) { return false; }
            // Preserve evaluation order: try optional 1h first; a rejected
            // altitude window can still allow an independent 3h alert.
            if (fastEnabled && n1 >= 5 && newestAt - oldestAt1 >= 3000 &&
                (oldestPa1 - newestPa) / 100.0 >= srSetting("stormFastDropV310", 2)) {
                if (stableElevation(3600, 3000, now)) { return true; }
            }
            if (n3 >= 5 && newestAt - oldestAt3 >= 9000 &&
                (oldestPa3 - newestPa) / 100.0 >= srSetting("stormDropV3", 4)) {
                return stableElevation(10800, 9000, now);
            }
            return false;
        } catch (e) { return false; }
    }

    function stableElevation(windowSeconds, minimumSeconds, now) {
        try {
            var iter = History.getElevationHistory({
                :period => new Time.Duration(windowSeconds),
                :order => History.ORDER_NEWEST_FIRST
            });
            if (iter == null) { return false; }
            var item = iter.next();
            var minAlt = 100000.0;
            var maxAlt = -100000.0;
            var newestAt = null;
            var oldestAt = null;
            var n = 0;
            // Do not sample only endpoints: a real elevation excursion in
            // between must still reject a false pressure-drop warning.
            while (item != null && n < 400) {
                if (item.data != null && item.when != null) {
                    var altitude = item.data.toFloat();
                    if (altitude < minAlt) { minAlt = altitude; }
                    if (altitude > maxAlt) { maxAlt = altitude; }
                    if (newestAt == null) { newestAt = item.when.value(); }
                    oldestAt = item.when.value();
                    n++;
                }
                item = iter.next();
            }
            if (n < 5 || newestAt == null || oldestAt == null) { return false; }
            if (now - newestAt > 900 || newestAt - oldestAt < minimumSeconds) { return false; }
            return maxAlt - minAlt < srSetting("stormAltitudeV3", 20);
        } catch (e) { return false; }
    }
}
