# Compass Pro 7X v1.3.2 SDK FIX

Samodzielna aplikacja Garmin Connect IQ (`watch-app`) dla Fenix 7X Pro / 7X Pro bez Wi-Fi. 
Pełnoekranowa róża kompasu, azymut, prowadzenie do kierunku, pięć miejsc zapisu, TRUE/MAG, deklinacja WMM2025 z ostatniej dostępnej pozycji, ustawienie ręczne, jednostki °/mil i profile ECO 700 ms / SMOOTH 100 ms / TURBO 80 ms. 

**Wersja 1.3.2 jest poprawką błędów kompilatora, nie nowym zestawem funkcji.** Szczegóły: `SDK_FIX_1_3_2_PL.md`.

Kompilacja i testy pamięci na rzeczywistym zegarku wymagają potwierdzenia po wgraniu na GitHub. WMM2025 działa dla lat 2025–2029; program informuje, kiedy nie ma wiarygodnej lokalizacji.

## Obsługa

- START/SELECT: zatwierdzenie lub zapis aktualnego azymutu zależnie od strony.
- DOWN: menu i poruszanie się po opcjach.
- UP: przewijanie / zmiana wybranej wartości.
- BACK: powrót.

Zachowuje stały identyfikator: `93F847268B3845A49991C28B7E590E2A`.

## Wersja 1.3.3 — interfejs po testach na zegarku
Duża róża kompasu, rozdzielone wiersze CEL i LEWO/PRAWO/NA KIERUNKU, osobny status czujnika. Zmierzona szerokość pasów jest dopasowana do malejącej szerokości koła przy dolnej krawędzi ekranu. Pomoc ma trzy krótkie strony. Turbo 80 ms pozostaje bez zmian.

**Azymuty:** na głównym ekranie START ustawia aktualny kierunek jako cel, następnie START otwiera MENU, pozycja ZAPISZ DO SLOTU pozwala zapisać ten kierunek do 5 pozycji. Zajęte miejsce wymaga potwierdzenia przez drugi START. Do wyboru miejsca użyj UP/DOWN.

Wybór MAG z automatyczną deklinacją bez dostępnej pozycji wyświetli `TRUE*` oraz ostrzeżenie `MAG: BRAK GPS`, aby nie udawać poprawnego wskazania magnetycznego.

## Zmiana v1.3.4

Główny ekran nie pokazuje już statusu czujnika ani napisu TURBO/SMOOTH/ECO. Dolna część ekranu jest przeznaczona wyłącznie na czytelne informacje o celu i odchyłce. Ustawienie prędkości pozostaje w menu USTAWIENIA → PŁYNNOŚĆ. Zobacz `CHANGELOG_1_3_4_PL.md`.
