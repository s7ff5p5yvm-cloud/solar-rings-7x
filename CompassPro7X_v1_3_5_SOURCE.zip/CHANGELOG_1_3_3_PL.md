# Compass Pro 7X v1.3.3 — poprawka interfejsu po testach na zegarku

- **Prowadzenie:** CEL oraz LEWO/PRAWO/NA KIERUNKU w dwóch oddzielnych pasach. Oba mieszczą się w bezpiecznej szerokości okrągłego ekranu 280×280, bez nachodzenia na siebie i na status.
- Status czujnika i Turbo/Smart/Eco we własnym, krótkim wierszu poniżej prowadzenia.
- Dolny panel ma 180 px szerokości i nie wychodzi poza okrąg; etykiety są ograniczone do 168 px, status do 112 px.
- Litery N/E/S/W nie są rysowane, jeśli weszłyby w dolny panel nawigacyjny; znaczniki kierunku i czerwonej północy pozostają.
- Skrócone etykiety TRUE/MAG, brak GPS, potwierdzenie nadpisania oraz stopka na okrągłym ekranie.
- Pomoc podzielona na 3 przełączane strony (UP/DOWN).
- Menu i lista zapisów do 5 pozycji na ekranie, wyróżniony wybór i podgląd celu.
- Zapis do zajętego slotu wymaga drugiego START (potwierdzenia nadpisania).
- Nie zmieniono algorytmu Turbo 80 ms, WMM2025, zapisu azymutów TRUE ani identyfikatora aplikacji.
- Zaktualizowano testy geometrii ekranu 280×280. **Wymagana kompilacja w Garmin SDK i potwierdzenie układu na urządzeniu.**
