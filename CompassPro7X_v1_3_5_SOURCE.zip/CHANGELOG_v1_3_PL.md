# Compass Pro 7X — v1.3.0 (pełny pakiet płynności i użyteczności)

- Tryby ECO 700 ms / SMOOTH 100 ms / TURBO 80 ms, przełączane w ustawieniach. Rzeczywiste FPS zależą od zegarka i częstotliwości odczytów czujnika.
- Adaptacyjne wygładzanie kątów (mała zwłoka przy szybkim obrocie, tłumienie drobnych drgań w bezruchu). Bez narastania błędu przy przejściu 359°/0°.
- Progi odświeżania dopasowane do trybu; brak przerysowywania bez potrzeby. Timer działa tylko na ekranach kompasu i prowadzenia.
- Przewijane, większe menu: na okrągłym wyświetlaczu widać maksymalnie 5 pozycji naraz.
- Wsteczna kompatybilność zapisanego wyboru ECO/SMOOTH. Zachowane stare identyfikatory aplikacji, cele, pięć zapisów, WMM2025 i wszystkie funkcje.
- Wymaga kompilacji Connect IQ SDK i weryfikacji na rzeczywistym zegarku przed publikacją.
- Poprawne trwałe usuwanie celu (`Application.Storage.deleteValue`).
- Odrzucanie przestarzałej lokalizacji GPS (>7 dni) i niedostępnej jakości, bez sugerowania, że aplikacja przeszła na ręczną deklinację.
