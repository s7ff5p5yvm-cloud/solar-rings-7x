using Toybox.Application.Storage as Store;

module CompassStore {
    function read(key, fallback) {
        try {
            var value = Store.getValue(key);
            return value == null ? fallback : value;
        } catch (e) {
            return fallback;
        }
    }

    function write(key, value) {
        try {
            Store.setValue(key, value);
            return true;
        } catch (e) {
            return false;
        }
    }

    function remove(key) {
        try {
            Store.deleteValue(key);
            return true;
        } catch (e) {
            return false;
        }
    }

    function slotKey(index) {
        return "bearing_" + index.toString();
    }

    function slot(index) {
        return read(slotKey(index), null);
    }
}
