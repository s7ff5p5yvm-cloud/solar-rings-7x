using Toybox.WatchUi as Ui;

class CompassKeys extends Ui.BehaviorDelegate {
    var _screen;

    function initialize(screen) {
        BehaviorDelegate.initialize();
        _screen = screen;
    }

    function onSelect() {
        _screen.select();
        return true;
    }

    function onNextPage() {
        _screen.down();
        return true;
    }

    function onPreviousPage() {
        _screen.up();
        return true;
    }

    function onMenu() {
        _screen.menu();
        return true;
    }

    function onBack() {
        _screen.back();
        return true;
    }
}
