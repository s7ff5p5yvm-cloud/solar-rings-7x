using Toybox.Lang as Lang;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as G;
using Toybox.Sensor as Sensor;
using Toybox.Activity as Activity;
using Toybox.Position as Position;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Timer as Timer;
using Toybox.System as Sys;
using Toybox.Math as M;

// Compass Pro 7X 1.3.4 - clean two-row navigation layout, no sensor/speed footer.
// Main values/saved bearings are always stored in TRUE degrees.
// Pages: 0 compass, 1 guide, 2 menu, 3 load bearing, 4 save bearing,
//        5 edit bearing, 6 settings, 7 edit declination, 8 help.
class CompassScreen extends Ui.View {
    var _page = 0;
    var _selection = 0;
    var _helpPage = 0;
    var _timer;
    var _timerActive = false;
    var _shown = false;

    var _heading = null;
    var _filtered = null;
    var _source = "BRAK";
    var _lastValid = 0;
    var _target = null;
    var _magnetic = false;
    var _mils = false;
    // Refresh profile: 0 ECO, 1 SMOOTH, 2 TURBO.
    // Legacy "eco" setting is kept for seamless upgrade from v1.2.
    var _speedMode = 1;
    var _autoDecl = true;
    var _decl10 = 0;
    var _autoDec = null;
    var _autoFrom = "BRAK POZYCJI";
    var _declLocationChecked = false;

    var _edit = 0.0;
    var _edit10 = 0;
    var _editCoarse = false;
    var _toast = null;
    var _overwriteArmed = false;
    var _lastDrawn = null;
    var _lastDrawValid = false;
    var _lastDrawSource = "";
    var _lastDrawMs = 0;
    // Explicit types + bounded arrays avoid SDK 9.3.0 type warnings
    // inside the 48-tick drawing loop and avoid resizing during startup.
    var _ticksSin = new [48] as Lang.Array<Lang.Float>;
    var _ticksCos = new [48] as Lang.Array<Lang.Float>;

    function initialize() {
        View.initialize();
        _timer = new Timer.Timer();
        for (var i = 0; i < 48; i++) {
            var r = CompassMath.radians(i * 7.5);
            _ticksSin[i] = M.sin(r);
            _ticksCos[i] = M.cos(r);
        }
        _target = CompassStore.read("target_true", null);
        _magnetic = CompassStore.read("magnetic", false);
        _mils = CompassStore.read("mils", false);
        var previousEco = CompassStore.read("eco", false);
        _speedMode = CompassStore.read("speedMode", previousEco ? 0 : 1);
        if (_speedMode < 0 || _speedMode > 2) { _speedMode = 1; }
        _autoDecl = CompassStore.read("autoDecl", true);
        _decl10 = CompassStore.read("decl10", 0);
    }

    function isCompassPage() { return _page == 0 || _page == 1; }

    function onShow() {
        _shown = true;
        if (_magnetic && _autoDecl) { _updateAutoDecl(); }
        _readHeading();
        _refreshTimer();
    }

    function onHide() {
        _shown = false;
        _stopTimer();
    }

    function _stopTimer() {
        if (_timerActive) {
            _timer.stop();
            _timerActive = false;
        }
    }

    function _refreshTimer() {
        _stopTimer();
        _lastDrawn = null;
        if (_shown && isCompassPage()) {
            // Active-view timer ONLY. No GPS/network/background polling.
            _timer.start(method(:_tick), _refreshPeriod(), true);
            _timerActive = true;
        }
        Ui.requestUpdate();
    }

    function _refreshPeriod() {
        if (_speedMode == 0) { return 700; }
        return _speedMode == 2 ? 80 : 100;
    }

    function _speedName() {
        if (_speedMode == 0) { return "ECO"; }
        return _speedMode == 2 ? "TURBO" : "SMOOTH";
    }

    function _tick() {
        _readHeading();
        var now = Sys.getTimer();
        var ok = _valid();
        var changed = false;
        if (ok && _filtered != null) {
            if (_lastDrawn == null) { changed = true; }
            else {
                var delta = CompassMath.shortest(_lastDrawn, _filtered);
                if (delta < 0.0) { delta = -delta; }
                // Subdegree redraw threshold only in fast modes.
                changed = delta >= (_speedMode == 0 ? 1.0 : (_speedMode == 2 ? 0.25 : 0.35));
            }
        }
        if (changed || ok != _lastDrawValid || _source != _lastDrawSource ||
            (now - _lastDrawMs) > 1600) {
            _lastDrawn = ok ? _filtered : null;
            _lastDrawValid = ok;
            _lastDrawSource = _source;
            _lastDrawMs = now;
            Ui.requestUpdate();
        }
    }

    function _readHeading() {
        var reading = null;
        var source = "BRAK";
        try {
            var info = Sensor.getInfo();
            if (info != null && info.heading != null) {
                reading = info.heading * 180.0 / M.PI;
                source = "SENSOR";
            }
        } catch (e) { }
        if (reading == null) {
            try {
                var activity = Activity.getActivityInfo();
                if (activity != null && activity.currentHeading != null) {
                    reading = activity.currentHeading * 180.0 / M.PI;
                    source = "SYSTEM";
                }
            } catch (e2) { }
        }
        if (reading != null && reading >= -360.0 && reading <= 720.0) {
            _heading = CompassMath.wrap(reading);
            if (_filtered == null) { _filtered = _heading; }
            else {
                var difference = CompassMath.shortest(_filtered, _heading);
                // Adaptive circular smoothing: fast turns should have virtually
                // no lag, while small stationary jitter is suppressed.
                var magnitude = difference < 0.0 ? -difference : difference;
                var gain;
                if (_speedMode == 0) {
                    gain = magnitude >= 10.0 ? 1.0 : 0.74;
                } else if (magnitude >= 12.0) {
                    gain = 1.0;
                } else if (magnitude >= 4.0) {
                    gain = _speedMode == 2 ? 0.99 : 0.96;
                } else if (magnitude >= 1.0) {
                    gain = _speedMode == 2 ? 0.91 : 0.84;
                } else {
                    gain = _speedMode == 2 ? 0.68 : 0.52;
                }
                _filtered = CompassMath.wrap(_filtered + difference * gain);
            }
            _source = source;
            _lastValid = Sys.getTimer();
        } else {
            _source = "BRAK";
        }
    }

    function _valid() {
        if (_filtered == null || _source == "BRAK") { return false; }
        var age = Sys.getTimer() - _lastValid;
        return age >= 0 && age < 3500;
    }

    // Do not misrepresent TRUE heading as MAG when AUTO location is missing.
    function _magReady() {
        return _magnetic && (!_autoDecl || _autoDec != null);
    }
    function _declination() { return _autoDecl ? _autoDec : _decl10 / 10.0; }
    function _display(value) {
        if (value == null) { return null; }
        return CompassMath.toDisplay(value, _magReady(), _magReady() ? _declination() : 0.0);
    }
    function _toTrue(displayDeg) {
        return CompassMath.toTrue(displayDeg, _magReady(), _magReady() ? _declination() : 0.0);
    }
    function _northLabel() {
        // Short labels are intentional: long texts would overflow the MIP
        // centre strip. Missing AUTO is explained below the numeric azimuth.
        if (_magnetic && _autoDecl && _autoDec == null) { return "TRUE*"; }
        return _magReady() ? (_autoDecl ? (_autoFrom=="OST. GPS" ? "MAG GPS" : "MAG AUTO") : "MAG RECZ") : "TRUE";
    }

    // One-shot *read of last known* location. Never call enableLocationEvents
    // from this application; no GPS start and no network/geolocation upload.
    function _updateAutoDecl() {
        _declLocationChecked = true;
        _autoDec = null;
        _autoFrom = "BRAK POZYCJI";
        try {
            var pos = Position.getInfo();
            if (pos == null || pos.position == null) { return; }
            // Only use a credible last position: a GPS fix from another
            // activity can be stale after the user travels to a new place.
            if (pos.accuracy == Position.QUALITY_NOT_AVAILABLE) {
                _autoFrom = "BRAK GPS";
                return;
            }
            if (pos.when == null) {
                _autoFrom = "BRAK DATY GPS";
                return;
            }
            var gpsAge = Time.now().value() - pos.when.value();
            if (gpsAge < 0 || gpsAge > 604800) {
                _autoFrom = "STARY GPS";
                return;
            }
            var latlon = pos.position.toDegrees();
            var lat = latlon[0];
            var lon = latlon[1];
            if (lat < -89.9 || lat > 89.9 || lon < -180.0 || lon > 180.0) { return; }
            var info = Gregorian.utcInfo(Time.now(), Time.FORMAT_SHORT);
            var year = WMM2025.decimalYear(info.year, info.month, info.day);
            _autoDec = WMM2025.declination(lat, lon, year);
            if (_autoDec != null) {
                _autoFrom = (pos.accuracy == Position.QUALITY_LAST_KNOWN) ? "OST. GPS" : "GPS";
            } else { _autoFrom = "WMM NIEDOST."; }
        } catch (e) {
            _autoDec = null;
            _autoFrom = "BRAK POZYCJI";
        }
    }

    function _goto(page) {
        _page = page;
        _selection = 0;
        if (page == 8) { _helpPage = 0; }
        _toast = null;
        _overwriteArmed = false;
        _refreshTimer();
    }
    function _remember(value) {
        if (value == null) { return; }
        _target = CompassMath.wrap(value);
        CompassStore.write("target_true", _target);
    }

    function select() {
        _toast = null;
        if (_page == 0) {
            if (_valid()) { _remember(_filtered); _goto(1); }
            else { _edit = 0.0; _editCoarse = false; _goto(5); }
        } else if (_page == 1) {
            _goto(2);
        } else if (_page == 2) {
            _chooseMenu();
        } else if (_page == 3) {
            var stored = CompassStore.slot(_selection);
            if (stored == null) { _toast = "PUSTY SLOT"; Ui.requestUpdate(); }
            else { _remember(stored); _goto(1); }
        } else if (_page == 4) {
            if (_target != null && !_overwriteArmed && CompassStore.slot(_selection) != null) {
                _overwriteArmed = true;
                _toast = "START: NADPISZ";
                Ui.requestUpdate();
            } else if (_target != null && CompassStore.write(CompassStore.slotKey(_selection), _target)) {
                _goto(1); _toast = "AZYMUT ZAPISANY";
            } else { _goto(2); _toast = "NIE ZAPISANO"; }
        } else if (_page == 5) {
            _remember(_toTrue(_edit)); _goto(1);
        } else if (_page == 6) {
            _chooseSettings();
        } else if (_page == 7) {
            _decl10 = _edit10;
            CompassStore.write("decl10", _decl10);
            _goto(6);
        }
    }

    function _chooseMenu() {
        if (_selection == 0) {
            if (_target == null && _valid()) { _remember(_filtered); }
            if (_target == null) { _edit=0.0; _goto(5); }
            else { _goto(4); }
        } else if (_selection == 1) {
            _edit = _target != null ? _display(_target) : (_valid() ? _display(_filtered) : 0.0);
            _editCoarse = false;
            _goto(5);
        } else if (_selection == 2) { _goto(3); }
        else if (_selection == 3) {
            _target = null;
            CompassStore.remove("target_true");
            _goto(0);
        } else if (_selection == 4) { _goto(6); }
        else if (_selection == 5) { _goto(8); }
        else { _goto(_target != null ? 1 : 0); }
    }

    function _chooseSettings() {
        if (_selection == 0) {
            _magnetic = !_magnetic;
            CompassStore.write("magnetic", _magnetic);
            if (_magnetic && _autoDecl && !_declLocationChecked) { _updateAutoDecl(); }
        } else if (_selection == 1) {
            _autoDecl = !_autoDecl;
            CompassStore.write("autoDecl", _autoDecl);
            if (_autoDecl) { _updateAutoDecl(); }
        } else if (_selection == 2) {
            _updateAutoDecl();
            _toast = _autoDec == null ? "BRAK GPS / WMM" : "DEKLINACJA OK";
        } else if (_selection == 3) {
            _edit10 = _decl10;
            _editCoarse = false;
            _goto(7); return;
        } else if (_selection == 4) {
            _mils = !_mils;
            CompassStore.write("mils", _mils);
        } else if (_selection == 5) {
            _speedMode = (_speedMode + 1) % 3;
            CompassStore.write("speedMode", _speedMode);
            // Keep the legacy setting synchronized for older installations.
            CompassStore.write("eco", _speedMode == 0);
            _refreshTimer();
        } else { _goto(2); return; }
        Ui.requestUpdate();
    }

    function up() { _navigate(-1); }
    function down() { _navigate(1); }
    function _navigate(direction) {
        _toast = null;
        _overwriteArmed = false;
        if (_page == 0) { _goto(direction < 0 ? 3 : 2); return; }
        if (_page == 1 && _target != null) {
            _remember(_target + direction * (_mils ? 0.05625 : 1.0));
        } else if (_page == 2) { _selection = (_selection + direction + 7) % 7; }
        else if (_page == 3 || _page == 4) { _selection = (_selection + direction + 5) % 5; }
        else if (_page == 5) {
            // One-degree accurate setting, with MENU toggling +/-10 degrees.
            _edit = CompassMath.wrap(_edit + direction *
                (_mils ? (_editCoarse ? 5.625 : 0.05625) : (_editCoarse ? 10.0 : 1.0)));
        } else if (_page == 6) { _selection = (_selection + direction + 7) % 7; }
        else if (_page == 7) {
            _edit10 += direction * (_editCoarse ? 10 : 1);
            if (_edit10 > 300) { _edit10 = 300; }
            if (_edit10 < -300) { _edit10 = -300; }
        } else if (_page == 8) {
            _helpPage = (_helpPage + direction + 3) % 3;
        }
        Ui.requestUpdate();
    }

    function menu() {
        if (_page == 5 || _page == 7) {
            _editCoarse = !_editCoarse;
            Ui.requestUpdate();
        } else { _goto(2); }
    }

    function back() {
        if (_page == 0) { _stopTimer(); Sys.exit(); }
        else if (_page == 1) { _goto(0); }
        else if (_page == 2) { _goto(_target != null ? 1 : 0); }
        else if (_page == 7) { _goto(6); }
        else { _goto(2); }
    }

    function onUpdate(dc) {
        dc.setColor(G.COLOR_BLACK, G.COLOR_BLACK);
        dc.clear();
        if (isCompassPage()) { _drawCompass(dc); }
        else { _drawPanel(dc); }
    }

    function _px(cx, r, degrees) {
        return cx + (M.sin(CompassMath.radians(degrees))*r).toNumber();
    }
    function _py(cy, r, degrees) {
        return cy - (M.cos(CompassMath.radians(degrees))*r).toNumber();
    }
    function _fitText(dc, x, y, preferred, fallback, maxWidth, value, color) {
        var font=preferred;
        if (dc.getTextWidthInPixels(value, font) > maxWidth) { font=fallback; }
        dc.setColor(color, G.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, value, G.TEXT_JUSTIFY_CENTER);
    }

    // Center text within measured vertical bands, avoiding font-height overlaps.
    function _fitBandText(dc, x, top, bandHeight, preferred, fallback, maxWidth, value, color) {
        var font=preferred;
        if (dc.getFontHeight(font)>bandHeight-2 || dc.getTextWidthInPixels(value,font)>maxWidth) {
            font=fallback;
        }
        var y=top+((bandHeight-dc.getFontHeight(font))/2).toNumber();
        dc.setColor(color,G.COLOR_TRANSPARENT);
        dc.drawText(x,y,font,value,G.TEXT_JUSTIFY_CENTER);
    }

    // Prefer larger navigation captions now that the sensor/speed footer is gone.
    // Step down through native bitmap fonts until the full caption fits its
    // measured circular-safe band. No dynamic vector-font allocation.
    function _navBandText(dc, x, top, bandHeight, maxWidth, value, color) {
        var font = G.FONT_MEDIUM;
        if (dc.getFontHeight(font) > bandHeight - 2 ||
            dc.getTextWidthInPixels(value, font) > maxWidth) { font = G.FONT_SMALL; }
        if (dc.getFontHeight(font) > bandHeight - 2 ||
            dc.getTextWidthInPixels(value, font) > maxWidth) { font = G.FONT_TINY; }
        if (dc.getFontHeight(font) > bandHeight - 2 ||
            dc.getTextWidthInPixels(value, font) > maxWidth) { font = G.FONT_XTINY; }
        var y = top + ((bandHeight - dc.getFontHeight(font)) / 2).toNumber();
        dc.setColor(color, G.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, value, G.TEXT_JUSTIFY_CENTER);
    }

    function _drawCompass(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();
        var cx = (w/2).toNumber();
        var cy = (h*0.49).toNumber();
        var radius = ((w < h ? w : h)/2).toNumber()-12;
        var active = _valid();
        var heading = active ? _display(_filtered) : null;
        var guided = _page==1 && _target!=null;

        // Compass card almost fills the entire round 280px MIP panel.
        dc.setPenWidth(2);
        dc.setColor(0x425563, G.COLOR_TRANSPARENT);
        dc.drawCircle(cx,cy,radius);
        dc.setPenWidth(1);
        dc.setColor(0x24333D, G.COLOR_TRANSPARENT);
        dc.drawCircle(cx,cy,radius-14);
        if (heading != null) {
            var a=CompassMath.radians(heading);
            var sh=M.sin(a); var ch=M.cos(a);
            for (var i=0; i<48; i++) {
                var major=i%4==0;
                var ui=_ticksSin[i]*ch-_ticksCos[i]*sh;
                var vi=_ticksCos[i]*ch+_ticksSin[i]*sh;
                var inner=radius-(major ? 15 : 9);
                var outer=radius-3;
                dc.setColor(major ? 0xC4D8DF : 0x556D7A, G.COLOR_TRANSPARENT);
                dc.drawLine(cx+(ui*inner).toNumber(), cy-(vi*inner).toNumber(),
                            cx+(ui*outer).toNumber(), cy-(vi*outer).toNumber());
            }
            var letters=["N","E","S","W"];
            for (var k=0;k<4;k++) {
                var angle=CompassMath.wrap(k*90.0-heading);
                var letterY=_py(cy,radius-27,angle)-8;
                // The lower quadrant is reserved for guidance. Never allow
                // cardinal labels to intersect the navigation dashboard.
                if (letterY < h-107) {
                    dc.setColor(k==0 ? 0xFF5C51 : 0xDCE8EB, G.COLOR_TRANSPARENT);
                    dc.drawText(_px(cx,radius-27,angle),letterY,
                                G.FONT_TINY, letters[k], G.TEXT_JUSTIFY_CENTER);
                }
            }
            // Clearly visible RED NORTH marker along the compass ring.
            var north=CompassMath.wrap(-heading);
            dc.setPenWidth(3);
            dc.setColor(0xFF5146,G.COLOR_TRANSPARENT);
            dc.drawLine(_px(cx,radius-24,north),_py(cy,radius-24,north),
                        _px(cx,radius-13,north),_py(cy,radius-13,north));
            dc.setPenWidth(1);
            if (guided) {
                var aim=CompassMath.shortest(heading,_display(_target));
                var tx=_px(cx,radius-4,aim);
                var ty=_py(cy,radius-4,aim);
                dc.setColor(0x31F0C4,G.COLOR_TRANSPARENT);
                dc.fillCircle(tx,ty,5);
            }
        }

        // The white arrow is the WATCH'S fixed forward aiming line.
        dc.setColor(G.COLOR_WHITE,G.COLOR_TRANSPARENT);
        dc.fillPolygon([[cx,cy-radius+8],[cx-7,cy-radius-6],[cx+7,cy-radius-6]]);

        // Opaque central area prevents dial letters from colliding with numbers.
        // Explicit vertical zones: bearing (90..181), navigation (190..250), footer (255..270).
        dc.setColor(G.COLOR_BLACK,G.COLOR_BLACK);
        dc.fillRoundedRectangle(cx-100,cy-44,200,88,10);
        var number=heading==null ? "---" :
                   (_mils ? (CompassMath.degreesToMils(heading)%6400).toString() :
                           ((heading+0.5).toNumber()%360).toString());
        var numberFont=G.FONT_NUMBER_MEDIUM;
        if (dc.getTextWidthInPixels(number,numberFont)>165) { numberFont=G.FONT_LARGE; }
        var fheight=dc.getFontHeight(numberFont);
        // The large value is vertically centered inside the top 59 pixels of the data panel.
        var numY=cy-43+((60-fheight)/2).toNumber();
        dc.setColor(G.COLOR_WHITE,G.COLOR_TRANSPARENT);
        dc.drawText(cx,numY,numberFont,number,G.TEXT_JUSTIFY_CENTER);
        if (heading != null && !_mils) {
            dc.drawText(cx + (dc.getTextWidthInPixels(number,numberFont)/2).toNumber() + 3,
                        numY+4,G.FONT_TINY,"°",G.TEXT_JUSTIFY_LEFT);
        }
        _fitText(dc,cx,cy+21,G.FONT_XTINY,G.FONT_XTINY,166,
                 heading==null ? "BRAK KIERUNKU" : (_mils ? "MIL" : "AZYMUT") + " / " + _northLabel(),
                 0x96B9C5);

        // The entire lower safe area now belongs to the navigation data.
        // NO sensor/Turbo/Speed text on the main screen. Those controls remain
        // in Settings. Two independent opaque panels avoid dial-letter overlap.
        // 280px geometry: upper band 181..217 (max caption 192px),
        // lower band 219..251 (max caption 148px); the lower panel (168px)
        // stays inside the circular chord even at y=251.
        dc.setColor(G.COLOR_BLACK, G.COLOR_BLACK);
        dc.fillRoundedRectangle(cx-100, h-99, 200, 36, 10);
        dc.fillRoundedRectangle(cx-84, h-61, 168, 32, 10);
        var firstLine;
        var secondLine;
        var secondColor=0x32E8C0;
        if (guided) {
            firstLine="CEL " + CompassMath.text(_display(_target),_mils);
            if (heading==null) {
                secondLine="BRAK ODCZYTU";
                secondColor=0xFFD067;
            } else {
                var diff=CompassMath.shortest(heading,_display(_target));
                var mag=diff < 0 ? -diff : diff;
                secondLine=mag < 2.0 ? "NA KIERUNKU" :
                           (diff>0 ? "PRAWO " : "LEWO ") + CompassMath.text(mag,_mils);
            }
        } else {
            firstLine="START: USTAW CEL";
            secondLine="UP SLOTY  DN MENU";
            secondColor=0x9CC2CD;
        }
        if (_magnetic && _autoDecl && _autoDec==null) {
            secondLine="MAG: BRAK GPS";
            secondColor=0xFFD067;
        } else if (_toast!=null) {
            secondLine=_toast;
            secondColor=0xFFDE67;
        }
        _navBandText(dc,cx,h-99,36,192,firstLine,0xD5F4EA);
        _navBandText(dc,cx,h-61,32,148,secondLine,secondColor);
    }

    function _drawPanel(dc) {
        var w=dc.getWidth();
        var h=dc.getHeight();
        var cx=(w/2).toNumber();
        var items=[];
        var title="";
        if (_page==2) {
            title="MENU";
            items=["ZAPISZ DO SLOTU","USTAW AZYMUT","ZAPISANE (5)",
                   "USUN CEL","USTAWIENIA","POMOC","POWROT"];
        } else if (_page==3 || _page==4) {
            title=_page==3 ? "WCZYTAJ CEL" : "ZAPISZ CEL";
            for (var i=0;i<5;i++) {
                var value=CompassStore.slot(i);
                items.add((i+1).toString()+".   "+(value==null ? "PUSTY" : CompassMath.text(_display(value),_mils)));
            }
        } else if (_page==6) {
            title="USTAWIENIA";
            items=["POLNOC: "+(_magnetic ? "MAG" : "TRUE"),
                   "DEKLINACJA: "+(_autoDecl ? "AUTO" : "RECZNA"),
                   "ODSWIEZ POZYCJE",
                   "RECZNIE: "+(_decl10/10.0).toString()+"°",
                   "JEDNOSTKI: "+(_mils ? "6400 MIL" : "STOPNIE"),
                   "PLYNNOSC: "+_speedName(),
                   "POWROT"];
        }
        _fitText(dc,cx,24,G.FONT_MEDIUM,G.FONT_SMALL,176,title,0x38DCC0);

        if (_page==8) {
            // Exactly four compact rows per page, never nine stacked labels.
            var help=[];
            if (_helpPage==0) {
                help=["TRZYMAJ POZIOMO", "CZERWONE N: POLNOC",
                      "BIALY ZNAK: PRZOD", "ZIELONY: CEL"];
            } else if (_helpPage==1) {
                help=["START: USTAW CEL", "START W PROW.: MENU",
                      "UP/DOWN: LISTA / KROK", "BACK: POWROT"];
            } else {
                help=["MAG: WMM2025 + GPS", "GPS: OSTATNIA POZYCJA",
                      "KALIBRACJA: GARMIN", "BRAK DANYCH? SPRAWDZ GPS"];
            }
            for (var j=0;j<help.size();j++) {
                var y=78+j*35;
                dc.setColor(0x14252B,G.COLOR_BLACK);
                dc.fillRoundedRectangle(32,y-4,w-64,31,7);
                _fitBandText(dc,cx,y-4,31,G.FONT_TINY,G.FONT_XTINY,w-78,help[j],0xD8E9ED);
            }
            _fitText(dc,cx,h-52,G.FONT_XTINY,G.FONT_XTINY,154,
                     "UP/DOWN: STRONA "+(_helpPage+1).toString()+"/3",0x38DCC0);
            _fitText(dc,cx,h-28,G.FONT_XTINY,G.FONT_XTINY,130,"BACK: POWROT",0xA6BFC9);
            return;
        }

        if (_page==5 || _page==7) {
            _fitText(dc,cx,53,G.FONT_SMALL,G.FONT_TINY,200,
                     _page==5 ? "USTAW CEL" : "DEKLINACJA E+ / W-",0xC9D8E0);
            var str=_page==5 ? CompassMath.text(_edit,_mils) : (_edit10/10.0).toString()+"°";
            _fitText(dc,cx,100,G.FONT_NUMBER_MEDIUM,G.FONT_LARGE,216,str,G.COLOR_WHITE);
            var step = _page==5 ? (_mils ? (_editCoarse ? "KROK 100 MIL" : "KROK 1 MIL")
                                            : (_editCoarse ? "KROK 10°" : "KROK 1°")) :
                                 (_editCoarse ? "KROK 1°" : "KROK 0.1°");
            _fitText(dc,cx,189,G.FONT_SMALL,G.FONT_TINY,192,step,0x2AE6C0);
            _fitText(dc,cx,218,G.FONT_XTINY,G.FONT_XTINY,182,"MENU: ZMIEN KROK",0xA8C3CB);
            _fitText(dc,cx,243,G.FONT_XTINY,G.FONT_XTINY,138,"START OK / BACK ANUL",0xA8C3CB);
            return;
        }

        if (_page==4 && _target != null) {
            _fitText(dc,cx,51,G.FONT_TINY,G.FONT_XTINY,174,
                     "CEL: "+CompassMath.text(_display(_target),_mils),0xB3E8D8);
        }
        var visible=items.size()>5 ? 5 : items.size();
        var first=0;
        if (items.size()>visible) {
            first=_selection-2;
            if (first<0) { first=0; }
            if (first>items.size()-visible) { first=items.size()-visible; }
        }
        var slotPage=_page==3 || _page==4;
        var stepHeight=slotPage ? 30 : (visible==5 ? 32 : 34);
        var yStart=slotPage ? 79 : 67;
        for (var row=0; row<visible; row++) {
            var index=first+row;
            var y=yStart+row*stepHeight;
            if (index==_selection) {
                dc.setColor(0x164642,G.COLOR_BLACK);
                dc.fillRoundedRectangle(35,y-3,w-70,stepHeight-1,8);
            }
            _fitBandText(dc,cx,y-3,stepHeight-1,G.FONT_SMALL,G.FONT_TINY,w-82,items[index],
                         index==_selection ? 0x4AF4D0 : 0xD4E3E7);
        }
        if (first>0) {
            _fitText(dc,cx,43,G.FONT_XTINY,G.FONT_XTINY,80,"^",0x81AFB4);
        }
        if (first+visible<items.size()) {
            _fitText(dc,cx,h-39,G.FONT_XTINY,G.FONT_XTINY,80,"v",0x81AFB4);
        }
        var footer;
        if (_page==4) { footer="START ZAPISZ / BACK"; }
        else if (_page==3) { footer="START WCZYTAJ / BACK"; }
        else if (_page==6 && _autoDecl) {
            footer=_autoDec==null ? "AUTO BRAK: TRUE" :
                   "WMM2025 "+(_autoDec<0 ? "" : "+")+(_autoDec).format("%.1f")+"°";
        } else { footer="UP/DOWN WYBOR  START OK"; }
        if (_toast!=null) {
            _fitText(dc,cx,h-29,G.FONT_XTINY,G.FONT_XTINY,142,_toast,0xFFDA6D);
        } else {
            _fitText(dc,cx,h-29,G.FONT_XTINY,G.FONT_XTINY,142,footer,0xA4BAC4);
        }
    }
}
