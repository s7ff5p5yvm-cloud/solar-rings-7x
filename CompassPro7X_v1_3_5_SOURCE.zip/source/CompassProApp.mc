using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Complications as Complications;

class CompassProApp extends App.AppBase {
    function initialize() {
        AppBase.initialize();
    }

    // Publish a static launch target, not a sensor sample. This is executed
    // only when Compass Pro is opened; no background tasks are registered.
    function onStart(state) {
        try {
            Complications.updateComplication(0, { :value => "OPEN" });
        } catch (e) {
            // Launch still works when complication APIs are temporarily unavailable.
        }
    }

    function getInitialView() {
        var face = new CompassScreen();
        return [face, new CompassKeys(face)];
    }
}
