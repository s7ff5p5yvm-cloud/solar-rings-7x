using Toybox.Math as M;

// All stored headings are TRUE-north degrees, irrespective of display mode.
module CompassMath {
    function wrap(deg) {
        while (deg < 0.0) { deg += 360.0; }
        while (deg >= 360.0) { deg -= 360.0; }
        return deg;
    }

    function shortest(fromDeg, toDeg) {
        var delta = wrap(toDeg - fromDeg);
        if (delta > 180.0) { delta -= 360.0; }
        return delta;
    }

    function toDisplay(trueDeg, magnetic, declination) {
        return wrap(trueDeg - (magnetic ? declination : 0.0));
    }

    function toTrue(displayDeg, magnetic, declination) {
        return wrap(displayDeg + (magnetic ? declination : 0.0));
    }

    function degreesToMils(deg) {
        return (wrap(deg) * 6400.0 / 360.0 + 0.5).toNumber();
    }

    function text(deg, mils) {
        if (mils) {
            var units = degreesToMils(deg);
            if (units >= 6400) { units = 0; }
            return units.toString() + " mil";
        }
        var rounded = (wrap(deg) + 0.5).toNumber();
        if (rounded == 360) { rounded = 0; }
        return rounded.toString() + "°";
    }

    function radians(deg) { return deg * M.PI / 180.0; }
}
