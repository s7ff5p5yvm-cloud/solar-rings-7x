# Compass Pro 7X 1.3.2 — poprawki błędów kompilacji

## Przyczyna niepowodzenia v1.3.1

SDK Connect IQ 9.3.0 zgłaszał `Cannot resolve type 'Array'` oraz `Cannot resolve type 'Float'` w plikach `CompassScreen.mc` (linie 50–51) i `WMM2025.mc` (linie 144–149). Typy `Array` i `Float` należą do `Toybox.Lang`, ale kod używał ich bez importu. 

## Zmiany

- Oba pliki importują `using Toybox.Lang as Lang;`.
- Sześć buforów ma jawne deklaracje `Lang.Array<Lang.Float>`.
- Dodano testy regresji kompilatora, by uniknąć powtórzenia tej usterki.
- Numer wersji podniesiony do 1.3.2. **ID aplikacji oraz klucze zapisów azymutu bez zmian.**
- Płynność, układ ekranu, TRYB TRUE/MAG, WMM2025 i pozostałe funkcje bez zmian.

## Co zostało sprawdzone?

Testy lokalne Python, walidacja XML, ZIP, spójność SHA-256 źródeł i pliku GitHub Actions. Brak lokalnej instalacji kompilatora Monkey C; kompilacja SDK na GitHubie nadal jest wymagana. 

## Instalacja

W repozytorium `s7ff5p5yvm-cloud/solar-rings-7x` dodaj do gałęzi `main`:
1. `CompassPro7X_v1_3_2_SOURCE.zip` w katalogu głównym;
2. `.github/workflows/CompassPro7X_v1_3_2_BUILD.yml`.

GitHub uruchomi workflow dla 1.3.2. Po sukcesie pobierz artefakt z `.prg`; plik `.iq` jest generowany tylko ze stałym kluczem deweloperskim.
