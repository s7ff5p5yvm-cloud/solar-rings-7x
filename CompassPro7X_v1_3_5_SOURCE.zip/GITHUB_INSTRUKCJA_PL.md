# Compass Pro 7X v1.3.4 — GitHub Actions

1. Wgraj `CompassPro7X_v1_3_4_SOURCE.zip` do katalogu głównego repozytorium `solar-rings-7x`.
2. Wgraj `CompassPro7X_v1_3_4_BUILD.yml` do folderu `.github/workflows/`.
3. Kliknij **Commit changes**.
4. W **Actions** wybierz **Compass Pro 7X v1.3.4 PRO clean layout...**.
5. Po udanej kompilacji pobierz artefakt `CompassPro7X_v1_3_4_PRO_build`, zawierający dwa pliki `.prg`.
6. Wybrany wariant testowy `.prg` skopiuj przez USB do folderu `GARMIN/APPS`.

Uwaga: `.iq` do Connect IQ Store zostanie wyeksportowany tylko przy ustawionym trwałym sekrecie `CONNECTIQ_DEVELOPER_KEY_BASE64`. Aktualizacja aplikacji w sklepie musi być podpisana tym samym kluczem co poprzednia.
