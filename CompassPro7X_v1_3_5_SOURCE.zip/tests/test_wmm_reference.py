import unittest
from pathlib import Path
import re
class WMMReferenceTest(unittest.TestCase):
    def test_full_model(self):
        code=(Path(__file__).parents[1]/"source/WMM2025.mc").read_text()
        self.assertEqual(len(re.findall(r"^            \[\d+, \d+,",code,re.M)),90)
        self.assertIn("decimalYear >= 2030.0",code)
        self.assertIn("horizontal < 6000.0",code)

if __name__=="__main__": unittest.main()
