import re, math, unittest
from pathlib import Path

S=(Path(__file__).parents[1]/'source/WMM2025.mc').read_text()
COEFF=[]
for line in S.splitlines():
    m=re.match(r'\s*\[(\d+),\s*(\d+),\s*([-+\deE.]+),\s*([-+\deE.]+),\s*([-+\deE.]+),\s*([-+\deE.]+)\],',line)
    if m:
        n,k=int(m[1]),int(m[2]);vals=list(map(float,m.groups()[2:]))
        COEFF.append((n,k,*vals))

def wmm(lat,lon,year):
    # Independent Python evaluator of the embedded, Schmidt-denormalized coefficients.
    rlat=math.radians(lat);rlon=math.radians(lon)
    a,b,re=6378.137,6356.7523142,6371.2
    a2=a*a;b2=b*b;c2=a2-b2;a4=a2*a2;b4=b2*b2;c4=a4-b4
    sl=math.sin(rlat);cl=math.cos(rlat)
    q=math.sqrt(a2-c2*sl*sl)
    ct=sl/math.sqrt((a2/b2)**2*cl*cl+sl*sl)
    st=math.sqrt(1-ct*ct)
    r=math.sqrt((a4-c4*sl*sl)/(q*q))
    d=math.sqrt(a2*cl*cl+b2*sl*sl)
    ca=d/r;sa=c2*cl*sl/(r*d)
    p=[[0.0]*13 for _ in range(13)];dp=[[0.0]*13 for _ in range(13)]
    p[0][0]=1.0
    ar=(re/r)**2;aor=re/r
    bt=bp=br=0.0;dt=year-2025
    i=0
    for n in range(1,13):
        ar*=aor
        for m in range(n+1):
            if n==m:
                p[n][m]=st*p[n-1][m-1]
                dp[n][m]=st*dp[n-1][m-1]+ct*p[n-1][m-1]
            elif n==1:
                p[n][m]=ct;dp[n][m]=-st
            else:
                k=((n-1)**2-m*m)/((2*n-1)*(2*n-3))
                q=p[n-2][m] if n-2>=m else 0.0
                rdp=dp[n-2][m] if n-2>=m else 0.0
                p[n][m]=ct*p[n-1][m]-k*q
                dp[n][m]=ct*dp[n-1][m]-st*p[n-1][m]-k*rdp
            ni,mi,g,h,dg,dh=COEFF[i];i+=1
            assert (ni,mi)==(n,m)
            g+=dt*dg;h+=dt*dh
            cp,sp=math.cos(m*rlon),math.sin(m*rlon)
            temp1=g*cp+h*sp;temp2=g*sp-h*cp
            par=ar*p[n][m]
            bt-=ar*temp1*dp[n][m]
            bp+=m*temp2*par
            br+=(n+1)*temp1*par
    bp/=st
    bx=-bt*ca-br*sa
    by=bp
    return math.degrees(math.atan2(by,bx)),math.sqrt(bx*bx+by*by)

class WMMDataTest(unittest.TestCase):
    def test_full_coefficient_count(self): self.assertEqual(len(COEFF),90)
    def test_degree_12(self): self.assertEqual(COEFF[-1][:2],(12,12))
    def test_seattle_reference_from_pygeomag_noaa_algorithm(self):
        self.assertAlmostEqual(wmm(47.6205,-122.3493,2025.25)[0],15.065629638512593,places=4)
    def test_krakow_2026_reasonable(self):
        self.assertTrue(5.0 < wmm(50.0647,19.945,2026.9)[0] < 8.0)
    def test_equator_sanity(self):
        self.assertTrue(-10.0<wmm(0.0,0.0,2025.0)[0]<10.0)
    def test_gps_standby_no_receiver_start(self):
        screen=(Path(__file__).parents[1]/'source/CompassScreen.mc').read_text()
        self.assertIn('Position.getInfo()',screen)
        self.assertNotIn('Position.enableLocationEvents(',screen)
    def test_five_year_validity_guard(self):
        self.assertIn('decimalYear >= 2030.0',S)
        self.assertIn('decimalYear < 2025.0',S)
    def test_magnetic_pole_caution(self): self.assertIn('horizontal < 6000.0',S)

if __name__=='__main__': unittest.main()
