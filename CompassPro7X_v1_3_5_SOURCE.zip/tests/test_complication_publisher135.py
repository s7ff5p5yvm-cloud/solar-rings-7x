"""Static validation of the Compass Pro public launch complication."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]

class Publisher135(unittest.TestCase):
    def test_manifest(self):
        root = ET.parse(ROOT / 'manifest.xml').getroot()
        app = root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['type'], 'watch-app')
        self.assertEqual(app.attrib['id'], '93F847268B3845A49991C28B7E590E2A')
        self.assertEqual(app.attrib['version'], '1.3.5')
        self.assertIn('ComplicationPublisher', (ROOT/'manifest.xml').read_text())

    def test_public_complication_uses_svg(self):
        root = ET.parse(ROOT / 'resources/complications.xml').getroot()
        self.assertEqual(root.tag, 'complications')
        items = root.findall('complication')
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].attrib['id'], '0')
        self.assertEqual(items[0].attrib['access'], 'public')
        self.assertEqual(items[0].attrib['icon'], '@Drawables.CompassLinkIcon')
        self.assertIsNotNone(items[0].find('faceIt'))
        svg = ROOT / 'resources/drawables/compass_link.svg'
        self.assertTrue(svg.is_file())
        self.assertTrue(ET.parse(svg).getroot().tag.endswith('svg'))
        self.assertIn('filename="compass_link.svg"', (ROOT / 'resources/drawables/drawables.xml').read_text())

    def test_unique_stable_labels_and_update(self):
        labels = (ROOT/'resources/strings.xml').read_text()
        self.assertIn('Compass Pro 7X Link', labels)
        self.assertIn('CP7X', labels)
        app = (ROOT/'source/CompassProApp.mc').read_text()
        self.assertIn('Complications.updateComplication(0,', app)
        self.assertNotIn('Timer.', app)

    def test_existing_functions_preserved(self):
        screen = (ROOT/'source/CompassScreen.mc').read_text()
        self.assertIn('function onUpdate(', screen)
        self.assertTrue((ROOT/'source/WMM2025.mc').exists())
        for f in ROOT.rglob('*.xml'): ET.parse(f)

if __name__ == '__main__': unittest.main()
