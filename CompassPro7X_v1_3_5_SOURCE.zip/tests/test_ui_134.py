from pathlib import Path
import math
import re
import unittest
ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'source'/'CompassScreen.mc').read_text(encoding='utf-8')

class CleanNavigationLayout(unittest.TestCase):
    def test_removed_status_footer_only_from_main_view(self):
        compass=SRC.split('function _drawCompass(dc) {',1)[1].split('function _drawPanel(dc)',1)[0]
        self.assertNotIn('_speedName()',compass)
        self.assertNotIn('_source+" / "',compass)
        self.assertNotIn('"SENSOR / TURBO"',compass)
        self.assertIn('"PLYNNOSC: "+_speedName()',SRC)
    def test_two_navigation_bands_do_not_overlap(self):
        a=(280-99,280-99+36)
        b=(280-61,280-61+32)
        self.assertLess(a[1],b[0])
        self.assertGreater(b[1],a[1])
        self.assertIn('dc.fillRoundedRectangle(cx-100, h-99, 200, 36, 10)',SRC)
        self.assertIn('dc.fillRoundedRectangle(cx-84, h-61, 168, 32, 10)',SRC)
    def test_round_display_safe_widths(self):
        for bottom,width in [(217,192),(251,148)]:
            chord=2*math.sqrt(140**2-(bottom-140)**2)
            self.assertLess(width+10,chord)
        self.assertLess(168+2,2*math.sqrt(140**2-(251-140)**2))
    def test_navigation_font_has_four_tiers(self):
        h=SRC.split('function _navBandText(',1)[1].split('function _drawCompass(',1)[0]
        for family in ['G.FONT_MEDIUM','G.FONT_SMALL','G.FONT_TINY','G.FONT_XTINY']:
            self.assertIn(family,h)
        self.assertIn('dc.getTextWidthInPixels(value, font) > maxWidth',h)
    def test_all_guidance_text_kept(self):
        for label in ['"CEL "','"NA KIERUNKU"','"PRAWO " : "LEWO "','"MAG: BRAK GPS"','"START: USTAW CEL"']:
            self.assertIn(label,SRC)
    def test_turbo_unchanged(self):
        self.assertIn('return _speedMode == 2 ? 80 : 100;',SRC)

if __name__ == '__main__': unittest.main()
