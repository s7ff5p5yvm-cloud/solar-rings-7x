import math
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MATH=(ROOT/'source/CompassMath.mc').read_text()
SCREEN=(ROOT/'source/CompassScreen.mc').read_text()

def wrap(x): return x%360.0
def shortest(a,b):
    d=wrap(b-a)
    return d-360 if d>180 else d

def mil(x): return int(wrap(x)*6400/360+0.5)%6400

class BearingMath(unittest.TestCase):
    def test_wrap_0(self): self.assertEqual(wrap(360),0)
    def test_wrap_negative(self): self.assertEqual(wrap(-1),359)
    def test_wrap_multiturn(self): self.assertEqual(wrap(721),1)
    def test_shortest_forward_wrap(self): self.assertEqual(shortest(350,10),20)
    def test_shortest_backward_wrap(self): self.assertEqual(shortest(10,350),-20)
    def test_shortest_opposite(self): self.assertEqual(shortest(0,180),180)
    def test_shortest_same(self): self.assertEqual(shortest(100,100),0)
    def test_cardinal_mils(self):
        self.assertEqual([mil(x) for x in (0,90,180,270)], [0,1600,3200,4800])
    def test_roundtrip_true_mag(self):
        for t in (0,0.05,78.9,270,359.99):
            for dec in (-20.6,0,6.4,16.8):
                self.assertAlmostEqual(wrap(wrap(t-dec)+dec),t,places=4)
    def test_guidance_direction_right(self): self.assertEqual(shortest(268,345),77)
    def test_guidance_direction_left(self): self.assertEqual(shortest(268,250),-18)
    def test_smooth_crosses_zero_correctly(self):
        self.assertAlmostEqual(wrap(359+shortest(359,1)*0.9),0.8)
    def test_mag_conversion_in_real_code(self):
        self.assertIn('CompassMath.toDisplay(value, _magReady()',SCREEN)
        self.assertIn('CompassMath.toTrue(displayDeg, _magReady()',SCREEN)
    def test_bearing_is_persisted_as_true(self):
        self.assertIn('CompassStore.write("target_true", _target)',SCREEN)
        self.assertIn('target_true',SCREEN)
    def test_unit_switch_keeps_saved_bearings(self):
        self.assertIn('CompassStore.write("mils", _mils)',SCREEN)
        self.assertIn('CompassStore.slot(_selection)',SCREEN)
    def test_precise_manual_modes(self):
        self.assertIn('0.05625',SCREEN)
        self.assertIn('5.625',SCREEN)
    def test_no_rounding_to_360(self):
        self.assertIn('if (rounded == 360) { rounded = 0; }',MATH)

if __name__=='__main__': unittest.main()
