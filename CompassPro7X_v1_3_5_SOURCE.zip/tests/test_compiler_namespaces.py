import re, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
class CompilerNamespaces(unittest.TestCase):
    def test_typed_arrays_are_qualified_and_lang_is_imported(self):
        for fname in ("WMM2025.mc", "CompassScreen.mc"):
            src = (ROOT / 'source' / fname).read_text()
            self.assertIn("using Toybox.Lang as Lang;", src)
            self.assertNotRegex(src, r"\bas Array<")
            self.assertRegex(src, r"as Lang\.Array<Lang\.Float>")
    def test_no_zero_length_buffers(self):
        src = (ROOT / 'source/WMM2025.mc').read_text()
        for name, size in (("p",169),( "dp",169), ("sp",13), ("cp",13)):
            self.assertIn(f"var {name} = new [{size}] as Lang.Array<Lang.Float>", src)
        screen = (ROOT / 'source/CompassScreen.mc').read_text()
        for name in ("_ticksSin", "_ticksCos"):
            self.assertIn(f"var {name} = new [48] as Lang.Array<Lang.Float>", screen)
    def test_same_app_identity(self):
        manifest=(ROOT/'manifest.xml').read_text()
        self.assertIn('version="1.3.5"', manifest)
        self.assertIn('id="93F847268B3845A49991C28B7E590E2A"', manifest)
        self.assertIn('type="watch-app"', manifest)
if __name__ == "__main__": unittest.main()
