import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MC = (ROOT/'source/CompassScreen.mc').read_text()
WMM = (ROOT/'source/WMM2025.mc').read_text()

class ReleaseTest(unittest.TestCase):
    def test_manifest_app_and_unchanged_identity(self):
        manifest = (ROOT/'manifest.xml').read_text()
        assert 'type="watch-app"' in manifest
        assert 'version="1.3.5"' in manifest
        assert 'id="93F847268B3845A49991C28B7E590E2A"' in manifest
        assert 'launcherIcon="@Drawables.LauncherIcon"' in manifest
        assert 'id="Sensor"' in manifest and 'id="Positioning"' in manifest
    def test_xml_and_icon(self):
        for path in ROOT.rglob('*.xml'):
            ET.parse(path)
        assert (ROOT/'resources/drawables/launcher_icon.png').is_file()
    def test_all_five_slots_retained(self):
        assert 'CompassStore.slot(_selection)' in MC
        assert 'CompassStore.slotKey(_selection)' in MC
        assert '(_selection + direction + 5) % 5' in MC
        assert '_overwriteArmed' in MC
    def test_heading_source(self):
        assert 'Sensor.getInfo()' in MC
        assert 'Activity.getActivityInfo()' in MC
        assert 'activity.currentHeading' in MC
        assert 'difference * gain' in MC and 'magnitude >= 12.0' in MC
    def test_draw_performance(self):
        assert '_ticksSin[i] = M.sin(r);' in MC and '_ticksCos[i] = M.cos(r);' in MC
        assert 'i < 48' in MC
        assert 'changed = delta >= (_speedMode == 0 ? 1.0' in MC
        assert 'return 700;' in MC and 'return _speedMode == 2 ? 80 : 100;' in MC
        assert '_navBandText(dc,cx,h-99,36,192,firstLine' in MC and '_navBandText(dc,cx,h-61,32,148,secondLine' in MC
        assert 'dc.getTextWidthInPixels' in MC
    def test_true_magnetic_fallback(self):
        assert '_magReady()' in MC
        assert '_autoDec != null' in MC
        assert 'TRUE*' in MC
        assert 'MAG GPS' in MC
        assert 'MAG: BRAK GPS' in MC
    def test_no_background_gps_or_network(self):
        joined = '\n'.join(p.read_text() for p in (ROOT/'source').glob('*.mc'))
        assert 'enableLocationEvents' not in joined.replace('// from this application; no GPS start and no network/geolocation upload.', '') or 'Position.enableLocationEvents(' not in joined
        for s in ('makeWebRequest(', 'Communications.makeWebRequest', 'registerForTemporalEvent('):
            assert s not in joined
        assert 'Position.getInfo()' in MC
        assert '_stopTimer();' in MC
    def test_precision_bearing_edit(self):
        assert '0.05625' in MC
        assert 'KROK 1 MIL' in MC and 'KROK 10°' in MC
        assert '_editCoarse = !_editCoarse' in MC
    def test_model_validity(self):
        assert 'decimalYear(year, month, day)' in WMM
        assert 'horizontal < 6000.0' in WMM
        assert 'decimalYear >= 2030.0' in WMM
    def test_saved_true_north(self):
        assert 'target_true' in MC
        assert 'CompassMath.toTrue' in MC
        assert 'CompassMath.toDisplay' in MC

if __name__ == '__main__': unittest.main()
