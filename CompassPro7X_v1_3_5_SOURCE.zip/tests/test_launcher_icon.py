import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
from struct import unpack

ROOT = Path(__file__).resolve().parents[1]

class TestLauncherIcon(unittest.TestCase):
    def test_manifest_launcher_reference(self):
        manifest=ET.parse(ROOT / "manifest.xml").getroot()
        ns={"iq":"http://www.garmin.com/xml/connectiq"}
        app=manifest.find("iq:application",ns)
        self.assertEqual(app.get("type"),"watch-app")
        self.assertEqual(app.get("launcherIcon"),"@Drawables.LauncherIcon")

    def test_drawable_icon_matches_device(self):
        node=ET.parse(ROOT / "resources/drawables/drawables.xml").getroot().find("bitmap")
        self.assertEqual(node.get("id"),"LauncherIcon")
        icon=ROOT / "resources/drawables" / node.get("filename")
        payload=icon.read_bytes()
        self.assertEqual(payload[:8],b"\x89PNG\r\n\x1a\n")
        self.assertEqual(unpack(">II",payload[16:24]),(40,40))

if __name__ == "__main__": unittest.main()
