# Compass Pro 7X v1.3.5 — publikator komplikacji

* Wersja 1.3.5; zachowany app ID: 93F847268B3845A49991C28B7E590E2A.
* Nowe uprawnienie: `ComplicationPublisher` (nie wymaga uruchamiania GPS).
* Publiczna komplikacja id 0, unikalne nazwy `Compass Pro 7X Link` / `CP7X`.
* Osobna ikona SVG wymagana przez Garmin dla publicznych komplikacji.
* `onStart` jednorazowo publikuje wartość `OPEN`; nie ma dodatkowego procesu w tle.
* Zachowane wszystkie ekrany, azymuty i trzy tryby wyświetlania v1.3.4.

Instaluj przed Solar Rings 3.26.85. Sideload PRG może zachowywać się inaczej niż aplikacja ze sklepu Connect IQ; sprawdź obecność komplikacji i uruchamianie na zegarku. Nie da się przetestować tej integracji statycznym testem Pythona.
