# Compass Pro 7X v1.2.0 PRO — zmiany

- Przebudowa ekranu głównego: róża niemal na pełnym ekranie MIP 280×280; brak stałych instrukcji zajmujących połowę wyświetlacza.
- Duży azymut, wyraźna strzałka kierunku zegarka, czerwona północ, turkusowy znacznik celu; odseparowane odczyty CEL i PRAWO/LEWO.
- Wykorzystanie 48 preobliczonych kątów podziałki i maksymalnie dwóch funkcji trygonometrycznych na klatkę obrotu podziałki; dynamiczne wyświetlanie bez renderowania w bezruchu.
- SMOOTH 160 ms, ECO 700 ms; filtr kątowy obsługuje przejście przez 359°/0°.
- WMM2025: pełne 90 współczynników (stopień/rząd 12), data 2025–2029, szacowanie deklinacji ze znanej pozycji zegarka, bez uruchamiania GPS; ręczna korekta dostępna jak wcześniej.
- Bezpieczny fallback TRUE przy braku lokalizacji / poza zakresem modelu / słabym poziomym polu magnetycznym.
- Zachowane pięć slotów zapisanych azymutów i dotychczasowy identyfikator aplikacji; potwierdzenie nadpisania.
- Edycja dokładna 1°/1 mil i szybka 10°/100 mil.
- Manifest nadal `type=watch-app`; nowy dostęp Positioning służy wyłącznie do odczytu ostatniej znanej pozycji.
- Zachowane brak GPS, brak sieci, brak rejestracji aktywności, brak działającej w tle usługi i niezależność od Solar Rings.

**Stan weryfikacji:** testy lokalne Pythona / struktury XML / danych WMM, następnie wymagana kompilacja Garmin SDK 9.3.0 i oględziny na Fenix 7X Pro.
