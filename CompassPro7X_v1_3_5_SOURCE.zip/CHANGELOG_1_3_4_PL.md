# Compass Pro 7X v1.3.4 — czysty ekran kompasu

- Usunięto z głównego ekranu stopkę „SENSOR / SMOOTH / TURBO / ECO”.
- Przeznaczono odzyskane miejsce na **dwa większe wiersze nawigacji**: „CEL” oraz „LEWO/PRAWO/NA KIERUNKU”.
- Oba napisy są dopasowywane do szerokości **okrągłego** ekranu za pomocą pomiaru czcionek bitmapowych (4 wielkości).
- W trybie podstawowym wyświetlane są „START: USTAW CEL” i skrócone wskazówki UP/DOWN.
- Tryb płynności nadal wybiera się w **Ustawienia → Płynność**; Turbo 80 ms, Smooth 100 ms i Eco 700 ms pozostają bez zmian.
- Nie zmieniono algorytmu kompasu, zapisywania celów, ustawień ani modelu WMM2025.
- Zachowano identyfikator aplikacji, więc aktualizacja zastępuje v1.3.3.

## Weryfikacja

Testy regresji Python + XML, testy geometrii pasów i weryfikacja SHA-256 w GitHub Actions. Kompilację Garmin SDK 9.3.0 trzeba jeszcze potwierdzić na GitHub.
