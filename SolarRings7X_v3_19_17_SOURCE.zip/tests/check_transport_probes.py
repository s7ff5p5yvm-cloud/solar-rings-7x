#!/usr/bin/env python3
"""Regression checks for independent GitHub probes, not runtime SDK simulation."""
import ast
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
svc=(r/'source/ImgwService.mc').read_text()
face=(r/'source/SolarRings7X.mc').read_text()
feed=(r/'scripts/update_imgw_feed.py').read_text()
xml=ET.parse(r/'resources/settings/settings.xml')
entries=xml.findall('.//setting[@propertyKey="@Properties.imgwTestStageV3194"]/settingConfig/listEntry')
assert {x.attrib['value'] for x in entries} == {'0','1','2','3','4','5','6'}
a=svc.split('function onTemporalEvent()',1)[1].split('function parseCounty(',1)[0]
assert a.index('if (stage == 5)') < a.index('var loc = Storage.getValue')
assert a.index('if (stage == 6)') < a.index('var loc = Storage.getValue')
txt=svc.split('function beginTextProbe()',1)[1].split('function beginJsonProbe()',1)[0]
js=svc.split('function beginJsonProbe()',1)[1].split('function onTextProbeResponse(',1)[0]
assert 'health.txt' in txt and 'HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN' in txt
assert '12.json' in js and 'HTTP_RESPONSE_CONTENT_TYPE_JSON' in js
assert 'GetCountyByXY' not in txt+js
assert 'processWarnings(' not in txt+js
assert 'method(:onTextProbeResponse)' in txt
assert 'method(:onJsonProbeResponse)' in js
assert 'resultCode == 14' in face and 'resultCode == 15' in face
assert 'stage == 5 || stage == 6' in face
assert "write_text('IMGW_FEED_OK\\n'" in feed or "write_text('IMGW_FEED_OK\n'" in feed
assert svc.count('__GITHUB_OWNER_REPO__') == 1
assert 'srSetting("imgwTestStageV3194", 0) != 4' in face, 'Only full mode can display real alerts'
print('PASS: 4A one TXT HTTP, 4B one JSON HTTP; independent of GPS/GUGiK, neither produces weather all-clear')
