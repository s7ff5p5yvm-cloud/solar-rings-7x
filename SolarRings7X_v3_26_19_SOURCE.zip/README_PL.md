# Solar Rings 7X v3.26.19 — stabilizacja po awariach ustawień

**Najnowsza i wiążąca dokumentacja:** `RAPORT_NAPRAWY_3_26_19.md`.
Poprawiono obsługę zdarzenia zapisu konfiguracji, odczyt `gwPreviewV332`,
odcięto od API podczas pierwszego odświeżenia po zapisie, ograniczono
obciążenie pamięci i wycofano 19 historycznych, niewidocznych pól.
Wszystkie 64 widoczne opcje Connect IQ pozostają dostępne.

**Wymagane:** kompilacja GitHub Actions (Monkey C) i próba na rzeczywistym
Fenix 7X Pro Solar. Nie ma jeszcze potwierdzenia stabilności ani gwarancji
przywrócenia wcześniejszych ustawień po ich uszkodzeniu przez firmware.

---

# Solar Rings v3.26.17 — poprawka kompilacji

Wersja v3.26.17 zachowuje wszystkie funkcje i ustawienia v3.26.16. Zmienia tylko odwołanie do pierwszego elementu pustej tablicy podczas rysowania StormGuard. Szczegóły: `POPRAWKA_KOMPILACJI_v3_26_17.md`.

---

# Solar Rings v3.26.16 — pełna wersja zintegrowana do testów Garmin

**Główne i aktualne instrukcje:** `AUDYT_CALOSCIOWY_v3_26_16.md` oraz `PLAN_TESTU_v3_26_16.md`. Poniższa historyczna dokumentacja wersji v3.26.15 pozostaje wyłącznie dla śledzenia ewolucji projektu.

**Nie jest to gotowy PRG**; kompilacja GitHub Actions i próba na urządzeniu są obowiązkowe. Nowa wersja łączy ciśnieniowy StormGuard, prognozę 1min/15min/1h, urzędowe alerty z opcjonalną próbą pobrania szczegółów, AQI, zabezpieczenia pamięci oraz uczciwe oznaczanie wieku danych. Maksymalny harmonogram: pogoda bieżąca cel co 10 min, 1min i 15min cele co 30 min, 1h i AQI co 60 min, dzienna co 12 h. Nie ma żadnej gwarancji alarmu sekunda po początku lokalnego zjawiska.

---

# Solar Rings v3.26.15 — wydanie do testów sprzętowych

**Najnowsze zasady i ograniczenia są w `AUDYT_CALOSCIOWY_v3_26_15.md` oraz `PLAN_TESTU_v3_26_15.md`.** Dalsza część README zachowuje wcześniejsze informacje historyczne (nie opisuje w całości bieżącego harmonogramu). W v3.26.15: bieżąca pogoda co około 10 minut, 15-minutowe dane prognozowe co około 20 minut, godzinowe osobno co 60 minut, AQI co 60 minut, dane dzienne co 12 godzin; jedno zapytanie na wybudzenie Garmina. Kolory ostrzeżeń uwzględniają bieżące vs przeszłe vs prognozowane opady.

**Pakiet nie zawiera gotowego skompilowanego PRG.** Przed instalacją trzeba zakończyć GitHub Actions bez błędów; prognozy 15-minutowe mogą nadal napotkać Garmin `K-403`. Klucz API i dostawca nie są automatycznie zmieniane.

---

# Solar Rings 7X v3.26.10 — naprawa P0 i K-214

**Główna poprawka:** Monkey C porównuje napisy po referencji przy `==`, więc kody `"current"`, `"forecast"`, `"daily"`, `"air"` mogły nie zostać rozpoznane. Naprawiono wszystkie porównania rodzaju żądania za pomocą `String.equals()` i dodano blokadę wysłania nierozpoznanego endpointu.

Naprawiono też porównania tekstów w innych plikach tarczy, wykrywanie odpowiedzi BG `OWM`, porównanie typu miejsca w geokoderze, i nieczytelny licznik `NEXT F` przy pustym terminie. Nowy ekran TEST 20 powinien pokazywać `P1` (bieżąca), `P2` (prognoza), `P3` (dzień), `P4` (AQI) zamiast `P0`.

Nie zmieniano ustawień ostrzeżeń pogodowych, klucza API ani mapowania kodów zjawisk. Wszystkie poprzednie raporty i procedury testowe są w archiwum.

**Weryfikacja:** testy źródłowe Python i kontrole XML, ZIP. Nie wykonano jeszcze kompilacji Garmin SDK i testu na zegarku.

# Solar Rings v3.26.9 — naprawa i diagnostyka OpenWeather

# Opis zmian v3.26.8 (historia diagnostyki)

Ta wersja rozszerza **diagnostykę OpenWeather**. Nie zmienia klucza API ani zasad wykrywania zjawisk, kolorów ikon czy domyślnych częstotliwości. Dodaje ekrany **TEST 16–19** opisane w `DIAGNOSTYKA_OPENWEATHER_v3268.md`.

# Solar Rings 7X v3.26.7 — instrukcja użytkownika

**Stan:** projekt źródłowy przygotowany do kompilacji w Garmin Connect IQ. Bez lokalnego kompilatora Monkey C i testu sprzętowego NIE jest to potwierdzony, instalowalny PRG. Zachowaj kopię działającej wersji tarczy.

## 1. Co się zmieniło

- **Ta sama polityka prognozy deszczu / śniegu / deszczu ze śniegiem** dla Garmin Weather i OpenWeather One Call 4.0: gdy rozpoznano zjawisko i procent jest dostępny, respektowany jest wybrany próg; gdy procentu nie ma (`null`), ikona prognozy pozostaje; gdy `pop` jest nieprawidłowy, nie jest traktowany jak brak danych. Sam procent bez rozpoznanego zjawiska nie tworzy ikony.
- **Bieżąca obserwacja nie podlega progowi prognozy.** Przykład: aktualny deszcz z `pop=10%` = czerwona ikona; prognoza deszczu z `pop=10%` przy progu 40% = bez turkusowej ikony.
- **Burze, grad, marznący deszcz, tornado/szkwał i inne niebezpieczne jawne kody** nie są filtrowane przez ogólne prawdopodobieństwo opadów, które NIE jest prawdopodobieństwem piorunów, gradu lub oblodzenia. W Garmin kod `CHANCE_OF_THUNDERSTORMS` oznacza prognozę możliwości burzy, nawet bez procentów. Stary parametr `gwStormChanceV332` zachowano w pliku properties dla zgodności, lecz ukryto w ustawieniach i nie wpływa na silnik.
- **Mgła / ograniczona widoczność:** jawny FOG w Garmin lub 741 w OWM daje ikonę; dodatkowo uznawana jest prawidłowa widoczność mniejsza od ustawionego progu, również gdy kod zjawiska jest pusty. Ikona informuje o mgle **lub** istotnie ograniczonej widoczności, nie potwierdza źródła problemu.
- **Silny wiatr:** wspólny próg prędkości (m/s), dodatkowo tylko w OpenWeather próg porywów (domyślnie 15 m/s). Garmin WINDY bez prędkości może pokazać ikonę jakościową, ale nie oznacza to przekroczenia progu w m/s. Kody skrajnych zjawisk wiatrowych są odrębne.
- **Oblodzenie:** to wyłącznie *szacowane ryzyko śliskości* wynikające z kodu ICE lub wilgotnych opadów i niskiej temperatury powietrza; nie jest pomiarem nawierzchni. Marznący deszcz nie tworzy już drugiej, redundantnej ikony „oblodzenie”.
- **Intensywność:** przełączniki „tylko intensywne opady” dalej działają niezależnie od prawdopodobieństwa. OWM przy silnym deszczu ufa jawnemu kodowi 502/503/504/522 **lub** prawidłowej ilości deszczu ≥ 8 mm/h. Dla śniegu używa kodów 602/622; nie utożsamia samego `pop` z intensywnością.
- **Zachowane:** 109 mapowań (54 Garmin + 55 OWM), aktualne temperatury i wskaźniki mrozu/upału, ostrzeżenie AQI włączane osobno (OWM), StormGuard, 3 miejsca ikon, stan czerwony/turkusowy/łączony, opcja 1–3 h prognozy, pozostałe istniejące ustawienia projektu bez zmian.

## 2. Ustawienia na telefonie — czułość prognoz

W menu Connect IQ wybierz **Prognozy deszczu i śniegu: czułość**:

| Tryb | Deszcz / śnieg w prognozie z dostępnym % | Brak procentów przy rozpoznanym zjawisku |
|---|---|---|
| Czuły (0) | Wyświetl przy dowolnej poprawnej wartości 0–100% | Wyświetl |
| Standard (1; domyślny) | Wyświetl od **40%** | Wyświetl |
| Własny (2) | Wyświetl od indywidualnego progu deszczu i śniegu, ustawionego poniżej | Wyświetl |

Wszystkie te tryby dotyczą **prognozy**, nie bieżących warunków. Przełącznik „tylko intensywne” nadal może ukryć lekkie zjawisko nawet przy 90%. Dla mieszanego opadu używany jest niższy z progów WŁĄCZONYCH rodzajów opadów. W trybie własnym stary próg `gwIceChanceV332` nadal dotyczy tylko *wnioskowanego* ryzyka oblodzenia, nie rzeczywiście zmierzonego lodu.

**Ważne:** 40% to prawdopodobieństwo jakichkolwiek opadów, a nie szansa wystąpienia konkretnego rodzaju burzy, gradu lub opadów marznących. Wybrany dostawca może się mylić — tarcza nie jest certyfikowanym systemem ostrzegania.

## 3. OpenWeather — częstotliwość odświeżania

W menu **OpenWeather — częstotliwość / bateria** dostępne są:

| Tryb | Warunki bieżące | Odświeżanie prognozy | Orientacyjna liczba żądań/dobę bez AQI |
|---|---:|---:|---:|
| Dokładniejszy | 15 min | 30 min | 146 |
| Zrównoważony (domyślny) | 30 min | 60 min | 74 |
| Oszczędny | 60 min | 120 min | 38 |

Liczenie: 1440 / minuty aktualnych danych + 1440 / minuty prognozy + 2 zapytania dziennej temperatury maks./min. **AQI dodaje do 24 żądań na dobę**, jeśli włączone. To górne wartości orientacyjne przy ciągłym działaniu, sprawnym telefonie i API; zadania Connect IQ mogą się opóźniać, przy błędach i ograniczeniach zapytania odraczane są jeszcze dłużej. Zwiększenie częstotliwości może zwiększyć zużycie baterii. Zmiana trybu powoduje ponowne harmonogramowanie, nie mnoży zadań tła.

Te tryby dotyczą wyłącznie zapytań **OpenWeather**. Garmin Weather udostępnia dane z własnego cache, odświeżanego przez system i telefon — tarcza nie może wymusić świeżości API Garmin. Osobne istniejące ustawienie „Ostrzeżenia: sprawdzaj dane co” steruje tylko ponowną analizą **już posiadanych** danych, a nie interwałem pobierania pogodowego API.

**Wprowadzono w v3.26.5: prognoza z krokiem 15 minut.** W menu Connect IQ pojawia się przełącznik `OpenWeather - prognoza 15 min (test)` (domyślnie włączony). Włączony tryb korzysta z oficjalnego endpointu `timeline/15min` **zamiast** `timeline/1h` w istniejącym przedziale pobierania (odświeżanie prognozy co 30/60/120 minut zależnie od trybu). Nie dodaje osobnego, równoległego zapytania. Ostrzeżenia analizują **do 12 przyszłych rekordów** z zakresu najbliższych 3 godzin, a resztę odrzucają. Zachowujemy w storage wyłącznie kompaktowe wartości niezbędne do ostrzeżeń. Działa z dotychczasowym horyzontem 1/2/3 h; **aby sprawdzić pełne 3 godziny, ustaw horyzont na 3 h**.

**WAŻNE O PAMIĘCI:** 15-minutowe API zwraca **do 50 rekordów w jednym JSON** i nie udostępnia w dokumentacji oficjalnego parametru `cnt` do ograniczenia do 12. Dlatego odfiltrowanie nadmiaru rekordów **po odebraniu** nie zmniejsza pamięci potrzebnej do odebrania i dekodowania JSON. Nie potwierdzono jeszcze, że pełna odpowiedź zmieści się w pamięci procesu tła Garmin Fenix 7X Pro Solar. W razie błędu 15-minutowej odpowiedzi (np. `-403`: brak pamięci), niezgodnego formatu lub wykrytej przerwanej próby, tarcza wstrzymuje ten tryb na 24 godziny i wykonuje kolejne zapytania przez sprawdzoną trasę `timeline/1h`. Błędy autoryzacji lub limitu 401/403/429 nadal skutkują dłuższą przerwą dla całego źródła: godzinowy endpoint nie naprawiłby takich błędów. W razie problemów możesz też wyłączyć opcję 15 min w ustawieniach. Nie ma gwarancji odzyskania działania, jeśli proces jest wielokrotnie zabijany, pamięć jest stale niewystarczająca lub nie działa połączenie.

**Diagnostyka:** ustaw `TEST 15` w istniejących ustawieniach testowych tarczy. Nagłówek pokaże `OWM 15M` (odebrano prognozę 15-minutową), `OWM 15M?` (jeszcze nie ma aktualnej prognozy 15-minutowej), `OWM FALLBACK` (automatycznie wymuszono prognozę godzinową) albo `OWM 1H` (opcja wyłączona). Zmiana źródła prognozy nie zmienia kolorów ikon: czerwony to stan bieżący, turkusowy to prognoza. Strona z diagnostyką pokazuje też czas, kod zjawiska, procent i decyzję o ikonie deszczu dla kilku próbek.

**Nie zmieniono** logiki Garmin Weather, temperatury, AQI, progów pogody ani odświeżania danych bieżących. Nadal: **jeden HTTP request na jedno uruchomienie zadania tła**. Wersja testowa wymaga kompilacji SDK i testów RAM na zegarku; bez nich nie można stwierdzić, że 15-minutowa odpowiedź zadziała na sprzęcie.

## 4. Inne ostrzeżenia — działanie i ograniczenia

| Zjawisko | Garmin Weather | OpenWeather | Kluczowa uwaga |
|---|---|---|---|
| Deszcz / śnieg | Kod + szansa opadów w prognozie | Kod + `pop` w prognozie | Bieżące: bez filtra % |
| Opady mieszane | Jeden symbol | Jeden symbol | Brak podwójnej ikony deszczu i śniegu |
| Burza | Kody burz; `CHANCE_OF_THUNDERSTORMS` prognoza | 200–232 | Ogólne `pop` NIE filtruje burz |
| Marznący deszcz | Kod `FREEZING_RAIN` | 511 | Ostrzeżenie niezależne od `pop` |
| Grad | Kod `HAIL` | Brak jednoznacznego standardowego kodu | Nie dopowiadamy gradu na podstawie burzy |
| Silny wiatr | Wiatr m/s lub `WINDY` bez wartości | Wiatr m/s **lub porywy m/s** | Osobne skrajne zjawiska wiatrowe |
| Mgła / widzialność | `FOG` lub mierzona widzialność | 741 lub mierzona widzialność | Ikona może oznaczać ograniczoną widoczność *nie z powodu mgły* |
| Oblodzenie / śliskość | Kod ICE lub estymacja | Estymacja z temp. + opadów | Nie jest czujnikiem oblodzenia nawierzchni |
| Dym / pył / piasek / popiół | Jawne kody | Jawne kody 711/731/751/761/762 | To nie jest pomiar PM2.5 |
| UV | Progowe UV | Progowe UV | Oddzielnie, domyślnie wyłączone |
| AQI | Brak tej funkcji w Garmin Weather | Osobny opcjonalny endpoint | OWM skala 1–5, próg 3/4/5 |
| Temperatura zimna/gorąca | Aktualna | Aktualna | Osobna ikona termometru, nie POP |

**Rekomendowane ustawienia na start:** `Standard 40%`, `Horyzont 2 h` (należy ręcznie przestawić, jeśli wcześniej było 1 h), odświeżanie `Zrównoważony 30/60` podczas testu, a następnie `Dokładniejszy 15/30` jeśli akceptujesz wpływ na baterię.

## 5. Jak zbudować projekt — dwa pliki na GitHub

1. Wgraj **SolarRings7X_v3_26_7_SOURCE.zip** wprost do głównego katalogu repozytorium GitHub. Nie rozpakowuj tego archiwum.
2. Wgraj **SolarRings7X_v3_26_7_BUILD.yml** do `.github/workflows/` (to właśnie ten folder jest wykrywany przez Actions). Jeżeli pobierasz pakiet `DWA_PLIKI_DO_GITHUB.zip`, rozpakuj tylko zewnętrzny pakiet, aby uzyskać osobny plik `.yml` i właściwy `SOURCE.zip`.
3. Sekret GitHub `CONNECTIQ_DEVELOPER_KEY_BASE64` pozostaje bez zmian. Nigdy nie wpisuj klucza OpenWeather do GitHuba ani kodu źródłowego.
4. Uruchom Actions → `Solar Rings 7X v3.26.7 - Build from ZIP` → `Run workflow` na gałęzi domyślnej.
5. Dopiero po zielonym wyniku kompilacji pobierz artefakt PRG/IQ i rozpocznij test na Fenixie. Nie pobieraj samego pliku `SOURCE.zip` na zegarek.

## 6. Co poprawiono w v3.26.7 (OpenWeather)

- Pozycja do zapytań OWM: najpierw geolokalizacja Garmin Weather, jeśli jej obserwacja jest aktualna (do 3 h); jeśli nie, ostatnia znana pozycja z aktywności; w dalszej kolejności współrzędne Garmin Weather z obserwacji do 24 h lub bez znacznika czasu. Dane pogodowe nie są mieszane między dostawcami.
- OWM nie przerywa już próby wyłącznie dlatego, że zapisane współrzędne mają ponad 12 h (granicą jest 48 h od ostatniego udostępnienia pozycji tarczy).
- Nazwa miejscowości w trybie OWM wyświetla się na podstawie zapisanych współrzędnych również wtedy, gdy pogoda jeszcze się nie pobrała.
- TEST 15 pokazuje w dolnej linii status ostatniego kroku OWM: `OWM TERAZ: OK`, `OWM TERAZ: 401`, `OWM LOK: BRAK GPS`, `OWM TERAZ: ODPOWIEDZ`, `OWM TERAZ: BRAK TELEFONU`, `OWM PROG: TIMEOUT` itp.
- Status `OK` oznacza zapis danego wyniku w pamięci tarczy, nie jest potwierdzeniem prawidłowej prognozy lub jakości danych dostawcy. Jeśli nadal brak temperatury mimo `OK`, potrzebny jest kolejny test.
- Po zmianie dostawcy i dostępności współrzędnych pierwsze zapytanie może zostać wykonane dopiero po kilku minutach zgodnie z ograniczeniami zadań tła Connect IQ. Kolejne endpointy (prognoza, dzień, AQI) mają osobne wywołania.
- Zapisany wcześniej klucz API (`srOpenKeyV326`) i wszystkie ustawienia progów ostrzeżeń pozostają kompatybilne.

**Weryfikacja:** 77 testów zaliczonych, 1 pominięty (testy Pythona, kontrakty i kontrole statyczne). Nie przeprowadzono kompilacji Monkey C w lokalnym Garmin SDK ani testów z kluczem użytkownika/na zegarku. W razie błędu instalacyjnego decydujący jest wynik GitHub Actions i kod z TEST 15.

## Audyt przedinstalacyjny v3.26.5

- Poprawiono próg ryzyka oblodzenia: `gwIceChanceV332` jest niezależnym progiem procentowym zarówno w Garmin, jak i OpenWeather (domyślnie 50%). Nie ma wpływu na jawny kod ICE ani marznący deszcz. Brak procentów przy rozpoznanych opadach nie blokuje estymacji, natomiast niepoprawny procent blokuje.
- Poprawiono watchdog prognozy 15-minutowej: znacznik niedokończonego żądania pozostaje zapisany aż do końca walidacji i zapisu prognozy, dzięki czemu przerwane przetwarzanie danych może uruchomić 24-godzinny fallback.
- Przy ponad trzech równoczesnych ostrzeżeniach dodatkowe ikony obracają się co 5 sekund, zgodnie z ustawioną polityką, zamiast co minutę.
- **Nie należy uważać paczki źródłowej za skompilowaną aplikację.** Uruchom workflow Garmin i zweryfikuj `.prg` i `.iq`. 15-minutowy JSON może przekroczyć pamięć procesów tła mimo ochrony.
- Ostrzeżenia pogodowe są informacyjne. Brak ikony nie oznacza, że zjawisko na pewno nie wystąpi.


## v3.26.7 – test odpowiedzi OpenWeather
Po zdjęciu z TEST 15 (`OWM LOK: ODPOWIEDZ`) dodano utrwalenie etapu żądania i precyzyjne kody `JSON`, `FORMAT`, `STARE DANE`, `ZAPIS`, `WYJATEK`, `KONTEKST`. Te kody pozwalają wyjaśnić błąd zamiast zgadywać. Nie zmieniono klucza API ani ustawień użytkownika.

**Stan:** nowy kod przeszedł testy źródłowe, nie był kompilowany w Garmin SDK ani sprawdzony na zegarku.


## v3.26.11 — mniej pamięci i wymuszenie pierwszego odczytu
- `-403` to `NETWORK_RESPONSE_OUT_OF_MEMORY` w Garmin Connect IQ, nie kod HTTP 403.
- Prognoza godzinowa prosi OpenWeather One Call 4.0 o `cnt=4` rekordy (zamiast maksymalnie 20), a przy ponownym -403 wykonuje jedną próbę `cnt=2`.
- Prognoza 15-minutowa: `cnt=12` zamiast maksymalnie 50; dzienna: `cnt=2`.
- Po pierwszym uruchomieniu nowej wersji zerowane są terminy, aby najpierw pobrać aktualną temperaturę (`P1`), a następnie prognozę (`P2`).
- Jeśli `cnt` okaże się ignorowany przez API lub nawet najmniejsza odpowiedź przekroczy pamięć, błąd nadal będzie widoczny. Dalszym krokiem jest lekki serwer pośredniczący (proxy) zwracający kilkaset bajtów.
- Nie zmieniono progów ostrzeżeń, kolorów, klucza API ani uprawnień lokalizacji.


## v3.26.12 — rozróżnienie czasu zjawisk, audyt ostrzeżeń i bateria

- Kod aktualnego deszczu/śniegu = czerwony (jedynie przy świeżej obserwacji).
- Kod zachmurzenia przy `rain.1h` lub `snow.1h` >=0,1 mm/h = szara, **historyczna** ikonka: informacja o opadach w przedziale godzinowym, **bez twierdzenia że pada TERAZ**. Po >45 minutach wieku obserwacji taki sygnał nie jest wyświetlany.
- Jawny kod opadów ma pierwszeństwo, więc nie dublujemy ikon. Dwie dodatnie wartości (deszcz i śnieg) tworzą jedną ikonę mieszanych opadów.
- Przyszła prognoza może rozpoznawać opady również z dodatniego, ilościowego `rain.1h/snow.1h`, nawet jeśli kod wskazuje chmury. Jeśli OpenWeather podaje `pop`, obowiązuje wybrany próg procentowy; brak procentów nie oznacza 0%; nieprawidłowy procent blokuje tę prognozę.
- Prognozy są **zawsze turkusowe**, również dla bieżącego przedziału godzinowego/kwadransowego. Nigdy nie prezentujemy prognozy jako czerwonego faktu.
- Wiatr, burze, marznące opady, pył, mgła, oblodzenie, UV, AQI i osobny termometr pozostają niezależne. OWM nie ma bezpośredniego standardowego kodu gradu; nie zgadujemy gradu z burzy. Oblodzenie nadal pozostaje szacunkiem, nie pomiarem drogi.
- TEST 15 OWM pokazuje surowy kod `K`, wiek obserwacji oraz `rain.1h/snow.1h`, żeby wyjaśnić rozbieżności między ikonami i rzeczywistą pogodą.
- Bez nowych API, timerów ani częstszego pobierania. Domyślnie 30 minut bieżąca / 60 minut prognoza, dzienna co 12h i AQI co 60 min, jeśli aktywne.
- Prognoza 15-minutowa pozostaje domyślnie wyłączana podczas diagnostyki błędu pamięci; domyślna wartość ustawień użytkownika nie jest zmieniana.
- Kompilację SDK, limity RAM oraz trafność prognoz należy zweryfikować na Fenixie — testy Python nie zastępują rzeczywistej kompilacji.


## v3.26.13 — maksymalna aktualnosc OWM (5-minutowe sloty Garmin)
- Nowa opcja odswiezania: "Maksymalna aktualnosc". Zegar planuje jedno zapytanie w kazdym dostepnym slocie (nie czesciej niz co 5 minut).
- Biezace warunki oraz prognoza krotkoterminowa maja docelowo po 10 minut; w godzinach z dodatkowymi zadaniami jedna z prob moze byc opozniona o 5 minut.
- Dane dzienne pozostaja co 12 godzin, AQI co 60 minut (gdy wlaczone). Priorytet wybierany wedlug najdawniej zaleglego terminu, bez zaglodzenia dziennej/AQI.
- Utrzymany jeden HTTP request na uruchomienie BG, co ogranicza liczbe prob na jednym zegarku do okolo 288/dobe (przy ciaglym dzialaniu). Dodano ostrozny lokalny limit 700 prob na dobe; limit OpenWeather trzeba niezaleznie ustawic w panelu konta, bo inne aplikacje moga korzystac z tego samego klucza.
- Ta wersja nie poprawia jeszcze osobno problemu `P2 K-403` na niektorych firmware, jesli serwer zignoruje cnt; brak nowych metod ani dodatkowego parsowania JSON.
- Cel baterii >=10 dni nie jest potwierdzony, nalezy porownac zuzycie przez 24-72 godziny.


## v3.26.15 — pełne strojenie alertów i szybkie odzyskiwanie po błędach
- Pierwsze uruchomienie v3.26.15 automatycznie aplikuje zestaw ustawień ostrzeżeń i harmonogram 5min do Garmin Connect IQ. Zmienia zapisane preferencje raz, bez nadpisywania dostawcy i klucza API. Późniejsze ręczne zmiany są respektowane.
- Pełny profil: horyzont 3h; ocena ostrzeżeń 5min; deszcz 30%, śnieg 40%, wiatr 10m/s, porywy 15m/s, mgła/ograniczona widzialność <=500m, oblodzenie 1°C/50%, UV>=7, AQI>=4; wszystkie przełączniki ostrzeżeń włączone, filtr "tylko intensywne" wyłączony.
- 15-minutowa prognoza jest testowana dopiero gdy działa już pierwsza mała prognoza godzinowa; po błędzie korzystamy z prognozy godzinowej.
- Przerwa po utracie telefonu: 5min zamiast 60min. Pozostałe niekrytyczne błędy: 15min zamiast 60min; po trudnym pamięciowym błędzie prognozy: 60min zamiast 6h. Autoryzacja 401/403 i limit 429 pozostają w 6h cooldown.
- W trybie Maksymalna aktualność nie przedstawiamy prognozy starszej niż 45min jako świeżej. Nie dodano HTTP w renderowaniu ani żądań GPS, nie zwiększono liczby zaplanowanych odpytań.
- Realny efekt i zużycie baterii nadal wymagają walidacji na Fenix 7X Pro. Kompilator Garmin SDK nie został uruchomiony lokalnie.
