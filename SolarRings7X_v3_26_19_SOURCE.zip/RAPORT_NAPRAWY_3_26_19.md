# Solar Rings 7X v3.26.19 – kompleksowy hotfix konfiguracji

## Dane z urządzenia
- v3.26.17: 8 × `Out Of Memory Error`, 2 × `Unexpected Type Error`.
- v3.26.18: `Unexpected Type Error` na `0x1000779a`, przypisany do `Config.mc:37`, `Properties.getValue()` dla `gwPreviewV332` w normalnym `onUpdate()`.
- Na urządzeniu wielokrotnie wróciły ustawienia domyślne (dostawca Garmin, pusty klucz OWM, włączony pierścień).
- Znana grupa problemów Garmin CIQ: `Properties.getValue()` i utrata ustawień podczas zapisu/przy ograniczonej pamięci. Brak dowodu na jedną wyłączną przyczynę resetu.

## Zmiany
1. `onSettingsChanged()` **nie** zeruje już cache ani nie odczytuje API ustawień. Od razu blokuje kolejne natywne odczyty (`srFreezeSettingsReads`).
2. Pierwsze `onUpdate()` po zmianie rysuje prosty zegar bez wywołania `Properties.getValue()` czy silnika pogody. Przywrócenie konfiguracji dopiero w kolejnym odświeżeniu przy co najmniej 30 KB wolnego heap.
3. Podczas blokady `srSetting()` zwraca istniejący zapisany wcześniej odczyt albo wartości bezpieczne; nie wywołuje wrażliwego natywnego API.
4. Zmiana czysto wizualna nie usuwa buforowanych danych pogodowych ani harmonogramu OWM. Resetowane są wyłącznie bufory wyglądu oraz czas klasyfikacji ostrzeżeń.
5. Usunięto **19 niewidocznych w Connect IQ** starych definicji właściwości (sterowanie fontami i rozmiarami, martwe pola). Wszystkie **64 widoczne ustawienia** zachowują te same klucze i typy. Klucz OWM pozostaje tylko w ustawieniach Garmin; aplikacja go nie zapisuje dodatkowo.
6. Usunięto nieużywane, skompilowane funkcje masowego zapisu właściwości (z 3.26.15/16). Cache bieżących ustawień pozostaje ograniczony do 48 elementów (jak w v3.26.18), aby ograniczać natywne odczyty w czasie rysowania.
7. Zachowano OWM, Garmin Weather, ostrzeżenia, StormGuard, tryby testowe, temperaturę odczuwalną i opcję pierścienia.

## Ograniczenia
- Testy w tym pakiecie są testami Python/struktur XML, nie wykonują kodu Monkey C na sprzęcie.
- Bez SDK i testu rzeczywistego urządzenia nie da się potwierdzić kompilacji ani stabilności.
- Po zmianie ustawień na jednej klatce tarcza pokaże uproszczony zegar „ODSWIEZANIE USTAWIEN”, potem przy dostatecznej pamięci wróci do pełnego widoku (może potrwać do kolejnego normalnego odświeżenia).
- Przy wolnej pamięci poniżej 30 KB pozostaje uproszczony zegar, zamiast ryzykować kolejne wyłączenie tarczy.
- Gdy firmware Connect IQ sam porzuci zapisane ustawienia, aplikacja nie jest w stanie wiarygodnie odtworzyć klucza OWM. Nie wprowadzamy potajemnej kopii prywatnego klucza.
- Zmiana liczby wpisów `properties.xml` może spowodować migrację ustawień podczas aktualizacji; przed instalacją należy znać lub bezpiecznie zapisać własną konfigurację.
