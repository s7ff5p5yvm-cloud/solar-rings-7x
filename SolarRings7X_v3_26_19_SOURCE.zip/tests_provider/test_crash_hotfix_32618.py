"""v3.26.19 regression invariants derived from real CIQ_LOG.YML and v3.26.17 debug.xml.
Static source verification only: does not simulate Connect IQ execution or measure memory.
"""
from pathlib import Path
import unittest

R=Path(__file__).resolve().parents[1]
APP=(R/'source/SolarRings7X.mc').read_text()
CONFIG=(R/'source/Config.mc').read_text()
WARN=(R/'source/GarminWeatherWarnings.mc').read_text()

class CrashHotfix32618(unittest.TestCase):
    def test_settings_callback_does_not_read_provider_or_allocate_weather(self):
        p=APP.split('    function onSettingsChanged() {',1)[1].split('\n    }',1)[0]
        self.assertIn('markSettingsDirty()',p)
        self.assertNotIn('srOwmProviderChanged()',p)
        self.assertNotIn('rebuildWeatherWarnings()',p)
        self.assertNotIn('resetPerformanceCaches()',p)
    def test_provider_sync_only_for_weather_changes(self):
        p=APP.split('    function applyPendingSettings() {',1)[1].split('\n    }',1)[0]
        self.assertIn('if (weatherContextChanged)',p)
        self.assertIn('srOwmProviderChanged();',p)
        self.assertIn('if (providerChanged)',p)
        self.assertIn('invalidateAppearanceCaches();',p)
    def test_forecast_memory_guard(self):
        self.assertIn('freeMemory < 30000',WARN)
        self.assertIn('Weather.getHourlyForecast()',WARN)
        self.assertIn('return orderAlerts(matched);',WARN)
    def test_minimum_memory_guard(self):
        self.assertIn('freeMemory < 18000',WARN)
    def test_settings_cache_bounded_and_token_not_cached(self):
        self.assertIn('_srSettingCacheSize < 48',CONFIG)
        self.assertIn('!key.equals("srOpenKeyV326")',CONFIG)
        self.assertIn('freeMemory < 24000',CONFIG)
    def test_no_repeat_bulk_property_write_on_initial_view(self):
        p=APP.split('    function getInitialView() {',1)[1].split('\n    }',1)[0]
        self.assertNotIn('srApplyOptimizedWeatherDefaults32616();',p)
        self.assertIn('srOwmProviderChanged();',p)

if __name__=='__main__': unittest.main()
