"""Regression safeguards for the 3.26.19 on-device crash.
These are structural tests. CIQ execution is verified ONLY by GitHub SDK + device.
"""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1]
APP=(R/'source/SolarRings7X.mc').read_text()
CFG=(R/'source/Config.mc').read_text()
PROPS=ET.parse(R/'resources/settings/properties.xml').getroot()
UI=(R/'resources/settings/settings.xml').read_text()

class SettingsTransaction32619(unittest.TestCase):
    def test_event_handler_does_not_touch_props_or_caches(self):
        s=APP.split('    function onSettingsChanged() {',1)[1].split('\n    }',1)[0]
        self.assertIn('srFreezeSettingsReads();',s)
        self.assertIn('markSettingsDirty();',s)
        for bad in ('srResetSettingsCache();','srOwmProviderChanged();',
                    'resetPerformanceCaches();','Props.getValue(', 'Props.setValue('):
            self.assertNotIn(bad,s)
    def test_transition_frame_never_calls_properties(self):
        s=APP.split('    function drawSettingsTransition(dc) {',1)[1].split('\n    }',1)[0]
        self.assertIn('System.getClockTime()',s)
        self.assertNotIn('srSetting(',s)
        self.assertNotIn('srOwm',s)
        self.assertNotIn('Props',s)
    def test_read_barrier_before_property_calls(self):
        pos=CFG.index('if (_srSettingsReadsFrozen) { return fallback; }')
        self.assertLess(pos,CFG.index('var value = Props.getValue(key);'))
    def test_settings_reload_guard_and_cooldown(self):
        s=APP.split('    function onUpdate(dc) {',1)[1].split('        // One-way low-memory fallback',1)[0]
        self.assertLess(s.index('_settingsWarmupFrames > 0'),s.index('srThawSettingsReads()'))
        self.assertIn('stats.freeMemory >= 30000',s)
        self.assertIn('srFreezeSettingsReads();',s)
    def test_nonweather_changes_preserve_weather_snapshots(self):
        s=APP.split('    function applyPendingSettings() {',1)[1].split('\n    }',1)[0]
        self.assertIn('if (weatherContextChanged)',s)
        self.assertNotIn('resetPerformanceCaches()',s)
        self.assertIn('invalidateAppearanceCaches()',s)
    def test_legacy_entries_only_and_keep_visible_settings(self):
        ids={p.attrib['id'] for p in PROPS.findall('property')}
        self.assertNotIn('fontClockV31',ids)
        self.assertNotIn('sizeTopLeftV37',ids)
        self.assertNotIn('gwStormChanceV332',ids)
        self.assertIn('showFeelsLikeV319',ids)
        self.assertIn('outerRingV31',ids)
        self.assertIn('srOpenKeyV326',ids)
        for key in __import__('re').findall(r'@Properties\.([A-Za-z0-9_]+)',UI):
            self.assertIn(key,ids)
    def test_no_legacy_bulk_writers(self):
        self.assertNotIn('function srApplyOptimizedWeatherDefaults32615',CFG)
        self.assertNotIn('function srApplyOptimizedWeatherDefaults32616',CFG)
