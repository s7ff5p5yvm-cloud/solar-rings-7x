"""Independent scheduling and source-contract review for v3.26.19.

These are NOT Monkey C runtime tests and cannot verify the response size,
Garmin's task scheduling, API coverage or physical battery drain.
"""
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NETWORK = (ROOT/'source/SolarOpenNetwork.mc').read_text()
DATA = (ROOT/'source/SolarOpenData.mc').read_text()
WARN = (ROOT/'source/SolarOpenWarnings.mc').read_text()
APP = (ROOT/'source/SolarRings7X.mc').read_text()
CONF = (ROOT/'source/Config.mc').read_text()
PROPS = {p.attrib['id']:p.text for p in ET.parse(ROOT/'resources/settings/properties.xml').iter('property')}


def simulate_day():
    # A simple discrete-event scheduling model, not a Monkey C interpreter.
    due = dict(current=0, hourly=0, daily=0, air=0)
    durations = dict(current=10, hourly=60, short=20, daily=720, air=60)
    history = {key:[] for key in durations}
    have_hourly = False
    for minute in range(0,1440,5):
        if have_hourly and 'short' not in due:
            due['short'] = minute
        # Forecast role chooses whichever variant is due first.
        forecast_due = min(due['hourly'],due.get('short',10**8))
        if due['current'] <= minute:
            selected = 'current'
        elif forecast_due <= minute:
            selected = 'short' if due.get('short',10**8) < due['hourly'] else 'hourly'
        elif due['air'] <= minute:
            selected = 'air'
        elif due['daily'] <= minute:
            selected = 'daily'
        else:
            continue
        history[selected].append(minute)
        due[selected] = minute + durations[selected]
        if selected == 'hourly':
            have_hourly = True
    return history


class CompleteRelease32615(unittest.TestCase):
    def test_current_cadence_is_prioritized(self):
        self.assertIn('if (nextC <= _now) { _kind = "current"; }',NETWORK)
        self.assertIn('return _interval == 5 ? 10 * 60',NETWORK)
        self.assertIn('else if (nextF <= _now) { _kind = "forecast"; }',NETWORK)
        h=simulate_day()
        self.assertEqual(h['current'], list(range(0,1440,10)))

    def test_all_other_sources_remain_serviced(self):
        h=simulate_day()
        self.assertGreaterEqual(len(h['short']),65)
        self.assertGreaterEqual(len(h['hourly']),23)
        self.assertGreaterEqual(len(h['air']),23)
        self.assertEqual(len(h['daily']),2)
        for k in ('hourly','short','air'):
            self.assertLessEqual(max(b-a for a,b in zip(h[k],h[k][1:])),65)

    def test_quota_and_single_request(self):
        h=simulate_day()
        total=sum(map(len,h.values()))
        self.assertLessEqual(total,288)
        self.assertLess(total,700)
        self.assertLess(total,1000)
        self.assertEqual(NETWORK.count('Comm.makeWebRequest('),1)
        self.assertIn('if (used >= 700)',NETWORK)
        self.assertIn('if (!reserveQuota())',NETWORK)

    def test_separate_forecast_deadlines(self):
        self.assertIn('srONextSV32615',NETWORK)
        self.assertIn('srONextFV326',NETWORK)
        self.assertIn('return _interval == 5 ? 30 * 60',NETWORK)
        self.assertIn('return _interval == 5 ? 60 * 60',NETWORK)
        self.assertIn('_shortRequest = _shortChoice',NETWORK)
        self.assertIn('srOwmWrite("srONextSV32615", 0)',DATA)

    def test_hybrid_forecast_not_replace_hourly(self):
        self.assertIn('var shortData = srOwmRead("srOShortV3264");',DATA)
        self.assertIn('var hourly = srOwmRead("srOHoursV326");',DATA)
        self.assertIn('result.add(shortRows[i]);',DATA)
        self.assertIn('result.add(hourlyRows[j]);',DATA)
        self.assertIn('h.size() > 10 && srOwmNumber(h[10])',WARN)
        self.assertIn('bucket]);',NETWORK)

    def test_weather_time_semantics(self):
        self.assertIn('recentPrecipitation(d)',WARN)
        self.assertIn('addAlert(out, 66)',WARN)
        self.assertIn('addAlert(out, 67)',WARN)
        self.assertIn('if (elapsed <= freshSeconds)',WARN)
        self.assertIn('20 * 60 : 2700',WARN)
        self.assertIn('futureKinds[z] + 16',WARN)
        self.assertIn('if (h[0] <= now - slotSeconds',WARN)

    def test_runtime_memory_fallback(self):
        self.assertIn('q["cnt"] = "4"',NETWORK)
        self.assertIn('q["cnt"] = "1"',NETWORK)
        self.assertIn('"2" : "3"',NETWORK)
        self.assertIn('code == -403',NETWORK)
        self.assertIn('srOShortPausedV3264',NETWORK)
        self.assertIn('if (code == 401 || code == 403 || code == 429)',NETWORK)

    def test_upgrade_only_once_and_preserves_credentials(self):
        self.assertNotIn('srOptimal32616',CONF)
        self.assertNotIn('srApplyOptimizedWeatherDefaults32616()',CONF)
        self.assertNotIn('Props.setValue("srOpenKeyV326"',CONF)
        self.assertNotIn('Props.setValue("srProviderV326"',CONF)
        self.assertIn('srODVersionV32616',DATA)
        self.assertIn('srOwmWrite("srOHoursV326", null)',DATA)
        self.assertIn('srOwmWrite("srOShortV3264", null)',DATA)
        self.assertEqual(PROPS['gwRainChanceV332'],'30')
        self.assertEqual(PROPS['gwSnowChanceV332'],'40')
        self.assertEqual(PROPS['srOwmMinutesV326'],'5')

    def test_diagnostic_real_next_forecast(self):
        self.assertIn('var sf = value("srONextSV32615");',NETWORK)
        self.assertIn('if (canUseShort() && num(sf)',NETWORK)
        self.assertIn('OWM STATUS v32616',APP)
        self.assertIn('if (num(f) && f > 0)',NETWORK)

    def test_required_files_and_no_settings_secrets(self):
        for f in ['manifest.xml','monkey.jungle','resources/settings/settings.xml',
                  'resources/settings/properties.xml','resources/strings.xml']:
            self.assertTrue((ROOT/f).is_file())
        self.assertNotIn('<property id="srOpenKeyV326" type="string">',
                         (ROOT/'resources/settings/properties.xml').read_text())
        self.assertNotIn('Comm.makeWebRequest', WARN)

if __name__ == '__main__': unittest.main()
