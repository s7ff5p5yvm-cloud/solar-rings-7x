using Toybox.Application.Properties as Props;
using Toybox.Graphics as Gfx;

// Cache ONLY persisted settings; dynamic device data is never cached here.
// All entries are invalidated after the safe settings handover (not in its callback).
// At most 48 compact entries; never cache the user API token in heap.
// This cache is an optimization, not the owner of persisted settings.
var _srSettingCache = {};
var _srSettingCacheSize = 0;
// True only during settings import and its first transition frame.
// While frozen, use the last readable settings (or the caller fallback),
// never Application.Properties.getValue() in the rendering path.
var _srSettingsReadsFrozen = false;

function srFreezeSettingsReads() { _srSettingsReadsFrozen = true; }
function srThawSettingsReads() { _srSettingsReadsFrozen = false; }

function srResetSettingsCache() {
    _srSettingCache = {};
    _srSettingCacheSize = 0;
}

// Mobile app settings. Exposed keys are defined in properties.xml; legacy
// font/size keys intentionally return fixed values without a native read.
// Deliberately use NEW keys so stale v2.x settings cannot unexpectedly override
// the new three-ring layout. All 8 visible slots are selectable from the phone.
function srSetting(key, fallback) {
    // Version 3.18: font controls removed from Connect IQ settings because
    // they were not reliable on the MIP screen. Preserve the accepted layout
    // and ignore values persisted by previous versions of the phone app.
    if (key.equals("fontClockV31") || key.equals("fontDateV31") ||
        key.equals("fontTopV31") || key.equals("fontRingV31") ||
        key.equals("fontWeatherV31")) { return 2; }
    if (key.equals("fontFaceV36")) { return 0; }
    if (key.equals("fontExtraV36")) { return 1; }
    if (key.equals("sizeTopLeftV37") || key.equals("sizeTopMidV37") ||
        key.equals("sizeTopRightV37") || key.equals("sizeRingLeftV37") ||
        key.equals("sizeRingMidV37") || key.equals("sizeRingRightV37") ||
        key.equals("sizeWeatherValueV37") || key.equals("sizeWeatherLabelV37") ||
        key.equals("sizeFooterV37") || key.equals("moonFontV38")) { return -1; }
    var cached = _srSettingCache[key];
    if (cached != null) { return cached; }
    // Garmin may still be importing properties immediately after a save.
    // This is particularly important when it has very little free heap.
    if (_srSettingsReadsFrozen) { return fallback; }
    try {
        var value = Props.getValue(key);
        if (value != null) {
            // Reject damaged/imported diagnostic values before comparing them
            // to numeric mode constants elsewhere in the drawing code.
            if (key.equals("gwPreviewV332") &&
                !(value instanceof Toybox.Lang.Number)) { return fallback; }
            if (_srSettingCacheSize < 48 && !key.equals("srOpenKeyV326")) {
                var mayCache = true;
                try {
                    if (_srFrameSystemStats != null &&
                        _srFrameSystemStats.freeMemory < 24000) { mayCache = false; }
                } catch (e) { }
                if (mayCache) {
                    _srSettingCache[key] = value;
                    _srSettingCacheSize += 1;
                }
            }
            return value;
        }
    } catch (e) { }
    return fallback;
}

function srColor(value) {
    if (value == 0) { return Gfx.COLOR_RED; }
    if (value == 1) { return Gfx.COLOR_GREEN; }
    if (value == 2) { return Gfx.COLOR_BLUE; }
    if (value == 3) { return Gfx.COLOR_ORANGE; }
    if (value == 4) { return Gfx.COLOR_YELLOW; }
    if (value == 5) { return Gfx.COLOR_WHITE; }
    return 0x00FFFF;
}

// Legacy bulk-default writers removed in v3.26.19.
// User settings come only from Connect IQ properties.xml.
