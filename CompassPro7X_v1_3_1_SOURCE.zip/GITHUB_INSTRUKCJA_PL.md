# Compass Pro 7X v1.3 PRO — kompilacja GitHub Actions

1. Wgraj `CompassPro7X_v1_3_SOURCE.zip` do katalogu głównego repozytorium Compass Pro 7X na GitHubie (gałąź `main`).
2. Wgraj `CompassPro7X_v1_3_BUILD.yml` do `.github/workflows/` na tej samej gałęzi.
3. Zatwierdź zmiany. Otwórz **Actions → Compass Pro 7X v1.3 PRO → Run workflow** (jeśli nie uruchomił się automatycznie).
4. Po zielonym zakończeniu pobierz artefakt `CompassPro7X_v1_3_PRO_build`.
5. Do lokalnego testu użyj `CompassPro7X_v1_3_fenix7xpro.prg` (lub wariantu `fenix7xpronowifi` dla wersji bez Wi-Fi) w katalogu `GARMIN/APPS` zegarka.
6. `.iq` do Store generuje się tylko, jeśli repozytorium ma sekret `CONNECTIQ_DEVELOPER_KEY_BASE64` z **tym samym trwałym kluczem deweloperskim**, którego użyto do opublikowania tej aplikacji wcześniej. Bez sekretu pipeline tworzy tymczasowy klucz wyłącznie dla testowego PRG.

Zachowany identyfikator aplikacji `93F847268B3845A49991C28B7E590E2A` oraz klucze istniejących zapisów. Nie instaluj równocześnie dwóch różnych buildów z tym samym identyfikatorem.

**Uwaga:** testy lokalne są statyczne i numeryczne; wymagane jest potwierdzenie kompilacji Garmin SDK oraz test płynności, grafik i pamięci na Fenix 7X Pro Solar.

