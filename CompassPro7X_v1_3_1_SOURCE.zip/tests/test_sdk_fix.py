import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
WMM = (ROOT / 'source' / 'WMM2025.mc').read_text()
UI = (ROOT / 'source' / 'CompassScreen.mc').read_text()

class SDKFixTests(unittest.TestCase):
    def test_wmm_fixed_size_type(self):
        for name, size in [('p',169),('dp',169),('sp',13),('cp',13)]:
            self.assertIn(f'var {name} = new [{size}] as Array<Float>;', WMM)
        self.assertNotIn('var p = [];', WMM)
        self.assertNotIn('var sp=[];', WMM)
    def test_wmm_numeric_initialized_prior_to_access(self):
        self.assertIn('p[idx]=0.0; dp[idx]=0.0;', WMM)
        self.assertIn('sp[j]=0.0; cp[j]=0.0;', WMM)
        self.assertLess(WMM.index('p[idx]=0.0;'), WMM.index('p[0]=1.0'))
    def test_sincos_fixed_buffers(self):
        self.assertIn('var _ticksSin = new [48] as Array<Float>;', UI)
        self.assertIn('var _ticksCos = new [48] as Array<Float>;', UI)
        self.assertIn('_ticksSin[i] = M.sin(r);', UI)
        self.assertIn('_ticksCos[i] = M.cos(r);', UI)
        self.assertNotIn('_ticksSin.add(', UI)
    def test_id_and_app_type_preserved(self):
        m=(ROOT/'manifest.xml').read_text()
        self.assertIn('version="1.3.1"',m)
        self.assertIn('type="watch-app"',m)
        self.assertIn('93F847268B3845A49991C28B7E590E2A',m)

if __name__ == '__main__': unittest.main()
