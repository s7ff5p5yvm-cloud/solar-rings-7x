using Toybox.Application as App;
using Toybox.WatchUi as Ui;

class CompassProApp extends App.AppBase {
    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        var face = new CompassScreen();
        return [face, new CompassKeys(face)];
    }
}
