# Compass Pro 7X v1.3.1 — naprawa kompilacji SDK 9.3.0

Poprawka na podstawie pełnego logu GitHub Actions #45826293972.

- WMM2025.mc: `p`, `dp` mają rozmiar 169, a `sp`, `cp` rozmiar 13; wszystkie
  tablice są jawnie deklarowane jako `Array<Float>` i inicjowane wartościami 0.0.
  Usuwa błędy statycznej analizy `Array index is out of bounds`.
- CompassScreen.mc: 48-elementowe bufory `sin/cos` mają stały rozmiar,
  z jawnym `Array<Float>`; usuwa ostrzeżenia typowania w pętli rysowania.
- Numer wersji 1.3.1, ten sam identyfikator aplikacji i te same klucze
  danych użytkownika. Bez zmian w obsłudze azymutów, WMM i częstotliwości.
- To poprawka kodu na podstawie logu: aktualny SDK nie jest zainstalowany
  w środowisku lokalnym, więc zgodność trzeba jeszcze sprawdzić w GitHub Actions.

**Instalacja:** źródłowy ZIP do katalogu głównego repozytorium, workflow
`.github/workflows/CompassPro7X_v1_3_1_BUILD.yml`. Nie zastępuj ZIP-a v1.3;
nowa wersja ma osobne nazwy. `Actions` -> nowy workflow -> `Run workflow`.
W artefakcie szukaj `.prg`; `.iq` powstaje tylko z podpisem istniejącym
kluczem produkcyjnym.
