# Compass Pro 7X — v1.3.0 PRO

Samodzielna aplikacja (`watch-app`) dla **Garmin Fenix 7X Pro Solar**. Jest niezależna od tarczy Solar Rings i zachowuje identyfikator aplikacji z wersji 1.1 (`93F847268B3845A49991C28B7E590E2A`), dzięki czemu zapisane azymuty pozostają pod tymi samymi kluczami pamięci.

## Co nowego w wersji PRO

- Pełnoekranowa, obracająca się róża kompasu dopasowana do okrągłego ekranu MIP 280×280.
- Duży bieżący azymut na środku; biała stała strzałka oznacza kierunek górnej krawędzi zegarka.
- **Czerwone N = północ** odniesienia widocznego na dole (TRUE lub MAG). **Zielona kropka = zapisany cel/azymut**.
- Kontrastowy obszar prowadzenia: CEL + wskazówka PRAWO/LEWO/NA KIERUNKU; żadnych nachodzących na siebie instrukcji.
- SMOOTH odczytuje kierunek co 100 ms (teoretycznie 10/s), TURBO co 80 ms (12,5/s), ECO co 700 ms; brak niepotrzebnego rysowania w bezruchu.
- Pięć trwałych slotów; potwierdzenie przed nadpisaniem istniejącego zapisu.
- Precyzyjny edytor azymutu: krok **1° / 10°** albo **1 / 100 mil** (MENU przełącza krok).
- Północ TRUE lub MAG z ręczną korektą albo automatyczną **deklinacją WMM2025**, gdy zegarek udostępnia lokalizację.
- Bez uruchamiania GPS, bez sieci i bez usługi w tle. Do odczytania *ostatniej znanej* lokalizacji potrzeba uprawnienia Positioning; aplikacja wywołuje tylko `Position.getInfo()`, nie `enableLocationEvents()`.

## Jak korzystać

**Kompas (główny ekran):** Biały grot u góry jest kierunkiem celowania. Czerwone N pokazuje północ, a środek pokazuje aktualny azymut. START wybiera bieżący kierunek jako cel i przełącza w tryb prowadzenia. UP otwiera zapisane azymuty, DOWN / MENU menu, BACK zamyka aplikację.

**Prowadzenie:** Zielona kropka na obręczy wskazuje ustawiony cel. Na dole są odczyty CEL i np. PRAWO 17°. Obróć górę zegarka w tę stronę. Napis NA KIERUNKU oznacza, że odchylenie wynosi mniej niż 2°. UP/DOWN zmienia cel o 1° (albo 1 mil). START otwiera menu, BACK wraca do kompasu.

**Menu:** Możesz zapisać cel do jednego z pięciu miejsc, ustawić go ręcznie, załadować zapis, wyczyścić bieżący cel, przejść do ustawień i pomocy. W edytorze UP/DOWN zmienia wartość, MENU przełącza krok, START zatwierdza, BACK rezygnuje. Zapis do zajętego slotu wymaga dodatkowego START.

**Północ TRUE / MAG:** Sensor oraz rezerwowy odczyt systemowy przekazują **azymut TRUE**. MAG powstaje z przeliczenia `TRUE − deklinacja`. Wszystkie zapisy w pamięci pozostają w TRUE, dzięki czemu zmiana trybu nie przekręca zapamiętanych celów.

**Deklinacja AUTO:** W ustawieniach wybierz POLNOC: MAG i DEKLINACJA: AUTO. Model WMM2025 obliczy korektę na podstawie ostatniej dostępnej pozycji z Garmina oraz bieżącej daty (2025–2029). W ustawieniach „ODSWIEZ POZYCJE” ponownie odczytuje ostatnią dostępną pozycję — **nie uruchamia modułu GPS**. Jeżeli brak pozycji, model zgłasza niepewne dane lub model wygaśnie, program **nie udaje MAG**: wyświetla TRUE / AUTO BRAK i ostrzeżenie. Można wtedy wybrać DEKLINACJA: RECZNA i ustawić lokalną wartość, dodatnią na wschód (E+), ujemną na zachód (W-).

Wartość z WMM jest szacunkiem dla wskazanego miejsca i daty. Jeśli zegarek ma bardzo starą ostatnią lokalizację (np. z innego kraju), wynik może być nieodpowiedni. W menu podawany jest stan „OST. GPS”; przed wymagającą dokładności nawigacją porównaj z mapą lub skalibrowanym kompasem.

**Jednostki:** 360° albo 6400 mil (przybliżenie zaokrąglane do pełnego mil).

**Kalibracja:** Jeżeli azymut jest błędny, otwórz fabryczną aplikację Kompas Garmina i przeprowadź kalibrację. Trzymaj zegarek z dala od silnych magnesów i dużych metalowych elementów. Wskaźnik SENSOR oznacza dostępny odczyt sensora, SYSTEM to odczyt rezerwowy (może nie być aktualny na postoju).

## Wydajność i bateria

Uruchomiona aplikacja korzysta z czujnika i rysuje ekran. Domyślnie SMOOTH odpytuje kierunek co 100 ms, TURBO co 80 ms, ECO co 700 ms; gdy kierunek się nie zmienia, pomijane są niektóre pełne aktualizacje ekranu. W menu i po zamknięciu timery są zatrzymane. Maksymalna szybkość aktualizacji zależy od czujnika i rzeczywistego czasu rysowania. Obliczenie WMM2025 odbywa się tylko przy uruchomieniu MAG AUTO / odświeżeniu lokalizacji, **nigdy** w pętli renderowania.

Nie ma wiarygodnego oszacowania „% baterii na godzinę” bez pomiaru na fizycznym zegarku. Aplikacja nie zmienia poboru energii Solar Rings, kiedy jest zamknięta.

## Dostępność i ograniczenia

- Model WMM2025 jest ważny do końca 2029 r.; po tym okresie trzeba dołączyć nowy model.
- W obszarach o bardzo słabym poziomym polu magnetycznym (<6000 nT) AUTO jest wyłączane ze względów jakościowych.
- Kompas zależy od odczytu sensorów udostępnionych przez Connect IQ i ich kalibracji; nie jest instrumentem certyfikowanym. Nie powinien być jedynym źródłem orientacji w terenie.
- Manifest żąda uprawnień `Sensor` i `Positioning`, ale aplikacja nie włącza GPS i nie wysyła współrzędnych.
- Interfejs użytkownika jest w języku polskim.
- **Status:** przygotowany kod i testy lokalne; kompilacja w Garmin Connect IQ SDK oraz test UI na Fenix 7X Pro są do przeprowadzenia przez workflow i instalację PRG.

## Źródła techniczne

- [Garmin `Sensor.Info.heading` — TRUE](https://developer.garmin.com/connect-iq/api-docs/Toybox/Sensor/Info.html)
- [Garmin `Position.getInfo()` i `QUALITY_LAST_KNOWN`](https://developer.garmin.com/connect-iq/api-docs/Toybox/Position.html)
- [NOAA/NCEI WMM2025 — model geomagnetyczny 2025–2030](https://www.ncei.noaa.gov/products/world-magnetic-model)
- Model obliczeniowy wykorzystuje komplet 90 współczynników WMM2025 stopnia/rzędu 12, przeliczonych na postać niesznormalizowaną na etapie budowania źródeł. Jest oparty na algorytmie NOAA WMM.

## Obsługa profili płynności
W USTAWIENIACH wybierz PŁYNNOŚĆ i naciśnij START, aby przełączać: SMOOTH → TURBO → ECO. SMOOTH daje dobry kompromis, TURBO priorytetuje responsywność, ECO oszczędza energię w trakcie korzystania z aplikacji. Interwały nie są gwarantowaną liczbą klatek.

**Ograniczenia:** działanie czujnika oraz dokładność deklinacji wymagają testu na zegarku. GPS nie jest samodzielnie uruchamiany, więc AUTO MAG może wymagać wcześniej pobranej lokalizacji Garmin.

## Korekty niezawodności v1.3
- USUN CEL usuwa wartość także z trwałego `Application.Storage` poprzez `deleteValue()`; nie wraca po ponownym otwarciu.
- AUTO MAG używa wyłącznie pozycji z datą pomiaru nie starszą niż 7 dni. Stary lub niedostępny fix = TRUE i komunikat o braku AUTO MAG. Używanie ostatniej dostępnej pozycji **nie włącza GPS**. Gdy ktoś przemieścił się daleko od ostatniego fixu, powinien odświeżyć GPS w fabrycznej aplikacji.
- 80/100 ms to okres timera, a nie zmierzona liczba faktycznych odczytów magnetometru lub klatek.
- Nie testowano kompilacji Monkey C ani działania na rzeczywistym zegarku w środowisku tworzenia archiwum; potrzebny zielony build GitHub Actions.
