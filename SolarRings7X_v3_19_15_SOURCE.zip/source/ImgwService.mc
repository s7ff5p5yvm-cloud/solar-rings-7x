using Toybox.System as Sys;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Application.Storage as Storage;
using Toybox.Time as Time;
using Toybox.Application.Properties as Props;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as PersistedContent;

// IMGW beta: county TERYT from GUGiK ULDK (two HTTPS requests per refresh).
// Background service cannot enable GPS. The face stores a recent GPS fix.
// Privacy: coordinates are sent to GUGiK for geocoding; IMGW receives no coords.
(:background)
class ImgwServiceV318 extends Sys.ServiceDelegate {
    var _county;
    var _lat;
    var _lon;
    // HTTP error (code 6/8) or exact GUGiK payload validation reason (code 7).
    var _httpStatus;

    function initialize() {
        ServiceDelegate.initialize();
        _county = null;
        _lat = 0.0;
        _lon = 0.0;
        _httpStatus = 0;
    }

    // Missing or stale location/network => no warning, not a false all-clear.
    // Status: 1 active alert, 2 verified no alert, 3 no GPS, 4 stale GPS,
    // 5 outside Poland, 6 county HTTP, 7 county format,
    // 8 IMGW HTTP, 9 IMGW format, 10 local processing error, 13 stale feed.
    // 14 test 4A: text/plain GitHub probe passed; 15 test 4B: compact JSON parsed.
    function stop(code) {
        var county = _county == null ? "" : _county;
        var networkDetail = (code == 6 || code == 7 || code == 8) ? _httpStatus : 0;
        Bg.exit([county, networkDetail, 0, Time.now().value(), _lat, _lon, code]);
    }

    // Shared base URL; GitHub workflow replaces ONE placeholder in the
    // compile-only copy. The two test stages do not contact GUGiK,
    // do not require GPS and never produce a weather all-clear.
    function smallFeedUrl(fileName) {
        return "https://raw.githubusercontent.com/__GITHUB_OWNER_REPO__/imgw-feed/feed/"
            + fileName;
    }

    function beginTextProbe() {
        _county = "1261"; // Fixed diagnostic probe for Krakow, never used as GPS county.
        Comm.makeWebRequest(smallFeedUrl("health.txt"), null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN },
            method(:onTextProbeResponse));
    }

    function beginJsonProbe() {
        _county = "1261"; // Fixed diagnostic province 12; NO GUGiK lookup here.
        Comm.makeWebRequest(smallFeedUrl("12.json"), null,
            { :method => Comm.HTTP_REQUEST_METHOD_GET,
              :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
            method(:onJsonProbeResponse));
    }

    function onTextProbeResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
            if (!(payload instanceof Lang.String) ||
                payload.find("IMGW_FEED_OK") != 0) { stop(9); return; }
            Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 14]);
        } catch (e) { stop(10); }
    }

    function onJsonProbeResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
            if (!(payload instanceof Lang.Dictionary) || payload["v"] != 1) { stop(9); return; }
            var when = payload["ts"];
            var alerts = payload["a"];
            if (!(when instanceof Lang.Number) || !(alerts instanceof Lang.Dictionary)) { stop(9); return; }
            var age = Time.now().value() - when;
            if (age < -300 || age > 7200) { stop(13); return; }
            // Only JSON transport + minimal schema: no county matching, no icons.
            Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 15]);
        } catch (e) { stop(10); }
    }

    function onTemporalEvent() {
        try {
            if (Props.getValue("imgwOnV317") != true) { stop(10); return; }
            var stage = Props.getValue("imgwTestStageV3194");
            if (stage == null) { stage = 0; }
            // Isolate the scheduler itself. No GPS, no network, no JSON.
            if (stage == 2) {
                Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 11]);
                return;
            }
            // 4A (value 5): one raw GitHub text request, no JSON/GPS/GUGiK.
            if (stage == 5) { beginTextProbe(); return; }
            // 4B (value 6): one compact GitHub JSON request, no GPS/GUGiK.
            if (stage == 6) { beginJsonProbe(); return; }
            if (stage != 3 && stage != 4) { stop(10); return; }
            var loc = Storage.getValue("imgwLocV318");
            if (loc == null || !(loc instanceof Lang.Array) || loc.size() < 3) { stop(3); return; }
            var age = Time.now().value() - loc[2];
            if (age < 0 || age > 21600) { stop(4); return; } // max 6-hour-old GPS fix
            _lat = loc[0].toFloat();
            _lon = loc[1].toFloat();
            if (_lat < 49.0 || _lat > 55.1 || _lon < 14.0 || _lon > 24.3) { stop(5); return; }
            // Official ULDK. WKT EPSG:4326 order is longitude,latitude.
            var coords = _lon.format("%.5f") + "," + _lat.format("%.5f") + ",4326";
            // Use the documented ULDK GET URL directly. A fixed set of
            // parameter names and validated numeric coordinates means no
            // query dictionary transformation is needed here.
            var url = "https://uldk.gugik.gov.pl/?request=GetCountyByXY&xy="
                + coords + "&result=teryt";
            Comm.makeWebRequest(url, null,
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN },
                method(:onCountyResponse));
        } catch (e) { stop(10); }
    }

    // GUGiK ULDK uses a plain text status line and a TERYT value on
    // the following line. Validate strictly, but accept LF or CRLF and
    // harmless whitespace before the TERYT code.
    // Diagnostic reason on code 7 (FORMAT):
    // F1 empty; F2 non-string; F3 too short; F4 no newline;
    // Hxx.xx unexpected first line: leading Unicode codepoints in hex;
    // F6 missing code; F7 non-digit code.
    // Do not interpret any nonzero ULDK service status as successful.
    function parseCounty(raw) {
        _httpStatus = 0;
        if (raw == null) { _httpStatus = 1; return null; }
        if (!(raw instanceof Lang.String)) { _httpStatus = 2; return null; }
        if (raw.length() < 2) { _httpStatus = 3; return null; }
        var nl = raw.find("\n");
        if (nl == null) { _httpStatus = 4; return null; }
        var header = raw.substring(0, nl);
        // Accept harmless ASCII whitespace around the status, but require
        // the complete first line to be exactly 0 afterwards.
        // The status must be exactly the ASCII digit 0 after removing only
        // the recognized BOM/invisible separators from the text response.
        // Compare numeric Unicode codepoints; Monkey C does not support
        // backslash-u escapes in source string literals.
        var status = "";
        var statusChars = header.toCharArray();
        for (var h = 0; h < statusChars.size(); h++) {
            var cp = statusChars[h].toNumber();
            if (cp != 32 && cp != 9 && cp != 13 &&
                cp != 0xFEFF && cp != 0x00A0 &&
                cp != 0x200B && cp != 0x2060) {
                status += statusChars[h].toString();
            }
        }
        // IMPORTANT: Monkey C compares String references with ==/!=.
        // Compare contents with equals(); H30 confirmed the server sends '0'.
        // A correct status must be recognized even when rebuilt char by char.
        if (!status.equals("0")) {
            // Preserve a tiny, ASCII-only sample of the server's first line.
            // This exposes e.g. status 1/-1 or HTML errors directly on the
            // watch, without logging coordinates or showing a false OK.
            var preview = "";
            for (var k = 0; k < status.length() && preview.length() < 4; k++) {
                var x = status.substring(k, k + 1);
                if ("0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".find(x) != null) {
                    preview += x;
                }
            }
            // For an unexpected status line report its ACTUAL character codes.
            // The previous F5-0 lost invisible/control characters and was
            // impossible to distinguish from a genuine success header.
            // Up to 3 hexadecimal code points are enough to identify BOM,
            // CR/LF, NUL, control characters, or a different service status.
            // No coordinates or sensitive data are displayed/stored.
            var hexHeader = "H";
            var count = statusChars.size();
            if (count > 3) { count = 3; }
            for (var j = 0; j < count; j++) {
                if (j > 0) { hexHeader += "."; }
                hexHeader += statusChars[j].toNumber().format("%X");
            }
            if (count == 0) { hexHeader += "EMPTY"; }
            _httpStatus = hexHeader;
            return null;
        }
        var pos = nl + 1;
        while (pos < raw.length()) {
            var ch = raw.substring(pos, pos + 1);
            var chCode = ch.toCharArray()[0].toNumber();
            if (chCode != 13 && chCode != 10 && chCode != 32 && chCode != 9 &&
                chCode != 0xFEFF && chCode != 0x00A0 &&
                chCode != 0x200B && chCode != 0x2060) { break; }
            pos++;
        }
        if (pos + 4 > raw.length()) { _httpStatus = 6; return null; }
        var code = raw.substring(pos, pos + 4);
        for (var i = 0; i < 4; i++) {
            if ("0123456789".find(code.substring(i, i + 1)) == null) {
                _httpStatus = 7;
                return null;
            }
        }
        // Check the following character so malformed 5+-digit IDs are
        // not silently mapped to the wrong district.
        if (pos + 4 < raw.length() &&
            "0123456789".find(raw.substring(pos + 4, pos + 5)) != null) {
            _httpStatus = 7;
            return null;
        }
        return code;
    }

    function onCountyResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { _httpStatus = responseCode; stop(6); return; }
            _county = parseCounty(payload);
            if (_county == null) { stop(7); return; }
            if (Props.getValue("imgwTestStageV3194") == 3) {
                // GUGiK verified. End before contacting IMGW.
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 12]);
                return;
            }
            // Do NOT download IMGW's entire national JSON on Garmin. The
            // background task has only ~32 KB heap, and Connect IQ allocates
            // both the HTTP payload and its parsed Dictionary before callbacks.
            // GitHub Actions converts the official data into 16 tiny feeds.
            // A request reveals only the voivodeship prefix, never GPS coords.
            var feedUrl = smallFeedUrl(_county.substring(0, 2) + ".json");
            Comm.makeWebRequest(feedUrl, null,
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
                method(:onWarningsResponse));
        } catch (e) { stop(10); }
    }

    // Tiny, validated JSON replaces the national IMGW payload. Format:
    // {"v":1, "ts":<Unix epoch>, "a":{"1261":[2,4], ...}}
    // An absent county is safe to treat as 'no alerts' ONLY if this whole feed
    // is valid and fresh. 0/invalid/stale data is never silently an all-clear.
    function onWarningsResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        if (responseCode != 200) { _httpStatus = responseCode; stop(8); return; }
        if (payload == null) { stop(9); return; }
        try { processWarnings(payload); }
        catch (e) { stop(10); }
    }

    function processWarnings(body as Lang.Object) as Void {
        try {
            if (!(body instanceof Lang.Dictionary)) { stop(9); return; }
            if (body["v"] != 1) { stop(9); return; }
            var when = body["ts"];
            var alerts = body["a"];
            if (!(when instanceof Lang.Number) ||
                !(alerts instanceof Lang.Dictionary)) { stop(9); return; }
            var age = Time.now().value() - when;
            // Publishing pauses/errors must never appear as no warnings.
            if (age < -300 || age > 7200) { stop(13); return; }
            var match = alerts[_county];
            if (match == null) {
                Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 2]);
                return;
            }
            if (!(match instanceof Lang.Array) || match.size() != 2 ||
                !(match[0] instanceof Lang.Number) ||
                !(match[1] instanceof Lang.Number)) { stop(9); return; }
            var level = match[0];
            var kind = match[1];
            if (level < 1 || level > 3 || kind < 1 || kind > 13) {
                stop(9); return;
            }
            Bg.exit([_county, level, kind, Time.now().value(), _lat, _lon, 1]);
        } catch (e) { stop(10); }
    }
}
