from pathlib import Path
r=Path('/tmp/garmin3214')
p=r/'source/SolarRings7X.mc';s=p.read_text()
# Introduce approximate weather fallback without inventing live GPS.
a=s.index('    // A watch face cannot start GPS or use direct live-position queries reliably.')
b=s.index('    // Take another look immediately when returning from a GPS activity,',a)
s=s[:a]+'''    // G3 is a missing Activity.Info.currentLocation, not a request to enable GPS.
    // 1=device GPS; 2=missing Activity.Info; 3=no GPS/weather position;
    // 4=out of Poland; 5=exception; 6=approximate weather station;
    // 7=cached GPS still valid (its timestamp is NOT refreshed).
    function imgwGpsReport(code) {
        try {
            var old = Storage.getValue("imgwGpsReasonV3213");
            if (old != code) { Storage.setValue("imgwGpsReasonV3213", code); }
        } catch (e) { }
    }

    function saveImgwLocation(lat, lon, source) {
        if (lat < 49.0 || lat > 55.1 || lon < 14.0 || lon > 24.3) {
            imgwGpsReport(4); return false;
        }
        var now = Time.now().value();
        var old = Storage.getValue("imgwLocV318");
        var update = true;
        if (old != null && old instanceof Lang.Array && old.size() >= 3 &&
            (old[0] instanceof Lang.Number || old[0] instanceof Lang.Float) &&
            (old[1] instanceof Lang.Number || old[1] instanceof Lang.Float) &&
            old[2] instanceof Lang.Number) {
            var oldSource = old.size() >= 4 ? old[3] : 0;
            update = oldSource != source || now < old[2] ||
                now - old[2] >= 900 ||
                Math.abs(old[0] - lat) > 0.002 ||
                Math.abs(old[1] - lon) > 0.002;
        }
        if (update) { Storage.setValue("imgwLocV318", [lat, lon, now, source]); }
        imgwGpsReport(source == 3 ? 6 : 1);
        return true;
    }

    function captureImgwLocation() {
        if (!srSetting("imgwOnV317", false) ||
            srSetting("imgwTestStageV3194", 0) == 0) { return; }
        try {
            var info = Activity.getActivityInfo();
            if (info != null && info.currentLocation != null) {
                var gps = info.currentLocation.toDegrees();
                if (gps != null && gps.size() >= 2) {
                    saveImgwLocation(gps[0].toFloat(), gps[1].toFloat(), 0);
                    return;
                }
            }
            // Reuse a real GPS position for at most 6 hours without silently
            // extending the time of the fix when currentLocation is null.
            var old = Storage.getValue("imgwLocV318");
            if (old != null && old instanceof Lang.Array && old.size() >= 3 &&
                (old.size() < 4 || old[3] == 0) &&
                old[2] instanceof Lang.Number) {
                var age = Time.now().value() - old[2];
                if (age >= 0 && age <= 21600) { imgwGpsReport(7); return; }
            }
            // Garmin Weather may provide a WEATHER STATION location. It is
            // approximate, not the watch's exact GPS and must be so labeled.
            try {
                var wx = Weather.getCurrentConditions();
                if (wx != null && wx.observationLocationPosition != null &&
                    wx.observationTime != null) {
                    var ageWx = Time.now().value() - wx.observationTime.value();
                    if (ageWx >= 0 && ageWx <= 7200) {
                        var approximate = wx.observationLocationPosition.toDegrees();
                        if (approximate != null && approximate.size() >= 2 &&
                            saveImgwLocation(approximate[0].toFloat(),
                                             approximate[1].toFloat(), 3)) { return; }
                    }
                }
            } catch (wxErr) { }
            imgwGpsReport(info == null ? 2 : 3);
        } catch (e) { imgwGpsReport(5); }
    }

'''+s[b:]
# Full alert icons should validate manual county by TERYT and response age,
# not by nonexistent GPS. Preserve strict GPS location validation in automatic.
a=s.index('    function activeImgwAlert(snapshot) {');b=s.index('    // Opt-in live diagnostics.',a)
s=s[:a]+'''    function activeImgwAlert(snapshot) {
        if (!srSetting("imgwOnV317", false) ||
            srSetting("imgwTestStageV3194", 0) != 4 ||
            srSetting("imgwDiagnosticsV3193", false) ||
            !srSetting("imgwIconsV3203", false)) { return null; }
        var source = 0;
        if (snapshot != null && snapshot instanceof Lang.Array && snapshot.size() >= 9) {
            source = snapshot[8];
        }
        // Source 2 (manual) and 1 (last county) have no live coordinates.
        var requirePosition = source == 0 || source == 3;
        var d = verifiedImgwResult(4, requirePosition, snapshot);
        if (d == null || d[6] != 1) { return null; }
        if (source == 2) {
            var manual = srSetting("imgwFallbackCountyV3213", 0);
            if (!(manual instanceof Lang.Number) ||
                !manual.format("%04d").equals(d[0])) { return null; }
        }
        if (source == 1) {
            try {
                var cached = Storage.getValue("imgwLastCountyV3213");
                if (cached == null || !(cached instanceof Lang.Array) ||
                    cached.size() < 4 || !(cached[0] instanceof Lang.String) ||
                    !cached[0].equals(d[0]) ||
                    !(cached[3] instanceof Lang.Number) ||
                    Time.now().value() - cached[3] > 86400) { return null; }
            } catch (e) { return null; }
        }
        return d;
    }

'''+s[b:]
# Reject mismatched coordinate source for approximate-position result
needle='''                // Treat movement as a reason to RECHECK the county. Never'''
assert needle in s
s=s.replace(needle,'''                var resultSource = d.size() >= 9 ? d[8] : 0;
                var observationSource = loc.size() >= 4 ? loc[3] : 0;
                if (resultSource != observationSource) { return 9; }
                // Treat movement as a reason to RECHECK the county. Never''')
# source labels
s=s.replace('(result[8] == 1 || result[8] == 2)) {\n                        var pfx = result[8] == 1 ? "OST" : "RECZ";',
            '(result[8] == 1 || result[8] == 2 || result[8] == 3)) {\n                        var pfx = result[8] == 1 ? "OST" : (result[8] == 2 ? "RECZ" : "PRZYBL");')
s=s.replace('(imgwSnapshot[8] == 1 || imgwSnapshot[8] == 2) &&','(imgwSnapshot[8] == 1 || imgwSnapshot[8] == 2 ||\n             imgwSnapshot[8] == 3) &&')
s=s.replace('var srcLabel = imgwSnapshot[8] == 1 ? "OSTATNI" : "RECZNY";',
            'var srcLabel = imgwSnapshot[8] == 1 ? "OSTATNI" : (imgwSnapshot[8] == 2 ? "RECZNY" : "PRZYBL.");')
s=s.replace('(response[8] == 1 || response[8] == 2) &&','(response[8] == 1 || response[8] == 2 ||\n                     response[8] == 3) &&')
s=s.replace('shortStatus = response[8] == 1 ? "T4 O" : "T4 M";',
            'shortStatus = response[8] == 1 ? "T4 O" : (response[8] == 2 ? "T4 M" : "T4 P");')
# An explicit local preview of all warning icons, including wind and ice.
needle='''    function imgwAlert(dc, x, y, category, level) {'''
assert needle in s
s=s.replace(needle,'''    function previewImgwName(kind) {
        if (kind == 1) { return "BURZA"; }
        if (kind == 2) { return "WIATR"; }
        if (kind == 3) { return "DESZCZ"; }
        if (kind == 4) { return "SNIEG"; }
        if (kind == 5) { return "OBLODZENIE"; }
        if (kind == 6) { return "MARZNACE"; }
        if (kind == 7) { return "UPAL"; }
        if (kind == 8) { return "MROZ"; }
        if (kind == 9) { return "PRZYMROZEK"; }
        if (kind == 10) { return "MGLA"; }
        if (kind == 11) { return "ZAMIEC"; }
        if (kind == 12) { return "ROZTOPY"; }
        return "INNE";
    }

'''+needle)
needle='''        var imgw = isTemp ? activeImgwAlert(imgwSnapshot) : null;
        var hasImgw = (imgw != null) && isTemp;'''
assert needle in s
s=s.replace(needle,'''        var previewKind = srSetting("imgwIconPreviewV3214", 0);
        var iconPreview = isTemp && previewKind instanceof Lang.Number &&
                          previewKind >= 1 && previewKind <= 13;
        var imgw = isTemp ? activeImgwAlert(imgwSnapshot) : null;
        if (iconPreview) {
            var previewLevel = srSetting("imgwIconPreviewLevelV3214", 1);
            if (!(previewLevel instanceof Lang.Number) || previewLevel < 1 ||
                previewLevel > 3) { previewLevel = 1; }
            imgw = ["TEST", previewLevel, previewKind];
        }
        var hasImgw = (imgw != null) && isTemp;''')
needle='''        if (diag != null) {
            // Fixed-size native font: avoid extra scalable-font allocations.'''
assert needle in s
s=s.replace(needle,'''        // Preview is DRAW ONLY. Always label it TEST, even if diagnostics
        // are enabled; it never represents a real meteorological warning.
        if (iconPreview) {
            diag = null;
            lowerLabel = "TEST: " + previewImgwName(previewKind);
            lowerColor = Gfx.COLOR_YELLOW;
        }
        if (diag != null) {
            // Fixed-size native font: avoid extra scalable-font allocations.''')
# do not display stale manual warning text after manual county changed
needle='''            srSetting("imgwTestStageV3194", 0) == 4) {'''
assert needle in s
s=s.replace(needle,'''            srSetting("imgwTestStageV3194", 0) == 4 &&
            imgwValidationProblem(4, imgwSnapshot[8] == 3, imgwSnapshot) == 0 &&
            (imgwSnapshot[8] != 2 ||
             srSetting("imgwFallbackCountyV3213", 0).format("%04d").equals(imgwSnapshot[0]))) {''',1)
p.write_text(s)
# Service: honor manually selected county even when a prior GPS position exists
p=r/'source/ImgwService.mc';s=p.read_text()
needle='''            // Isolate the scheduler itself. No GPS, no network, no JSON.'''
assert needle in s
s=s.replace(needle,'''            // User-selected county is explicit and overrides a cached GPS
            // solely in full mode 4. Source 2 is clearly labeled manual.
            if (stage == 4) {
                var manualTestCounty = Props.getValue("imgwFallbackCountyV3213");
                if (manualTestCounty instanceof Lang.Number &&
                    manualTestCounty >= 1000 && manualTestCounty <= 9999) {
                    _county = manualTestCounty.format("%04d");
                    _source = 2;
                    _lat = 0.0;
                    _lon = 0.0;
                    beginUnifiedImgwRequest(11);
                    return;
                }
            }
'''+needle)
needle='''            _lat = loc[0].toFloat();
            _lon = loc[1].toFloat();'''
assert needle in s
s=s.replace(needle,'''            _lat = loc[0].toFloat();
            _lon = loc[1].toFloat();
            _source = loc.size() >= 4 && loc[3] == 3 ? 3 : 0;''')
p.write_text(s)
# Settings
p=r/'resources/settings/properties.xml';s=p.read_text();s=s.replace('''  <property id="imgwFallbackCountyV3213" type="number">0</property>''','''  <property id="imgwFallbackCountyV3213" type="number">0</property>
  <property id="imgwIconPreviewV3214" type="number">0</property>
  <property id="imgwIconPreviewLevelV3214" type="number">1</property>''');p.write_text(s)
p=r/'resources/settings/settings.xml';s=p.read_text();needle='''  <setting propertyKey="@Properties.imgwFallbackCountyV3213"''';assert needle in s
addition='''  <setting propertyKey="@Properties.imgwIconPreviewV3214" title="@Strings.title_imgwIconPreviewV3214">
    <settingConfig type="list">
'''
for i in range(14):addition+=f'      <listEntry value="{i}">@Strings.imgwPreview_{i}</listEntry>\n'
addition+='''    </settingConfig>
  </setting>
  <setting propertyKey="@Properties.imgwIconPreviewLevelV3214" title="@Strings.title_imgwIconPreviewLevelV3214">
    <settingConfig type="list">
'''
for i in (1,2,3):addition+=f'      <listEntry value="{i}">@Strings.imgwPreviewLevel_{i}</listEntry>\n'
addition+='''    </settingConfig>
  </setting>
'''
p.write_text(s.replace(needle,addition+needle))
p=r/'resources/strings.xml';s=p.read_text();name={0:'Wylacz podglad',1:'Burza',2:'Silny wiatr',3:'Intensywny deszcz',4:'Intensywne opady sniegu',5:'Oblodzenie',6:'Opady marznace',7:'Upal',8:'Silny mroz',9:'Przymrozki',10:'Mgla',11:'Zawieje i zamiecie',12:'Roztopy',13:'Inne'}
addition='''  <string id="title_imgwIconPreviewV3214">IMGW: podglad ikony TEST (bez GPS)</string>
  <string id="title_imgwIconPreviewLevelV3214">IMGW: stopien testowanej ikony</string>
'''
for i,n in name.items():addition+=f'  <string id="imgwPreview_{i}">{n}</string>\n'
for i in (1,2,3):addition+=f'  <string id="imgwPreviewLevel_{i}">Stopien {i}</string>\n'
p.write_text(s.replace('</strings>',addition+'</strings>'))
p=r/'manifest.xml';p.write_text(p.read_text().replace('version="3.21.3"','version="3.21.4"'))
p=r/'check_version.py';p.write_text(p.read_text().replace('3.21.3','3.21.4'))
# Old tests are kept, but update previous test assumptions about G3 path.
p=r/'tests/test_v3213.py';s=p.read_text().replace('3.21.3','3.21.4').replace("self.assertIn('activity.currentLocation == null) { imgwGpsReport(3); return; }',face)","self.assertIn('info != null && info.currentLocation != null',face)").replace("self.assertIn('now - last[2] >= 900',face)","self.assertIn('now - old[2] >= 900',FACE)");p.write_text(s)
p=r/'tests/test_3213_regressions.py';s=p.read_text().replace("self.assertIn('imgwGpsReport(3); return;',face)","self.assertIn('imgwGpsReport(info == null ? 2 : 3);',face)");p.write_text(s)
print('PATCH OK')
