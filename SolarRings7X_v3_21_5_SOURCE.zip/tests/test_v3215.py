import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
class RegressionChecks(unittest.TestCase):
    def test_manifest(self):
        self.assertIn('version="3.21.5"', (ROOT/'manifest.xml').read_text())
    def test_manual_does_not_use_weather_position(self):
        s=(ROOT/'source/SolarRings7X.mc').read_text()
        func=s[s.index('function captureImgwLocation()'):s.index('// Take another look immediately')]
        self.assertIn('Storage.deleteValue("imgwLocV318")',func)
        self.assertNotIn('Weather.getCurrentConditions()',func)
    def test_manual_mode_no_premature_fetch(self):
        s=(ROOT/'source/ImgwService.mc').read_text()
        func=s[s.index('function onTemporalEvent()'):s.index('function parseCounty(')]
        self.assertNotIn('manualTestCounty',func)
        self.assertIn('tryLastCountyWhenGpsMissing()',func)
    def test_manual_precedes_last_cached_county(self):
        s=(ROOT/'source/ImgwService.mc').read_text()
        f=s[s.index('function tryLastCountyWhenGpsMissing()'):s.index('function onTemporalEvent()')]
        self.assertLess(f.index('var manual ='), f.index('var last ='))
        self.assertIn('beginUnifiedImgwRequest(11)', f)
    def test_preview_remains_offline(self):
        s=(ROOT/'source/SolarRings7X.mc').read_text()
        self.assertIn('TEST: ',s)
        self.assertIn('previewImgwName',s)
    def test_resource_xml(self):
        for p in (ROOT/'resources').rglob('*.xml'):
            ET.parse(p)
if __name__=='__main__': unittest.main()
