# Solar Rings 7X v3.21.5 — rollback ryzykownej zmiany

Ta wersja cofa zmianę uruchamiania bezpośredniego pobierania IMGW dla ręcznie wybranego TERYT dodaną w v3.21.4. Przywrócono obsługę z v3.21.3, która wcześniej zwróciła na zegarku `T4 M1261?`.

- Ręczne TERYT ma pierwszeństwo przed pamięcią ostatniego powiatu.
- Podczas ręcznego testu tarcza nie korzysta z GPS ani przybliżonej pozycji stacji pogodowej.
- Zachowano podgląd dowolnych ikon IMGW bez internetu.
- Dla automatycznej lokalizacji Garmin może nadal zwracać G3, ponieważ aplikacja tarczy nie może włączyć odbiornika GPS. Nie udajemy, że ten problem został usunięty.

To wersja ograniczająca regresję, a nie udowodnione usunięcie przyczyny wszystkich wcześniejszych awarii. Testy statyczne nie zastępują Garmin SDK ani logu awarii urządzenia.

Bezpieczna procedura: uruchomić najpierw podgląd ikony przy IMGW wyłączonym; potem IMGW włączony, diagnostyka włączona, ikony wyłączone, TERYT 1261, etap 4 i co 5 minut. Jeśli nastąpi awaria, wyłączyć IMGW i zebrać log Connect IQ; dalsze zgadywanie mija się z celem.
