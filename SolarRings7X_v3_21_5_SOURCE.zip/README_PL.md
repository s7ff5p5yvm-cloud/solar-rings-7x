# Solar Rings 7X v3.21.4 — test ikon i obejście braku GPS (G3)

## Co nowego

1. **Ręczny podgląd ikon IMGW**: w ustawieniach Connect IQ wybierz `IMGW: podglad ikony TEST (bez GPS)`. Dostępne są: burza, silny wiatr, intensywny deszcz, śnieg, oblodzenie, opady marznące, upał, silny mróz, przymrozki, mgła, zamiecie, roztopy i inny alert. `IMGW: stopien testowanej ikony` pozwala wybrać poziom 1, 2 lub 3. Tarcza wyświetla ikonkę **bez potrzeby Internetu, GPS czy rzeczywistego ostrzeżenia** i zawsze podpisuje ją `TEST: ...`. W dolnym polu musi być ustawiona pogoda lub temperatura. Po sprawdzeniu wyłącz podgląd (wartość 0).
2. **Prawdziwe ikony dla ręcznie wybranego powiatu**: włącz IMGW, ustaw tryb `4 - Pelne IMGW`, ustaw `IMGW: powiat awaryjny TERYT` np. `1261` wyłącznie dla miasta Krakowa, włącz opcję `IMGW: pokaz ikony ostrzezen`, wyłącz diagnostykę i podgląd ikon. Rzeczywista ikona pojawi się tylko, jeśli IMGW wydało ważne ostrzeżenie dla wybranego kodu. Napis `RECZNY` rozróżnia je od wyniku ustalonego automatycznie. Kod `0` przywraca wybór automatyczny. Ręcznie wybrany powiat ma pierwszeństwo, kiedy ustawiono kod różny od zera.
3. **G3 — brak `Activity.currentLocation`**: Garmin nie pozwala tarczy włączyć GPS. Jeśli ta pozycja jest niedostępna, najpierw korzystamy z ostatnio zapisanej pozycji zegarka (maksymalnie 6 h, bez fałszywego odświeżania czasu), a gdy jej nie ma — próbujemy odczytać położenie obserwacji z Garmin Weather (maksymalnie 2 h od obserwacji). UWAGA: to może być stacja pogodowa, **nie dokładna pozycja zegarka**. Taki wynik jest oznaczony `PRZYBL.`/`G6` i nie stanowi potwierdzenia bieżących ostrzeżeń w Twoim powiecie. Dalej istnieje opcja ostatniego potwierdzonego przez GUGiK powiatu (do 24 h) lub ręcznego wyboru. Jeśli żadne źródło nie jest dostępne, tarcza nadal pokazuje informację o braku GPS — nie udaje, że działa.

## Budowanie

- Wrzuć `SolarRings7X_v3_21_4_SOURCE.zip` do głównego katalogu repozytorium GitHub.
- Wrzuć `SolarRings7X_v3_21_4_BUILD.yml` do `.github/workflows/` na głównej gałęzi.
- W Actions wybierz `Build Solar Rings 7X v3.21.4` → `Run workflow`.
- Po udanej kompilacji instaluj wynikowy plik IQ na Garminie tak jak dotychczas.

**Kontrola**: lokalne testy sprawdzają kod, strukturę i model danych. Nie są kompilacją Monkey C i nie zastępują testu na zegarku. Tarcza pogodowa nie powinna być jedynym źródłem ostrzeżeń w sytuacjach niebezpiecznych.
