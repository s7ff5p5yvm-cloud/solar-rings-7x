using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;

class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    function getInitialView() { return [new SolarRingsFaceV3()]; }
    function onSettingsChanged() { Ui.requestUpdate(); }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
    }

    // Select genuinely different font sizes for SMALL / NORMAL / LARGE.
    // Always fit the selected font to a reserved box; never draw outside it.
    // IMPORTANT: using a single dynamic largest-fit list made small and
    // large look identical in v3.1. This implementation uses distinct caps.
    function fitScaled(dc, value, x, top, width, height, color, numeric, scale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }

        var isNumber = numeric;
        if (numeric) {
            for (var i = 0; i < str.length(); i++) {
                var character = str.substring(i, i + 1);
                if ("0123456789:".find(character) == null) {
                    isNumber = false;
                    break;
                }
            }
        }
        var fonts;
        if (isNumber) {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale <= 0) {
                fonts = [Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }

        var font = null;
        var glyphH = 0;
        for (var n = 0; n < fonts.size(); n++) {
            var dimensions = dc.getTextDimensions(str, fonts[n]);
            if (dimensions[0] <= width && dimensions[1] <= height) {
                font = fonts[n];
                glyphH = dimensions[1];
                break;
            }
        }
        if (font == null) {
            font = Gfx.FONT_XTINY;
            glyphH = dc.getFontHeight(font);
            // Never truncate digits such as 12345 / 25000.
            if (!isNumber) {
                while (str.length() > 1 &&
                       dc.getTextWidthInPixels(str, font) > width) {
                    str = str.substring(0, str.length() - 1);
                }
            }
        }
        // Prevent Garmin's native font bearings from spilling into adjacent
        // sections even when a model has unusually large font metrics.
        var left = (x - width / 2).toNumber();
        dc.setClip(left, top, width, height);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.drawText(x, top + ((height - glyphH) / 2).toNumber(),
                    font, str, Gfx.TEXT_JUSTIFY_CENTER);
        dc.clearClip();
    }

    function fit(dc, value, x, top, width, height, color, numeric) {
        fitScaled(dc, value, x, top, width, height, color, numeric, 1);
    }


    // Reuse the already tested 3x7 digit raster from the sunrise fields.
    // No system FONT_NUMBER resource is needed to render the main clock.
    // Actual setting values: small = 5 px, medium = 6 px, large = 7 px.
    function drawClock(dc, clock) {
        var sz = srSetting("fontClockV31", 2);
        var pixel = sz <= 0 ? 5 : (sz == 1 ? 6 : 7);
        var value = twoDigits(clock.hour) + ":" + twoDigits(clock.min);
        drawPixelDigits(dc, value, 102, 89, pixel, Gfx.COLOR_WHITE);
    }

    // Narrow 3x7 bitmap digit font used for clock, sunrise, sunset and ring values.
    function miniGlyph(ch) {
        if (ch == "0") { return ["111","101","101","101","101","101","111"]; }
        if (ch == "1") { return ["010","110","010","010","010","010","111"]; }
        if (ch == "2") { return ["111","001","001","111","100","100","111"]; }
        if (ch == "3") { return ["111","001","001","111","001","001","111"]; }
        if (ch == "4") { return ["101","101","101","111","001","001","001"]; }
        if (ch == "5") { return ["111","100","100","111","001","001","111"]; }
        if (ch == "6") { return ["111","100","100","111","101","101","111"]; }
        if (ch == "7") { return ["111","001","001","010","010","010","010"]; }
        if (ch == "8") { return ["111","101","101","111","101","101","111"]; }
        if (ch == "9") { return ["111","101","101","111","001","001","111"]; }
        if (ch == ":") { return ["0","1","1","0","1","1","0"]; }
        return ["000","000","000","000","000","000","000"];
    }

    // Fixed-width 3x7 glyphs. All writes are confined to the intended
    // region; use only filled rectangles so this works without font assets.
    function drawPixelDigits(dc, value, centerX, top, pixel, color) {
        if (value == null || value.length() == 0) { return; }
        var units = 0;
        for (var i = 0; i < value.length(); i++) {
            var g = miniGlyph(value.substring(i, i + 1));
            units += g[0].length() + 1;
        }
        units -= 1;
        var x = (centerX - (units * pixel) / 2).toNumber();
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        for (var k = 0; k < value.length(); k++) {
            var glyph = miniGlyph(value.substring(k, k + 1));
            for (var row = 0; row < 7; row++) {
                var bits = glyph[row];
                for (var col = 0; col < bits.length(); col++) {
                    if (bits.substring(col, col + 1) == "1") {
                        dc.fillRectangle(x + col * pixel, top + row * pixel,
                                         pixel, pixel);
                    }
                }
            }
            x += (glyph[0].length() + 1) * pixel;
        }
    }

    function onlyDigits(str) {
        if (str == null || str.length() == 0) { return false; }
        for (var i = 0; i < str.length(); i++) {
            if ("0123456789".find(str.substring(i, i + 1)) == null) {
                return false;
            }
        }
        return true;
    }
    function drawTopClock(dc, value, center) {
        var sz = srSetting("fontTopV31", 2);
        var pixel = sz <= 0 ? 2 : (sz == 1 ? 3 : 4);
        // Three slots have 70 px each: the largest HH:MM is 68 px wide.
        drawPixelDigits(dc, value, center, 51, pixel, Gfx.COLOR_WHITE);
    }

    // Date uses three explicit, different native font sizes.
    // The two lines are inside a clip with a 3px vertical gutter.
    // Date is always to the RIGHT of the time. Larger font is allowed
    // without using a second line that overlaps the ring row.
    function drawDate(dc, dayLabel, dateLabel) {
        var sz = srSetting("fontDateV31", 2);
        var topFont = Gfx.FONT_TINY;
        var bottomFont = Gfx.FONT_XTINY;
        if (sz == 1) {
            topFont = Gfx.FONT_SMALL;
            bottomFont = Gfx.FONT_TINY;
        } else if (sz >= 2) {
            topFont = Gfx.FONT_MEDIUM;
            bottomFont = Gfx.FONT_SMALL;
        }
        var t = dc.getTextDimensions(dayLabel, topFont);
        var b = dc.getTextDimensions(dateLabel, bottomFont);
        // A native font may be taller on an MIP device; select a
        // guaranteed fall-back, but never let it cover the clock.
        if (t[0] > 62 || t[1] > 27) { topFont = Gfx.FONT_SMALL; }
        if (b[0] > 76 || b[1] > 21) { bottomFont = Gfx.FONT_TINY; }
        dc.setClip(190, 87, 78, 52);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.drawText(229, 87, topFont, dayLabel, Gfx.TEXT_JUSTIFY_CENTER);
        dc.drawText(229, 113, bottomFont, dateLabel, Gfx.TEXT_JUSTIFY_CENTER);
        dc.clearClip();
    }

    function rule(dc, y) {
        dc.setColor(0x555555, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        var left = 28;
        var right = 252;
        if (y >= 245) { left = 74; right = 206; }
        dc.drawLine(left, y, right, y);
    }

    function sunIcon(dc, x, y, settingSun) {
        dc.setColor(settingSun ? Gfx.COLOR_YELLOW : Gfx.COLOR_ORANGE,
                    Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 5, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 9, y, x + 9, y);
        dc.drawLine(x, y - 9, x, y - 6);
        dc.setPenWidth(1);
    }

    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 2, 4);
        dc.fillCircle(x + 4, y - 2, 4);
        dc.fillRectangle(x - 5, y, 10, 4);
        dc.drawLine(x - 7, y + 2, x, y + 9);
        dc.drawLine(x, y + 9, x + 7, y + 2);
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, 7);
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x + 4, y - 2, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // independent pressure-warning bolt, they describe present weather.
    function weatherSymbol(dc, x, y, weather) {
        if (weather == null || weather.condition == null) {
            // Missing weather: neutral outline, no invented condition.
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.drawLine(x, y - 4, x, y + 1);
            dc.drawCircle(x, y + 5, 1);
            dc.setPenWidth(1);
            return;
        }
        var c = weather.condition;
        // Pure sunshine.
        if (c == Weather.CONDITION_CLEAR || c == Weather.CONDITION_FAIR ||
            c == Weather.CONDITION_MOSTLY_CLEAR) {
            dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y - 2, 10);
            dc.drawLine(x, y - 19, x, y - 15);
            dc.drawLine(x, y + 11, x, y + 16);
            dc.drawLine(x - 18, y - 2, x - 14, y - 2);
            dc.drawLine(x + 14, y - 2, x + 18, y - 2);
            dc.drawLine(x - 13, y - 15, x - 10, y - 12);
            dc.drawLine(x + 10, y + 8, x + 13, y + 11);
            dc.drawLine(x + 12, y - 15, x + 9, y - 12);
            dc.drawLine(x - 9, y + 8, x - 12, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Cloud with some sun.
        if (c == Weather.CONDITION_PARTLY_CLOUDY ||
            c == Weather.CONDITION_PARTLY_CLEAR ||
            c == Weather.CONDITION_THIN_CLOUDS) {
            cloud(dc, x, y);
            return;
        }
        // Cloud and precipitation.
        if (c == Weather.CONDITION_RAIN || c == Weather.CONDITION_LIGHT_RAIN ||
            c == Weather.CONDITION_HEAVY_RAIN || c == Weather.CONDITION_DRIZZLE ||
            c == Weather.CONDITION_SCATTERED_SHOWERS || c == Weather.CONDITION_SHOWERS ||
            c == Weather.CONDITION_LIGHT_SHOWERS || c == Weather.CONDITION_HEAVY_SHOWERS ||
            c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN ||
            c == Weather.CONDITION_UNKNOWN_PRECIPITATION) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(0x00AAFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 12, x - 13, y + 18);
            dc.drawLine(x, y + 12, x - 3, y + 18);
            dc.drawLine(x + 10, y + 12, x + 7, y + 18);
            dc.setPenWidth(1);
            return;
        }
        // Snow / wintry conditions.
        if (c == Weather.CONDITION_SNOW || c == Weather.CONDITION_LIGHT_SNOW ||
            c == Weather.CONDITION_HEAVY_SNOW || c == Weather.CONDITION_FLURRIES ||
            c == Weather.CONDITION_CHANCE_OF_SNOW || c == Weather.CONDITION_WINTRY_MIX ||
            c == Weather.CONDITION_RAIN_SNOW || c == Weather.CONDITION_ICE_SNOW ||
            c == Weather.CONDITION_LIGHT_RAIN_SNOW || c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
            c == Weather.CONDITION_FREEZING_RAIN || c == Weather.CONDITION_SLEET ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 11, x - 10, y + 19);
            dc.drawLine(x - 14, y + 15, x - 6, y + 15);
            dc.drawLine(x + 7, y + 11, x + 7, y + 19);
            dc.drawLine(x + 3, y + 15, x + 11, y + 15);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_THUNDERSTORMS ||
            c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
            c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS ||
            c == Weather.CONDITION_TROPICAL_STORM) {
            simpleCloud(dc, x, y - 6);
            stormBolt(dc, x + 2, y + 13);
            return;
        }
        if (c == Weather.CONDITION_FOG || c == Weather.CONDITION_MIST ||
            c == Weather.CONDITION_HAZY || c == Weather.CONDITION_HAZE) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 20, y - 9, x + 16, y - 9);
            dc.drawLine(x - 16, y - 2, x + 20, y - 2);
            dc.drawLine(x - 20, y + 5, x + 15, y + 5);
            dc.drawLine(x - 13, y + 12, x + 20, y + 12);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_WINDY || c == Weather.CONDITION_SQUALL) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 22, y - 5, x + 12, y - 5);
            dc.drawLine(x - 12, y + 3, x + 19, y + 3);
            dc.drawLine(x - 19, y + 11, x + 10, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Overcast / unclassified present weather.
        simpleCloud(dc, x, y);
    }

    function simpleCloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 11, y + 2, 8);
        dc.fillCircle(x + 1, y - 4, 11);
        dc.fillCircle(x + 14, y + 3, 8);
        dc.fillRectangle(x - 17, y + 3, 38, 9);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 35) {
            var currentWeather = null;
            try { currentWeather = Weather.getCurrentConditions(); } catch (e) { }
            var event = nextSunEvent(currentWeather);
            if (event != null) { sunIcon(dc, x, y, event[0]); }
            else { genericIcon(dc, x, y, Gfx.COLOR_LT_GRAY); }
        }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3 || id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { stopwatch(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }

    function topSlot(dc, x, id, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        if (id == 35) {
            var nextEvent = nextSunEvent(weather);
            if (nextEvent != null) { sunIcon(dc, x, 35, nextEvent[0]); }
            else { genericIcon(dc, x, 35, Gfx.COLOR_LT_GRAY); }
        } else {
            drawIcon(dc, x, 35, id, 0x00CCFF);
        }
        var value = d[1];
        if ((id == 14 || id == 15 || id == 35) &&
            value.length() == 5 && value.substring(2, 3) == ":" &&
            value.substring(0, 1) != "-") {
            drawTopClock(dc, value, x);
        } else {
            fitScaled(dc, value, x, 52, 68, 27, Gfx.COLOR_WHITE,
                      false, srSetting("fontTopV31", 2));
        }
    }

    

    function ring(dc, x, id, colorCode, monitor, weather) {
        if (id == 0) { return; }
        var data = readField(id, monitor, weather);
        var y = 172;
        var radius = 29;
        var col = srColor(colorCode);
        dc.setPenWidth(4);
        dc.setColor(0x4A4A4A, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        var ratio = data[2];
        if (ratio == null) {
            dc.setPenWidth(3);
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            dc.drawCircle(x, y, radius);
        } else {
            var progress = ratio.toFloat();
            if (progress < 0.0) { progress = 0.0; }
            if (progress > 1.0) { progress = 1.0; }
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            if (progress >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (progress > 0.004) {
                var end = 90 - (progress * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
        drawIcon(dc, x, 156, id, col);
        var displayed = data[1];
        if (id == 2 && displayed.length() > 5) {
            var steps = monitor.steps;
            if (steps != null && steps >= 100000) { displayed = compact(steps); }
        }
        var fontChoice = srSetting("fontRingV31", 2);
        if (onlyDigits(displayed) && displayed.length() <= 5) {
            var px = fontChoice <= 0 ? 2 : 3;
            if (fontChoice >= 2 && displayed.length() <= 3) { px = 4; }
            drawPixelDigits(dc, displayed, x,
                            (170 + (28 - 7 * px) / 2).toNumber(), px,
                            Gfx.COLOR_WHITE);
        } else {
            fitScaled(dc, displayed, x, 173, 58, 24,
                      Gfx.COLOR_WHITE, false, fontChoice);
        }
    }

    

    // Dedicated 43px weather area. Same visual composition as the reference:
    // pictogram LEFT, large temperature RIGHT, short condition BELOW.
    // Weather zone Y=208..246, deliberately independent from the rings
    // and footer. The icon changes with the actual Garmin weather condition.
    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var sz = srSetting("fontWeatherV31", 2);
        if (id == 16) {
            weatherSymbol(dc, 68, 224, weather);
            fitScaled(dc, d[1], 172, 207, 126, 28,
                      Gfx.COLOR_WHITE, false, sz);
            fitScaled(dc, conditionText(weather), 172, 233, 126, 16,
                      Gfx.COLOR_WHITE, false, sz);
        } else {
            drawIcon(dc, 68, 225, id, 0x00CCFF);
            fitScaled(dc, d[1], 172, 207, 126, 28,
                      Gfx.COLOR_WHITE, false, sz);
            fitScaled(dc, d[0], 172, 233, 126, 16,
                      Gfx.COLOR_LT_GRAY, false, sz);
        }
    }

    // Battery footer resides inside the circle at Y=251..267 and cannot
    // touch the outer progress ring. All contents stay in a 76px box.
    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 113, 259, id, Gfx.COLOR_GREEN);
        fitScaled(dc, d[1], 158, 250, 75, 18,
                  Gfx.COLOR_WHITE, false, srSetting("fontWeatherV31", 2));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = readField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 133;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function onUpdate(dc) {
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var clock = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND","PN","WT","SR","CZ","PT","SB"];
        var months = ["STY","LUT","MAR","KWI","MAJ","CZE","LIP","SIE","WRZ","PAZ","LIS","GRU"];
        var monitor = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }

        // Backdrop first; the optional ring never replaces any field.
        outerProgressRing(dc, monitor, w, clock);

        // 1. SUNRISE | MOON | SUNSET, within Y=28..79.
        topSlot(dc, 77, srSetting("slotTop1V3", 14), monitor, w);
        topSlot(dc, 140, srSetting("slotTop2V3", 34), monitor, w);
        topSlot(dc, 203, srSetting("slotTop3V3", 15), monitor, w);
        rule(dc, 82);

        // 2. LARGE TIME, LARGE DATE to its right: Y=87..138.
        drawClock(dc, clock);
        drawDate(dc, days[date.day_of_week - 1],
                 date.day.toString() + " " + months[date.month - 1]);
        rule(dc, 140);

        // 3. Three configurable progress rings: Y=143..202.
        ring(dc, 67, srSetting("slotRing1V3", 1),
             srSetting("colorRing1V3", 0), monitor, w);
        ring(dc, 140, srSetting("slotRing2V3", 2),
             srSetting("colorRing2V3", 2), monitor, w);
        ring(dc, 213, srSetting("slotRing3V3", 3),
             srSetting("colorRing3V3", 6), monitor, w);
        rule(dc, 206);

        // 4. Large weather icon, temperature and two-line condition.
        drawWeather(dc, monitor, w);
        rule(dc, 249);
        drawBattery(dc, monitor, w);

        // Independent pressure warning at the right margin, not a weather icon.
        if (_storm.warning()) { stormBolt(dc, 255, 170); }
    }

    
}
