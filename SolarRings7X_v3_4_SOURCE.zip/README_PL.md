# Solar Rings 7X v3.4 — kod tarczy ze zdjęcia

Wersja dla Garmin Fenix 7X Pro Solar (MIP, 280 x 280).

## Układ
- Góra: wschód | faza Księżyca | zachód (wszystkie pola konfigurowalne).
- Wiersz 2: duża godzina, obok czytelna data.
- Środek: 3 duże pierścienie, ikony i wartości (bez /10k).
- Dół: duża ikonka pogody, temperatura, warunki, bateria.
- Pierścień zewnętrzny: opcjonalny (pora dnia, kroki, stres, bateria itp.).
- Ostrzeżenie ciśnieniowe: domyślnie wyłączone; ikona pioruna z prawej strony.

## Zmiana ustawień z iPhone'a
Connect IQ > Moje urządzenie > Moje tarcze > Solar Rings 7X > Ustawienia.
Zachowano 21 kluczy konfiguracji v3.x, by ustawienia nie znikały przy aktualizacji.

## Jak zbudować online
1. Wyślij SolarRings7X_v3_4_SOURCE.zip do głównego katalogu repozytorium.
2. Otwórz .github/workflows/build-v3.yml i zastąp zawartość plikiem SolarRings7X_v3_4_BUILD.yml.
3. Actions > Build Solar Rings 7X v3.4 > Run workflow.
4. Po sukcesie pobierz paczkę IQ z Artifacts i zaktualizuj istniejącą betę Connect IQ.

Uwaga: lokalne testy sprawdzają struktury i układ, ale nie zastępują kompilacji Garmin SDK ani testu zegarka.
