# Solar Rings 7X v3.5 — naprawa znikających cyfr i layoutu

Ta wersja bazuje na sprawdzonym projekcie v3.4. Zachowuje IDENTYCZNE ID aplikacji i 21 kluczy ustawień w Connect IQ.

## Najważniejsze zmiany

- Godzina i wszystkie wartości pierścieni są rysowane **natywnym `Dc.drawText`**. Usunięto pętlę z kilkuset prostokątów 3×7, po której na zegarku znikały liczby.
- Dla godziny, daty, pierścieni i pogody ustawienie Mały/Średni/Duży wybiera inny zestaw czcionek. Dobór jest dodatkowo ograniczony rzeczywistą szerokością i wysokością wyświetlanego pola (`getTextDimensions`).
- Góra: 3 pola, 2 pionowe separatory, większe czasy wschodu i zachodu.
- Środek: godzina (x=106) + 2-liniowa data (x=223), oddzielone obszary bez obcinania tekstu.
- 3 pierścienie: ikony u góry, wartości u dołu; 5-cyfrowe kroki nie są obcinane.
- Pogoda: dynamiczna ikona po lewej, **pionowy separator** i temperatura oraz opis po prawej.
- Bateria w odrębnym wierszu; opcjonalny zewnętrzny pierścień rysowany jako pierwszy.
- Puls pochodzi z bieżącego `Activity.getActivityInfo().currentHeartRate` — bez powrotu do nieaktualnej historii.
- Ostrzeżenie ciśnieniowe pozostaje wyłączone domyślnie. To orientacyjny wskaźnik trendu, nie certyfikowane ostrzeżenie meteorologiczne.

## Instalacja

1. Wrzuć `SolarRings7X_v3_5_SOURCE.zip` do głównego katalogu GitHub.
2. Podmień `.github/workflows/build-v3.yml` zawartością `SolarRings7X_v3_5_BUILD.yml`.
3. Actions → Build Solar Rings 7X v3.5 → Run workflow.
4. W Artifacts pobierz `.IQ` i zaktualizuj **obecną** wersję beta Connect IQ (przez uprawnionego właściciela konta). Tylko instalacja przez sklep zapewnia ustawienia w iPhonie.

## Weryfikacja

Lokalne: XML, 21 ustawień, wywołania rysowania, test obszarów i archiwum ZIP. Z kompilacją w Garmin SDK i rzeczywistym zegarkiem trzeba potwierdzić po uruchomieniu GitHub Actions. Kod nie gwarantuje konkretnego renderingu, ponieważ rozmiary fontów zależą od urządzenia.
