#!/usr/bin/env python3
"""Static regression checks, run in CI before the Monkey C compiler.
Cannot replace an actual simulator/runtime test."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re

p = Path(__file__).resolve().parents[1]
s = (p/'source/SolarRings7X.mc').read_text(encoding='utf-8')
f = (p/'source/FieldData.mc').read_text(encoding='utf-8')
storm = (p/'source/StormGuard.mc').read_text(encoding='utf-8')
ns = '{http://www.garmin.com/xml/connectiq}'
root = ET.parse(p/'manifest.xml').getroot()
app = root.find(ns+'application')
assert app is not None
assert app.get('id') == 'D1F8E1A4B7FC45BD91E8F0A0959041BF'
assert app.get('version') == '3.5.0'
assert app.get('type') == 'watchface'
assert {n.attrib['id'] for n in app.find(ns+'products')} == {'fenix7xpro','fenix7xpronowifi'}

settings = ET.parse(p/'resources/settings/settings.xml').getroot()
properties = ET.parse(p/'resources/settings/properties.xml').getroot()
strings = ET.parse(p/'resources/strings.xml').getroot()
pids = {x.get('id') for x in properties.findall('property')}
sids = {x.get('id') for x in strings.findall('string')}
assert len(pids) == len(settings.findall('setting')) == 21
for entry in settings.findall('setting'):
    assert entry.get('propertyKey').split('.')[-1] in pids
    assert entry.get('title').split('.')[-1] in sids
    for item in entry.findall('.//listEntry'):
        assert item.text.split('.')[-1] in sids
for key in ('slotTop1V3', 'slotTop2V3', 'slotTop3V3',
            'slotRing1V3', 'slotRing2V3', 'slotRing3V3',
            'slotLowerV3', 'slotFooterV3',
            'fontClockV31', 'fontDateV31', 'fontTopV31',
            'fontRingV31', 'fontWeatherV31', 'outerRingV31',
            'stormOnV3'):
    assert key in pids, key
assert 'Activity.getActivityInfo()' in f
assert 'activity.currentHeartRate' in f
assert 'History.getHeartRateHistory' not in f.split('function recentHeartRate()')[1].split('function sunClock')[0]
assert 'srSetting("stormOnV3", false)' in storm

# Assert no regression: the main clock and ring numerics MUST draw through
# built-in Garmin fonts. The former bitmap-rectangle renderer made both blank.
def get_func(name):
    start = s.index('    function ' + name + '(')
    brace = s.index('{', start)
    n = 0
    for i in range(brace, len(s)):
        if s[i] == '{': n += 1
        elif s[i] == '}':
            n -= 1
            if n == 0: return s[start:i+1]
    raise AssertionError('Missing closing brace ' + name)
assert 'fitScaled(dc, value' in get_func('drawClock')
assert 'drawPixelDigits(' not in get_func('drawClock')
assert 'fitScaled(dc, v' in get_func('ring')
assert 'drawPixelDigits(' not in get_func('ring')
assert 'dc.drawText(' in get_func('fitScaled')
assert 'dc.getTextDimensions(' in get_func('fitScaled')
assert 'dc.setClip(' not in get_func('fitScaled')
assert 'drawPixelDigits(' in get_func('drawTopClock') # Known-working sun clocks
assert 'topDividers(dc)' in get_func('onUpdate')
assert 'weatherDivider(dc)' in get_func('onUpdate')
assert 'drawLine(113, 25, 113, 75)' in get_func('topDividers')
assert 'drawLine(167, 25, 167, 75)' in get_func('topDividers')
assert 'drawLine(112, 212, 112, 247)' in get_func('weatherDivider')
assert 'onSettingsChanged()' in s
assert 'srSetting("fontClockV31", 2)' in get_func('drawClock')
assert 'srSetting("fontDateV31", 2)' in get_func('drawDate')
assert 'srSetting("fontRingV31", 2)' in get_func('ring')
assert 'srSetting("fontWeatherV31", 2)' in get_func('drawWeather')

# Actual UI geometry for Fenix 7X Pro MIP 280x280.
# These are reserved content areas; text widths are also measured at runtime.
width, height = 280, 280
boxes = {
  'sunrise': (44, 25, 109, 78),
  'moon': (114, 25, 166, 78),
  'sunset': (171, 25, 236, 78),
  'time': (30, 86, 182, 138),
  'date': (189, 86, 260, 137),
  'rings': (37, 144, 241, 207),
  'weather': (42, 211, 223, 250),
  'footer': (103, 251, 179, 272),
}
for name, (l,t,r,b) in boxes.items():
    assert 0 <= l < r < width and 0 <= t < b < height, name
assert boxes['time'][2] < boxes['date'][0]
assert boxes['sunrise'][2] < boxes['moon'][0] < boxes['moon'][2] < boxes['sunset'][0]
assert boxes['time'][3] < boxes['rings'][1]
assert boxes['rings'][3] < boxes['weather'][1]
assert boxes['weather'][3] <= boxes['footer'][1]
for x in (69,140,211):
    assert x-30 >= 37 and x+30 <= 241
assert 140-131 >= 0 and 140+131 < 280
assert s.count('drawPixelDigits(dc,') == 2 # definition and top clock only

print('PASS: v3.5 XML, 21 iPhone settings, font renderer, separators, 280x280 geometry, HR and storm rules')
