#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
import re
p=Path(__file__).resolve().parent.parent
s=(p/'source/SolarRings7X.mc').read_text()
f=(p/'source/FieldData.mc').read_text()
ns='{http://www.garmin.com/xml/connectiq}'
app=ET.parse(p/'manifest.xml').getroot().find(ns+'application')
assert app.get('id')=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
assert app.get('version')=='3.4.0'
settings=ET.parse(p/'resources/settings/settings.xml').getroot()
properties=ET.parse(p/'resources/settings/properties.xml').getroot()
strings=ET.parse(p/'resources/strings.xml').getroot()
prop_ids={x.get('id') for x in properties}
str_ids={x.get('id') for x in strings}
assert len(prop_ids)==len(settings.findall('setting'))==21
for setting in settings.findall('setting'):
  assert setting.get('propertyKey').split('.')[-1] in prop_ids
  assert setting.get('title').split('.')[-1] in str_ids
  for opt in setting.findall('.//listEntry'):
    assert opt.text.split('.')[-1] in str_ids
assert 'function drawPixelDigits(' in s
assert 'drawPixelDigits(dc, value, 102, 89, pixel' in s
assert 'var pixel = sz <= 0 ? 5 : (sz == 1 ? 6 : 7)' in s
assert 'var pixel = sz <= 0 ? 2 : (sz == 1 ? 3 : 4)' in s
assert 'drawDate(dc, days[date.day_of_week - 1]' in s
assert 'Activity.getActivityInfo()' in f and 'activity.currentHeartRate' in f
assert 'onSettingsChanged()' in s
assert 'outerProgressRing(dc, monitor, w, clock)' in s
assert 'stormBolt(dc, 255, 170)' in s
tail=s[s.index('function onUpdate(dc)'):]
assert tail.index('topSlot(dc, 77')<tail.index('drawClock(dc, clock)')<tail.index('ring(dc, 67')<tail.index('drawWeather(dc, monitor, w)')<tail.index('drawBattery(dc, monitor, w)')
assert all(k in s for k in ['rule(dc, 82)','rule(dc, 140)','rule(dc, 206)','rule(dc, 249)'])
# Geometry safety: (top, clock, rings, weather, footer)
for name,top,bottom in [('top',28,79),('clock',87,138),('ring',143,203),('weather',208,247),('footer',250,269)]:
  assert 0 <= top < bottom < 280,name
assert 79 < 87 and 138 < 143 and 203 < 208 and 247 < 250
for center in (67,140,213):
  assert center-31>12 and center+31<268
for scale in (2,3,4):
  assert (18*scale)<=72
for scale in (5,6,7):
  assert (18*scale)<=126 and 7*scale<=49
print('PASS: v3.4 code, 21 phone settings, full-size clock and date, geometry and storm guard')
