"""v3.26.9: source-level contracts. Does NOT claim emulator/device execution."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest
P=Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
D=(P/'source/SolarOpenData.mc').read_text()
W=(P/'source/WeatherGeocode.mc').read_text()
U=(P/'source/SolarRings7X.mc').read_text()
S=(P/'resources/settings/settings.xml')
R=(P/'resources/strings.xml').read_text()

class BackgroundPipelineDiagnostics(unittest.TestCase):
    def test_callback_and_request_phase_can_be_traced(self):
        for gate in (10,11,12,13,14,15,16,17,18,19,21,90):
            self.assertIn(f'gate({gate})',N)
        self.assertIn('srODGateV3269',N)
        self.assertIn('runSafely()',N)
        self.assertIn('_openService.runSafely()',W)
    def test_catch_unhandled_background_start_error(self):
        self.assertIn('catch (e) {\n            // If anything fails before makeWebRequest',N)
        self.assertIn('status(-230)',N)
        self.assertIn('Time.Duration(10 * 60)',N)
    def test_fresh_release_resets_stale_deadlines_only_once(self):
        self.assertIn('diagVersion != 32611',D)
        self.assertIn('if (mode == 1 && resetDiag)',D)
        for k in ('srONextCV326','srONextFV326','srONextDV326','srONextAV326'):
            self.assertIn(f'srOwmWrite("{k}", 0)',D)
    def test_current_record_contract(self):
        self.assertIn('currentRows.size() > 0',N)
        self.assertNotIn('currentRows.size() == 1',N)
        self.assertIn('var d = currentRows[0] as Lang.Dictionary;',N)
        self.assertNotIn('var reason = -152',N)
    def test_each_phase_still_has_independent_result(self):
        for k in ('srODNowV3268','srODForecastV3268','srODDailyV3268','srODAirV3268'):
            self.assertIn(k,N)
        self.assertIn('status(100)',N)
        self.assertIn('status(200)',N)
    def test_new_display_and_setting_available(self):
        v=ET.parse(S).getroot()
        setting=next(x for x in v if x.get('propertyKey')=='@Properties.gwPreviewV332')
        entries=[x.get('value') for x in setting.find('settingConfig')]
        self.assertIn('20',entries)
        self.assertIn('gw_diag_20',R)
        self.assertIn('drawOpenDiagPage(dc, diagMode)',U)
        self.assertIn('diagMode >= 16 && diagMode <= 20',U)
    def test_no_secrets_in_diagnostic(self):
        self.assertNotIn('diagWrite("srODGateV3269", _key)',N)
        self.assertNotIn('diagWrite("srODGateV3269", data)',N)
        self.assertEqual(N.count('Comm.makeWebRequest('),1)
    def test_garmin_provider_unmodified(self):
        self.assertIn('new GarminWeatherWarnings()',U)
        self.assertIn('Weather.getCurrentConditions()',U)

if __name__=='__main__':unittest.main()
