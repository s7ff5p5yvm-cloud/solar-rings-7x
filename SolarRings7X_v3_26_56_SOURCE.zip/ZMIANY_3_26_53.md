# Solar Rings 7X v3.26.53 — WeatherSync Priority Guard

## Projekt docelowy
Wybór: bezpieczny model jednego HTTP na wybudzenie co minimum 5 minut. Priorytet: kompletne ostrzeżenia i brak awarii, następnie świeżość, potem bateria.

## Harmonogram przy wybranym profilu 5 lub 15 minut
- SPOKOJNA: prognoza 1h ~10 min, current ~20 min, 15m opcjonalne ~90 min, AQI ~60 min, dzienna ~12h.
- CZUJNOŚĆ / ZAGROŻENIE: 1h ~10 min, current ~15 min, 15m opcjonalne ~60 min, AQI ~90 min, dzienna ~12h.
- Dostępne 12 slotów/godzinę. Pod obciążeniem termin może przesunąć się o >=5 min.
- Ręczne profile 30 i 60 min nadal respektowane dla current/1h.
- Przy eskalacji z pogody spokojnej do czujności przyspieszono deadline bieżącej pogody, jeśli jest aktualny zapis.
- Źródła 1h i current spóźnione o >=5 min mają pierwszeństwo nad dodatkowymi. Pozostałe źródła zachowują limity zaległości i sprawiedliwość kolejki.

## Ochrona 15m
- Każda pojedyncza odpowiedź 15m może być zbyt duża dla RAM Garmin; cnt=12 nie daje gwarancji obcięcia JSON przez OpenWeather 4.0.
- Po pierwszym zaniku callbacku / błędzie -402/-403 tylko 15m ma 6h pauzy.
- Po drugim zaniku / błędzie pamięci 15m zostaje zablokowane do świadomego wyłączenia i włączenia opcji przez użytkownika. Nie ma więcej automatycznych dziennych prób, które mogłyby stale resetować tarczę.
- TEST 22 pokazuje „15M OCHRONA (2 BLEDY)”.

## Reguły bezpieczeństwa
- Żadnych równoległych/sekwencyjnych dwóch HTTP, żadnego zewnętrznego serwera ani push.
- Alerty current/1h/15m są niezależne, 1h nie może zostać wyparte przez 15m.
- Działa wyłącznie aktualizacja w terminach obsługiwanych przez Garmin; brak gwarancji publikacji dokładnie co 10 min.
- Sen/pobudka respektują zdarzenia Garmin, bez sztywnego zegara 22:00.
- Photon, progi ostrzeżeń, menu i ustawienia bez zmian.

## Warunki odbioru
1. GitHub Actions: testy Python i kompilacja Monkey C dla obu wariantów Fenix 7X Pro Solar.
2. Testy TEST22: current, 1h, 15m oraz zmiana trybu na podstawie danych rzeczywistych.
3. TEST21: poprawny Photon. Sen -> pobudka -> current + 1h.
4. 48-72 h realnego monitoringu restartów, baterii, BT, braku internetu, API 429/403 i zmiany ustawień.
5. Kod nie daje gwarancji 100% stabilności bez weryfikacji na zegarku.
