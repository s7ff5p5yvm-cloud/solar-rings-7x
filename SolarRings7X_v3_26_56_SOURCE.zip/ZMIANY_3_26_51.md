# Solar Rings v3.26.51 — naprawa wykrywania braku pobierania 15M

Baza: 3.26.50. Pozostawiono bez zmian strukturę ustawień, klucz API, identyfikator Connect IQ, formaty zapisanych danych pogodowych, Photon, wygląd tarczy, obsługę snu i alertów.

- Prognoza 15M nie wymaga już świeżego cache prognozy godzinowej **do zaplanowania samego zapytania**. Poprzednia blokada mogła trwale odraczać rozpoczęcie 15M w określonych przypadkach, mimo że pobieranie bieżące i 1H działało.
- W nowej wersji wyczyszczono stare diagnostyki i blokady nieudanych 15M. W chwili, gdy pogoda bieżąca i 1H mają świeże wyniki, jeszcze nietestowana 15M dostaje pojedynczą pierwszą próbę. Nie jest ponawiana w każdej pięciominutowej sesji.
- Gdy wcześniejsze zapytanie 15M nie zakończyło się callbackiem, TEST 22 otrzymuje `K-217`, a następnie pokazuje ochronną pauzę 6 h.
- Jeżeli nie było jeszcze żądania 15M, TEST 22 pokaże `15M KOLEJKA` lub `15M PLAN Xm` zamiast niezrozumiałego `--`.
- Zachowano jeden request HTTP na wybudzenie; nie dodano eksperymentalnych dwóch żądań, ani nowych obciążeń poza pierwszą próbą 15M.

**Ograniczenie:** One Call 4.0 `timeline/15min` może zwrócić do 50 rekordów. Parametr `cnt=12` nie ma wprost gwarantowanego ograniczenia tych rekordów w oficjalnym opisie endpointu. Przy zbyt dużej odpowiedzi pamięć Garmin może zwrócić `-402` lub `-403`, a brak callbacku może wywołać sześciogodzinną pauzę. Ten patch nie gwarantuje, że duży JSON da się odczytać bezpośrednio na Fenixie. Jeśli wystąpi `15M PAUZA` / `K-403` / `K-217`, należy wstrzymać bezpośrednią 15M i rozważyć mały JSON przez proxy, zamiast zwiększać RAM lub liczbę prób.

Wymagany jest build Monkey C w GitHub i test TEST22 na rzeczywistym zegarku.
