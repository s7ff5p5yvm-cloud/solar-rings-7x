"""v3.26.52: source-level invariants and deterministic 24h cadence model.
Does not replace real Monkey C compilation or device/background tests.
"""
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
NETWORK=(ROOT/'source/SolarOpenNetwork.mc').read_text()
UI=(ROOT/'source/SolarRings7X.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()

class IntegratedV48(unittest.TestCase):
    def test_weather_queue_fairness_and_photon_reserved(self):
        part=NET.split('    function start()')[1] if 'NET' in globals() else NETWORK.split('    function start()')[1]
        for token in ('var wantC = nextC <= _now;', 'var wantF = nextF <= _now;',
                      'var cityDue = cityLookupDue();',
                      'if ((wantC || wantF) && !reserveAux)',
                      'ageC <= 16 * 60 && ageF <= 16 * 60',
                      'if (cityDue && Sys.getDeviceSettings().phoneConnected)',
                      'startCityLookup(); return;'):
            self.assertIn(token,part)
        self.assertLess(part.index('if ((wantC || wantF) && !reserveAux)'),
                        part.index('if (cityDue && Sys.getDeviceSettings().phoneConnected)'))

    def test_independent_hourly_short_and_memory_fallback(self):
        self.assertIn('"srONextFV326", "srOHoursV326"',NETWORK)
        self.assertIn('"srONextSV32648", "srOShortV3264"',NETWORK)
        self.assertIn('write("srONextSV32648", _now + pauseShort);',NETWORK)
        self.assertIn('if (kindIs("forecast") && _shortRequest &&',NETWORK)
        self.assertIn('q["cnt"] = "12"',NETWORK)
        self.assertIn('q["cnt"] = value("srOHourlyTinyV32611") == 1 ? "2" : "4"',NETWORK)
    def test_aqi_optional_hourly_and_diagnostics(self):
        self.assertIn('deadline("srONextAV326", "srOAirV326", airSeconds())',NETWORK)
        self.assertIn('if (setting("srOwmAirV326", false))',NETWORK)
        self.assertIn('write("srONextAV326", _now + airSeconds())',NETWORK)
        for key in ('srODNowV3268','srOD1hV32648','srOD15mV32648',
                    'srODDailyV3268','srODAirV3268'):
            self.assertIn(key,UI)
        self.assertIn('if (srSetting("srOwmAirV326", false) == true)',UI)
        self.assertIn('401 ZLY KLUCZ',UI)
        self.assertIn('BRAK / ZA KROTKI',UI)
        self.assertIn('429 LIMIT',UI)
        self.assertNotIn('Comm.makeWebRequest(',UI)
    def test_geocoding_no_multihour_blackout_and_fallback(self):
        c=NETWORK.split('function cityRetry(code)')[1].split('function dictionary(v)')[0]
        self.assertNotIn('24 * 3600',c)
        self.assertIn('if (code == 429) { minutes = 60; }',c)
        self.assertIn('srGWideV32648',c)
        self.assertIn('city = props["name"]',c)
        self.assertIn('city = props["city"]',c)
        self.assertIn('stage == 23',c)
        self.assertIn('sameCity(_loc, value("srGRequest"))',c)
    def test_preserve_app_and_properties(self):
        app=ET.parse(ROOT/'manifest.xml').getroot()[0]
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(app.get('version'),'3.26.56')
        import hashlib
        self.assertEqual(hashlib.sha256((ROOT/'resources/settings/properties.xml').read_bytes()).hexdigest(),
                         'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
        settings=ET.parse(ROOT/'resources/settings/settings.xml').getroot()
        mode=next(e for e in settings if e.get('propertyKey')=='@Properties.gwPreviewV332')
        self.assertEqual([int(x.get('value')) for x in mode.find('settingConfig')],[0,15,21,22,23])
    def test_scheduler_no_aqi_starvation_in_day(self):
        # Discrete deterministic model of one request/5min at fastest mode.
        due={k:0 for k in ('current','hourly','photon','short','aqi','daily')}
        periods={'current':15,'hourly':15,'photon':10**7,
                 'short':30,'aqi':60,'daily':720}
        used={k:[] for k in due}
        for minute in range(0,24*60,5):
            # 15-minute enrichment waits for initial 1h success.
            order=('current','hourly','short','photon','aqi','daily')
            for k in order:
                if k=='short' and not used['hourly']:continue
                if due[k]<=minute:
                    used[k].append(minute)
                    due[k]=minute+periods[k]
                    break
        self.assertEqual([k for k in ('current','hourly','short') if used[k][0]<20],
                         ['current','hourly','short'])
        self.assertLessEqual(used['photon'][0],25)
        for kind in ('current','hourly','short','aqi','daily'):
            self.assertGreater(len(used[kind]),1,kind)
        self.assertLessEqual(len([x for kind in used.values() for x in kind]),288)

if __name__=='__main__':unittest.main()
