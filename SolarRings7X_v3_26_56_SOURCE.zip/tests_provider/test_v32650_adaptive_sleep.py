"""v3.26.52 design contracts and deterministic models; not a Monkey C simulator."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest
ROOT=Path(__file__).resolve().parents[1]
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
GEO=(ROOT/'source/WeatherGeocode.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()

# Reference model with the SAME conservative triggers as Monkey C helper.
def risk(current, hourly, now):
    if current is None or hourly is None: return True
    if now-current.get('seen',0)>45*60 or now-hourly.get('seen',0)>50*60: return True
    def code(v): return isinstance(v,(int,float)) and ((200<=v<700) or (711<=v<=781))
    def near(d):
        return (d.get('wind',0)>=8 or d.get('gust',0)>=12 or
                d.get('vis',10000)<=1000 or d.get('pop',0)>=30)
    if code(current.get('code')) or near(current):return True
    for item in hourly.get('rows',[])[:5]:
        if now-3600<item.get('time',0)<=now+3*3600:
            if code(item.get('code')) or near(item) or item.get('rain',0)>0 or item.get('snow',0)>0:
                return True
    return False

class AdaptiveSleep50(unittest.TestCase):
    def test_event_schedule_no_clock_fallback(self):
        win=NET.split('function nightWindow()',1)[1].split('function waitForMorning()',1)[0]
        self.assertNotIn('Sys.getClockTime()',win)
        self.assertIn('state[0] == 1',win)
        self.assertIn('age >= 0 && age < 14 * 3600',win)
        self.assertIn('return false;',win)
        self.assertIn('function onSleepTime() as Void',GEO)
        self.assertIn('function onWakeTime() as Void',GEO)
        self.assertIn('Bg.registerForSleepEvent()', DATA)
        self.assertIn('Bg.registerForWakeEvent()', DATA)
        self.assertIn('App.Storage.setValue("srONextSV32648", 0)',GEO)
        self.assertIn('new Time.Duration(5 * 60)',GEO)
        self.assertIn('new Time.Duration(60 * 60)',NET)
    def test_stable_settings_and_photon(self):
        app=ET.parse(ROOT/'manifest.xml').getroot()[0]
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(app.get('version'),'3.26.56')
        self.assertIn('srGQueryV32649',NET)
        self.assertIn('https://photon.komoot.io/reverse',NET)
        self.assertNotIn('hour >= 22 || hour < 6',NET)
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
    def test_active_conditions_and_conservative_missing(self):
        now=1800000000
        c=dict(seen=now,code=800,wind=2,gust=3,vis=10000)
        h=dict(seen=now,rows=[dict(time=now+900,code=800,pop=0)])
        self.assertFalse(risk(c,h,now))
        for code in [200,500,511,600,741,771]:
            self.assertTrue(risk({**c,'code':code},h,now),code)
        self.assertTrue(risk(c,{**h,'rows':[dict(time=now+1800,code=800,pop=65)]},now))
        self.assertTrue(risk(c,{**h,'rows':[dict(time=now+1800,code=800,wind=9)]},now))
        self.assertTrue(risk(None,h,now))
        self.assertTrue(risk(c,None,now))
        self.assertTrue(risk(c,{**h,'seen':now-80*60},now))
    def test_actual_code_has_guarded_enrichment(self):
        for token in ('function alertCode(code)', 'function nearThreat(wind, gust, visibility, chance)',
                      'function activeWeather()', 'hourly[3].size() > 0',
                      'current[2] <= _now + 300', '_now - hourly[2] <= 30 * 60',
                      'return _interval <= 15 ? 10 * 60 : _interval * 60;',
                      'return _interval <= 15 ? 10 * 60 : _interval * 60;',
                      'return _interval <= 15 ? (_alertMode == 2 ? 60 * 60 :',
                      'write("srOShortPausedV3264", _now + orphanPause)',
                      'var shCache = value("srOShortV3264")'):
            self.assertIn(token,NET)
    def test_profile_budget_and_daily_aqi_starvation_model(self):
        for fast in (True,False):
            due={k:0 for k in ('current','hourly','short','photon','aqi','daily')}
            spans={'current':15 if fast else 25,'hourly':15 if fast else 30,
                   'short':30 if fast else 60,'photon':10**9,'aqi':60,'daily':720}
            done={k:[] for k in due}
            for minute in range(0,24*60,5):
                for k in ('current','hourly','short','photon','aqi','daily'):
                    if k=='short' and not done['hourly']: continue
                    if due[k]<=minute:
                        done[k].append(minute)
                        due[k]=minute+spans[k]
                        break
            self.assertGreaterEqual(len(done['current']),40)
            self.assertGreaterEqual(len(done['hourly']),40)
            self.assertGreaterEqual(len(done['short']),20)
            self.assertGreaterEqual(len(done['aqi']),10)
            self.assertGreaterEqual(len(done['daily']),2)
            self.assertLessEqual(done['photon'][0],30)
            self.assertLessEqual(sum(map(len,done.values())),288)
    def test_adaptive_diagnostic_safe_no_volatile_heavy_reads(self):
        watch=(ROOT/'source/SolarRings7X.mc').read_text()
        block=watch.split('function drawOwmDiagnostics(dc)',1)[1].split('function onUpdate(dc)',1)[0]
        self.assertIn('srOAdaptiveV32650',block)
        self.assertIn('15M PAUZA',block)
        self.assertIn('15M WYLACZONE',block)
        for label in ('SPOKOJNA', 'CZUJNOSC', 'ZAGROZENIE', 'PROFIL RECZNY'):
            self.assertIn(label,block)
        self.assertNotIn('srOwmForecastSnapshot()',block)
        self.assertNotIn('Comm.makeWebRequest(',block)
        self.assertIn('diagWrite("srOAdaptiveV32650", packed)',NET)
        self.assertIn('function criticalMeasure(wind, gust, visibility, uv)',NET)
        self.assertIn('criticalMeasure(current[6], current[15],',NET)
        self.assertIn('criticalMeasure(h[2], h[9], h[8], h[4])',NET)
        self.assertIn('criticalMeasure(sh[2], sh[9], sh[8], sh[4])',NET)
    def test_settings_contract_preserved(self):
        from hashlib import sha256
        expected = {
                    'resources/settings/properties.xml': 'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63',
                    'source/WeatherCity.mc': '41e3c46fea97c5a8fedade097ab49ffdf55d72b15f87475cf9eeb6784714a51e'}
        for fname, digest in expected.items():
            self.assertEqual(sha256((ROOT/fname).read_bytes()).hexdigest(),digest)
    def test_upgrade_releases_old_24h_15m_block(self):
        self.assertIn('var resetDiag = diagVersion != 32654;',DATA)
        self.assertIn('srOwmWrite("srOShortPausedV3264", 0);',DATA)
        self.assertIn('srOwmWrite("srOShortAttemptV3264", 0);',DATA)
        self.assertIn('srOwmWrite("srODVersionV32612", 32654);',DATA)

if __name__=='__main__': unittest.main()
