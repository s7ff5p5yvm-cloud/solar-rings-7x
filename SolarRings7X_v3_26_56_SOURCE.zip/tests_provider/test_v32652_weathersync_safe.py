"""WeatherSync Safe source contract and edge-case reference model.
These checks do NOT replace an actual Garmin SDK runtime or device test.
"""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()

class WeatherSyncSafe52(unittest.TestCase):
    def test_fast_refresh_hourly_10_current_adaptive(self):
        self.assertIn('return _interval <= 15 ? 10 * 60 : _interval * 60;', NET)
        self.assertIn('return _interval <= 15 ? 10 * 60', NET)
        self.assertIn('return _interval <= 15 ? (_alertMode == 2 ? 60 * 60 :', NET)
    def test_no_parallel_and_single_request_per_background_wake(self):
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
        self.assertIn('finish(true);',NET)
        self.assertNotIn('method(:onSecondReceive)',NET)
    def test_evaluate_all_feeds_before_mode(self):
        block=NET.split('    function activeWeather() {')[1].split('    function currentSeconds()',1)[0]
        self.assertIn('var currentOK =',block)
        self.assertIn('var hourlyOK =',block)
        self.assertIn('if (hourlyOK) {',block)
        self.assertIn('if (shortReady()) {',block)
        self.assertIn('return risk(mode, reason);',block)
        self.assertNotIn('return risk(1,',block)
        self.assertNotIn('return risk(2,',block)
        self.assertLess(block.index('if (shortReady())'),block.index('return risk(mode, reason);'))
    def test_conservative_missing_and_upward_escalation(self):
        self.assertIn('if (!currentOK || !hourlyOK) { mode = 1; reason = 1; }',NET)
        self.assertIn('if (mode < 2) { mode = 2; reason = 4; }',NET)
        self.assertIn('if (mode < 2) { mode = 2; reason = 5; }',NET)
    def test_two_new_forecasts_to_return_to_calm(self):
        self.assertIn('srOCalmProbeV32652',NET)
        self.assertIn('firstCalm >= hourly[2]',NET)
        self.assertIn('POTWIERDZANIE SPOKOJU',FACE)
    def test_memory_failures_only_pause_optional_15m(self):
        self.assertIn('memoryFault = code == -402 || code == -403 || code == -217',NET)
        self.assertIn('function shortLocked()',NET)
        self.assertIn('return num(faults) && faults >= 2;',NET)
        self.assertIn('if (kindIs("forecast") && _shortRequest &&',NET)
        self.assertIn('write("srOShortPausedV3264", _now + pauseShort)',NET)
        self.assertIn('write("srONextFV326", _now + 10 * 60)',NET)
        self.assertIn('Preserve 15m fault cooldown and orphan marker across upgrades',DATA)
    def test_both_forecast_feeds_contribute_alert_icons(self):
        warnings=(ROOT/'source/SolarOpenWarnings.mc').read_text()
        self.assertIn('srOwmHourlyWarningsSnapshot()',warnings)
        self.assertIn('srOwmShortWarningsSnapshot()',warnings)
        self.assertIn('for (var source = 0; source < 2; source++)',warnings)
        self.assertIn('addAlert(_lastKinds, futureKinds[z] + 16)',warnings)
        data=(ROOT/'source/SolarOpenData.mc').read_text()
        self.assertIn('function srOwmHourlyWarningsSnapshot()',data)
        self.assertIn('function srOwmShortWarningsSnapshot()',data)
    def test_mode_reassessed_after_successful_callback(self):
        self.assertIn('if (_interval <= 15 && (kindIs("current") || kindIs("forecast")))',NET)
        self.assertIn('_alertMode = -1;',NET)
        self.assertIn('activeWeather();',NET)
    def test_mode_photon_sleep_settings_unchanged(self):
        import hashlib
        p=(ROOT/'resources/settings/properties.xml').read_bytes()
        self.assertEqual(hashlib.sha256(p).hexdigest(), 'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
        self.assertIn('function nightWindow()',NET)
        self.assertIn('https://photon.komoot.io/reverse',NET)
        self.assertIn('srODVersionV32612", 32654',DATA)
    def test_fast_queue_capacity_model(self):
        # Idealized envelope: forecast ~6/h, current ~3/h,
        # calm short ~0.67/h, AQI ~1/h. Actual jitter/deadline conflicts
        # can delay individual calls; this is not an SLA.
        self.assertLessEqual(6+3+1+1, 12)
        self.assertLess(6+4+1+0.67, 12) # Threat budget leaves a small reserve.
