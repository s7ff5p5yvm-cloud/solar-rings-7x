"""Regressions for v3.26.47 source-level. Does not execute Monkey C."""
from pathlib import Path
from xml.etree import ElementTree as ET
from hashlib import sha256
import unittest
BASE = Path(__file__).resolve().parents[1]
BASELINE_SHA256 = {'resources/settings/properties.xml': 'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63', 'resources/settings/settings.xml': '95751a72cd2e04a7f61b03c30f0825a3fb57e7b576f3931fbed951613ee9cdd7', 'resources/strings.xml': 'f8c750ad54ddb4ffb02de4d21e24c1e4275e4f34f075badb2af1ae2a4e0595c1', 'source/Config.mc': '5e28fa55088f5a5fee4dc9248952301e6ad8351413c2f5d52cc3fd72f6d8e11d', 'source/FieldData.mc': '2391caa6249cebda033ccc37f766fd0cfa3877e23f6ec62c278dfa625a13a443', 'source/SolarOpenData.mc': '6348151dbadb81000f75134cea41e54bdd5299f9ada0cf7eeddb64799d107ca0', 'source/GarminWeatherWarnings.mc': 'f937252eafeca85c431d996b1e43927294d68f07449298501cd070ca34383823', 'source/SolarOpenWarnings.mc': '418187f7d4e002eb63e500a1e20517c443fba762b1613898cd0e009d32b13ef9', 'source/WeatherCity.mc': '41e3c46fea97c5a8fedade097ab49ffdf55d72b15f87475cf9eeb6784714a51e'}
FACE = (BASE/'source/SolarRings7X.mc').read_text()
NET = (BASE/'source/SolarOpenNetwork.mc').read_text()
GEO = (BASE/'source/WeatherGeocode.mc').read_text()

class V32647Safety(unittest.TestCase):
    def test_stable_properties_and_core_are_bit_identical(self):
        unchanged = ['resources/settings/properties.xml',
                     'source/FieldData.mc','source/WeatherCity.mc']
        for item in unchanged:
            self.assertEqual(sha256((BASE/item).read_bytes()).hexdigest(), BASELINE_SHA256[item], item)
        b=ET.parse(BASE/'manifest.xml').getroot()[0]
        self.assertEqual(b.get('id'), 'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        self.assertEqual(b.get('type'), 'watchface')
        self.assertEqual(b.get('entry'), 'SolarRings7XApp')
    def test_diagnostics_only_15_and_21(self):
        self.assertIn('drawPhotonDiag',FACE)
        self.assertIn('diagMode == 21',FACE)
        self.assertIn('srGTraceV32647',NET)
        self.assertNotIn('drawOpenDiagPage(',FACE)
        config=ET.parse(BASE/'resources/settings/settings.xml').getroot()
        preview=next(s for s in config if s.attrib.get('propertyKey')=='@Properties.gwPreviewV332')
        values={int(i.get('value')) for i in preview.find('settingConfig')}
        self.assertEqual(values, {0,15,21,22,23})
    def test_one_http_per_wake_and_short_photon_response(self):
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
        self.assertEqual(GEO.count('Comm.makeWebRequest('),1)
        self.assertIn('"limit" => "2"',NET)
        self.assertIn('"radius" => wide ? "15" : "10"',NET)
        self.assertIn('q["osm_tag"] = "place"',NET)
        self.assertIn('"limit" => "2"',GEO)
        self.assertIn('"radius" => "10"',GEO)
        self.assertIn('"osm_tag" => "place"',GEO)
    def test_background_populates_request_without_ui_redraw(self):
        self.assertIn('if (!sameCity(target, _loc))',NET)
        self.assertIn('write("srGRequest", [_loc[0], _loc[1]])',NET)
        self.assertIn('cityLookupDue()',NET)
        self.assertIn('sameCity(_loc, value("srOLocV326"))',NET)
    def test_city_not_starved_by_frequent_current(self):
        self.assertIn('if (cityDue && Sys.getDeviceSettings().phoneConnected)', NET)
        self.assertLess(NET.index('if ((wantC || wantF) && !reserveAux)'),NET.index('if (cityDue && Sys.getDeviceSettings().phoneConnected)'))
        self.assertIn('cityAt < earliest',NET)
    def test_persist_only_on_http200_valid_place_and_matching_coordinates(self):
        self.assertIn('else if (!(data instanceof Lang.Dictionary)) { stage = 22; }',NET)
        self.assertIn('osm.equals("place")',NET)
        self.assertIn('sameCity(_loc, value("srGRequest"))',NET)
        self.assertIn('saved = write("srGResult",',NET)
        self.assertIn('finish(saved)',NET)
        self.assertIn('App.Storage.setValue("srGResult", [_requestedLat, _requestedLon, city]);', GEO)
    def test_failure_cooldown_bounded(self):
        self.assertIn('if (code == 429) { minutes = 60; }',NET)
        self.assertIn('if (code == 429) { minutes = 60; }',GEO)
        self.assertNotIn('3 * 3600',NET[NET.index('function cityRetry('):NET.index('function dictionary(v)')])
    def test_no_network_from_render(self):
        self.assertNotIn('Comm.makeWebRequest(',FACE)
        self.assertIn('remote != null ? 3600 : 5 * 60',FACE)
        self.assertIn('remoteStored != null ? 3600 : 5 * 60',FACE)
    def test_weather_network_endpoints_are_identical_to_v37(self):
        for endpoint in ['api.openweathermap.org/data/4.0/onecall/current',
                         'api.openweathermap.org/data/4.0/onecall/timeline/15min',
                         'api.openweathermap.org/data/4.0/onecall/timeline/1h',
                         'api.openweathermap.org/data/4.0/onecall/timeline/1day',
                         'api.openweathermap.org/data/2.5/air_pollution']:
            self.assertIn(endpoint,NET)
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
if __name__ == '__main__': unittest.main()
