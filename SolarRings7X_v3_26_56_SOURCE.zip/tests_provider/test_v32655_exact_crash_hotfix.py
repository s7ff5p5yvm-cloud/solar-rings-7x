"""Regression: actual Store-Version 114 OOM PC 0x1000ad6a mapped
with the installed .iq debug.xml to GarminWeatherWarnings.evaluate line 370.
Source checks are NOT a substitute for real Monkey C/on-device tests.
"""
from pathlib import Path
import unittest
P=Path(__file__).resolve().parents[1]
GW=(P/'source/GarminWeatherWarnings.mc').read_text()
U=(P/'source/SolarRings7X.mc').read_text()
OW=(P/'source/SolarOpenWarnings.mc').read_text()

class ExactOOMRegression(unittest.TestCase):
    def test_no_garmin_hourly_sdk_allocation_in_render(self):
        effective='\n'.join(line for line in (GW+'\n'+U).splitlines() if not line.lstrip().startswith('//'))
        self.assertNotIn('Weather.getHourlyForecast()', effective)
    def test_garmin_now_alerts_retained(self):
        self.assertIn('var observed = classify(current.condition,', GW)
        self.assertIn('return orderAlerts(matched);', GW)
    def test_owm_forecast_alerts_not_removed(self):
        self.assertIn('srOwmHourlyWarningsSnapshot()', OW)
        self.assertIn('srOwmShortWarningsSnapshot()', OW)
        self.assertIn('function allWarnings(current)', OW)
    def test_provider_diagnostics(self):
        self.assertIn('"ZRODLO OWM" : "ZRODLO GARMIN"', U)
        self.assertIn('var hourly = srUseOpenWeather() ? srOwmForecastSnapshot() : null;', U)
    def test_owm_pipeline_unchanged(self):
        from hashlib import sha256
        original=Path('/mnt/data/garmin_v54_work/source/SolarOpenNetwork.mc')
        if original.exists():
            self.assertEqual(sha256((P/'source/SolarOpenNetwork.mc').read_bytes()).hexdigest(),sha256(original.read_bytes()).hexdigest())
