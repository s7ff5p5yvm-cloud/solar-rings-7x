import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
C=(ROOT/'source/Config.mc').read_text()
U=(ROOT/'source/SolarRings7X.mc').read_text()
class NativeSettingsSafety(unittest.TestCase):
    def test_no_synchronous_setting_reload(self):
        cb=U.split('function onSettingsChanged()',1)[1].split('\n    }',1)[0]
        self.assertIn('srBeginSettingsHold()',cb)
        self.assertNotIn('srResetSettingsCache()',cb)
        self.assertNotIn('Ui.requestUpdate()',cb)
        self.assertNotIn('Props.getValue(',cb)
        self.assertNotIn('new ',cb)
    def test_deferred_reconciliation(self):
        body=U.split('function refreshChangedSettings()',1)[1].split('function rebuildWeatherWarnings()',1)[0]
        self.assertIn('elapsed < 45000',body)
        self.assertIn('srFinishSettingsHold()',body)
        self.assertIn('resetPerformanceCaches()',body)
        self.assertIn('open != _srSelectedProvider',body)
    def test_cached_fallback_while_held(self):
        self.assertIn('if (_srSettingsHold) { return fallback; }',C)
        self.assertIn('if (cached != null) { return cached; }',C)
    def test_type_validate_all_settings(self):
        self.assertIn('fallback instanceof Toybox.Lang.Number',C)
        self.assertIn('fallback instanceof Toybox.Lang.Boolean',C)
        self.assertIn('fallback instanceof Toybox.Lang.String',C)
        self.assertIn('var parsed = value.toNumber()',C)
    def test_no_settings_migration_or_key_changes(self):
        props=(ROOT/'resources/settings/properties.xml').read_bytes()
        import hashlib
        self.assertEqual(hashlib.sha256(props).hexdigest(), 'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
        self.assertIn('version="3.26.56"',(ROOT/'manifest.xml').read_text())
