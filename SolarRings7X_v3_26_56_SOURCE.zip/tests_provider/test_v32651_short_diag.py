"""Static safeguards for v3.26.52. Device validation remains mandatory."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
NETWORK=(ROOT/'source/SolarOpenNetwork.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
DATA=(ROOT/'source/SolarOpenData.mc').read_text()
class ShortDiagnostics(unittest.TestCase):
    def test_no_hourly_dependency_in_short_ready(self):
        block=NETWORK.split('function shortReady()',1)[1].split('function schedule()',1)[0]
        self.assertNotIn('srOHoursV326',block)
        self.assertIn('srOShortPausedV3264',block)
    def test_optional_probe_only_after_fresh_essential_data(self):
        self.assertIn('var shortDue = _shortEnabled && shortReady()', NETWORK)
        self.assertIn('var reserveAux = _interval <= 15 &&', NETWORK)
        self.assertIn('ageC <= 16 * 60 && ageF <= 16 * 60', NETWORK)
        self.assertIn('else if (shortDue) { _kind = "forecast"; _shortRequest = true; }',NETWORK)
    def test_lost_callback_is_not_hidden(self):
        self.assertIn('diagWrite("srOD15mV32648", [_now, -217, 90, 0])',NETWORK)
        self.assertIn('write("srOShortPausedV3264", _now + orphanPause)',NETWORK)
    def test_unattempted_is_visible(self):
        self.assertIn('15M KOLEJKA',FACE)
        self.assertIn('15M PLAN ',FACE)
        self.assertIn('srONextSV32648',FACE)
    def test_upgrade_discards_old_suppression(self):
        self.assertIn('diagVersion != 32654',DATA)
        self.assertIn('srOwmWrite("srOShortPausedV3264", 0)',DATA)
