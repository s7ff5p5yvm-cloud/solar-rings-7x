"""WeatherSync 5 design contracts + deterministic scheduler stress tests.
These do NOT compile Monkey C nor emulate Garmin background memory.
"""
from pathlib import Path
import unittest, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
D=(P/'source/SolarOpenData.mc').read_text()
U=(P/'source/SolarRings7X.mc').read_text()
W=(P/'source/SolarOpenWarnings.mc').read_text()
G=(P/'source/WeatherGeocode.mc').read_text()

def model(minutes=1440, threat=False, outage=None, travel=False, jitter=False):
    now=0; lastC=-100000;lastF=-100000;lastAux=-100000
    due={k:0 for k in 'CFSADP'};done={k:[] for k in due}
    for tick in range(minutes//5):
        now=tick*5+(10 if jitter and tick>0 and tick%47==0 else 0)
        if outage and outage[0]<=now<outage[1]:continue
        c=due['C']<=now;f=due['F']<=now
        s=due['S']<=now;a=due['A']<=now;d=due['D']<=now
        p=travel and due['P']<=now and not done['P']
        ageC=now-lastC;ageF=now-lastF
        auxiliary=(s or a or d or p) and ageC<=16 and ageF<=16 and now-lastAux>=25
        if (c or f) and not auxiliary:
            choice='F' if f and (not c or ageF>=ageC) else 'C'
        elif auxiliary or (not c and not f):
            choice=('P' if p else 'A' if a and due['A']<now-30 else
                    'D' if d and due['D']<now-120 else 'S' if s else
                    'A' if a else 'D' if d else None)
        else:choice=None
        if choice is None and (c or f):
            choice='F' if f and (not c or ageF>=ageC) else 'C'
        if choice is None:continue
        done[choice].append(now)
        if choice=='C':lastC=now;due['C']=now+10
        elif choice=='F':lastF=now;due['F']=now+10
        else:
            lastAux=now
            if choice=='S':due['S']=now+(60 if threat else 120)
            if choice=='A':due['A']=now+(90 if threat else 75)
            if choice=='D':due['D']=now+720
            if choice=='P':due['P']=now+10000
    return done

class WeatherSync5(unittest.TestCase):
    def test_version_identity_and_no_new_properties(self):
        x=ET.parse(P/'manifest.xml').getroot()[0]
        self.assertEqual(x.get('version'),'3.26.56')
        self.assertEqual(x.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
        from hashlib import sha256
        self.assertEqual(sha256((P/'resources/settings/properties.xml').read_bytes()).hexdigest(),
                         'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
    def test_fast_pulse_and_independent_current_forecast(self):
        self.assertIn('seconds = 300;',N)
        self.assertIn('seconds = 600;',N)
        self.assertIn('return _interval <= 15 ? 10 * 60 : _interval * 60;',N)
        self.assertIn('var wantC = nextC <= _now;',N)
        self.assertIn('var wantF = nextF <= _now;',N)
    def test_one_http_only_not_chain_or_parallel(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),2) # OWM, Photon
        self.assertEqual(N.count('method(:onReceive)'),1)
        self.assertNotIn('onSecondReceive',N)
        self.assertIn('Bg.exit(["OWM", changed ? 1 : 0]);',N)
    def test_fair_aux_only_when_both_core_fresh(self):
        self.assertIn('ageC <= 16 * 60 && ageF <= 16 * 60',N)
        self.assertIn('lastAux == 0 || _now - lastAux >= 25 * 60',N)
        self.assertIn('if ((wantC || wantF) && !reserveAux)',N)
    def test_weather_guard_stale_never_calm(self):
        self.assertIn('if (!currentOK || !hourlyOK) { mode = 1; reason = 1; }',N)
        self.assertIn('mode < 2',N)
        self.assertIn('firstCalm >= hourly[2]',N)
        self.assertIn('var severity = codeLevel(h[1], h[5], true, h[3], h[6], h[7]);',N)
        self.assertIn('var shortLevel = codeLevel(sh[1], sh[5], true, sh[3], sh[6], sh[7]);',N)
    def test_real_warning_filters_preserved(self):
        for key in ('gwRainChanceV332','gwSnowChanceV332',
                    'gwRainHeavyV332','gwSnowHeavyV332','gwIceOnV332'):
            self.assertIn(key,N)
            self.assertIn(key,W)
        self.assertIn('srOwmHourlyWarningsSnapshot()',W)
        self.assertIn('srOwmShortWarningsSnapshot()',W)
    def test_garmin_hint_no_fake_red_warning(self):
        self.assertIn('function garminSignal()',N)
        self.assertIn('Weather.getCurrentConditions()',N)
        self.assertIn('observed.observationTime.value()',N)
        self.assertIn('coords(xy) && same(xy, _loc)',N)
        self.assertIn('age >= -300 && age <= 40 * 60',N)
        self.assertIn('if (_interval <= 15 && mode < 2 && garminSignal() == 1 && mode < 1)',N)
        self.assertIn('srOGarminGuardV32654',N)
        self.assertNotIn('Weather.getCurrentConditions()',W)
    def test_optional_memory_fail_isolation(self):
        self.assertIn('function shortLocked()',N)
        self.assertIn('faults >= 2',N)
        self.assertIn('code == -402 || code == -403 || code == -217',N)
        self.assertIn('write("srONextSV32648", _now + pauseShort)',N)
        self.assertIn('15M OCHRONA (2 BLEDY)',U)
    def test_test22_and_test23_are_lightweight(self):
        panel=U.split('function drawOwmDiagnostics(dc)')[1].split('function onUpdate(dc)')[0]
        self.assertIn('function drawOwmSchedulerDiagnostics(dc)',panel)
        self.assertIn('srOPlanV32654',panel)
        self.assertIn('srOGarminGuardV32654',panel)
        self.assertNotIn('Comm.makeWebRequest(',panel)
        self.assertNotIn('srOwmForecastSnapshot()',panel)
        menu=ET.parse(P/'resources/settings/settings.xml').getroot()
        opt=next(t for t in menu if t.get('propertyKey')=='@Properties.gwPreviewV332')
        self.assertEqual([int(x.get('value')) for x in opt.find('settingConfig')],
                         [0,15,21,22,23])
    def test_sleep_uses_actual_events_no_fixed_22_06(self):
        self.assertIn('Bg.registerForSleepEvent()',D)
        self.assertIn('Bg.registerForWakeEvent()',D)
        self.assertIn('function onWakeTime() as Void',G)
        self.assertIn('if (nightWindow()) { waitForMorning(); return; }',N)
        self.assertNotIn('hour >= 22 || hour < 6',N)
    def test_24hr_calm_and_storm_budget(self):
        for threat in (False,True):
            done=model(threat=threat)
            self.assertLessEqual(sum(map(len,done.values())),288)
            for feed in ('C','F'):
                self.assertGreaterEqual(len(done[feed]),115)
                self.assertLessEqual(max(b-a for a,b in zip(done[feed],done[feed][1:])),15)
            self.assertGreaterEqual(len(done['A']),13)
            self.assertGreaterEqual(len(done['S']),10)
            self.assertEqual(len(done['D']),2)
    def test_location_refresh_does_not_starve_core(self):
        done=model(travel=True)
        self.assertEqual(len(done['P']),1)
        self.assertLessEqual(done['P'][0],35)
        for feed in ('C','F'):
            self.assertLessEqual(max(b-a for a,b in zip(done[feed],done[feed][1:])),15)
    def test_jitter_and_bluetooth_outage_recovery(self):
        j=model(jitter=True)
        self.assertGreater(len(j['C']),110)
        self.assertGreater(len(j['F']),110)
        off=model(outage=(240,300))
        self.assertTrue(any(x>=300 and x<=315 for x in off['C']))
        self.assertTrue(any(x>=300 and x<=315 for x in off['F']))
