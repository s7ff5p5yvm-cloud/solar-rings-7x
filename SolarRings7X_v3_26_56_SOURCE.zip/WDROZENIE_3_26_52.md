# Solar Rings 7X 3.26.52 — WeatherSync Safe

## Decyzja
Jeden request HTTP na wybudzenie (nie ma drugiego w callbacku). Priorytet na 1h/10 min, current/20 min przy szybkim profilu ustawień OWM 5 lub 15. 15m: planowo co 60 min spokojnie, co 30 min przy zagrożeniu; dodatkowe dane, nie warunek ostrzeżeń. AQI 60 min, dzienna 12h, Photon tylko po potrzebie. Profil ręczny 30/60 pozostawiony.

## Dokładność czasów
5-minutowe cykle usług Connect IQ, przesunięcia wykonywania, wspólna kolejka i aktualizacje serwera OWM mogą opóźnić pobranie. Brak gwarancji natychmiast po aktualizacji modelu.

## Kluczowe zabezpieczenia
- Najwyższa wykryta klasa zagrożenia z wszystkich świeżych źródeł wygrywa. Brak 1H/current = CZUJNOŚĆ, nie SPOKOJNA.
- Ikony ostrzegawcze łączą prognozy 1H i 15M; późniejsza 15M nie ukrywa zagrożenia z 1H.
- Po dwóch nowych poprawnych odczytach prognozy godzinowej bez sygnałów zagrożenia można wrócić do SPOKOJNA; eskalacja jest natychmiastowa.
- 15M zachowuje ochronę pamięci i oddzielne statusy K-402/K-403/-217. Pierwszy błąd pamięci lub utracony callback = 6 h pauzy, kolejny = 24 h. Pauza utrzymuje się po aktualizacji kodu, żeby uniknąć ponawiania OOM.
- Nie zastąpiono formatu ustawień, ID Garmin, Photon, harmonogramu snu ani layoutu tarczy.
- TEST 22 pokazuje K200/K100, blokadę 15M, tryb i nowe odległości C20 H10 M60/M30. W diagnozie K200 wskazuje ostatnią zapisaną odpowiedź, nie czas wydania nowego modelu przez OWM.

## Symulacja obciążenia (model idealny, nie urządzenie)
Wykonano symulację 24 h na siatce 5-minutowych cykli, 1 HTTP/cykl, stale dostępny telefon, brak błędów sieci, Photon jednorazowo:
- SPOKOJNA: 1H 144 odczyty (największy odstęp 15 min); current 72 (do 25 min); 15M 24 (do 70 min); AQI 24 (60 min); dzienna 2.
- ZAGROŻENIE: 1H 144 (do 15 min); current 72 (do 25 min); 15M 36 (do 40 min); AQI 18 (do 80 min); dzienna 2.
Wyniki nie są gwarancją na Garminie. W sytuacjach braku łączności lub opóźnienia systemowego odstępy rosną.

## Plan testów po kompilacji Monkey C
1. Nie usuwaj ani nie resetuj starej aplikacji. Zachowaj poprzedni działający plik PRG.
2. W GitHub Actions: build obu wariantów `fenix7xpro` i `fenix7xpronowifi`. Gdy kompilacja ma błąd, nie instaluj tarczy.
3. TEST22 po 15/30/60 min: sprawdź `1H K200`, TERAZ K200, `15M K200/PAUZA/K-403` i tryb.
4. TEST21: Photon musi nadal wyświetlać potwierdzoną miejscowość bez tyldy i błędu 400.
5. 24-72 h na zegarku: test zmiany ustawień z telefonu, sen/pobudka, zerwany Bluetooth, brak internetu, lokalizacja, odczyt pamięci/CIQ_LOG; sprawdź opóźnienia, alerty i baterię.
6. Jeśli wywali się tarcza lub 15M ponownie przekroczy RAM: wróć do działającej wersji i wyłącz 15M do czasu sprawdzenia rzeczywistego limitu odpowiedzi. 1H pozostaje podstawowym źródłem ostrzeżeń.

## Status sprawdzenia
Testy źródłowe Python i archiwów oraz syntaktyczne XML: wykonane. Kompilacja Monkey C/SDK oraz test na fizycznym Garminie: **NIE wykonane**. Paczka jest kandydatem testowym, a nie potwierdzoną stabilną wersją.

## Oficjalna dokumentacja
- Garmin Background: https://developer.garmin.com/connect-iq/articles/core-topics/Backgrounding.html
- Garmin Background API: https://developer.garmin.com/connect-iq/api-docs/Toybox/Background.html
- Garmin Communications: https://developer.garmin.com/connect-iq/api-docs/Toybox/Communications.html
- OpenWeather One Call 4.0: https://openweathermap.org/api/one-call-4
