# Solar Rings 7X v3.26.52 — WeatherSync Safe / wczesne ostrzeżenia

Podstawa: v3.26.51. Wersja wdrożeniowa do kompilacji i testu urządzenia, nie poświadczona jako stabilna na zegarku.

## Decyzja architektoniczna
- Jeden request HTTP na wybudzenie, bez łańcuchów callbacków i dodatkowych serwerów.
- Dla profilu szybkiego (ustawienie 5/15): prognoza 1h co ~10 min, bieżąca co ~20 min, opcjonalna 15m: ~60 min w spokojną pogodę / ~30 min przy czujności lub zagrożeniu.
- AQI nadal ~60 min i prognoza dzienna ~12 h, ale przy konfliktach najwyższy priorytet mają 1h i bieżąca. Kolejka ma ograniczenie głodzenia pozostałych danych, bez gwarancji idealnej punktualności.
- Profil ręczny 30/60 pozostaje ustawieniem użytkownika dla bieżącej i 1h; brak przymusowego przełączania.

## Poprawki kluczowe
- WeatherGuard ocenia wszystkie świeże źródła przed wyborem najwyższego poziomu, bez wcześniejszego return po CZUJNOŚCI.
- Sygnał z 15m nie może nadpisać silniejszego ostrzeżenia z 1h; brak świeżych danych utrzymuje CZUJNOŚĆ.
- Ikony ostrzeżeń łączą wszystkie świeże informacje 1H i 15M zamiast wybierać wyłącznie jedno źródło. Deduplikacja korzysta z istniejących reguł, bez zmiany progów.
- Klasyfikacja WeatherGuard przeliczana natychmiast po udanym callbacku current/1h/15m, nie dopiero po kolejnym wybudzeniu.
- Powrót z CZUJNOŚCI/ZAGROŻENIA do SPOKOJNA po dwóch kolejnych niezależnych, świeżych odczytach godzinowych; zagrożenie aktywuje tryb szybko.
- Kolejka opiera wybór między 1h a bieżącą na starszym terminie, faworyzując 1h przy remisie. Jednorazowy pierwszy test 15m pozostaje dozwolony tylko po zapisaniu aktualnych dwóch głównych źródeł.
- Błędy pamięci -402/-403 i przerwane wywołania 15m (-217) wywołują wyłącznie blokadę 15m: 6h pierwszy raz, 24h przy powtórzeniu, bez zatrzymania 1h i current.
- Ochronna pauza 15m jest zachowana przy aktualizacji tarczy — nowa wersja nie wymusza ponownego OOM. Zmiana klucza, źródła lub ręczne przełączenie 15m zeruje stan ochrony.
- Zaktualizowano napisy TEST 22 na `C20 H10 M60` i `C20 H10 M30` oraz dodano stan `POTWIERDZANIE SPOKOJU`.
- Obsługa Garmin sleep/wake, Photon, ustawień i wyglądu tarczy pozostaje bez zmian.

## Granice techniczne
- Nie da się gwarantować pobrania natychmiast po publikacji nowego modelu OWM ani co do minuty wymusić wybudzenia Garmin.
- Parametr `cnt` w endpointach One Call 4.0 nie jest udokumentowany jako gwarantujący ograniczenie długości odpowiedzi; parsowanie 50-row JSON 15m nadal może wywołać błąd pamięci. Dlatego 15m jest opcjonalnym uzupełnieniem, nie rdzeniem ostrzeżeń.
- TEST 22 pokazuje ostatni wynik żądania, a nie datę publikacji modelu OWM.
- Testy Python/static NIE zastępują kompilacji Monkey C i testów na urządzeniu.
