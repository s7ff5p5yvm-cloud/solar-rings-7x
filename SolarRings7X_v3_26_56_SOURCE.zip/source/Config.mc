using Toybox.Application.Properties as Props;
using Toybox.Graphics as Gfx;

// Cache ONLY persisted settings; dynamic device data is never cached here.
// All entries are invalidated on AppBase.onSettingsChanged().
// A 96-entry cap covers the original settings plus provider selections while bounding RAM.
var _srSettingCache = {};
var _srSettingCacheSize = 0;
// Settings are imported by Garmin asynchronously; do not call native getValue
// while the settings callback is active or during a short settling period.
var _srSettingsHold = false;
function srBeginSettingsHold() { _srSettingsHold = true; }
function srFinishSettingsHold() {
    srResetSettingsCache();
    _srSettingsHold = false;
}

function srResetSettingsCache() {
    _srSettingCache = {};
    _srSettingCacheSize = 0;
}

// Mobile app settings. All default keys are defined in resources/settings/properties.xml.
// Deliberately use NEW keys so stale v2.x settings cannot unexpectedly override
// the new three-ring layout. All 8 visible slots are selectable from the phone.
function srSetting(key, fallback) {
    // Malformed keys should never propagate into native Properties.getValue.
    if (!(key instanceof Toybox.Lang.String)) { return fallback; }
    // Version 3.18: font controls removed from Connect IQ settings because
    // they were not reliable on the MIP screen. Preserve the accepted layout
    // and ignore values persisted by previous versions of the phone app.
    if (key.equals("fontClockV31") || key.equals("fontDateV31") ||
        key.equals("fontTopV31") || key.equals("fontRingV31") ||
        key.equals("fontWeatherV31")) { return 2; }
    if (key.equals("fontFaceV36")) { return 0; }
    if (key.equals("fontExtraV36")) { return 1; }
    if (key.equals("sizeTopLeftV37") || key.equals("sizeTopMidV37") ||
        key.equals("sizeTopRightV37") || key.equals("sizeRingLeftV37") ||
        key.equals("sizeRingMidV37") || key.equals("sizeRingRightV37") ||
        key.equals("sizeWeatherValueV37") || key.equals("sizeWeatherLabelV37") ||
        key.equals("sizeFooterV37") || key.equals("moonFontV38")) { return -1; }
    var cached = _srSettingCache[key];
    if (cached != null) { return cached; }
    // Preserve already cached values instead of re-entering Garmin's native
    // property store immediately after onSettingsChanged().
    if (_srSettingsHold) { return fallback; }
    try {
        var value = Props.getValue(key);
        if (value != null) {
            // Garmin Connect may deliver a String for a numeric property.
            // Validate EVERY setting against its expected fallback type, not
            // only gwPreviewV332. Never persist wrong-typed values in RAM.
            if (fallback instanceof Toybox.Lang.Number &&
                !(value instanceof Toybox.Lang.Number)) {
                if (value instanceof Toybox.Lang.String) {
                    var parsed = value.toNumber();
                    if (!(parsed instanceof Toybox.Lang.Number)) { return fallback; }
                    value = parsed;
                } else { return fallback; }
            }
            if (fallback instanceof Toybox.Lang.Boolean &&
                !(value instanceof Toybox.Lang.Boolean)) { return fallback; }
            if (fallback instanceof Toybox.Lang.String &&
                !(value instanceof Toybox.Lang.String)) { return fallback; }
            // Guard the exact diagnostic setting that produced an
            // Unexpected Type Error in 3.26.18. A wrongly typed saved value
            // cannot be used in numeric comparisons during onUpdate.
            if (key.equals("gwPreviewV332") &&
                !(value instanceof Toybox.Lang.Number)) { return fallback; }
            if (_srSettingCacheSize < 96) {
                _srSettingCache[key] = value;
                _srSettingCacheSize += 1;
            }
            return value;
        }
    } catch (e) { }
    return fallback;
}

function srColor(value) {
    if (value == 0) { return Gfx.COLOR_RED; }
    if (value == 1) { return Gfx.COLOR_GREEN; }
    if (value == 2) { return Gfx.COLOR_BLUE; }
    if (value == 3) { return Gfx.COLOR_ORANGE; }
    if (value == 4) { return Gfx.COLOR_YELLOW; }
    if (value == 5) { return Gfx.COLOR_WHITE; }
    return 0x00FFFF;
}
