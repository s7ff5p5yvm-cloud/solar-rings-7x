using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;
using Toybox.System as Sys;
using Toybox.Time as Time;
using Toybox.Weather as Weather;

// WeatherSync 5: exactly one HTTP request per 5-minute temporal opportunity.
// Current and hourly forecast are equally important essential feeds. Optional 15-min forecast is lower-priority
// enrichment; 15m JSON may exceed background RAM, so keep a safe fallback.
// Only a bounded set of upcoming rows is persisted, never full API JSON.
(:background)
class SolarOpenNetwork {
    var _kind;
    var _loc;
    var _now;
    var _interval;
    var _key;
    var _unsafe;
    var _shortEnabled;
    var _shortRequest;
    // Compact diagnostic counters; no keys, URLs, coordinates or raw JSON.
    var _diagStep;
    var _diagMask;
    var _diagRows;
    var _diagAccepted;
    var _diagAge;
    var _alertMode;

    function initialize() {
        _kind = "";
        _loc = null;
        _now = 0;
        _interval = 30;
        _key = "";
        _unsafe = false;
        _shortEnabled = true;
        _shortRequest = false;
        _diagStep = 0;
        _diagMask = 0;
        _diagRows = 0;
        _diagAccepted = 0;
        _diagAge = 0;
        _alertMode = -1;
    }
    function setting(key, fallback) {
        try {
            var v = App.Properties.getValue(key);
            if (v != null) { return v; }
        } catch (e) { }
        return fallback;
    }
    function num(v) {
        return v != null && (v instanceof Lang.Number || v instanceof Lang.Long ||
                             v instanceof Lang.Float || v instanceof Lang.Double);
    }
    function value(key) {
        try { return App.Storage.getValue(key); } catch (e) { return null; }
    }
    function write(key, v) {
        try {
            if (App.Storage.getValue(key) != v) { App.Storage.setValue(key, v); }
            return true;
        } catch (e) { _unsafe = true; return false; }
    }
    // Logging is best-effort. Failures of diagnostic storage MUST NOT mark
    // the entire meteorological update unsafe or stop normal weather writes.
    function diagWrite(key, v) {
        try { App.Storage.setValue(key, v); } catch (e) { }
    }
    function coords(v) {
        return v != null && v instanceof Lang.Array && v.size() >= 2 &&
            num(v[0]) && num(v[1]) && v[0] >= -90 && v[0] <= 90 &&
            v[1] >= -180 && v[1] <= 180;
    }
    function same(a, b) {
        return coords(a) && coords(b) &&
            a[0] > b[0] - 0.025d && a[0] < b[0] + 0.025d &&
            a[1] > b[1] - 0.035d && a[1] < b[1] + 0.035d;
    }
    // Name resolution is more location-specific than OWM weather cache reuse.
    function sameCity(a, b) {
        return coords(a) && coords(b) &&
            a[0] > b[0] - 0.008d && a[0] < b[0] + 0.008d &&
            a[1] > b[1] - 0.012d && a[1] < b[1] + 0.012d;
    }
    // Only scheduled sleep/wake EVENTS from Garmin decide whether to pause.
    // No hard-coded 22:00-06:00 fallback: it ignored custom sleep schedules.
    // No sleep event yet (new install / missed callback) means fail OPEN,
    // avoiding an unrequested evening outage. A stale sleep event fails open
    // after 14h to avoid a permanently suspended service if wake is lost.
    function nightWindow() {
        var state = value("srOSleepStateV32624");
        if (state instanceof Lang.Array && state.size() == 2 &&
            num(state[0]) && num(state[1]) && state[0] == 1) {
            var age = Time.now().value() - state[1];
            return age >= 0 && age < 14 * 3600;
        }
        return false;
    }
    function waitForMorning() {
        // Garmin wake event schedules a 5min recovery (current -> 1h -> 15m).
        // A single hourly watchdog handles missing callbacks without HTTP
        // requests during the scheduled sleep period.
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(60 * 60)));
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }
    function deadline(key, snapshot, duration) {
        var d = value(key);
        if (!num(d) || d < 0 || d > _now + 48 * 3600) { d = 0; }
        var s = value(snapshot);
        if (same(s, _loc) && s.size() >= 3 && num(s[2]) &&
            s[2] <= _now && _now - s[2] <= 10800 &&
            s[2] + duration > d) { d = s[2] + duration; }
        return d;
    }
    // WeatherGuard: require fresh current AND hourly for calm, select the
    // highest detected risk across all fresh feeds and local Garmin cache.
    // Only numeric snapshots; never fetch weather JSON in classification.
    // WeatherGuard signal levels mirror enabled alert categories and POP
    // thresholds. A forecast code below the user's POP threshold yields
    // CAUTION, not a falsely confirmed hazard. Current observed codes do
    // not depend on forecast POP. No raw conditions or forecast JSON stored.
    function alertCode(code) {
        return num(code) && ((code >= 200 && code <= 232) ||
            (code >= 300 && code <= 321) || (code >= 500 && code <= 531) ||
            (code >= 600 && code <= 622) || (code >= 711 && code <= 781));
    }
    function nearThreat(wind, gust, visibility, chance) {
        var windLimit = setting("gwWindV332", 10);
        var gustLimit = setting("srOwmGustV3263", 15);
        var fogLimit = setting("gwFogMetersV332", 500);
        if (!num(windLimit)) { windLimit = 10; }
        if (!num(gustLimit)) { gustLimit = 15; }
        if (!num(fogLimit)) { fogLimit = 500; }
        return (setting("gwWindOnV332", true) &&
            ((num(wind) && wind >= windLimit * 0.8) ||
             (num(gust) && gust >= gustLimit * 0.8))) ||
            (setting("gwFogOnV332", true) && num(visibility) &&
                visibility <= fogLimit * 2) ||
            ((setting("gwRainOnV332", true) || setting("gwSnowOnV332", true)) &&
                num(chance) && chance >= 25);
    }
    function criticalMeasure(wind, gust, visibility, uv) {
        return (setting("gwWindOnV332", true) &&
                ((num(wind) && wind >= setting("gwWindV332", 10)) ||
                 (num(gust) && gust >= setting("srOwmGustV3263", 15)))) ||
            (setting("gwFogOnV332", true) && num(visibility) &&
             visibility <= setting("gwFogMetersV332", 500)) ||
            (setting("gwUvOnV332", false) && num(uv) &&
             uv >= setting("gwUvV332", 7));
    }
    function codeLevel(code, chance, forecast, temp, rainRate, snowRate) {
        if (!num(code)) { return 0; }
        // Unambiguous severe phenomena do not use POP as a proxy.
        if ((code >= 200 && code <= 232 && setting("gwStormOnV332", true)) ||
            (code == 511 && setting("gwFreezeOnV332", true)) ||
            ((code == 771 || code == 781) && setting("gwWindOnV332", true)) ||
            (code == 741 && setting("gwFogOnV332", true)) ||
            ((code == 711 || code == 731 || code == 751 || code == 761 ||
              code == 762) && setting("gwAirOnV332", true))) { return 2; }
        var rain = (code >= 300 && code <= 321) ||
            (code >= 500 && code <= 504) || (code >= 520 && code <= 531);
        var snow = code >= 600 && code <= 622;
        var active = (rain && setting("gwRainOnV332", true)) ||
                     (snow && setting("gwSnowOnV332", true));
        if (!active) { return 0; }
        // Honor existing heavy-only icon settings; a light-rain code must
        // not be labelled an active danger if that icon is suppressed.
        var rainHeavy = code == 502 || code == 503 || code == 504 ||
                        code == 522 || (num(rainRate) && rainRate >= 8);
        var snowHeavy = code == 602 || code == 622;
        if ((rain && setting("gwRainHeavyV332", false) && !rainHeavy) ||
            (snow && setting("gwSnowHeavyV332", false) && !snowHeavy)) {
            return 1;
        }
        // Match the display engine's precipitation sensitivity: sensitive
        // accepts all valid chances, standard needs 40%, custom uses the
        // configured rain/snow minimum. -1 is invalid, NOT missing POP.
        var configured = snow ? setting("gwSnowChanceV332", 40) :
                                setting("gwRainChanceV332", 30);
        var sensitivity = setting("srPrecipModeV3263", 1);
        var chanceAllowed = !forecast || chance == null;
        if (forecast && num(chance) && chance >= 0 && chance <= 100) {
            chanceAllowed = sensitivity == 0 ||
                (sensitivity == 1 && chance >= 40) ||
                (sensitivity == 2 && chance >= configured);
        }
        // Road ice is only an estimate; it has its own probability rule.
        var iceAllowed = !forecast || chance == null ||
            (num(chance) && chance >= setting("gwIceChanceV332", 50));
        if (setting("gwIceOnV332", true) && num(temp) &&
            temp <= setting("gwIceTempV332", 1) && iceAllowed) { return 2; }
        // Present weather is observed rather than a probabilistic forecast.
        if (!forecast) { return 2; }
        if (!chanceAllowed) { return 1; }
        // Missing POP: the existing icon rules treat explicit recognized
        // codes as potentially actionable. Keep conservative severity.
        return 2;
    }
    // Compact state: 0 calm, 1 caution, 2 hazard, 3 manual.
    // Reasons 0 clear, 1 stale/missing, 2 current, 3 near threshold,
    // 4 hourly, 5 15-minute, 6 calm confirmation, 7 Garmin cache.
    function risk(mode, reason) {
        _alertMode = mode;
        var packed = mode * 10 + reason;
        if (value("srOAdaptiveV32650") != packed) {
            diagWrite("srOAdaptiveV32650", packed);
        }
        return mode == 1 || mode == 2;
    }
    // Garmin's own cache can signal CAUTION only. It never creates a RED
    // alert and never replaces OWM. Source must be recent and geographically
    // close to the OWM location; omitted/mismatched Garmin data are ignored.
    // No HTTP request, no fresh GPS fix, no unbounded array processing.
    function garminSignal() {
        var signal = 0;
        var stamp = 0;
        var quality = 0; // 0 missing, 1 valid, 2 stale, 3 elsewhere.
        try {
            var observed = Weather.getCurrentConditions();
            if (observed != null && observed.observationTime != null) {
                stamp = observed.observationTime.value();
                var age = _now - stamp;
                if (age >= -300 && age <= 40 * 60) {
                    var p = observed.observationLocationPosition;
                    if (p != null) {
                        var xy = p.toDegrees();
                        if (coords(xy) && same(xy, _loc)) {
                            quality = 1;
                            var c = observed.condition;
                            // Garmin CONDITION codes are NOT OWM IDs.
                            if (num(c) && ((c >= 3 && c <= 19) ||
                                c == 21 || (c >= 24 && c <= 29) ||
                                c == 31 || c == 32 || c == 34 || c == 36 ||
                                (c >= 41 && c <= 51))) { signal = 1; }
                            var wind = observed.windSpeed;
                            if (setting("gwWindOnV332", true) && num(wind) &&
                                wind >= setting("gwWindV332", 10) * 0.8) {
                                signal = 1;
                            }
                        } else { quality = 3; }
                    } else { quality = 3; }
                } else { quality = 2; }
            }
        } catch (e) { quality = 0; signal = 0; }
        var previous = value("srOGarminGuardV32654");
        var oldStamp = 0;
        if (previous instanceof Lang.Array && previous.size() == 3 &&
            num(previous[0])) { oldStamp = previous[0]; }
        if (oldStamp != stamp || !(previous instanceof Lang.Array) ||
            previous.size() != 3 || previous[1] != quality ||
            previous[2] != signal) {
            // Writes only when Garmin actually changes its observation/status.
            diagWrite("srOGarminGuardV32654", [stamp, quality, signal]);
            if (signal == 1 && oldStamp != stamp) {
                var c = value("srOCurrV326");
                // One accelerated OWM check on a NEW Garmin signal, never
                // an endless loop due to the same cached Garmin observation.
                if (c instanceof Lang.Array && c.size() == 19 &&
                    same(c, _loc) && num(c[2]) &&
                    _now - c[2] >= 8 * 60) {
                    write("srONextCV326", 0);
                }
            }
        }
        return signal;
    }
    // Evaluate all three OWM feeds, then optionally a cached Garmin hint.
    // Never let an earlier CAUTION hide a later higher-severity signal.
    function activeWeather() {
        if (_alertMode >= 0) { return _alertMode == 1 || _alertMode == 2; }
        var mode = 0;
        var reason = 0;
        var current = value("srOCurrV326");
        var hourly = value("srOHoursV326");
        var currentOK = current instanceof Lang.Array && current.size() == 19 &&
            same(current, _loc) && num(current[2]) &&
            current[2] <= _now + 300 && _now - current[2] <= 30 * 60 &&
            num(current[11]);
        var hourlyOK = hourly instanceof Lang.Array && hourly.size() == 4 &&
            same(hourly, _loc) && num(hourly[2]) &&
            hourly[2] <= _now + 300 && _now - hourly[2] <= 30 * 60 &&
            hourly[3] instanceof Lang.Array && hourly[3].size() > 0;
        if (!currentOK || !hourlyOK) { mode = 1; reason = 1; }
        if (currentOK) {
            var present = codeLevel(current[11], current[16], false, current[4], current[17], current[18]);
            if (present == 2 || criticalMeasure(current[6], current[15],
                                                current[9], current[8])) {
                mode = 2; reason = 2;
            } else if (mode < 1 && (present == 1 ||
                nearThreat(current[6], current[15], current[9], current[16]))) {
                mode = 1; reason = 3;
            }
        }
        if (hourlyOK) {
            var rows = hourly[3];
            var found = false;
            for (var i = 0; i < rows.size() && i < 5; i++) {
                var h = rows[i];
                if (!(h instanceof Lang.Array) || h.size() < 10 ||
                    !num(h[0]) || h[0] > _now + 3 * 3600 ||
                    h[0] <= _now - 3600) { continue; }
                found = true;
                var severity = codeLevel(h[1], h[5], true, h[3], h[6], h[7]);
                if (severity == 2 ||
                    criticalMeasure(h[2], h[9], h[8], h[4])) {
                    if (mode < 2) { mode = 2; reason = 4; }
                } else if (mode < 1 && (severity == 1 ||
                    nearThreat(h[2], h[9], h[8], h[5]))) {
                    mode = 1; reason = 3;
                }
            }
            if (!found && mode < 1) { mode = 1; reason = 1; }
        }
        if (shortReady()) {
            var shCache = value("srOShortV3264");
            if (shCache instanceof Lang.Array && shCache.size() == 4 &&
                same(shCache, _loc) && num(shCache[2]) &&
                shCache[2] <= _now + 300 && _now - shCache[2] <= 75 * 60 &&
                shCache[3] instanceof Lang.Array) {
                var shRows = shCache[3];
                for (var j = 0; j < shRows.size() && j < 12; j++) {
                    var sh = shRows[j];
                    if (!(sh instanceof Lang.Array) || sh.size() < 10 ||
                        !num(sh[0]) || sh[0] > _now + 3 * 3600 ||
                        sh[0] <= _now - 900) { continue; }
                    var shortLevel = codeLevel(sh[1], sh[5], true, sh[3], sh[6], sh[7]);
                    if (shortLevel == 2 ||
                        criticalMeasure(sh[2], sh[9], sh[8], sh[4])) {
                        if (mode < 2) { mode = 2; reason = 5; }
                    } else if (mode < 1 && (shortLevel == 1 ||
                        nearThreat(sh[2], sh[9], sh[8], sh[5]))) {
                        mode = 1; reason = 3;
                    }
                }
            }
        }
        // A mismatched/missing Garmin observation is NOT a new hazard and
        // must not demote a confirmed OWM hazard.
        if (_interval <= 15 && mode < 2 && garminSignal() == 1 && mode < 1) {
            mode = 1; reason = 7;
        }
        var prior = value("srOAdaptiveV32650");
        if (mode == 0 && num(prior) && prior >= 10 && prior < 30 && hourlyOK) {
            var firstCalm = value("srOCalmProbeV32652");
            if (!num(firstCalm) || firstCalm <= 0 || firstCalm >= hourly[2]) {
                if (firstCalm != hourly[2]) {
                    diagWrite("srOCalmProbeV32652", hourly[2]);
                }
                mode = 1; reason = 6;
            } else { diagWrite("srOCalmProbeV32652", 0); }
        } else if (mode > 0 && value("srOCalmProbeV32652") != 0) {
            diagWrite("srOCalmProbeV32652", 0);
        }
        return risk(mode, reason);
    }
    // Core feeds are budgeted symmetrically: 5 current + 5 hourly attempts
    // per nominal hour, plus up to 2 auxiliary opportunities. A missed or
    // delayed Garmin wake shifts actual times; these are targets, not SLAs.
    function currentSeconds() {
        return _interval <= 15 ? 10 * 60 : _interval * 60;
    }
    function forecastSeconds() {
        return _interval <= 15 ? 10 * 60 : _interval * 60;
    }
    function shortSeconds() {
        return _interval <= 15 ? (_alertMode == 2 ? 60 * 60 :
                                  _alertMode == 1 ? 90 * 60 : 120 * 60) :
                                  90 * 60;
    }
    function airSeconds() {
        return _interval <= 15 && _alertMode == 2 ? 90 * 60 : 75 * 60;
    }
    // Two separate background memory failures (including missing callbacks)
    // disable only the optional 15m feed until the user explicitly toggles
    // it off/on in settings. Do not trigger another daily OOM automatically.
    function shortLocked() {
        var faults = value("srOShortFaultV32652");
        return num(faults) && faults >= 2;
    }
    function shortReady() {
        if (!_shortEnabled || shortLocked()) { return false; }
        var paused = value("srOShortPausedV3264");
        return !(num(paused) && paused > _now);
    }
    function schedule() {
        var now = Time.now().value();
        var earliest = deadline("srONextCV326", "srOCurrV326", currentSeconds());
        var f = deadline("srONextFV326", "srOHoursV326", forecastSeconds());
        if (earliest == 0 || f < earliest) { earliest = f; }
        if (shortReady()) {
            var sh = deadline("srONextSV32648", "srOShortV3264", shortSeconds());
            if (earliest == 0 || sh < earliest) { earliest = sh; }
        }
        var daily = deadline("srONextDV326", "srODayV326", 12 * 3600);
        if (earliest == 0 || daily < earliest) { earliest = daily; }
        if (setting("srOwmAirV326", false)) {
            var a = deadline("srONextAV326", "srOAirV326", airSeconds());
            if (earliest == 0 || a < earliest) { earliest = a; }
        }
        // Preserve a dedicated chance for unresolved Photon. It is never
        // prevented by the secondary daily/AQI/high-resolution endpoints.
        var target = value("srGRequest");
        var known = value("srGResult");
        var missing = !(known instanceof Lang.Array && known.size() == 3 &&
            sameCity(known, _loc) && known[2] instanceof Lang.String);
        if (missing) {
            var cityAt = now + 5 * 60;
            var next = value("srGNextAt");
            var last = value("srGLastTry");
            if (num(next) && next > cityAt && next <= now + 60 * 60 &&
                !(num(last) && next - last > 60 * 60)) { cityAt = next; }
            if (num(last) && last + 15 * 60 > cityAt &&
                last <= now + 300) { cityAt = last + 15 * 60; }
            try {
                if (Sys.getDeviceSettings().phoneConnected &&
                    (earliest == 0 || cityAt < earliest)) { earliest = cityAt; }
            } catch (e) { }
        }
        var seconds = earliest - now;
        if (seconds < 300) { seconds = 300; }
        if (seconds > 6 * 3600) { seconds = 6 * 3600; }
        if (_interval <= 15 && !_unsafe) {
            // WeatherGuard needs a regular chance to react to a NEW Garmin
            // observation or changed 1h/current data. Exactly one HTTP max.
            seconds = 300;
            try {
                if (!Sys.getDeviceSettings().phoneConnected) { seconds = 600; }
            } catch (e) { }
        }
        if (_unsafe) { seconds = 6 * 3600; }
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(seconds)));
        } catch (e) { _diagStep = 90; status(-222); }
    }
    // Endpoint index: 0=position, 1=current, 2=forecast, 3=daily, 4=AQI.
    // Diagnostic result uses HTTP code or a small local negative code.
    // Durable pipeline breadcrumbs: [epoch, gate, endpoint, currentWaitSec, forecastWaitSec].
    // Each gate is a concrete stage, not a guessed HTTP or GPS error.
    // Bounded numeric-only record, no token, URL, response text or coordinates.
    function gate(stage) {
        var trace = setting("gwPreviewV332", 0);
        if (stage != 18 && stage < 90 && trace < 16) { return; }
        var now = Time.now().value();
        var c = value("srONextCV326");
        var f = value("srONextFV326");
        var cw = -1;
        var fw = -1;
        if (num(c) && c > 0) { cw = c.toNumber() - now; }
        if (num(f) && f > 0) { fw = f.toNumber() - now; }
        // No persistent flash write at every internal stage in normal use.
        // Keep the request gate (needed for async callback recovery), terminal
        // failures and the verbose diagnostic mode.
        diagWrite("srODGateV3269", [now, stage, phase(), cw, fw]);
    }
    function runSafely() {
        try { start(); }
        catch (e) {
            // If anything fails before makeWebRequest or before its normal
            // error handler, retain a visible breadcrumb and retry safely.
            _diagStep = 91;
            gate(90);
            status(-230);
            try {
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(10 * 60)));
            } catch (e2) { }
            Bg.exit(["OWM", 0]);
        }
    }
    // Monkey C compares String references with ==; compare contents using equals().
    // Without this, every request can be labelled P0 and sent to the wrong endpoint.
    function kindIs(name) {
        return _kind instanceof Lang.String && _kind.equals(name);
    }
    function phase() {
        if (kindIs("current")) { return 1; }
        if (kindIs("forecast")) { return 2; }
        if (kindIs("daily")) { return 3; }
        if (kindIs("air")) { return 4; }
        return 0;
    }
    function endpointKey(p) {
        if (p == 1) { return "srODNowV3268"; }
        if (p == 2) { return "srODForecastV3268"; }
        if (p == 3) { return "srODDailyV3268"; }
        if (p == 4) { return "srODAirV3268"; }
        return "srODSystemV3268";
    }
    function status(code) {
        // Format of per-endpoint snapshot: [time, endpoint, stage, result,
        // structural flags, response records, accepted records, ageSec, 15m].
        // The legacy 3-field status remains readable by the old TEST 15.
        var p = phase();
        // Background can be killed/restarted during an async request. If
        // transient _kind is unavailable, use the last safely stored phase.
        if (p == 0 && code != 0) {
            var selected = value("srODGateV3269");
            if (selected instanceof Lang.Array && selected.size() == 5 &&
                num(selected[0]) && num(selected[2]) &&
                selected[0] <= Time.now().value() + 300 &&
                Time.now().value() - selected[0] <= 1800 &&
                selected[2] >= 1 && selected[2] <= 4) {
                p = selected[2];
            }
        }
        if (p == 0 && code != 0) {
            var ctx = value("srOReqCtxV3267");
            var tm = Time.now().value();
            if (ctx instanceof Lang.Array && ctx.size() == 6 &&
                num(ctx[0]) && num(ctx[1]) &&
                ctx[0] <= tm + 300 && tm - ctx[0] <= 1800 &&
                ctx[1] >= 1 && ctx[1] <= 4) { p = ctx[1]; }
        }
        var stamp = Time.now().value();
        diagWrite("srODiagV3266", [stamp, p, code]);
        diagWrite(endpointKey(p), [stamp, p, _diagStep, code, _diagMask,
                               _diagRows, _diagAccepted, _diagAge,
                               _shortRequest ? 1 : 0]);
        // Diagnostic snapshots, never raw HTTP body, token or coordinates.
        // 100=sent/queued, 200=parsed+saved, 401=invalid key,
        // 403=endpoint access, 429=rate limit; negatives are local failures.
        if (p == 2) {
            diagWrite(_shortRequest ? "srOD15mV32648" : "srOD1hV32648",
                      [stamp, code, _diagStep, _diagAccepted]);
        }
        // Keep the last six terminal outcomes. Each entry is four integers.
        // Never retain the API token, request URL, location or response body.
        // Store failed attempts in full; successful requests already have a
        // per-endpoint status and need no duplicate history write every 5min.
        if (code != 100 && code != 0 &&
            (code != 200 || setting("gwPreviewV332", 0) >= 16)) {
            var old = value("srODHistoryV3268");
            var history = [];
            if (old instanceof Lang.Array) {
                var first = old.size() > 5 ? old.size() - 5 : 0;
                for (var i = first; i < old.size(); i++) {
                    if (old[i] instanceof Lang.Array && old[i].size() == 4) {
                        history.add(old[i]);
                    }
                }
            }
            history.add([stamp, p, code, _diagStep]);
            diagWrite("srODHistoryV3268", history);
        }
    }
    // A compact structural fingerprint, independent from the parser result.
    // Flags: 1=dict 2=array 4=nonempty 8=first record dict,
    // 16=dt 32=temp 64=weather ID 128=timezone 256=air.main.
    function inspectResponse(data) {
        _diagMask = 0;
        _diagRows = 0;
        _diagAccepted = 0;
        _diagAge = 0;
        _alertMode = -1;
        if (!dictionary(data)) { return; }
        _diagMask += 1;
        if (num(data["timezone_offset"])) { _diagMask += 128; }
        var rows = kindIs("air") ? data["list"] : data["data"];
        if (!(rows instanceof Lang.Array)) { return; }
        _diagMask += 2;
        _diagRows = rows.size();
        if (_diagRows < 1) { return; }
        _diagMask += 4;
        var row = rows[0];
        if (!dictionary(row)) { return; }
        _diagMask += 8;
        if (num(row["dt"])) {
            _diagMask += 16;
            _diagAge = _now - row["dt"].toNumber();
        }
        if (num(row["temp"]) || dictionary(row["temp"])) {
            _diagMask += 32;
        }
        if (firstId(row) != null) { _diagMask += 64; }
        if (dictionary(row["main"])) { _diagMask += 256; }
    }
    // An HTTP callback can arrive after a background-service state change.
    // Restore only the bounded request metadata, never the API key or JSON.
    function restoreRequestContext() {
        var r = value("srOReqCtxV3267");
        var t = Time.now().value();
        if (!(r instanceof Lang.Array) || r.size() != 6 ||
            !num(r[0]) || !num(r[1]) || !num(r[2]) || !num(r[3]) ||
            !num(r[4]) || !num(r[5]) || r[0] > t + 300 ||
            t - r[0] > 1800 || r[1] < 1 || r[1] > 4) { return false; }
        var pos = [r[2], r[3], r[0]];
        if (!coords(pos)) { return false; }
        _kind = r[1] == 1 ? "current" : r[1] == 2 ? "forecast" :
                r[1] == 3 ? "daily" : "air";
        _now = r[0];
        _loc = pos;
        _interval = r[4];
        _shortRequest = r[5] == 1;
        return true;
    }
    function finish(changed) {
        schedule();
        Bg.exit(["OWM", changed ? 1 : 0]);
    }
    function fail(code) {
        if (_diagStep < 20) { _diagStep = 12; }
        status(code);
        if (_shortRequest) { write("srOShortAttemptV3264", 0); }
        // A 15min endpoint failure must not disable the basic hourly alerts.
        // HTTP 401/403/429 are key/rate-limit problems; retrying the same
        // credentials against 1h would be wasteful. -403 is Garmin's network
        // out-of-memory error, NOT HTTP 403; fall back without a retry loop.
        if (kindIs("forecast") && _shortRequest &&
            code != -12 && code != 401 && code != 403 && code != 429) {
            // Memory failures get a long circuit breaker, invalid payloads
            // only a short delay. Repeated OOM doubles the safety interval.
            var faults = value("srOShortFaultV32652");
            if (!num(faults) || faults < 0 || faults > 3) { faults = 0; }
            var memoryFault = code == -402 || code == -403 || code == -217;
            if (memoryFault) { faults += 1; }
            if (faults > 3) { faults = 3; }
            write("srOShortFaultV32652", faults);
            var pauseShort = memoryFault ? (faults >= 2 ? 24 * 3600 : 6 * 3600) : 30 * 60;
            // 2+ faults also latch shortLocked() until settings toggle.
            write("srOShortPausedV3264", _now + pauseShort);
            write("srONextSV32648", _now + pauseShort);
            finish(false);
            return;
        }
        // Hourly payload may still be too large on low-memory devices.
        // Retry once with only two timeline rows, then use the normal
        // six-hour backoff if even the minimal response cannot be parsed.
        if (kindIs("forecast") && !_shortRequest && code == -403 &&
            value("srOHourlyTinyV32611") != 1) {
            write("srOHourlyTinyV32611", 1);
            write("srONextFV326", _now + 10 * 60);
            finish(false); return;
        }
        // A bad key stops hammering the endpoint, but editing the key clears
        // deadlines immediately. HTTP 429 uses an hour, not a whole day.
        // Memory exhaustion pauses the affected endpoint, not other feeds.
        var pause = code == -12 ? 5 * 60 : 15 * 60;
        if (code == 401) { pause = 30 * 60; }
        if (code == 403 || code == 429) { pause = 60 * 60; }
        if (code == -403) { pause = 60 * 60; }
        if (kindIs("current")) { write("srONextCV326", _now + pause); }
        if (kindIs("forecast")) {
            write(_shortRequest ? "srONextSV32648" : "srONextFV326",
                  _now + pause);
        }
        if (kindIs("daily")) { write("srONextDV326", _now + pause); }
        if (kindIs("air")) { write("srONextAV326", _now + pause); }
        finish(false);
    }
    function reserveQuota() {
        var day = (_now / 86400).toNumber(); // UTC day
        var budget = value("srOBudgetV32613");
        var used = 0;
        if (budget instanceof Lang.Array && budget.size() == 2 &&
            num(budget[0]) && num(budget[1]) && budget[0] == day &&
            budget[1] >= 0 && budget[1] < 10000) {
            used = budget[1];
        }
        if (used >= 700) { return false; }
        // Reserve before makeWebRequest, including an unsuccessful attempt.
        return write("srOBudgetV32613", [day, used + 1]);
    }
    function start() {
        _now = Time.now().value();
        _diagStep = 10; // Background service actually woke.
        // Night suspension comes first: avoid diagnostic writes, flash I/O
        // and network calls while the sleep watch face is in use.
        if (nightWindow()) { waitForMorning(); return; }
        // Diagnostic wake time only while troubleshooting.
        if (setting("gwPreviewV332", 0) >= 16) {
            diagWrite("srODWakeV3268", _now);
        }
        gate(10);
        if (setting("srProviderV326", 0) != 1) {
            gate(11);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        _key = setting("srOpenKeyV326", "");
        _loc = value("srOLocV326");
        if (!(_key instanceof Lang.String) || _key.length() < 8) {
            gate(12); status(-11);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        // Use the last location seen on the face, even when a Garmin
        // weather observation is older than 3h. Never request data using
        // coordinates absent or not seen by the face for over 48h.
        if (!coords(_loc) || _loc.size() < 3 || !num(_loc[2]) ||
            _loc[2] > _now + 300 || _now - _loc[2] > 48 * 3600) {
            gate(13); status(-10);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        _interval = setting("srOwmMinutesV326", 30);
        if (_interval != 5 && _interval != 15 && _interval != 30 && _interval != 60) {
            _interval = 30;
        }
        _shortEnabled = setting("srOwm15MinV3264", true) == true;
        if (_interval > 15) { risk(3, 0); }
        else { activeWeather(); }
        var previousStatus = value("srODiagV3266");
        if (previousStatus instanceof Lang.Array && previousStatus.size() == 3 &&
            num(previousStatus[0]) && previousStatus[2] == 100 &&
            previousStatus[0] < _now - 8 * 60) {
            _diagStep = 90;
            status(-17);
            _diagStep = 10;
        }
        // Previous 15m call may have been preempted before a callback.
        // Backoff is endpoint-only and escalates for repeated failures.
        var orphaned = value("srOShortAttemptV3264");
        if (num(orphaned) && orphaned > 0 &&
            orphaned <= _now - 5 * 60 && orphaned >= _now - 24 * 3600) {
            // A start without a terminal callback is NOT "never attempted".
            // Record it against 15m before the memory circuit breaker, so
            // TEST 22 shows the actual last attempted endpoint.
            diagWrite("srOD15mV32648", [_now, -217, 90, 0]);
            var orphanFaults = value("srOShortFaultV32652");
            if (!num(orphanFaults) || orphanFaults < 0 || orphanFaults > 3) {
                orphanFaults = 0;
            }
            orphanFaults += 1;
            if (orphanFaults > 3) { orphanFaults = 3; }
            write("srOShortFaultV32652", orphanFaults);
            var orphanPause = orphanFaults >= 2 ? 24 * 3600 : 6 * 3600;
            // At 2+ faults shortLocked() suppresses all further 15m requests.
            write("srOShortPausedV3264", _now + orphanPause);
            write("srONextSV32648", _now + orphanPause);
        }
        if (num(orphaned) && orphaned > 0) {
            write("srOShortAttemptV3264", 0);
        }
        var nextC = deadline("srONextCV326", "srOCurrV326", currentSeconds());
        var nextF = deadline("srONextFV326", "srOHoursV326", forecastSeconds());
        var nextD = deadline("srONextDV326", "srODayV326", 12 * 3600);
        var nextA = deadline("srONextAV326", "srOAirV326", airSeconds());
        var nextS = _shortEnabled && shortReady() ?
            deadline("srONextSV32648", "srOShortV3264", shortSeconds()) :
            _now + shortSeconds();
        // WeatherSync 5 fairness: two nominal auxiliary slots per hour, but
        // only while BOTH core snapshots are recent. In a stale-data or
        // reconnect recovery the essential feeds always take precedence.
        var c = value("srOCurrV326");
        var h = value("srOHoursV326");
        var ageC = 999999;
        var ageF = 999999;
        if (c instanceof Lang.Array && c.size() == 19 &&
            same(c, _loc) && num(c[2]) && c[2] <= _now) {
            ageC = _now - c[2];
        }
        if (h instanceof Lang.Array && h.size() == 4 &&
            same(h, _loc) && num(h[2]) && h[2] <= _now) {
            ageF = _now - h[2];
        }
        var wantC = nextC <= _now;
        var wantF = nextF <= _now;
        var airDue = setting("srOwmAirV326", false) && nextA <= _now;
        var dailyDue = nextD <= _now;
        var shortDue = _shortEnabled && shortReady() && nextS <= _now;
        var cityDue = cityLookupDue();
        var lastAux = value("srOAuxLastV32654");
        if (!num(lastAux) || lastAux > _now ||
            _now - lastAux > 48 * 3600) { lastAux = 0; }
        var reserveAux = _interval <= 15 &&
            (cityDue || shortDue || airDue || dailyDue) &&
            ageC <= 16 * 60 && ageF <= 16 * 60 &&
            (lastAux == 0 || _now - lastAux >= 25 * 60);
        // Portable selection logic for slow/manual 30/60 minute profiles.
        // The first two OWM feeds always outrank optional services when old.
        if ((wantC || wantF) && !reserveAux) {
            if (wantC && wantF) {
                if (ageF >= ageC) { _kind = "forecast"; }
                else { _kind = "current"; }
            } else if (wantF) { _kind = "forecast"; }
            else { _kind = "current"; }
        }
        // Aux order: Photon once when city unknown, overdue AQI, overdue
        // daily, 15m then normal AQI/daily. A failed 15m never blocks core.
        if (kindIs("") && (reserveAux || (!wantC && !wantF))) {
            if (cityDue && Sys.getDeviceSettings().phoneConnected) {
                if (_interval <= 15) { diagWrite("srOAuxLastV32654", _now); }
                if (setting("gwPreviewV332", 0) == 22 ||
                    setting("gwPreviewV332", 0) == 23) {
                    diagWrite("srOPlanV32654", [_now, 6, 2,
                        (ageC / 60).toNumber(), (ageF / 60).toNumber(),
                        ((nextC - _now) / 60).toNumber(),
                        ((nextF - _now) / 60).toNumber(),
                        ((nextS - _now) / 60).toNumber(),
                        lastAux == 0 ? -1 : ((_now - lastAux) / 60).toNumber()]);
                }
                startCityLookup(); return;
            }
            if (airDue && nextA < _now - 30 * 60) { _kind = "air"; }
            else if (dailyDue && nextD < _now - 2 * 3600) { _kind = "daily"; }
            else if (shortDue) { _kind = "forecast"; _shortRequest = true; }
            else if (airDue) { _kind = "air"; }
            else if (dailyDue) { _kind = "daily"; }
            if (!kindIs("") && _interval <= 15) {
                diagWrite("srOAuxLastV32654", _now);
            }
        }
        // A stored backoff may make a core feed temporarily unavailable.
        // Never send another HTTP in that case merely to fill an empty slot.
        if (kindIs("") && (wantC || wantF)) {
            if ((wantC && wantF && ageF >= ageC) || (!wantC && wantF)) {
                _kind = "forecast";
            } else if (wantC) { _kind = "current"; }
        }
        if (setting("gwPreviewV332", 0) == 22 ||
            setting("gwPreviewV332", 0) == 23) {
            var picked = _shortRequest ? 3 :
                kindIs("current") ? 1 : kindIs("forecast") ? 2 :
                kindIs("air") ? 4 : kindIs("daily") ? 5 : 0;
            diagWrite("srOPlanV32654", [_now, picked,
                reserveAux ? 2 : 1, (ageC / 60).toNumber(),
                (ageF / 60).toNumber(),
                ((nextC - _now) / 60).toNumber(),
                ((nextF - _now) / 60).toNumber(),
                ((nextS - _now) / 60).toNumber(),
                lastAux == 0 ? -1 : ((_now - lastAux) / 60).toNumber()]);
        }
        if (kindIs("")) { gate(14); finish(false); return; }
        // Never send a request if the endpoint type is not known.
        if (phase() == 0) { gate(16); status(-232); finish(false); return; }
        gate(16); // Which endpoint was actually selected?
        if (!Sys.getDeviceSettings().phoneConnected) {
            gate(15); fail(-12); return;
        }
        var route = "";
        if (kindIs("current")) { route = "https://api.openweathermap.org/data/4.0/onecall/current"; }
        else if (kindIs("forecast")) {
            if (_shortRequest) {
                route = "https://api.openweathermap.org/data/4.0/onecall/timeline/15min";
            } else {
                route = "https://api.openweathermap.org/data/4.0/onecall/timeline/1h";
            }
        }
        else if (kindIs("daily")) { route = "https://api.openweathermap.org/data/4.0/onecall/timeline/1day"; }
        else { route = "https://api.openweathermap.org/data/2.5/air_pollution"; }
        var q = {
            "lat" => _loc[0].format("%.4f"),
            "lon" => _loc[1].format("%.4f"),
            "appid" => _key
        };
        if (!kindIs("air")) {
            q["units"] = "metric";
            q["lang"] = "pl";
        }
        // OpenWeather 4.0 documents up to 20 x 1h / 50 x 15m rows per
        // response. The API documentation does NOT guarantee that 'cnt'
        // trims timeline responses; keep the memory circuit breaker for 15m.
        // Hourly data remain the reliable primary forecast for alerts.
        if (kindIs("forecast")) {
            if (_shortRequest) { q["cnt"] = "12"; }
            else {
                q["cnt"] = value("srOHourlyTinyV32611") == 1 ? "2" : "4";
            }
        } else if (kindIs("daily")) { q["cnt"] = "2"; }
        // Conservative on-device total weather API budget (includes AQI).
        // Other devices/apps using the same API key are NOT covered; set
        // OpenWeather's account-level daily limit separately.
        if (!reserveQuota()) {
            _diagStep = 18; status(-234); finish(false); return;
        }
        // Protect against a missing callback or a killed background process.
        // A conservative deadline is persisted BEFORE the request, and a
        // one-shot 15-min watchdog is armed. Successful callback replaces the
        // watchdog with the normal schedule, without an extra persistent
        // write when the deadline remains the same.
        var nextKey = "srONextCV326";
        var nextEpoch = _now + currentSeconds();
        if (kindIs("forecast")) {
            nextKey = _shortRequest ? "srONextSV32648" : "srONextFV326";
            nextEpoch = _now + (_shortRequest ? shortSeconds() : forecastSeconds());
        } else if (kindIs("daily")) {
            nextKey = "srONextDV326";
            nextEpoch = _now + 12 * 3600;
        } else if (kindIs("air")) {
            nextKey = "srONextAV326";
            nextEpoch = _now + airSeconds();
        }
        if (!write(nextKey, nextEpoch)) { status(-16); finish(false); return; }
        if (_shortRequest && !write("srOShortAttemptV3264", _now)) {
            finish(false); return;
        }
        // Persist just the request phase and location for callback recovery.
        if (!write("srOReqCtxV3267", [_now, phase(), _loc[0], _loc[1],
                                     _interval, _shortRequest ? 1 : 0])) {
            status(-154); finish(false); return;
        }
        gate(17); // Request context persisted.
        _diagStep = 20; // Request queued for Connect IQ.
        status(100);
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(15 * 60)));
        } catch (e) { fail(-221); return; }
        try {
            // The gate is persisted before the asynchronous network call.
            gate(18);
            Comm.makeWebRequest(route, q, {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            }, method(:onReceive));
        } catch (e) { fail(-220); }
    }
    // Resolve coordinates actually used by OWM. Background can create the
    // target even if the watch-face display cache skips a draw update.
    function cityLookupDue() {
        try {
            // One-time migration of the old Photon lang=pl request.
            // That language was rejected by the public server (HTTP 400).
            // Preserve an already verified city, but clear old error delays.
            if (value("srGQueryV32649") != 1) {
                if (!write("srGQueryV32649", 1)) { return false; }
                write("srGNextAt", 0);
                write("srGLastTry", 0);
                write("srGWideV32648", 0);
            }
            var target = value("srGRequest");
            if (!sameCity(target, _loc)) {
                if (!write("srGRequest", [_loc[0], _loc[1]])) { return false; }
                write("srGWideV32648", 0);
                target = _loc;
            }
            var known = value("srGResult");
            if (known instanceof Lang.Array && known.size() == 3 &&
                sameCity(known, target) && known[2] instanceof Lang.String) {
                return false;
            }
            var next = value("srGNextAt");
            var last = value("srGLastTry");
            // Retire old v3.26.37 multi-hour cooldowns in place. A 429
            // response in the new policy is allowed up to one hour.
            if (num(next) && next > _now &&
                !(num(last) && last > 0 && next - last > 60 * 60) &&
                next <= _now + 60 * 60) {
                return false;
            }
            if (num(last) && last > 0 && _now - last < 15 * 60) {
                return false;
            }
            return true;
        } catch (e) { return false; }
    }

    // [UTC epoch, stage, transport/HTTP]. Written only when Photon runs.
    function cityTrace(stage, code) {
        diagWrite("srGTraceV32647", [Time.now().value(), stage, code]);
    }
    function cityRetry(code) {
        // HTTP 400 is a request problem, not a quota lockout; allow a
        // corrected request to retry after the minimum 15-minute interval.
        var minutes = 30;
        // Invalid requests must not hammer Photon or starve optional OWM feeds.
        // v3.26.49 clears the OLD 400 cooldown once, so it retries immediately.
        if (code == 429) { minutes = 60; }
        write("srGNextAt", Time.now().value() + minutes * 60);
    }

    function startCityLookup() {
        // One response rather than three minimizes Connect IQ background RAM.
        // One HTTP request per wake, using the same OWM temporal event.
        try {
            if (!Sys.getDeviceSettings().phoneConnected) {
                finish(false);
                return;
            }
            if (!write("srGLastTry", _now)) { finish(false); return; }
            if (!write("srGNextAt", _now + 15 * 60)) {
                finish(false); return;
            }
            var wide = value("srGWideV32648") == 1;
            var q = {
                "lat" => _loc[0].format("%.4f"),
                "lon" => _loc[1].format("%.4f"),
                "limit" => "2",
                "radius" => wide ? "15" : "10"
            };
            if (!wide) { q["osm_tag"] = "place"; }
            // Background callback watchdog; a timeout is retryable.
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(15 * 60)));
            cityTrace(10, 0);
            Comm.makeWebRequest("https://photon.komoot.io/reverse", q, {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            }, method(:onCityReceive));
        } catch (e) {
            cityTrace(29, -1);
            cityRetry(-1);
            finish(false);
        }
    }

    function onCityReceive(code as Lang.Number,
        data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        var saved = false;
        var stage = 23; // valid HTTP, no usable place name
        try {
            if (code < 0) { stage = 27; }
            else if (code != 200) { stage = 21; }
            else if (!(data instanceof Lang.Dictionary)) { stage = 22; }
            else {
                var items = data["features"];
                if (items instanceof Lang.Array && items.size() > 0) {
                    var count = items.size();
                    if (count > 2) { count = 2; }
                    for (var i = 0; i < count; i++) {
                        if (!(items[i] instanceof Lang.Dictionary)) { continue; }
                        // Explicit cast avoids a Garmin Monkey C type-inference
                        // error when indexing a union-typed API response.
                        var feature = items[i] as Lang.Dictionary;
                        var props = feature["properties"];
                        if (!(props instanceof Lang.Dictionary)) { continue; }
                        var city = props["city"];
                        if (!(city instanceof Lang.String) || city.length() < 2) {
                            var osm = props["osm_key"];
                            // The nearby feature's own name is only valid
                            // for an actual place, never a road or business.
                            if (osm instanceof Lang.String && osm.equals("place")) {
                                city = props["name"];
                            }
                        }
                        if (!(city instanceof Lang.String) ||
                            city.length() < 2 || city.length() > 42) { continue; }
                        if (!sameCity(_loc, value("srGRequest")) ||
                            !sameCity(_loc, value("srOLocV326"))) {
                            stage = 24;
                        } else {
                            saved = write("srGResult", [_loc[0], _loc[1], city.toUpper()]);
                            stage = saved ? 20 : 25;
                        }
                        break;
                    }
                }
            }
        } catch (e) { saved = false; stage = 29; }
        cityTrace(stage, code);
        if (saved) {
            write("srGFail", 0);
            write("srGWideV32648", 0);
            write("srGNextAt", 0);
        } else {
            // First 200/no place: next attempt reads the city from a nearby
            // feature's administrative field instead of a road's name.
            if (code == 200 && stage == 23 && value("srGWideV32648") != 1) {
                write("srGWideV32648", 1);
                write("srGNextAt", Time.now().value() + 15 * 60);
            } else { cityRetry(code); }
        }
        finish(saved);
    }

    function dictionary(v) { return v != null && v instanceof Lang.Dictionary; }
    function firstId(d) {
        if (!dictionary(d)) { return null; }
        var list = d["weather"];
        if (!(list instanceof Lang.Array) || list.size() < 1 ||
            !dictionary(list[0])) { return null; }
        var id = list[0]["id"];
        return num(id) ? id.toNumber() : null;
    }
    function nestedRate(d, key) {
        var r = d[key];
        if (!dictionary(r)) { return null; }
        var amount = r["1h"];
        return num(amount) ? amount : null;
    }
    function pct(d) {
        var p = d["pop"];
        if (p == null) { return null; }
        // Invalid but present is NOT the same thing as absent: -1 sentinel.
        // View model turns this sentinel into --, warning rule fails closed.
        if (!num(p) || p < 0 || p > 1) { return -1; }
        return (p * 100).toNumber();
    }
    function optionalNumber(d, k) {
        var v = d[k];
        return num(v) ? v : null;
    }
    function onReceive(code as Lang.Number,
            data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        _diagStep = 25; // Callback invoked, regardless of HTTP code.
        // Also restore context on a normal callback: storage is authoritative
        // for endpoint and the 15-minute variant after a background restart.
        if (phase() == 0) { restoreRequestContext(); }
        gate(19);
        if (phase() == 0) {
            status(-19); Bg.exit(["OWM", 0]); return;
        }
        if (code != 200) { fail(code); return; }
        _diagStep = 30;
        try { inspectResponse(data); }
        catch (e) { fail(-216); return; }
        if (!dictionary(data)) { fail(-151); return; }
        // Keep the attempt marker until the entire response is validated and
        // successfully saved. If background dies DURING JSON processing, the
        // watchdog must still notice the orphan and switch to hourly.
        // Location may have changed while HTTP was pending; never save
        // a response from the previous city as the new city's weather.
        if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }
        var ok = false;
        var reason = -214; // Explicit unknown branch; no generic FORMAT -152.
        try {
            if (kindIs("current")) {
                // One Call 4.0 current uses {"data":[{...}]} (one item),
                // not the older 2.5/3.0 nested current Dictionary.
                var currentRows = data["data"];
                // Do not initialise 'd' with null: Monkey C infers Null and
                // rejects d["dt"] / d["temp"] even after dictionary(d).
                // Cast only an explicitly validated Dictionary, and keep all
                // indexed reads inside that guard (no additional allocations).
                if (!(currentRows instanceof Lang.Array)) { reason = -202; }
                else if (currentRows.size() == 0) { reason = -203; }
                else if (!dictionary(currentRows[0])) { reason = -204; }
                // V4 current normally returns one row. Do not reject a valid
                // first row solely because a future API response adds rows.
                if (currentRows instanceof Lang.Array && currentRows.size() > 0 &&
                    dictionary(currentRows[0])) {
                    var d = currentRows[0] as Lang.Dictionary;
                    if (!num(d["dt"])) { reason = -205; }
                    else if (!num(d["temp"])) { reason = -206; }
                    else if (d["dt"] > _now + 300 || _now - d["dt"] > 5400) {
                        reason = -153;
                    }
                    if (dictionary(d) && num(d["dt"]) && num(d["temp"]) &&
                        d["dt"] <= _now + 300 && _now - d["dt"] <= 5400) {
                        var snapshot = [
                            _loc[0], _loc[1], _now, d["dt"].toNumber(),
                            d["temp"], optionalNumber(d,"feels_like"),
                            optionalNumber(d,"wind_speed"), optionalNumber(d,"humidity"),
                            optionalNumber(d,"uvi"), optionalNumber(d,"visibility"),
                            optionalNumber(d,"clouds"), firstId(d),
                            optionalNumber(d,"pressure"), optionalNumber(d,"sunrise"),
                            optionalNumber(d,"sunset"), optionalNumber(d,"wind_gust"), pct(d),
                            nestedRate(d,"rain"), nestedRate(d,"snow")
                        ];
                        reason = -154;
                        _diagStep = 60;
                        ok = write("srOCurrV326", snapshot);
                        if (ok) { _diagAccepted = 1; }
                        if (ok) { write("srONextCV326", _now + currentSeconds()); }
                    } // Missing values and stale time are reported separately.
                }
            } else if (kindIs("forecast")) {
                // Both timelines use {data:[{dt,weather,pop,...}]}. The
                // high-resolution endpoint may send 50 records; bound both
                // iteration and STORAGE to the upcoming 3h (12 x 15min).
                // WARNING: this does not shrink the HTTP/JSON response itself.
                var records = data["data"];
                if (!(records instanceof Lang.Array)) { reason = -202; }
                else if (records.size() == 0) { reason = -203; }
                if (records instanceof Lang.Array && records.size() > 0) {
                    var mini = [];
                    var count = records.size();
                    if (count > 50) { count = 50; }
                    var horizonSeconds = _shortRequest ? 3 * 3600 : 5 * 3600;
                    var maxRows = _shortRequest ? 12 : 5;
                    var previous = 0;
                    for (var i = 0; i < count; i++) {
                        var h = records[i];
                        if (!dictionary(h) || !num(h["dt"])) { continue; }
                        var t = h["dt"].toNumber();
                        // Timeline stamps are period start/validity times.
                        // The current 1h / 15m forecast bucket can start
                        // before now without being an OBSERVED condition.
                        var bucket = _shortRequest ? 900 : 3600;
                        if (t <= _now - bucket || t > _now + horizonSeconds ||
                            t <= previous) { continue; }
                        // Forecast format shared with the old 1h engine.
                        mini.add([t, firstId(h), optionalNumber(h,"wind_speed"),
                            optionalNumber(h,"temp"), optionalNumber(h,"uvi"),
                            pct(h), nestedRate(h,"rain"), nestedRate(h,"snow"),
                            optionalNumber(h,"visibility"), optionalNumber(h,"wind_gust")]);
                        previous = t;
                        if (mini.size() >= maxRows) { break; }
                    }
                    // Never overwrite a good forecast with zero valid rows.
                    // At least one mapped record is required for the new
                    // endpoint; otherwise automatically switch back to 1h.
                    var valid = mini.size() > 0;
                    if (valid && _shortRequest) {
                        var recognized = false;
                        for (var z = 0; z < mini.size(); z++) {
                            if (mini[z][1] != null) { recognized = true; break; }
                        }
                        valid = recognized;
                    }
                    if (!valid) {
                        reason = mini.size() > 0 ? -209 : -208;
                    } else { _diagAccepted = mini.size(); }
                    if (valid) {
                        var saveKey = _shortRequest ? "srOShortV3264" : "srOHoursV326";
                        reason = -154;
                        _diagStep = 60;
                        ok = write(saveKey, [_loc[0], _loc[1], _now, mini]);
                        if (ok) {
                            write(_shortRequest ? "srONextSV32648" : "srONextFV326",
                                  _now + (_shortRequest ? shortSeconds() : forecastSeconds()));
                        }
                    }
                }
            } else if (kindIs("daily")) {
                var days = data["data"];
                var tz = data["timezone_offset"];
                if (!(days instanceof Lang.Array)) { reason = -202; }
                else if (!num(tz)) { reason = -211; }
                else if (days.size() == 0) { reason = -203; }
                if (days instanceof Lang.Array && num(tz)) {
                    var currentDay = ((_now + tz) / 86400).toNumber();
                    var day = null;
                    for (var k = 0; k < days.size() && k < 10; k++) {
                        var item = days[k];
                        if (!dictionary(item) || !num(item["dt"]) ||
                            !dictionary(item["temp"])) { continue; }
                        var dayId = ((item["dt"] + tz) / 86400).toNumber();
                        if (dayId != currentDay) { continue; }
                        var temps = item["temp"];
                        if (num(temps["min"]) && num(temps["max"])) {
                            day = [_loc[0],_loc[1],_now,dayId,temps["min"],temps["max"],tz];
                        }
                        break;
                    }
                    if (day == null) { reason = -210; }
                    if (day != null) {
                        reason = -154;
                        _diagStep = 60;
                        ok = write("srODayV326", day);
                        if (ok) { _diagAccepted = 1; }
                        if (ok) { write("srONextDV326", _now + 12 * 3600); }
                    }
                }
            } else if (kindIs("air")) {
                var air = data["list"];
                if (!(air instanceof Lang.Array)) { reason = -202; }
                else if (air.size() == 0) { reason = -203; }
                else if (!dictionary(air[0])) { reason = -204; }
                else if (!dictionary(air[0]["main"])) { reason = -212; }
                if (air instanceof Lang.Array && air.size() > 0 &&
                    dictionary(air[0]) && dictionary(air[0]["main"])) {
                    var a = air[0]["main"]["aqi"];
                    var t2 = air[0]["dt"];
                    if (num(a) && a >= 1 && a <= 5 && num(t2) &&
                        t2 <= _now + 300 && _now - t2 <= 7200) {
                        reason = -154;
                        _diagStep = 60;
                        ok = write("srOAirV326", [_loc[0],_loc[1],_now,t2.toNumber(),a.toNumber()]);
                        if (ok) { _diagAccepted = 1; }
                        if (ok) { write("srONextAV326", _now + airSeconds()); }
                    }
                }
            }
        } catch (e) { ok = false; reason = -155; }
        if (_unsafe) { reason = -154; }
        if (!ok || _unsafe) { fail(reason); return; }
        if (_shortRequest && !write("srOShortAttemptV3264", 0)) {
            fail(-16); return;
        }
        if (_shortRequest) { write("srOShortFaultV32652", 0); }
        // Refresh WeatherGuard immediately after accepting a new observation
        // or forecast. Do not wait for the following temporal wake to detect
        // an escalation or update the next forecast cadence.
        if (_interval <= 15 && (kindIs("current") || kindIs("forecast"))) {
            _alertMode = -1;
            activeWeather();
        }
        _diagStep = 70;
        gate(21);
        status(200);
        finish(true);
    }
}
