# Solar Rings 7X 3.26.55 — hotfix Out Of Memory (Store-Version 114)

## Dokładna przyczyna (nie domysł)
Prześledzono CIQ_LOG z 2026-11-20 08:00:35Z i 08:01:00Z przez `debug.xml` z oryginalnego `SolarRings7X_v32654.iq`, wariant urządzenia `006-B4376-00`. PC `0x1000ad6a` wskazuje `GarminWeatherWarnings.evaluate()` przy linii 370 `Weather.getHourlyForecast()`. Stos: `warning()` → `allWarnings()` → `drawAlertCenter()` → `onUpdate()`.

## Naprawa awaryjna i kompromis
* Usunięto **wyłącznie** wywołanie `Weather.getHourlyForecast()` z rysowania ostrzeżeń Garmin (i TEST15 dla trybu Garmin), które wywołało OOM. Garmin jako dostawca zachowuje ostrzeżenia dotyczące warunków bieżących, ale **tymczasowo traci przyszłe żółte ostrzeżenia z własnej prognozy godzinowej**.
* **OpenWeather 1H, 15M, TERAZ, WeatherSync 5, Photon, AQI, harmonogram snu, wszystkie ustawienia i układ pozostają nienaruszone**. Jeśli wybrano OWM, silnik SolarOpenWarnings nie używa usuniętego wywołania.
* TEST23 pokazuje teraz `ZRODLO OWM` lub `ZRODLO GARMIN` i pozwala zauważyć, czy ustawienie dostawcy rzeczywiście się zachowało po instalacji.
* Nie zmieniono identyfikatora aplikacji, `properties.xml`, `settings.xml`, kolejki ani nazw kluczy Storage. Wersja manifestu 3.26.55.

## Ograniczenia
To naprawa **konkretnego** udokumentowanego OOM, nie gwarancja wyeliminowania wszystkich innych problemów pamięci. OWM 15M nadal może być za duże w tle. Testy Pythona i ZIP nie kompilują Monkey C i nie symulują zasobów realnego urządzenia.

## Pierwszy test
1. Zachowaj działający plik PRG v3.26.49.
2. W GitHub uruchom BUILD.yml v55 z SOURCE.zip v55 i sprawdź kompilację obu wariantów.
3. Zainstaluj dopiero po poprawnym buildzie. TEST23: sprawdź `ZRODLO OWM` (jeśli ten dostawca jest wybrany).
4. TEST22: TERAZ i 1H K200; sprawdź normalną tarczę i zmianę ustawień. TEST15 w trybie Garmin będzie zgłaszał brak prognoz godzinowych zamiast pobierać ciężki obiekt.
5. Po ewentualnej ponownej awarii wyślij nowy CIQ_LOG i .iq, bez ponownych instalacji w pętli.
