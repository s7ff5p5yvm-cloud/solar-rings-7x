# Solar Rings 7X v3.26.53 — WeatherSync Priority Guard

## Decyzja oparta o ograniczenia Garmin Connect IQ
Utrzymujemy dokładnie jedno żądanie na jedno wybudzenie w tle (minimum 5 minut), bez równoległych i łańcuchowych HTTP. Nie można zagwarantować uruchomienia dokładnie o zadanej minucie. 30 sekund to limit całego background task, a pobranie pełnego JSON w 15M nadal może przekroczyć dostępny RAM.

## Harmonogram w profilu 5 / 15 min
| źródło | Spokojna | Czujność lub zagrożenie |
|---|---:|---:|
| 1h (główne ostrzeżenia na kolejne godziny) | 10 min | 10 min |
| Teraz (warunki bieżące, czerwone ostrzeżenia) | 20 min | 15 min |
| 15m (uzupełnienie 1h, przy włączonej opcji i braku blokady RAM) | 90 min | 60 min |
| AQI (gdy włączone) | 60 min | 90 min |
| Dzienna | 12 h | 12 h |
| Photon | gdy potrzebny | gdy potrzebny |

**Terminy są docelowe, nie gwarantowane.** OWM publikuje nową prognozę mniej więcej co 10 min, lecz nie ogłasza dokładnej minuty publikacji. Przy 5-minutowej kolejce z innymi usługami 1h lub current mogą spóźnić się o co najmniej 5 minut. W symulacji występują również okresowe opóźnienia AQI i 15M. Profil ręczny 30/60 nadal respektuje ustawienia użytkownika dla podstawowych feedów.

## Zasady ostrzegania
- WeatherGuard czyta wszystkie świeże źródła; najwyższy wykryty stan wygrywa.
- Brak aktualnej prognozy albo current = CZUJNOŚĆ, nigdy SPOKOJNA.
- Zmiana z SPOKOJNEJ na CZUJNOŚĆ przyspiesza następny termin current do docelowo 15 minut od ostatniego poprawnego pobrania.
- Powrót do SPOKOJNEJ wymaga dwóch różnych świeżych prognoz godzinowych potwierdzających poprawę.
- Ikony ostrzegawcze łączą current, 1H i 15M bez tłumienia alertów 1H przez 15M.

## Ochrona pamięci 15M
- Nie ma udokumentowanej gwarancji, że parametr cnt obetnie One Call 4.0 timeline przed przesłaniem danych, więc nawet pojedyncza odpowiedź 15M może spowodować OOM.
- Pierwszy błąd typu -402/-403 lub brak callbacku: 6 h izolacji samego 15M.
- Drugi taki błąd: blokada kolejnych 15M do świadomego wyłączenia i ponownego włączenia opcji (lub zmiany dostawcy/klucza). TEST 22 = 15M OCHRONA (2 BLEDY).
- Current i 1H działają nadal. To nie zapewnia, że pierwszego OOM nie będzie; sam Garmin musi to potwierdzić w teście.

## Bezpieczeństwo i zachowanie
- Bez nowych właściwości/kluczy; struktury ustawień, identyfikator aplikacji, Photon, wygląd i Garmin sleep/wake zachowane.
- Test22: H10, C20 spokojnie albo C15 czujność/zagrożenie, M90/M60; osobny kod 15M i blokada RAM.
- TEST21: Photon i potwierdzenie miejscowości po zmienie lokalizacji.

## Testowanie
1. Uruchom GitHub Actions (Python testy i kompilacja Monkey C: fenix7xpro + fenix7xpronowifi). W razie błędu nie instaluj.
2. Zachowaj poprzedni działający plik PRG i konfigurację ustawień. Nie resetuj aplikacji.
3. Test22 po 20/45/90 min: 1H K200 oraz TERAZ K200. 15M może mieć K200, Kxxx, PAUZA lub OCHRONA. Informacje K200 = ostatni poprawny zapis, nie godzina wydania modelu przez OpenWeather.
4. Test21: Photon OK bez tyldy, GPS po przemieszczeniu.
5. Zmiana ustawień; BT offline/online; błąd serwera; 429; sen i pobudka; oszczędzanie baterii przez 48–72 h.
6. Jeśli tarcza ulega awarii, wróć do działającej wersji i przekaż CIQ_LOG, bez prób instalacji w pętli.

## Status weryfikacji
Wykonano testy źródłowe Python, XML, integralność archiwów, testy scenariuszy kolejki (symulacja). Nie wykonano Monkey C SDK ani testów na fizycznym Garminie. Nie deklarujemy stabilności w realnym urządzeniu.

## Oficjalne źródła
- Garmin Background: https://developer.garmin.com/connect-iq/articles/core-topics/Backgrounding.html
- Garmin Background FAQ: https://developer.garmin.com/connect-iq/connect-iq-faq/how-do-i-create-a-connect-iq-background-service/
- Garmin Communications: https://developer.garmin.com/connect-iq/api-docs/Toybox/Communications.html
- OpenWeather One Call 4.0: https://openweathermap.org/api/one-call-4
