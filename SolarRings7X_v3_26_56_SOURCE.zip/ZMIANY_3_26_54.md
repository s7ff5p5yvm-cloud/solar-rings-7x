# Zmiany v3.26.54
- WeatherSync 5: 5-min cykl planowania, symetryczne szybkie źródła TERAZ / 1H i rezerwacja dla usług dodatkowych.
- Photon w kolejce pomocniczej jako pierwsze zadanie po zmianie lokalizacji / gdy miasto nierozpoznane.
- Garmin Weather jako dodatkowa ostrożna wskazówka CZUJNOŚĆ tylko z aktualnych danych dotyczących właściwego miejsca.
- WeatherGuard analizuje wszystkie świeże źródła, respektuje progi i nie pozwala 15M ukryć 1H.
- TEST 23 pokazuje ostatni wybór kolejki, opóźnienia głównych źródeł, sygnał Garmin i ochronę 15M. TEST 21 i 22 pozostają.
- Ustawienia, manifest ID, layout, sleep/wake i Photon API bez zmian struktury.
- Brak gwarancji stabilności przed kompilacją Monkey C i testem urządzenia.
