# Solar Rings 7X v3.26.54 — WeatherSync 5

## Założenie architektury
JEDNO żądanie HTTP podczas jednego wybudzenia (minimalna kadencja 5 min). Maksymalizacja świeżości TERAZ i prognozy 1H przy stabilności tarczy. Żadnego równoległego ani łańcuchowego HTTP. Ograniczenia Connect IQ (czas pracy procesu w tle / pamięć) nie pozwalają obiecać stałych odstępów.

## Praktyczny harmonogram
* Profil szybki 5 lub 15 minut: TERAZ i 1H obie z celem 10 minut, zwykle 10–15 minut w idealnej pięciominutowej kolejce. Maksymalnie około 5 prób każdego źródła na godzinę w normalnych warunkach, aby pozostawić dwa cykle na dodatkowe usługi. Po awarii/utracie BT czasy mogą się wydłużyć.
* OWM 15M: opcjonalne, około 120 min w spokoju, 90 min przy czujności, 60 min przy zagrożeniu. Wysokie ryzyko RAM nawet przy pojedynczym zapytaniu.
* AQI: około 75 minut; do około 90 minut przy zagrożeniu. Dzienna: 12 godzin.
* Photon: tylko gdy brak nazwy miasta / zmiana pozycji; współdzieli kolejkę pomocniczą, ma niezależne ponowienia i nie blokuje TERAZ/1H. Błędy Photon nie wstrzymują OWM; 15M i AQI nie zagładzają Photon.
* Profile wolniejsze 30/60 minut: wybrane przez użytkownika ręczne odstępy głównych źródeł są zachowane.

## WeatherGuard
* Analizuje wszystkie świeże dane bieżące, 1H i, jeśli działa, 15M; wybiera najwyższą wykrytą klasę ryzyka bez zasłaniania 1H przez 15M.
* Brak / przeterminowanie podstawowych danych daje CZUJNOŚĆ, nigdy fałszywe SPOKOJNA.
* Uwzględnia ustawienia progów deszczu, śniegu, burz, wiatru, mgły i zjawisk lodowych; klasa ZAGROŻENIE NIE zastępuje odrębnych zasad czerwonych/żółtych ikon.
* Garmin Weather to wyłącznie pomocniczy odczyt już zbuforowanych warunków, gdy ma aktualny czas i odpowiadającą lokalizację. Nie generuje sam czerwonych ostrzeżeń ani nie wymaga dodatkowego HTTP.
* Powrót do SPOKOJNEJ wymaga dwóch różnych świeżych prognoz 1H.

## Diagnostyka
* TEST 21 — Photon: etap, ostatni HTTP, nazwa miejscowości, czas i potwierdzenie lokalizacji.
* TEST 22 — statusy OWM TERAZ / 1H / 15M / dzienna / AQI, stan 15M i tryb WeatherGuard.
* TEST 23 — nowy: aktualny tryb, powód, ostatni wybór kolejki (w tym PHOTON), wiek TERAZ i 1H, terminy kolejnych żądań, ostatni cykl pomocniczy, kontrolny odczyt Garmin Weather i zabezpieczenie 15M.
* Status K200 oznacza ostatnią poprawnie przyjętą odpowiedź, a nie moment wydania nowego modelu przez OWM.

## Bezpieczeństwo 15M
* Dwie próby zakończone błędem pamięci / brakiem callbacku wstrzymują wyłącznie 15M do świadomego ponownego przełączenia tej funkcji. Pierwszego OOM nie można wykluczyć; odczyt całego JSON może wyczerpać pamięć urządzenia.
* W razie błędu w obszarze 15M zachować poprzedni PRG i wyłączyć 15M do testu stabilności. Nie resetować ustawień bez potrzeby.

## Plan wdrożenia i obserwacji
1. Zachować działający plik .PRG i zrzut konfiguracji.
2. Wgrać SOURCE.zip do głównego katalogu repozytorium oraz BUILD.yml do .github/workflows/ i uruchomić workflow. Musi przejść SHA256, testy, kompilacja fenix7xpro i fenix7xpronowifi.
3. Jeśli GitHub zgłosi błąd Monkey C, NIE instalować tarczy, przesłać log.
4. Po instalacji: TEST 22 i TEST 23 po 20, 45 i 90 min. TERAZ i 1H powinny mieć K200 przy dostępnym internecie. TEST 23: WYBOR PHOTON tylko gdy miasto nierozpoznane/zmiana lokalizacji.
5. TEST 21 dla Photon oraz zmiany lokalizacji; TEST 22 przy opcjonalnej 15M. W razie awarii przy 15M wyłączyć tę opcję i przekazać CIQ_LOG.
6. Weryfikować zmianę ustawień, nocny harmonogram snu i pobudkę, Bluetooth offline/online, ponowienia, AQI, nową datę i baterię przez 48–72 h na porównywalnych dobach.
7. Gdy wystąpi crash, wrócić do poprzedniego działającego PRG; nie wykonywać serii ponownych instalacji bez diagnozy.

## Wyniki dostępnej weryfikacji
Python unittest: 265 testów, 264 zaliczone, 1 pominięty (w tym scenariusze harmonogramu); testy są głównie kontraktowe, NIE emulują Monkey C. Symulacje 5-min cykli nie odtwarzają błędów Connect IQ, warunków Bluetooth ani zużycia baterii. Brak lokalnego Garmin SDK: kod Monkey C i fizyczny Fenix NIE zostały zweryfikowane kompilacją/testem urządzenia. Nie oznacza to gotowej stabilnej wersji.

## Oficjalne dokumentacje
Garmin Background: https://developer.garmin.com/connect-iq/articles/core-topics/Backgrounding.html
Garmin Weather: https://developer.garmin.com/connect-iq/api-docs/Toybox/Weather/CurrentConditions.html
OWM One Call 4.0: https://openweathermap.org/api/one-call-4
