# Solar Rings v3.26.50 — sen Garmina i adaptacyjne ostrzeżenia

Baza: sprawdzona na zegarku v3.26.49. Zachowano identyfikator aplikacji, klucz OWM, wszystkie klucze konfiguracji, Photon oraz układ tarczy. Bez zmian algorytmu rozpoznawania miejscowości i progów samych ostrzeżeń.

## Harmonogram snu
- Usunięto sztywny zapasowy warunek `22:00–06:00` z sieci OWM; ten warunek ignorował zmianę godzin snu w Garminie.
- `onSleepTime()` zapisuje stan snu i wstrzymuje HTTP. `onWakeTime()` zapisuje koniec snu, zeruje terminy bieżącej / 1h / 15m i planuje pobieranie za ok. 5 minut.
- Zdarzenia wyzwalane przez zarejestrowane Garmin Background sleep/wake odwołują się do harmonogramu skonfigurowanego na zegarku. Nie oznacza to wykrywania ręcznie włączonego trybu snu.
- Podczas snu działa jedynie lekki kontrolny timer co godzinę, bez zapytań internetowych. Po maks. 14 godzinach bez zdarzenia pobudki blokada wygasa ochronnie, aby tarcza nie pozostała trwale bez aktualizacji.
- Jeśli system nie dostarczy zdarzenia snu, aplikacja nie może wiarygodnie odtworzyć godzin z konfiguracji i woli dalej aktualizować dane niż uruchomić błędne 22–06; TEST 22 pomoże wykryć tę sytuację na zegarku.

## Adaptacyjne aktualizacje (profil szybki 5/15 min)
Tarcza rozpoznaje pogodę z lekkich, zapisanych rekordów bieżących + 1h, dodatkowo 15m tylko jeśli istnieje i jest świeża. Niczego nie pobiera wyłącznie po to, żeby rozpoznać tryb.
- SPOKOJNA: świeża pogoda i 1h, brak istotnych kodów zjawisk, bliskich progów, opadów, mgły i istotnego prawdopodobieństwa opadów. Bieżąca co **25 min**, godzinowa co **30 min**, 15-minutowa co **60 min**.
- CZUJNOŚĆ: brak danych, nieaktualna obserwacja, nieznany kod, prawdopodobieństwo opadu >=30%, zbliżanie się wiatru do 80% progu, gorsza widoczność (<=1000 m) lub podwyższony UV. **15 / 15 / 30 min**.
- ZAGROŻENIE: potwierdzone w danych bieżących lub prognozie zjawiska (deszcz, śnieg, burze, marznący opad, groźne warunki, przekroczone progi ostrzeżeń). **15 / 15 / 30 min**.
- Wybranie ręcznie profilu 30/60 min nie jest przyspieszane adaptacją, z poszanowaniem wyboru użytkownika; 15-minutową pobiera osobno nie częściej niż co 60 min.
- Wszystkie odstępy są minimalnymi terminami; Garmin może przesunąć rzeczywiste wykonanie background task. Jeden HTTP na przebudzenie, nie dodatkowe timery. Pogoda bieżąca > 1h > 15m > Photon > AQI > dzienna. Jeśli 15m ma problem z pamięcią, nadal działa 1h.
- AQI (gdy włączone) co 60 min, prognoza dzienna co 12 h, Photon tylko gdy potrzeba rozpoznania lokalizacji; pozostałe zadania nie mogą być bez końca odraczane.
- OWM 15m po podejrzeniu zabicia procesu z powodu RAM: wyłącznie ten endpoint ma 6h bezpiecznik (wcześniej 24h). TEST 22 pokazuje pozostałą pauzę. Nie jest to blokada Photon ani całej pogody.

## Ekrany
TEST 21: Photon jak w v49, bez modyfikowania jego zapytań.
TEST 22: statusy bieżące / 1h / 15m / dzienne / AQI, API, nowa linia trybu SPOKOJNA/CZUJNOŚĆ/ZAGROŻENIE lub profil ręczny oraz powód i odstępy C/H/M w minutach. `15M PAUZA` opisuje lokalną pauzę ochronną (nie HTTP 200). W testach nie ma klucza ani współrzędnych.

## Ograniczenia
- Testy statyczne i model harmonogramu NIE uruchamiają Monkey C na prawdziwym zegarku. Kompilacja CI/GitHub oraz test odświeżania przed i po zmienionym harmonogramie snu są obowiązkowe.
- Rozpoznanie trybu oparte na prognozie nie gwarantuje, że nagłe zjawisko pomiędzy pobraniami zostanie wykryte natychmiast. W trybie spokojnym najbliższy kontrolny odczyt danych głównych to maksymalnie ok. 25–30 minut plus opóźnienie Garmina.
- Szybkość, RAM i bateria zależą od urządzenia, aktywnego profilu, serwera, LTE/Bluetooth telefonu. Nie potwierdzono pomiaru baterii w praktyce.
