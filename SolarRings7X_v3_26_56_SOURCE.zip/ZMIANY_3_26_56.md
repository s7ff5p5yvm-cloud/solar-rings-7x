# 3.26.56 — osłona ustawień Garmin Connect IQ (wersja testowa)

## Potwierdzone na podstawie CIQ_LOG i pakietu IQ v3.26.55
2026-11-20 08:19:15 UTC, Store-Version 115: `Unexpected Type Error`, stos: `Config.mc:37` (`Properties.getValue`), `SolarOpenData.mc:13` (`srUseOpenWeather`), `SolarRings7X.mc:146` (`refreshChangedSettings`), `SolarRings7X.mc:2363` (`onUpdate`).

## Zmiana architektury ustawień
- Callback `onSettingsChanged()` **nie czyści** w nim cache ustawień i **nie wywołuje** `Ui.requestUpdate()`.
- Zachowuje stare wartości ustawień podczas 45-sekundowego okna ochronnego. Przy następnym naturalnym odświeżeniu po 45 s zwalnia cache graficzne i wznawia odczyt Properties.
- Wszystkie właściwości są kontrolowane typami (Number, Boolean, String), liczby zapisane przez Garmin jako ciągi znaków można bezpiecznie sparsować.
- Bez wywołań `Properties.setValue`, bez zmian keys i XML, bez automatycznego resetowania ustawień, bez zmiany OWM/Photon.

## Ograniczenie
Wykryty błąd wystąpił wewnątrz natywnego `Properties.getValue()`. Zmiana zmniejsza ryzyko wejścia w odczyt podczas aktualizacji SET, **ale nie usuwa ewentualnej wady firmware/Garmin Connect ani nie zapobiega wszystkim przypadkom resetu SET**. Nie potwierdzono kompilacji Monkey C ani stabilności na urządzeniu. Jeśli wszystkie ustawienia w pliku SET zostały zastąpione domyślnymi, sam kod nie odzyska ich bez kopii.

## Test
Przed testem zrób kopię `/GARMIN/APPS/SETTINGS/GBE63537.SET` (o ile istnieje). Zmieniaj tylko jedną niewinną opcję, nie dane dostawcy ani klucz API. Po zapisie pozostaw tarczę aktywną 2 minuty i sprawdź, czy zmiana się pojawia bez awarii. Jeśli nastąpi reset, zachowaj SET sprzed i po, CIQ_LOG, oryginalny IQ. Nie instaluj w pętli; wróć do wersji stabilnej.
