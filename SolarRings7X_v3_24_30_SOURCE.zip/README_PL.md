## Poprawka v3.24.30

- W aktualnej v3.24.29 widoczny był deszcz teraz, a w widoku godzinowym Garmin deszcz później, lecz brakowało turkusowego paska. Jedna z możliwych przyczyn w kodzie: `HourlyForecast.precipitationChance` może być `null`; poprzedni kod zawsze odrzucał takie prognozy. Teraz wyraźne kategorie opadów, burzy, gradu lub śniegu przy braku procentu są akceptowane; jeżeli procent istnieje, obowiązuje ustawiony próg. Samo `CHANCE_OF_*` nadal wymaga liczbowego prawdopodobieństwa.
- Miejsce 1 (x=45) jest zawsze wyłącznie dla StormGuard i może pozostać puste. Prognozy Garmin mieszczą się w miejscach 2, 3, 4 (x=68,91,114), z paskiem pod ikoną. Przy ponad trzech odrębnych ostrzeżeniach Garmin ostatnia pozycja rotuje co 5 sekund.
- Nie zmieniono częstotliwości odczytu pogody, StormGuard ani lokalizacji; brak nowych zapytań do internetu i GPS.
- Przełącz w Connect IQ na **TEST 14**, aby zobaczyć trzy czerwone ikony z turkusowym paskiem niezależnie od danych Garmin Weather; po teście wyłącz go.
- Wersja i pliki workflow: **v3.24.30**.

# Solar Rings 7X v3.24.30 — poprawka ostrzeżeń i zarezerwowane miejsce StormGuard

**NOWE:** Czerwony = zaobserwowano teraz, turkusowy = prognozowano, czerwony
z turkusowym paskiem pod ikoną = oba stany. To samo zjawisko nie zajmuje dwóch
miejsc. StormGuard pozostaje pierwszy, termometr przy temperaturze jest
widoczny wyłącznie po przekroczeniu progów. Dodano tryb TEST 14, który pokazuje
trzy podwójne ikony. Nie zwiększamy częstotliwości odczytu Garmin Weather,
StormGuard ani liczby zapytań geolokalizacji. Dalsza część pliku opisuje
mechanizmy geolokalizacji zachowane z poprzednich wersji.

Bazą jest **v3.24.28** (ze wszystkimi poprawkami kompilacji i termometru).
W tej wersji zmieniono wyłącznie łączenie ostrzeżeń Garmin Weather, kolorowanie
ikon i obszar częściowego przerysowania. Zachowano działanie StormGuard,
termometru, geolokalizacji, kontrastowego Księżyca, licznika dni do pełni
i dotychczasowe ustawienia.

## Jak działa napis miejscowości

1. Tarcza korzysta z `Weather.getCurrentConditions().observationLocationPosition`.
   **To pozycja obserwacji Garmin Weather, nie GPS zegarka ani dokładna pozycja iPhone'a.**
2. Dostępne miasto z lokalnej listy 115 miast pokazuje się od razu.
3. Po zauważeniu NOWEGO obszaru (około 3 km od ostatniego zapytania)
   tarcza zapisuje najnowsze współrzędne. Rejestruje najwyżej JEDNO
   zadanie Connect IQ w tle, najwcześniej za 5 minut. Podczas
   podróży kolejne zmiany celu nie tworzą nowych timerów. Zadanie
   używa sieci przez Garmin Connect.
4. Serwer Photon (OpenStreetMap) zwraca najbliżej rozpoznaną miejscowość.
   Po sukcesie nazwę zapisujemy w pamięci trwałej i kasujemy zadanie;
   nie wysyłamy kolejnych zapytań dla tego samego rejonu.
5. GLOBALNY limit internetu: minimum 30 minut między próbami, niezależnie
   od liczby zmian lokalizacji. Kiedy brak telefonu/internetu lub serwer
   zwróci błąd, odstępy ponawiania rosną: 3h, 6h, 12h, 24h, 24h...
   (aż do kolejnego udanego pobrania). Tarcza pokazuje offline nazwę
   lub współrzędne, bez dodatkowego zużycia GPS.
6. Przy braku odpowiedzi HTTP połączenie jest kontrolowane przez
   trzygodzinny watchdog, a brak callbacku również zwiększa backoff.
   Nieaktualne odpowiedzi z opuszczonego rejonu są odrzucane.
7. Jeżeli Garmin nie udostępnia współrzędnych, tarcza próbuje starego
   `observationLocationName`; w przeciwnym razie pokazuje `BRAK LOK.`.

## Dlaczego takie ograniczenia?

- Zwykła tarcza nie ma dostępu do `Communications.makeWebRequest()` podczas
  rysowania. Do wywołań służy `System.ServiceDelegate` uruchamiany w tle.
- Photon pod adresem `https://photon.komoot.io/reverse` to publiczny SERWER
  DEMONSTRACYJNY z ograniczeniami i bez gwarancji dostępności. Niniejszy
  kod jest wariantem do **osobistych testów**, z bardzo rzadkimi zapytaniami.
  **Przed publikacją w Connect IQ Store należy użyć własnego geokodera
  lub wybrać dostawcę API z warunkami dopuszczającymi publiczną aplikację.**
- Współrzędne przybliżone do 3 miejsc dziesiętnych są wysyłane do zewnętrznego
  dostawcy Photon — warto o tym pamiętać z punktu widzenia prywatności.
- Bez współrzędnych Garmin Weather funkcja internetowa nie ruszy.

## Bateria

- Żadnych zapytań podczas `onUpdate()` i `onPartialUpdate()`.
- Jedno zaplanowane zadanie niezależnie od liczby zmian miejscowości.
- Maksymalnie jedna próba internetowa na 30 minut; po błędach przerwy
  3h -> 6h -> 12h -> 24h (maksymalnie jedna na dobę przy awarii).
- Po sukcesie usuwamy timer i zerujemy licznik błędów.
- Zmiana regionu nie resetuje limitów ani przerw po awariach.
- Przy braku odpowiedzi nadal działa watchdog; brak callbacku nie oznacza
  bezterminowego odpytywania co 3h.
- Brak uruchamiania GPS; brak dodatkowych danych pogodowych.
- Całe wyświetlanie zegarka ma awaryjną ścieżkę offline.

## Instalacja przez GitHub Actions

1. Wgraj `SolarRings7X_v3_24_30_SOURCE.zip` do głównego katalogu repo.
2. Zastąp stary aktywny workflow `.github/workflows/*.yml` plikiem
   `SolarRings7X_v3_24_30_BUILD.yml` z kompletnej paczki.
3. Uruchom workflow i pobierz jego artefakt PRG.
4. Pierwsza próba rozpoznawania nazwy może rozpocząć się po około 5 minutach.
   Przy podróży/awarii sieci należy liczyć się z dłuższym opóźnieniem,
   ponieważ oszczędzanie baterii ma pierwszeństwo.
5. W Connect IQ zegarek może poprosić o dodatkowe uprawnienia do
   komunikacji internetowej i zadań działających w tle.

## Granice weryfikacji

Zmiany są testowane lokalnie statycznie i regresyjnie w Pythonie.
Garmin SDK i symulator nie są dostępne w tym środowisku, dlatego
**kompilacja Monkey C, obsługa zadania w tle i wyświetlanie na Fenixie
wymagają sprawdzenia przez GitHub Actions oraz na zegarku**.

## Ważne ograniczenie

Automatyczny odczyt nazwy miejscowości działa tylko wtedy, gdy Garmin
Weather udostępni współrzędne obserwacji. Nie zawsze są to współrzędne
telefonu. Obliczenia nie uruchamiają odbiornika GPS zegarka. Nie ma
gwarancji bezbłędnego wskazania każdej miejscowości.

## Historia: korekta BUILD FIX (GitHub Actions)

Usunięto nieprzenośną ścieżkę `/mnt/data/...` z testu
`tests/test_online_geocode_32426.py`. Test sprawdza teraz workflow
w `.github/workflows/` względem katalogu repozytorium (jeśli
taki katalog istnieje), a zawsze sprawdza wersję w `check_version.py`.
Kod tarczy (`source/*.mc`), konfiguracja i logika StormGuard nie zostały zmienione.

## Poprawka v3.24.28 — termometr progowy

W starym kodzie termometr był rysowany również pomiędzy progami jako szary.
Teraz w zakresie normalnej temperatury nie jest rysowany wcale.
Dla konfiguracji ZIMNO poniżej 0°C i GORĄCO powyżej 30°C:
- -1°C: niebieski termometr
- 0°C, +1°C, +30°C: brak termometru
- +31°C: czerwony termometr

Ikona pozostaje obok temperatury i nie zajmuje miejsca w centrum ostrzeżeń.
Zmiana zmniejsza liczbę operacji rysowania w normalnych warunkach.
Test baterii rozpoczęty o 08:34 przy 91% można kontynuować, lecz
instalacja nowej wersji zmienia warunki testu — warto zapisać nowy punkt startowy.

## Nowe testy ikon (v3.24.29)

- **TEST 11** — jedna burza TERAZ i PROGNOZA, czerwona z turkusowym paskiem.
- **TEST 12** — tylko turkusowa prognozowana burza.
- **TEST 14** — trzy ikony: burza, deszcz, wiatr, każda czerwona z paskiem.
- Wyłącz tryb TEST (`0`), aby powrócić do prawdziwej pogody.
- Pasek oznacza zjawisko prognozowane w wybranym horyzoncie, a NIE ciągły
  deszcz czy burzę przez wszystkie godziny prognozy.
- Cztery różne zagrożenia: cztery ikony stale. Dopiero piąta kategoria
  uruchamia rotację czwartej pozycji co pięć sekund.

Po instalacji v3.24.29 test baterii trzeba zacząć od nowej godziny i procentu.

## Poprawka kompilacji v3.24.30 (Array index is out of bounds)

W `source/SolarRings7X.mc` usunięto bezpośredni dostęp do pierwszego
elementu dynamicznie budowanej tablicy alertów (`active[0]`).
Obecność ostrzeżenia StormGuard przechowuje teraz flaga `pressureActive`,
ustawiana tylko przy skutecznym dodaniu ostrzeżenia ciśnieniowego.
Pozostaje ono w pierwszym polu; pozostałe ostrzeżenia oraz tryb TEST 14
działają jak dotychczas. Testy sprawdzające poprzednią konstrukcję
zostały zaktualizowane. Kod poza centrum alertów nie był zmieniany.
To naprawa źródła, nie dowód przejścia kompilacji Garmin SDK.
