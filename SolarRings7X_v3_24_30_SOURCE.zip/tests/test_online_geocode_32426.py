"""Offline static regression checks for one-shot geocode worker (not SDK tests)."""
from pathlib import Path
import unittest, xml.etree.ElementTree as ET

R=Path(__file__).resolve().parents[1]
FACE=(R/'source/SolarRings7X.mc').read_text()
GEO=(R/'source/WeatherGeocode.mc').read_text()
STORM=(R/'source/StormGuard.mc').read_text()
MAN=ET.parse(R/'manifest.xml').getroot()

class OnlineGeoTest(unittest.TestCase):
    def test_new_version_and_same_app_id(self):
        app=MAN.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.24.30')
        self.assertEqual(app.attrib['id'],'D1F8E1A4B7FC45BD91E8F0A0959041BF')
    def test_background_only_network_and_communication_permissions(self):
        self.assertIn('(:background)\nclass SolarRingsGeoService',GEO)
        self.assertIn('function getServiceDelegate()',FACE)
        self.assertIn('function onBackgroundData(data)',FACE)
        self.assertIn('Comm.makeWebRequest(',GEO)
        self.assertNotIn('Comm.makeWebRequest(',FACE)
        self.assertNotIn('makeWebRequest',STORM)
        permissions={p.attrib['id'] for p in MAN.findall('.//{http://www.garmin.com/xml/connectiq}uses-permission')}
        self.assertTrue({'Communications','Background','Positioning','SensorHistory'}<=permissions)
    def test_uses_weather_observation_not_watches_gps(self):
        self.assertIn('weather.observationLocationPosition.toDegrees()',FACE)
        self.assertNotIn('Position.getInfo()',FACE)
        self.assertNotIn('enableLocationEvents(',FACE)
        self.assertNotIn('getCurrentLocation(',GEO)
    def test_rare_location_trigger_and_cancellation(self):
        self.assertIn('remoteCityForWeatherPosition(latitude, longitude)',FACE)
        self.assertIn('Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(delay)))',FACE)
        self.assertIn('Bg.deleteTemporalEvent();',GEO)
        self.assertIn('armTimer(now + 3 * 60 * 60)',GEO)
        self.assertIn('"srGRequest"',FACE)
        self.assertIn('"srGResult"',FACE)
        self.assertIn('Math.abs',GEO) if False else self.assertNotIn('Math.abs',GEO)
        self.assertNotIn('Math.abs',FACE)
    def test_photon_request_is_filtered_to_settlements(self):
        self.assertIn('https://photon.komoot.io/reverse',GEO)
        self.assertIn('"osm_tag" => "place"',GEO)
        self.assertIn('"limit" => "1"',GEO)
        self.assertIn('"lang" => "pl"',GEO)
        self.assertIn('Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON',GEO)
        self.assertIn('city = props["name"]',GEO)
        self.assertIn('city = city.toUpper()',GEO)
    def test_offline_fallback_and_legacy_name(self):
        self.assertIn('srWeatherCityFromDegrees(latitude, longitude)',FACE)
        self.assertIn('weather.observationLocationName',FACE)
        self.assertIn('BRAK LOK.',FACE)
        self.assertIn('clearLocationDisplayCache()',FACE)
    def test_temperature_and_alert_priority(self):
        self.assertIn('if (isTemp) { temperatureMarker(dc, weather, 142, 224); }',FACE)
        center=FACE.split('function drawAlertCenter(')[1].split('function drawBattery(')[0]
        self.assertIn('if (_storm.warning()) {',center)
        self.assertIn('pressureActive = true;',center)
        self.assertIn('if (pressureActive)',center)
        self.assertIn('active.add(warnings[i])',center)
        self.assertLess(center.find('active.add(-1)'),center.find('active.add(warnings[i])'))
        self.assertNotIn('active.add(-2)',center)
        self.assertNotIn('active.add(-3)',center)
    def test_only_one_weather_fetch_in_foreground_and_no_network_every_second(self):
        self.assertEqual(FACE.count('Weather.getCurrentConditions()'),1)
        partial=FACE.split('function onPartialUpdate(dc)')[1].split('function onUpdate(dc)')[0]
        self.assertNotIn('remoteCityForWeatherPosition',partial)
        self.assertNotIn('registerForTemporalEvent',partial)
        self.assertNotIn('makeWebRequest',partial)
    def test_build_workflow_and_version_match(self):
        # Source tests must also run outside the creator's local filesystem.
        # In GitHub Actions the source ZIP is extracted to SolarRings7X_weather/;
        # workflow files are kept one directory up, under .github/workflows/.
        self.assertIn("== '3.24.30'", (R/'check_version.py').read_text())
        workflow_dir = R.parent / '.github' / 'workflows'
        if workflow_dir.is_dir():
            files = list(workflow_dir.glob('*.yml')) + list(workflow_dir.glob('*.yaml'))
            workflows = [p.read_text(encoding='utf-8') for p in files]
            release = [w for w in workflows if 'SolarRings7X_v3_24_30_SOURCE.zip' in w]
            self.assertTrue(release, 'Missing v3.24.30 build workflow in .github/workflows')
            self.assertTrue(any('SolarRings7X_v32430.prg' in w for w in release),
                            'v3.24.30 workflow has an incorrect PRG filename')
            self.assertTrue(all('v3_24_25' not in w for w in release),
                            'v3.24.30 workflow references previous version')

if __name__=='__main__':unittest.main()
