"""Conservative v3.24.24 checks; these are not Garmin SDK runtime tests."""
import unittest, math, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
FIELDS=(ROOT/'source/FieldData.mc').read_text()
WEATHER=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
class ConservativeOptimization32423(unittest.TestCase):
    def test_moon_lookup_radius_7_matches_original(self):
        m=re.search(r'var _srMoonExtents7 = \[([^]]+)\];',FACE)
        self.assertIsNotNone(m)
        numbers=[float(v.strip()) for v in m.group(1).split(',')]
        self.assertEqual(len(numbers),15)
        for row,extent in zip(range(-7,8),numbers):
            self.assertAlmostEqual(extent,math.sqrt(49-row*row),places=12)
        self.assertIn('r == 7 ? _srMoonExtents7[row + 7]',FACE)
        self.assertIn('r == 12 ? _srMoonExtents12[row + 12]',FACE)
        self.assertIn('Math.sqrt((r * r - row * row).toFloat())',FACE)
    def test_date_is_cached_by_day_month_only_not_gregorian_reading(self):
        self.assertIn('var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);', FACE)
        self.assertIn('var dayMonthKey = date.month * 32 + date.day;', FACE)
        self.assertIn('drawDate(dc, _srDays[date.day_of_week - 1], dayMonthText);',FACE)
        self.assertIn('_dateTextCache = null;',FACE)
        # A different calendar day or month changes cache key immediately.
        self.assertNotEqual(1*32+31,2*32+1)
    def test_clock_cache_only_formats_minute(self):
        self.assertIn('var clock = System.getClockTime();',FACE)
        self.assertIn('var minuteOfDay = clock.hour * 60 + clock.min;',FACE)
        self.assertIn('_clockTextCache = [minuteOfDay, value];',FACE)
        self.assertIn('var pref = srSetting("fontClockV31", 2);',FACE)
    def test_age_cache_does_not_cache_observation_time_or_bt_connection(self):
        a=FACE.split('function drawWeatherAge(dc, current)')[1].split('function topDividers(')[0] if 'function topDividers(' in FACE else FACE.split('function drawWeatherAge(dc, current)')[1]
        self.assertIn('Time.now().value() - current.observationTime.value()', a)
        self.assertIn('_ageTextCache[0] == minutes',a)
        self.assertIn('_ageTextCache = [minutes, ageLabel, ageColor];',a)
        self.assertIn('drawPhoneBluetooth(dc);',a)
        self.assertIn('System.getDeviceSettings().phoneConnected',FACE)
        self.assertIn('_ageTextCache = null;',FACE)
        self.assertIn('if (minutes < 50)',a)
        self.assertIn('ageLabel = "1h";',a)
        self.assertIn('remainingMinutes.toString() + "m";',a)
        self.assertIn('if (minutes <= 30)',a)
        self.assertIn('else if (minutes <= 60)',a)
        self.assertIn('drawSized(dc, ageLabel, 260, 104, 36, 24',a)
    def test_settings_invalidation_and_hazards_remain(self):
        self.assertIn('resetPerformanceCaches();',FACE)
        self.assertIn('srResetSettingsCache();',FACE)
        self.assertIn('function onPartialUpdate(dc)',FACE)
        self.assertIn('Weather.getHourlyForecast()',WEATHER)
        self.assertIn('var remainingSteps = monitor.stepGoal - doneSteps;',FACE)
        self.assertIn('srSystemStatsForFrame().charging',FACE)
    def test_manifest(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.24.30')
        self.assertEqual(app.attrib['id'],'D1F8E1A4B7FC45BD91E8F0A0959041BF')
