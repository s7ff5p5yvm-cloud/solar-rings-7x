# Solar Rings 7X v3.26.45 — TEST 21 dla Photon

**Baza: v3.26.44 (hotfix z bazą stabilną v3.26.37).** Wersja zapasowa do diagnostyki.

- W opcjach podglądu ostrzeżeń dodano **TEST 21: Photon**. Działa zarówno przy Garmin Weather, jak i OWM.
- Pokazuje źródło pogody, łączność z telefonem, istnienie współrzędnych, stan potwierdzonej nazwy, ostatni ślad Photon i jego wiek, kod HTTP, ostatnią próbę, następny termin, licznik błędów, zaplanowanie usługi tła.
- Ślady zapisuje oszczędnie pod jednym nowym kluczem `srGDiagV32645`: `[czas, etap, kod]`. Kody etapów: 10 wysłano; 20 zapisano; 21 błąd HTTP; 22 zły JSON; 23 brak place; 24 zmiana pozycji; 25 błąd zapisu; 26 brak BT; 27 transport; 28 brak callback; 29 wyjątek.
- Ekran TEST 21 tylko czyta przechowywane dane. Nie odpytuje Photon, nie uruchamia GPS i nie zmienia kolejki HTTP.
- Nie zmieniono częstotliwości pogodowej, API, wyglądu normalnego zegara, separatorów, alertów ani numerów dotychczasowych opcji.
- Po instalacji **najpierw poczekaj na rzeczywistą próbę Photon**; wcześniejsze próby z v3.26.44 nie mają diagnostycznego śladu nowego formatu.

**Testy źródłowe nie zastępują kompilacji z Garmin Connect IQ SDK ani testu na zegarku.**
