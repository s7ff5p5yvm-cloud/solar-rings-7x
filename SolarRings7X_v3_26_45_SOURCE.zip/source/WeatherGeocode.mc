using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;
using Toybox.System as Sys;
using Toybox.Time as Time;

// Solar Rings 7X v3.24.29: bounded, persistent geocoding state machine.
// Single pending timer for ALL locations; no network calls in the render loop.
// Photon public endpoint: low-volume personal testing only. No GPS acquisition.
(:background)
class SolarRingsGeoService extends Sys.ServiceDelegate {
    var _requestedLat;
    var _requestedLon;
    var _openService;

    function initialize() {
        ServiceDelegate.initialize();
        _openService = null;
        _requestedLat = null;
        _requestedLon = null;
    }

    function storedNumber(key, fallback) {
        try {
            var value = App.Storage.getValue(key);
            if (value != null) { return value; }
        } catch (e) { }
        return fallback;
    }

    function saveNumber(key, value) {
        try { App.Storage.setValue(key, value); } catch (e) { }
    }

    // Compact Photon-only trace: [epoch, stage, HTTP code]. No coordinates,
    // city text, OWM token or response body. Only written on Photon events.
    function photonTrace(stage, code) {
        try { App.Storage.setValue("srGDiagV32645",
                [Time.now().value(), stage, code]); } catch (e) { }
    }

    function sameRegion(aLat, aLon, bLat, bLon) {
        return aLat < bLat + 0.008d && aLat > bLat - 0.008d &&
               aLon < bLon + 0.012d && aLon > bLon - 0.012d;
    }

    // Always use a single non-periodic Moment event; at least five minutes away.
    function armTimer(targetEpoch) {
        var now = Time.now().value();
        var delay = targetEpoch - now;
        if (delay < 5 * 60) { delay = 5 * 60; }
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(delay)));
            saveNumber("srGEventDue", now + delay);
        } catch (e) {
            saveNumber("srGEventDue", 0);
        }
    }

    function stopTimer() {
        try { Bg.deleteTemporalEvent(); } catch (e) { }
        saveNumber("srGEventDue", 0);
    }

    // Bounded retry for an unavailable or malformed place result. A global
    // 15-minute attempt spacing also applies, including after short failures.
    // HTTP 429 is allowed a full hour; no old 3-24 hour lockout.
    function retryLater(code) {
        saveNumber("srGInFlight", 0);
        var failures = storedNumber("srGFail", 0) + 1;
        if (failures > 4) { failures = 4; }
        saveNumber("srGFail", failures);
        var minutes = 10;
        if (failures == 2) { minutes = 20; }
        else if (failures == 3) { minutes = 30; }
        else if (failures >= 4) { minutes = 60; }
        if (code == 429) { minutes = 60; }
        var next = Time.now().value() + minutes * 60;
        saveNumber("srGNextAt", next);
        armTimer(next);
        Bg.exit(null);
    }

    // No phone means no HTTP call. Wait conservatively (one wake/hour) and
    // record the disconnect so the visible face can accelerate on reconnection.
    function retryPhoneMissing() {
        photonTrace(26, 0); // BLE disconnected: no HTTP request.
        saveNumber("srGInFlight", 0);
        saveNumber("srGPhoneMissingV32624", 1);
        armTimer(Time.now().value() + 60 * 60);
        Bg.exit(null);
    }

    // Network transport errors and lost callbacks are transient;
    // retry after 15 minutes without raising the server error counter.
    function retryTransport() {
        saveNumber("srGInFlight", 0);
        var next = Time.now().value() + 15 * 60;
        // Never override an already-active server cooldown with a shorter one.
        var serverNext = storedNumber("srGNextAt", 0);
        if (serverNext > next) { next = serverNext; }
        armTimer(next);
        Bg.exit(null);
    }

    // Events follow Garmin's configured sleep/wake schedule rather than a
    // hard-coded clock window. Neither event represents a manual sleep toggle.
    function onSleepTime() as Void {
        try {
            var now = Time.now().value();
            App.Storage.setValue("srOSleepStateV32624", [1, now]);
            // Do not replace geocoding's timer if Garmin is the provider.
            // A wake event may override the OWM watchdog at the configured time.
            var provider = App.Properties.getValue("srProviderV326");
            if (provider == 1) {
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(2 * 3600)));
            }
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }

    function onWakeTime() as Void {
        try {
            var now = Time.now().value();
            App.Storage.setValue("srOSleepStateV32624", [0, now]);
            var provider = App.Properties.getValue("srProviderV326");
            if (provider == 1) {
                // Recover expired current weather and 15min forecasts first.
                // Keep daily/AQI cadence unchanged; one endpoint per wake.
                App.Storage.setValue("srONextCV326", 0);
                App.Storage.setValue("srONextFV326", 0);
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(5 * 60)));
            }
        } catch (e) { }
        Bg.exit(["OWM", 0]);
    }

    function onTemporalEvent() {
        // The same OS background slot serves either city geocoding for
        // Garmin mode OR OpenWeather fetches. They never run together.
        var provider = 0;
        try { provider = App.Properties.getValue("srProviderV326"); } catch (e) { }
        if (provider == 1) {
            try {
                _openService = new SolarOpenNetwork();
                _openService.runSafely();
            } catch (e) {
                // Even an exception constructing the network service must
                // not disappear before the diagnostic breadcrumbs are saved.
                try {
                    var stamp = Time.now().value();
                    App.Storage.setValue("srODGateV3269", [stamp, 91, 0, -1, -1]);
                    App.Storage.setValue("srODiagV3266", [stamp, 0, -231]);
                    Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(10 * 60)));
                } catch (e2) { }
                Bg.exit(["OWM", 0]);
            }
            return;
        }
        saveNumber("srGEventDue", 0);
        var request = null;
        try { request = App.Storage.getValue("srGRequest"); } catch (e) { }
        if (request == null || request.size() < 2 ||
            request[0] == null || request[1] == null) {
            stopTimer();
            Bg.exit(null);
            return;
        }
        _requestedLat = request[0];
        _requestedLon = request[1];
        try {
            var answer = App.Storage.getValue("srGResult");
            if (answer != null && answer.size() == 3 &&
                sameRegion(_requestedLat, _requestedLon, answer[0], answer[1])) {
                stopTimer();
                Bg.exit(null);
                return;
            }
            // Check Bluetooth BEFORE the HTTP watchdog or server cooldown.
            // A disconnect must never count as a Photon server failure.
            if (!Sys.getDeviceSettings().phoneConnected) {
                retryPhoneMissing();
                return;
            }
            // A lost async callback is a transport failure, not HTTP 429.
            if (storedNumber("srGInFlight", 0) == 1) {
                photonTrace(28, 0); // No callback before watchdog.
                retryTransport();
                return;
            }
            if (storedNumber("srGPhoneMissingV32624", 0) == 1) {
                saveNumber("srGPhoneMissingV32624", 0);
            }
            var now = Time.now().value();
            var next = storedNumber("srGNextAt", 0);
            var fromLastRequest = storedNumber("srGLastTry", 0) + 15 * 60;
            if (fromLastRequest > next) { next = fromLastRequest; }
            if (now < next) {
                armTimer(next);
                Bg.exit(null);
                return;
            }
            // A global 15-minute limit across all destinations/providers.
            saveNumber("srGLastTry", now);
            saveNumber("srGInFlight", 1);
            // If response callback never fires, a watchdog detects this.
            armTimer(now + 15 * 60);
            var query = {
                "lat" => _requestedLat.format("%.4f"),
                "lon" => _requestedLon.format("%.4f"),
                "lang" => "pl",
                "osm_tag" => "place",
                "limit" => "3",
                "radius" => "5"
            };
            var options = {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            };
            photonTrace(10, 0); // Queued to Garmin Connect IQ.
            Comm.makeWebRequest("https://photon.komoot.io/reverse",
                                query, options, method(:onReceive));
        } catch (e) {
            photonTrace(29, -1); // Local exception before/calling HTTP.
            retryLater(-1);
        }
    }

    // Explicit callback signature required by the Connect IQ 9.3 typechecker.
    // Match the full makeWebRequest() response union, even though JSON
    // should arrive as a Dictionary. Never index other response types.
    function onReceive(code as Lang.Number,
                       data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        // Negative HTTP callback status indicates a transport problem,
        // not a reply from Photon. Keep the normal rate limit but avoid the
        // growing 24-hour retry lockout during a trip without internet.
        if (code < 0) { photonTrace(27, code); retryTransport(); return; }
        if (code != 200) {
            photonTrace(21, code); retryLater(code); return;
        }
        if (!(data instanceof Lang.Dictionary)) {
            photonTrace(22, code); retryLater(code); return;
        }
        var city = null;
        try {
            var features = data["features"];
            if (features instanceof Lang.Array) {
                // Some valid results have a place in the 2nd/3rd entry.
                // Do not accept a road or POI as the locality.
                for (var i = 0; i < features.size() && i < 3; i++) {
                    if (!(features[i] instanceof Lang.Dictionary)) { continue; }
                    var props = features[i]["properties"];
                    if (!(props instanceof Lang.Dictionary)) { continue; }
                    var tag = props["osm_key"];
                    var name = props["name"];
                    if (tag instanceof Lang.String && tag.equals("place") &&
                        name instanceof Lang.String && name.length() >= 2 &&
                        name.length() <= 42) {
                        city = name.toUpper();
                        break;
                    }
                }
            }
        } catch (e) { }
        if (city == null) {
            photonTrace(23, code); // HTTP 200, no usable place record.
            retryLater(code); return;
        }

        var now = Time.now().value();
        saveNumber("srGInFlight", 0);
        saveNumber("srGFail", 0);
        saveNumber("srGNextAt", now + 30 * 60);
        // Newer coordinates may have arrived while the network was busy.
        // Never clear the timer for the newer location or display stale data.
        var latest = null;
        try { latest = App.Storage.getValue("srGRequest"); } catch (e) { }
        if (latest == null || latest.size() < 2 ||
            !sameRegion(_requestedLat, _requestedLon, latest[0], latest[1])) {
            photonTrace(24, code); // New coordinates supersede this result.
            armTimer(now + 15 * 60);
            Bg.exit(null);
            return;
        }
        // Persist inside the service, even if a foreground callback is
        // delayed/lost. The foreground will still invalidate its short cache.
        try {
            App.Storage.setValue("srGResult", [_requestedLat, _requestedLon, city]);
            photonTrace(20, code); // Exact locality saved.
        } catch (e) {
            photonTrace(25, code); // Storage error: do not claim success.
            retryLater(code);
            return;
        }
        stopTimer();
        Bg.exit([_requestedLat, _requestedLon, city]);
    }
}
