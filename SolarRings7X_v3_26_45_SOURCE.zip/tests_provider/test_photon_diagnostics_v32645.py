"""Static checks for the read-only TEST 21 Photon trace added in 3.26.45.

Not a substitute for Monkey C compilation or testing on a Fenix.
"""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT / "source/SolarRings7X.mc").read_text()
OWM = (ROOT / "source/SolarOpenNetwork.mc").read_text()
GEO = (ROOT / "source/WeatherGeocode.mc").read_text()
ST = (ROOT / "resources/settings/settings.xml").read_text()
RES = (ROOT / "resources/strings.xml").read_text()

class PhotonDiagnostics32645Tests(unittest.TestCase):
    def test_test_21_setting_and_handler(self):
        self.assertIn('<listEntry value="21">@Strings.gw_diag_21</listEntry>', ST)
        self.assertIn('<string id="gw_diag_21">', RES)
        self.assertIn('if (diagMode == 21)', FACE)
        self.assertIn('drawPhotonDiagnostics(dc)', FACE)
        self.assertIn('function drawPhotonDiagnostics(dc)', FACE)

    def test_diagnostics_read_only(self):
        block = FACE.split('function drawPhotonDiagnostics(dc)')[1].split('function photonAgeText(')[0]
        self.assertNotIn('Comm.makeWebRequest(', block)
        self.assertNotIn('App.Storage.setValue(', block)
        self.assertNotIn('Position.getInfo()', block)
        self.assertNotIn('Bg.registerForTemporalEvent(', block)
        for item in ['srGRequest', 'srGResult', 'srGLastTry', 'srGNextAt', 'srGFail', 'srGDiagV32645']:
            self.assertIn(item, block)

    def test_both_background_paths_emit_diagnostic(self):
        self.assertIn('srGDiagV32645', OWM)
        self.assertIn('srGDiagV32645', GEO)
        for stage in ('(10, 0)', '(26, 0)', '(29, -1)'):
            self.assertIn('cityTrace' + stage, OWM)
            self.assertIn('photonTrace' + stage, GEO)
        self.assertIn('cityTrace(outcome, code)', OWM)
        for outcome in ('20', '21', '22', '23', '24', '25', '27', '29'):
            self.assertIn('outcome = ' + outcome, OWM)
        for stage in ('(20, code)', '(23, code)', '(27, code)', '(24, code)', '(28, 0)'):
            self.assertIn('photonTrace' + stage, GEO)

    def test_sources_are_strictly_v32645(self):
        manifest = ET.parse(ROOT / 'manifest.xml').getroot()
        app = manifest.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'], '3.26.45')

if __name__ == '__main__':
    unittest.main()
