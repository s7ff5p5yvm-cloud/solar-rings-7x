# GitHub Actions – Compass Pro 7X v1.3.2

1. Otwórz `https://github.com/s7ff5p5yvm-cloud/solar-rings-7x` i przejdź do `main`.
2. W katalogu głównym dodaj `CompassPro7X_v1_3_2_SOURCE.zip`.
3. W `.github/workflows/` dodaj `CompassPro7X_v1_3_2_BUILD.yml`.
4. Zatwierdź oba pliki. Actions → `Compass Pro 7X v1.3.2` → sprawdź status.
5. Po sukcesie pobierz `CompassPro7X_v1_3_2_PRO_build` i wybierz `.prg` odpowiedni dla fenix7xpro.
6. `.iq` powstanie tylko, jeśli masz `CONNECTIQ_DEVELOPER_KEY_BASE64` z trwałym kluczem podpisu.

Pozostałe pliki Solar Rings nie są zmieniane. Kompilacja w chmurze jest niezbędna, ponieważ w tym środowisku nie ma Garmin SDK.
