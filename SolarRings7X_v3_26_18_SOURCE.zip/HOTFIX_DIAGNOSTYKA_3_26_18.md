# Solar Rings 7X v3.26.18 — hotfix po realnych awariach Garmin

## Potwierdzona diagnoza (3.26.17, 17 listopada 2026)
Z urządzenia Fenix 7X Pro Solar, CIQ 6.0.4, FW 27.18 otrzymano 10 zdarzeń:
8 × Out Of Memory, 2 × Unexpected Type.
Dopasowano PC z `CIQ_LOG.YML` do `006-B4376-00/debug.xml` z oryginalnego `SolarRings7X_v32617.iq`:
- 0x1000a61d — `GarminWeatherWarnings.mc:415`, `Weather.getHourlyForecast()`
- 0x100077dd — `Config.mc:40`, `srSetting()`, podczas klasyfikacji Garmin Weather
- 0x100077c0 — `Config.mc:36`, `Props.getValue()` w ścieżce `onSettingsChanged()` → `srOwmProviderChanged()`

## Zmiany
1. Odroczona obsługa ustawień: callback nie wywołuje bezpośrednio odczytu properties ani operacji Storage/Background i nie przebudowuje obiektów pogodowych. Aktualizacja następuje w bezpieczniejszym kontekście `onUpdate()`.
2. Przy zmianie wyłącznie wizualnej nie synchronizuje się ponownie OWM; resetuje się pamięć podręczną rysowania. Przy zmianie dostawcy lub parametrów API zachowano synchronizację.
3. Ograniczono cache ustawień z 96 do 48 wpisów; API key nie jest w nim przechowywany. Pod niską pamięcią pomija się cache nowych kluczy.
4. Przy <30 KB wolnej pamięci podczas `onUpdate()` nie pobiera się rozbudowanej tablicy prognoz godzinowych Garmin; aktualne ostrzeżenia w miarę możliwości pozostają. Przy <18 KB pomija się całą kosztowną klasyfikację.
5. Usunięto wywołanie 35 zapisów gotowych już wartości domyślnych z funkcji uruchamiania tarczy. Wartości `properties.xml` i własne preferencje są zachowane.

## Ograniczenia
To jest wersja do kompilacji i testowania, NIE potwierdzona jako stabilna na zegarku. Testy Python/walidacja XML są tylko źródłowe. Bez SDK i próby na Garminie nie można potwierdzić braku OOM ani obiecać, że stare preferencje odzyskają się po zresetowaniu przez system. Przy niskiej pamięci ostrzeżenie prognozowe może zostać pominięte zamiast przełączania się na tarczę systemową. Kompromis wymaga sprawdzenia w logach.
