# Solar Rings v3.26.17 — poprawka kompilacji Monkey C

## Przyczyna
GitHub Actions, fenix7xpro, `SolarRings7X.mc:1691,12`: `Array index is out of bounds for type '$.Toybox.Lang.Array[]'`.
Zmienna `active` zaczynała jako pusta tablica `[]`; statyczny analizator Monkey C odrzucał odczyt `active[0]`, choć wcześniej dodawano element i sprawdzano flagę.

## Zmiana
Zachowano wyliczony symbol ciśnieniowy w prostej zmiennej `pressureGlyph` i przekazano go bezpośrednio do `drawAlertGlyph()`. Nie zmieniono progów StormGuard, jego działania, pozycji ikon, logiki OpenWeather, klucza API, harmonogramu zadań ani kluczy pamięci.

## Weryfikacja
Regresja Python, walidacja XML, integralność ZIP. Kompilacja z Garmin Connect IQ SDK jest nadal konieczna w GitHub Actions. Ostrzeżenia `WeatherGeocode.mc: Cannot determine if container access is using container type` nie są błędami zatrzymującymi kompilację.
