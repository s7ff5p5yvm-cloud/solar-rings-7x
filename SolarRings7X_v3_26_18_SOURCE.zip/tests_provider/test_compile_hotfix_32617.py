"""Monkey C compiler static-bound hotfix. Source checks do not replace SDK compilation."""
import unittest
from pathlib import Path

SOURCE=(Path(__file__).resolve().parents[1]/"source/SolarRings7X.mc").read_text()

class CompileHotfix32617(unittest.TestCase):
    def test_stormguard_no_static_empty_array_access(self):
        self.assertIn("var pressureGlyph = 0;", SOURCE)
        self.assertIn("pressureGlyph = pressureLevel == 2 ? -1 : -2;", SOURCE)
        self.assertIn("active.add(pressureGlyph);", SOURCE)
        self.assertIn("drawAlertGlyph(dc, 45, pressureGlyph);", SOURCE)
        self.assertNotIn("drawAlertGlyph(dc, 45, active[0]);", SOURCE)
    def test_pressure_and_weather_layout_still_separate(self):
        self.assertIn("weatherStart = 1;", SOURCE)
        self.assertIn("var centers = [68, 91, 114];", SOURCE)
        self.assertIn("active[weatherStart + j]", SOURCE)

if __name__=="__main__": unittest.main()
