import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent.parent
P=ET.parse(ROOT/'resources/settings/properties.xml')
PR={i.attrib['id']: i.text for i in P.iter('property')}
C=(ROOT/'source/Config.mc').read_text()
N=(ROOT/'source/SolarOpenNetwork.mc').read_text()
D=(ROOT/'source/SolarOpenData.mc').read_text()
W=(ROOT/'source/SolarOpenWarnings.mc').read_text()
F=(ROOT/'source/SolarRings7X.mc').read_text()
class Full32615(unittest.TestCase):
    def test_default_freshness(self):
        self.assertEqual(PR['srOwmMinutesV326'],'5')
        self.assertEqual(PR['gwIntervalV332'],'5')
        self.assertEqual(PR['gwHorizonV332'],'3')
        self.assertEqual(PR['srOwm15MinV3264'],'true')
    def test_alert_defaults(self):
        for k,v in {'srPrecipModeV3263':'2','gwRainChanceV332':'30','gwSnowChanceV332':'40','gwWindV332':'10','srOwmGustV3263':'15','gwIceTempV332':'1','gwUvV332':'7','srOwmAqiMinV326':'4'}.items():
            self.assertEqual(PR[k],v)
        for k in ('gwUvOnV332','srOwmAirV326','gwOnV332','gwForecastV332'):
            self.assertEqual(PR[k],'true')
    def test_upgrade_is_one_time_and_preserves_user_credentials(self):
        self.assertIn('Storage.getValue("srOptimal32616") == 1',C)
        self.assertIn('Storage.setValue("srOptimal32616", 1)',C)
        self.assertNotIn('srApplyOptimizedWeatherDefaults32616();',F)
        self.assertNotIn('Props.setValue("srOpenKeyV326"',C)
        self.assertNotIn('Props.setValue("srProviderV326"',C)
    def test_offline_retry_not_hour(self):
        self.assertIn('if (code == -12) { pause = 5 * 60; }',N)
        self.assertIn('var pause = 15 * 60;',N)
        self.assertIn('if (code == -403 && !kindIs("current"))',N)
    def test_forecast_stale_and_fallback(self):
        self.assertIn('maxAge = srSetting("srOwmMinutesV326", 30) == 5 ? 45 * 60 : 120 * 60;',D)
        self.assertIn('var hourly = value("srOHoursV326");',N)
        self.assertIn('srOShortPausedV3264',N)
    def test_cloud_and_recent_precip_not_current(self):
        self.assertIn('recentPrecipitation(d)',W)
        self.assertIn('addAlert(out, 66)',W)
        self.assertIn('var storm = mapped &&',W)
    def test_no_new_http_per_wakeup(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),1)
if __name__=='__main__':unittest.main()
