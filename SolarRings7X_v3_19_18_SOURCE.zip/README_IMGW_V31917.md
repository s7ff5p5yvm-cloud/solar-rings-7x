# IMGW v3.19.17: izolacja błędów T4

## Zmiany
- Poprawne odkładanie kodu powiatu bezpośrednio w zadaniu tła po wyniku GUGiK (Garmin API >=3.2.0).
- Nadal jedno żądanie HTTP w pojedynczym cyklu: GUGiK albo plik województwa na GitHubie.
- Status 10 (wyjątek lokalny) pokazuje `T4 E<nr>` — etap, który zwrócił błąd; nie jest to automatyczne potwierdzenie przyczyny wyjątku.
- Wynik diagnostyczny zapisywany przed dodatkowym cache, żeby usterka cache nie zgubiła wyniku.
- Wyniki innych testów nie są prezentowane jako awaria testu 4.

## Jak testować
Włącz IMGW, diagnostykę, etap 4, odświeżanie co 5 min.
`T4 POW ####` = ustalono powiat, czekamy na następny cykl; `T4 OK0 ####` = aktualny wynik bez ostrzeżeń; `T4 ALERT ####` = wykryto alert.
`T4 E##` = wyjątek w etapie programu; `T4 HTTP##`, `T4 FORMAT`, `T4 STARE` = błąd sieci/danych.
W razie wyłączenia tarczy wróć do testu 4B.

Nie potwierdzono kompilacji w SDK ani zachowania na fizycznym zegarku.
