# Solar Rings 7X v3.19.18 — diagnostyka bezpośredniego IMGW

To wersja testowa. Nie pokazuje prawdziwych ostrzeżeń w nowych testach.

W Connect IQ ustaw: IMGW WŁĄCZONE; diagnostyka WŁĄCZONA; odświeżanie 5 minut; etap **4C — IMGW bezpośrednio JSON, bez analizy**.

- `T4C OK` — zapytanie GET do oficjalnego API IMGW zakończyło się statusem HTTP 200. **Nie oznacza to przetworzenia ostrzeżeń.** Garmin dekoduje JSON, zanim wywoła nasz callback.
- `T4C HTTP-400` — możliwa niezgodność formatu JSON z parserem Garmin (np. odpowiedź będąca tablicą).
- `T4C HTTP-403` — możliwe przekroczenie pamięci podczas obsługi odpowiedzi.
- `T4C CZEKA` — brak wyniku z zadania; zadanie może być opóźnione.
- Jeśli tarcza się wyłączy, wróć do testu 3; ten objaw pomaga zawęzić problem, ale nie wskazuje sam z siebie dokładnego błędu.

Opcja **4D — IMGW bezpośrednio TXT, bez analizy** wymusza tekstowe odczytanie pełnego JSON. Może zwrócić `HTTP-400` na iPhonie z powodu niedopasowania Content-Type — to nie jest dowód, że IMGW jest niedostępne.

Nowy workflow v3.19.18 buduje tarczę przez GitHub Actions, ale **nie** tworzy ani nie aktualizuje gałęzi `imgw-feed`. Oba nowe testy 4C/4D łączą się z IMGW, a nie z GitHubem. Starsze workflow w repozytorium mogą nadal odświeżać `imgw-feed`, jeśli ich nie wyłączono.

Prawdziwych ostrzeżeń nie należy uznawać za sprawdzone, dopóki nie zostanie ponownie włączony w pełni działający tryb produkcyjny. Tradycyjny test 4 jest celowo zablokowany w tej diagnostycznej wersji, ponieważ korzystał z poprzedniego wariantu GitHub i wcześniej powodował awarie.
