# Diagnostyka IMGW v3.19.15 — testy 4A i 4B

To wersja **diagnostyczna**. Stabilność GPS i GUGiK potwierdzono w teście 3; test 4 (pełna ścieżka) w v3.19.14 nadal powodował zamknięcie tarczy.

- **4A**: jeden `GET https://raw.githubusercontent.com/.../imgw-feed/feed/health.txt` z typem `text/plain`; weryfikuje wyłącznie odpowiedź tekstową `IMGW_FEED_OK`. NIE uruchamia GUGiK, nie odczytuje GPS, nie interpretuje JSON.
- **4B**: jeden `GET .../feed/12.json` z automatyczną konwersją JSON, sprawdza tylko `v`, `ts` i `a`; brak GPS i GUGiK. NIE wybiera ostrzeżeń dla powiatu. Numer 12 jest stały wyłącznie dla diagnostyki.
- **4**: nadal pełne połączenie GPS/GUGiK -> plik województwa -> ostrzeżenia i ikona. Przy problemie wracaj do 3.

Po udanym ręcznym workflow sprawdź w gałęzi `imgw-feed`: `feed/health.txt` i `feed/12.json`. Nie instaluj zegarka zanim workflow nie skończy się na zielono. Włącz diagnostykę i 5-minutowy interwał, zacznij od 4A.

Przykładowe komunikaty: `T4A CZEKA`, `T4A OK R76K`, `T4A HTTP404`, `T4A FORMAT`, `T4B OK R76K`, `T4B STARE`, `T4B FORMAT`.

**Uwaga:** sukces 4A i 4B nie potwierdza działania pełnego IMGW. Nie udostępniaj prywatnych danych w repozytorium publicznym. Zadania w tle są limitowane do ok. 30 s i małej pamięci.

# Solar Rings 7X v3.19.15 — IMGW bez ogólnopolskiego JSON na zegarku

## Dlaczego poprzednia tarcza się wyłączała?

Test 3 (ULDK/GUGiK) przeszedł (`T3 1261 OK`). Test 4 uruchamiał pobieranie ogólnopolskiej odpowiedzi IMGW, mimo że serwis Garmina ma tylko ok. 32 KB pamięci. Rozmiar i dekodowanie całego JSON mogły wywołać awarię; bez logu urządzenia nie można uznać tego za przyczynę potwierdzoną.

## Co się zmieniło

- GPS i ustalanie powiatu GUGiK pozostawiono bez zmian.
- Workflow GitHub Actions pobiera ogólnopolskie ostrzeżenia z oficjalnego serwera IMGW, sprawdza ich strukturę i tworzy **16 małych plików JSON** — po jednym na województwo.
- Dane są zapisywane do osobnej gałęzi `imgw-feed` publicznego repozytorium na GitHubie. W pliku są wyłącznie aktywne ostrzeżenia, 4-cyfrowy powiat TERYT, stopień i kod zjawiska. Brak wskazanego powiatu w **prawidłowym, świeżym pliku** oznacza brak aktywnego ostrzeżenia.
- Garmin pobiera tylko jeden mały plik dla 2-cyfrowego prefiksu województwa; **nie pobiera już ogólnopolskiego JSON**.
- Zabezpieczenia: wymagany ważny czas aktualizacji, walidacja pól, błąd zamiast fałszywego „brak ostrzeżeń” przy przeterminowanym / uszkodzonym pliku.

## Wymagania

1. **Repozytorium GitHub musi być publiczne**, aby zegarek mógł pobrać plik `raw.githubusercontent.com` bez hasła. Jeśli repo jest prywatne, test 4 będzie zgłaszał błąd HTTP (najczęściej 404) — nie będzie fałszywego OK.
2. W repozytorium: Settings → Actions → General → Workflow permissions → **Read and write permissions** (o ile polityka konta pozwala). Workflow potrzebuje uprawnienia do utworzenia i aktualizowania gałęzi `imgw-feed`.
3. Plik `SolarRings7X_v3_19_14_SOURCE.zip` w katalogu głównym gałęzi domyślnej; `SolarRings7X_v3_19_14_BUILD.yml` w `.github/workflows/`.
4. W Actions ręcznie uruchom „Build Solar Rings 7X v3.19.15 (IMGW compact feed)”. Pierwszy job powinien pokazać `PASS IMGW compact feeds ...` i utworzyć gałąź `imgw-feed`, drugi skompilować tarczę.
5. Sprawdź w repozytorium gałąź `imgw-feed` i plik `feed/12.json` dla Małopolski. Wewnątrz powinien być mały obiekt z `"v":1`, `"ts":...`, `"a":...`.
6. Zainstaluj wygenerowany plik .IQ w Connect IQ, włącz IMGW, diagnostykę, test 4 i na potrzeby testu odświeżanie co 5 minut. **Prawdziwe dane na serwerze są odświeżane co ok. 30 minut**, nawet jeżeli zegarek pyta częściej.

## Interpretacja

- `T4 OK0 1261` — **pozytywne potwierdzenie**: świeży, poprawny plik IMGW, dla Krakowa brak aktualnych ostrzeżeń.
- `T4 ALERT 1261` — świeży plik z aktywnym ostrzeżeniem przypisanym do Krakowa (kolor ikony zależy od stopnia).
- `T4 HTTP404` — najczęściej prywatne repo, brak gałęzi `imgw-feed` lub brak pliku; sprawdź publikację.
- `T4 STARE` — plik ma starszą datę niż 2 godziny albo nieprawidłową datę; nie pokazuje fałszywego „OK 0”.
- `T4 FORMAT` — plik JSON ma zły format; nie jest traktowany jako brak ostrzeżeń.

## Ważne ograniczenia

- Testy lokalne obejmują parser danych i walidację pliku; nie oznaczają przebudowania w Garmin SDK ani gwarancji działania na fizycznym urządzeniu. Obie te rzeczy weryfikujesz w GitHub Actions / na zegarku.
- GitHub może opóźnić harmonogram lub wyłączyć planowane zadania w nieaktywnych repozytoriach; zegarek w takim przypadku zgłosi przeterminowanie, a nie brak ostrzeżeń.
- Aktualna lokalizacja GPS trafia wyłącznie do GUGiK w celu ustalenia powiatu. Zegarek pobiera plik z GitHub na poziomie województwa (GitHub zna wtedy adres IP i dwucyfrowy prefiks województwa).
- Jeśli repozytorium ma pozostać prywatne, zamiast raw.githubusercontent.com trzeba uruchomić publiczną usługę publikującą te małe pliki.
