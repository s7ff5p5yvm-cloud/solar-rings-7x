#!/usr/bin/env python3
"""Prepare small, per-voivodeship official IMGW warnings for Garmin.

Fetch one official national OSMET-Teryt JSON and publish only compact, validated
active warning summaries. A missing county in a validated, fresh voivodeship
feed means there are no active warnings for that county.
"""
import argparse
import gzip
import json
import re
import urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

IMGW_URL = 'https://meteo.imgw.pl/api/meteo/messages/v1/osmet/latest/osmet-teryt'
VOIVODESHIPS = tuple(f'{i:02d}' for i in range(2, 33, 2))
MAX_FEED_BYTES = 8192
MAX_UPSTREAM_BYTES = 3_000_000
PL = ZoneInfo('Europe/Warsaw')


def classify(name):
    name = str(name or '').casefold()
    if 'burz' in name:
        return 1
    if 'zawiej' in name or 'zamiec' in name or 'zamieć' in name:
        return 11
    if 'wiatr' in name or 'sztorm' in name:
        return 2
    if 'marzn' in name or 'marzną' in name or 'gołoled' in name or 'gołoledź' in name:
        return 6
    if 'oblodzen' in name or 'oblodzeń' in name or 'oblodzenie' in name:
        return 5
    if 'śnieg' in name or 'śnież' in name or 'snieg' in name:
        return 4
    if 'deszcz' in name or 'opad' in name:
        return 3
    if 'przymrozk' in name:
        return 9
    if 'roztop' in name:
        return 12
    if 'upa' in name:
        return 7
    if 'mróz' in name or 'mroz' in name:
        return 8
    if 'mgł' in name or 'mgl' in name:
        return 10
    return 13


def parse_time(text):
    if not isinstance(text, str):
        raise ValueError('Invalid warning validity timestamp')
    try:
        return datetime.strptime(text, '%Y-%m-%d %H:%M').replace(tzinfo=PL)
    except ValueError as exc:
        raise ValueError('Unexpected warning validity timestamp') from exc


def load_api(url=IMGW_URL):
    req = urllib.request.Request(url, headers={
        'User-Agent': 'SolarRings7X-OfficialIMGWFeed/1.0',
        'Accept': 'application/json',
        'Accept-Encoding': 'identity',
    })
    with urllib.request.urlopen(req, timeout=20) as resp:
        raw = resp.read(MAX_UPSTREAM_BYTES + 1)
        if len(raw) > MAX_UPSTREAM_BYTES:
            raise ValueError('IMGW response exceeds safety limit')
        if raw[:2] == b'\x1f\x8b' or 'gzip' in resp.headers.get('Content-Encoding', '').lower():
            raw = gzip.decompress(raw)
        if len(raw) > MAX_UPSTREAM_BYTES:
            raise ValueError('Uncompressed IMGW response too large')
    return json.loads(raw.decode('utf-8-sig'))


def build_feeds(source, now=None):
    if now is None:
        now = datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError('Current time must have a timezone')
    if not isinstance(source, dict) or not isinstance(source.get('warnings'), dict) or not isinstance(source.get('teryt'), dict):
        raise ValueError('Invalid IMGW response schema: missing warnings or teryt')
    program = source.get('program', {})
    if not isinstance(program, dict) or not isinstance(program.get('LxExportTime'), str):
        raise ValueError('Missing IMGW export timestamp, cannot validate freshness')
    export = datetime.fromisoformat(program['LxExportTime'])
    if export.tzinfo is None or not (-300 <= (now - export).total_seconds() <= 7200):
        raise ValueError('IMGW export is too old or dated in the future')

    alerts = {v: {} for v in VOIVODESHIPS}
    warning_records = source['warnings']
    for county, ids in source['teryt'].items():
        if not isinstance(county, str) or not re.fullmatch(r'\d{4}', county) or county[:2] not in alerts:
            raise ValueError(f'Invalid county TERYT {county!r}')
        if not isinstance(ids, list) or len(ids) > 30:
            raise ValueError(f'Invalid warning IDs for {county}')
        for warning_id in ids:
            if not isinstance(warning_id, str):
                raise ValueError('Non-string warning id')
            w = warning_records.get(warning_id)
            if not isinstance(w, dict):
                raise ValueError(f'Missing warning {warning_id}')
            start, end = parse_time(w.get('ValidFrom')), parse_time(w.get('ValidTo'))
            if not start <= now <= end:
                continue
            try:
                level = int(w['Level'])
            except (TypeError, ValueError, KeyError):
                raise ValueError('Invalid IMGW severity')
            if not 1 <= level <= 3:
                raise ValueError('Unexpected warning level')
            kind = classify(w.get('PhenomenonName'))
            old = alerts[county[:2]].get(county)
            # Pick strongest official level; stable phenomenon tie-break.
            if old is None or level > old[0] or (level == old[0] and kind < old[1]):
                alerts[county[:2]][county] = [level, kind]

    epoch = int(now.timestamp())
    files = {}
    for province, values in alerts.items():
        serialized = json.dumps({'v': 1, 'ts': epoch, 'a': values}, ensure_ascii=True, separators=(',', ':'), sort_keys=True).encode('ascii') + b'\n'
        if len(serialized) > MAX_FEED_BYTES:
            raise ValueError(f'Feed {province} would exceed {MAX_FEED_BYTES} bytes')
        files[province + '.json'] = serialized
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    files = build_feeds(load_api())
    args.output.mkdir(parents=True, exist_ok=True)
    for name, data in files.items():
        (args.output / name).write_bytes(data)
    # Plain-text probe isolates a single HTTPS request from any JSON decoder.
    # Published only after a complete, valid upstream refresh.
    (args.output / 'health.txt').write_text('IMGW_FEED_OK\n', encoding='ascii')
    print(f'PASS IMGW compact feeds: {len(files)} provinces; max {max(map(len, files.values()))} bytes; '
          f'{sum(len(json.loads(x)["a"]) for x in files.values())} counties with active alerts')


if __name__ == '__main__':
    main()
