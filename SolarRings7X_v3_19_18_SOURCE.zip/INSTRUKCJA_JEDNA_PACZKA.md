# Solar Rings 7X v3.20.1 — poprawiony pełny tryb IMGW

W tej wersji **tryb 4** korzysta z tej samej ścieżki, która na zegarku przeszła test **5C** (pokazując T11 OK0):

GPS -> GUGiK (kod powiatu) -> IMGW API (JSON) -> pełne dopasowanie ostrzeżeń -> wyświetlenie.

Dwa połączenia wykonywane są kolejno w jednym cyklu. **Nie jest używany GitHub jako źródło danych IMGW.** GitHub służy wyłącznie do budowania aplikacji.

Poprzedni tryb 4 miał osobny mechanizm pamięci powiatu i dodatkowy cykl, nieużywany w 5C. Został wyłączony na rzecz identycznej ścieżki dla 4 oraz 5C. Pozostałe 0–13 tryby diagnostyczne zachowano.

## Instalacja

1. Zastąp w głównym katalogu repozytorium stary plik `SolarRings7X_v3_19_18_SOURCE.zip` nowym ZIP-em o tej samej nazwie.
2. Uruchom **dotychczasowy** workflow `Build Solar Rings 7X v3.19.18`, bez dodawania nowego YAML.
3. Zainstaluj zbudowaną tarczę (wersja wewnętrzna 3.20.1).
4. Ustaw **IMGW włączone**, **diagnostyka włączona**, **test 4**, odświeżanie co 5 minut.
5. Oczekiwany jest `T4 OK0 <powiat>` lub `T4 ALERT <powiat>`, przy błędzie `T4 E...`, `T4 FORMAT` bądź HTTP. W razie awarii wróć do stabilnego testu 5C.

> Wyników działania na fizycznym zegarku nie gwarantują testy statyczne. Zanim wyłączysz diagnostykę, potwierdź kilka cykli bez awarii. Przy rzeczywistych zagrożeniach sprawdzaj oficjalne komunikaty IMGW.
