# Solar Rings 7X — zintegrowana diagnostyka v3.20.0

## Jedno wgranie na GitHub
Do repozytorium na gałąź main wgraj tylko plik `SolarRings7X_v3_19_18_SOURCE.zip`, nadpisując poprzedni o tej nazwie. Celowo użyto starej nazwy, ponieważ istniejący workflow `Build Solar Rings 7X v3.19.18` automatycznie kompiluje właśnie ten plik. **W środku jest aplikacja w wersji 3.20.0.** Nie wgrywaj dodatkowego pliku YAML. Po poprawnym zbudowaniu pobierz artefakt z Actions i zainstaluj nową tarczę.

## Wszystkie testy w jednej instalacji
W Garmin Connect IQ włącz IMGW, diagnostykę i odświeżanie 5 minut. Zmień wyłącznie `IMGW: etap testowania` — bez kolejnych aktualizacji:

- 0 ekran, 1 GPS, 2 zadanie w tle, 3 GUGiK;
- 4 docelowy tryb bez GitHuba — GUGiK i IMGW w osobnych cyklach;
- 4A (5) stary próbnik tekstowy GitHuba i 4B (6) stary próbnik JSON (opcjonalne, wymagają dostępnego feedu);
- 4C (7) IMGW JSON bez analizy; 4D (8) IMGW tekst bez analizy;
- 5A (9) **GUGiK i IMGW w jednym cyklu**, jedynie HTTP;
- 5B (10) GUGiK + IMGW w jednym cyklu, sprawdzenie JSON;
- 5C (11) GUGiK + IMGW w jednym cyklu, pełne dopasowanie ostrzeżeń;
- 6A (12) IMGW JSON bez GPS i GUGiK, sprawdzenie struktury;
- 6B (13) IMGW JSON bez GPS i GUGiK, pełne dopasowanie do **testowego powiatu 1261**. To **nie** jest tryb produkcyjny.

Pierwsze wyniki HTTP/JSON nie oznaczają, że ostrzeżenia są prawidłowe. Dopiero tryby 4/5C/6B sprawdzają dopasowanie do powiatu, a **6B** używa wyłącznie powiatu testowego. Wynik `OK0` wymaga poprawnego JSON i pełnego przeglądu rekordów.

### Zasady bezpieczeństwa działania
- Błędy, przeterminowana pozycja, zły format i brak danych **nie** są komunikatem „brak ostrzeżeń”.
- Ostrzeżenia są sprawdzane względem `obowiazuje_od` i `obowiazuje_do`, korzystając z czasu lokalnego ustawionego na zegarku. Dla ostrzeżeń w Polsce ustaw zegarek na poprawną strefę Europe/Warsaw.
- Mode 4 uruchamia maksymalnie jedno zapytanie na cykl. Mode 5A–5C celowo uruchamiają dwa zapytania po kolei i mogą nadal przeciążać zadanie w tle.
- Wartości `E##` to etap błędu, `HTTP-...` to kod odpowiedzi, `FORMAT` oznacza nieobsługiwany lub nieprawidłowy schemat.

## Ograniczenia testowe
Testy lokalne sprawdzają strukturę i spójność, ale **kompilację w Garmin SDK i zachowanie na fizycznym zegarku trzeba potwierdzić w GitHub Actions i na Fenix 7X Pro Solar**.
