#!/usr/bin/env python3
"""Regression for Monkey C reference equality bug from T3 H30 on hardware.
This is static verification, not SDK execution.
"""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / "source/ImgwService.mc").read_text(encoding="utf-8")
assert 'if (!status.equals("0")) {' in s
assert 'if (status != "0")' not in s
assert 'if (status == "0")' not in s
assert 'var status = "";' in s
assert 'status += statusChars[h].toString();' in s
assert 'if (!(raw instanceof Lang.String))' in s
assert 'var code = raw.substring(pos, pos + 4);' in s
# A reference-based string comparison would reject freshly concatenated "0";
# value-based String.equals() accepts the identical contents.
print('PASS: ULDK status uses String.equals, not reference comparison')
