#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path(__file__).parents[1]
s = (root/'source/ImgwService.mc').read_text()
f = (root/'source/SolarRings7X.mc').read_text()
xml = ET.parse(root/'resources/settings/settings.xml')
values={v.attrib['value'] for v in xml.findall('.//setting[@propertyKey="@Properties.imgwTestStageV3194"]/settingConfig/listEntry')}
assert {'7','8'} <= values
block = s.split('function beginDirectImgwProbe(asText)',1)[1].split('function beginTextProbe()',1)[0]
assert 'https://danepubliczne.imgw.pl/api/data/warningsmeteo' in block
assert 'HTTP_RESPONSE_CONTENT_TYPE_JSON' in block
assert 'HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN' in block
assert 'onDirectImgwResponse' in block
assert 'processWarnings(' not in block
assert 'parseCounty(' not in block
assert 'smallFeedUrl(' not in block
assert 'makeWebRequest' in block
assert 'if (responseCode != 200)' in block
assert 'Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 17]);' in block
assert 'Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 18]);' in block
assert 'payload[' not in block and 'payload.find(' not in block and 'payload.size(' not in block
main=s.split('function onTemporalEvent()',1)[1].split('function parseCounty(',1)[0]
for check in ['if (stage == 7) { beginDirectImgwProbe(false); return; }',
              'if (stage == 8) { beginDirectImgwProbe(true); return; }']:
    assert main.index(check) < main.index('Storage.getValue("imgwLocV318")')
assert 'T4C' in f and 'T4D' in f
assert 'if (stage == 7 || stage == 8)' in f
assert 'srSetting("imgwTestStageV3194", 0) != 4' in f
print('PASS: one direct IMGW GET per probe, no GitHub/GUGiK/GPS/warnings parsing in app')
