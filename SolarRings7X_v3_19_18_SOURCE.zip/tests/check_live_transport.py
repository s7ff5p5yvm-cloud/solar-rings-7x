#!/usr/bin/env python3
"""Offline test for real gzip/identity payload variants (no network required)."""
import gzip
import json
from check_live_imgw import decode_transport, validate_imgw, validate_uldk

sample={'warnings':{'w1':{'Level':'1'}},'teryt':{'1261':['w1']}}
json_bytes=json.dumps(sample, ensure_ascii=False).encode('utf-8')
compressed=gzip.compress(json_bytes)
assert compressed[:2] == b'\x1f\x8b'
assert validate_imgw(decode_transport(json_bytes))==sample
assert validate_imgw(decode_transport(compressed))==sample  # broken case in 3.19.9
assert validate_imgw(decode_transport(compressed, 'gzip'))==sample
assert validate_imgw(decode_transport(compressed, 'GZIP'))==sample
assert validate_imgw(decode_transport(json_bytes,'identity'))==sample
assert validate_uldk(b'0\n1261')=='1261'
assert validate_uldk(b'0\r\n1261\r\n')=='1261'
assert validate_uldk(decode_transport(gzip.compress(b'0\n1261'))) == '1261'
try:
    validate_imgw(decode_transport(compressed[:5]))
except (EOFError, OSError):
    pass
else:
    raise AssertionError('Damaged gzip must not be treated as valid JSON')
print('PASS: raw UTF-8, gzip magic without Content-Encoding, explicit gzip header, ULDK CRLF, corrupted gzip')
