#!/usr/bin/env python3
"""Offline tests: active warnings, absent county, expired alert, malformed payload, size cap."""
import importlib.util
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('imgw_compact', root/'scripts/update_imgw_feed.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
now = datetime(2026, 11, 13, 13, 30, tzinfo=timezone.utc)
src = {
    'program': {'LxExportTime': '2026-11-13T14:30:00+01:00'},
    'warnings': {
        'snow': {'Level': '1', 'PhenomenonName': 'Intensywne opady śniegu',
                 'ValidFrom': '2026-11-13 12:00', 'ValidTo': '2026-11-13 20:00'},
        'freeze': {'Level': '2', 'PhenomenonName': 'Opady marznące',
                   'ValidFrom': '2026-11-13 12:00', 'ValidTo': '2026-11-13 20:00'},
        'old': {'Level': '3', 'PhenomenonName': 'Silny wiatr',
                'ValidFrom': '2026-11-12 12:00', 'ValidTo': '2026-11-12 20:00'},
        'wind': {'Level': '1', 'PhenomenonName': 'Silny wiatr',
                 'ValidFrom': '2026-11-13 12:00', 'ValidTo': '2026-11-13 20:00'},
    },
    'teryt': {'1261': ['snow', 'freeze'], '1262': ['old'], '3205': ['wind']},
}
feeds = module.build_feeds(src, now)
assert len(feeds) == 16
assert max(map(len, feeds.values())) < 8192
assert all(f.endswith(b'\n') for f in feeds.values())
krakow = json.loads(feeds['12.json'])
assert krakow['v'] == 1 and krakow['ts'] == int(now.timestamp())
assert krakow['a']['1261'] == [2, 6], krakow
assert '1262' not in krakow['a']
assert json.loads(feeds['32.json'])['a']['3205'] == [1, 2]
assert json.loads(feeds['14.json'])['a'] == {}
assert module.classify('Opady śniegu') == 4
assert module.classify('Opady marznące') == 6
assert module.classify('Oblodzenie') == 5
assert module.classify('Przymrozki') == 9
for bad in (
    {**src, 'program': {'LxExportTime': '2026-11-12T10:00:00+01:00'}},
    {**src, 'teryt': {'1261': ['MISSING']}},
    {**src, 'warnings': None},
    {**src, 'teryt': {'12XX': []}},
):
    try:
        module.build_feeds(bad, now)
        raise AssertionError('Malformed/stale IMGW data incorrectly accepted')
    except ValueError:
        pass
service = (root/'source/ImgwService.mc').read_text()
assert 'osmet/latest/osmet-teryt' not in service, 'National JSON must never reach Garmin'
assert 'raw.githubusercontent.com/__GITHUB_OWNER_REPO__/imgw-feed/feed/' in service
assert 'Time.now().value() - when' in service
assert 'if (age < -300 || age > 7200)' in service
assert 'body["a"]' in service
assert 'stop(13)' in service
print('PASS: compact official IMGW feed, 16 voivodeships, fresh timestamp, empty county is clear, invalid/stale data rejected')
