#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]
svc=(p/'source/ImgwService.mc').read_text()
face=(p/'source/SolarRings7X.mc').read_text()
assert 'onWarningsResponse' in svc and 'processWarnings' in svc
assert 'http' not in svc.lower() or 'Comm.makeWebRequest' in svc
assert 'stop(8)' in svc and 'stop(9)' in svc and 'stop(13)' in svc
assert 'IMGW: STARE DANE' in face
assert 'T4 OK0' in face and 'T4 ALERT' in face
print('PASS: compact IMGW WatchFace status contracts')
