#!/usr/bin/env python3
"""Live IMGW / ULDK test run from GitHub Actions, separate from watch runtime.

IMGW may respond with gzip bytes, including when a bridge/proxy omits the
Content-Encoding header. Decode transport bytes first, then parse JSON.
This probe does not certify Garmin's background task or its memory limits.
"""
import gzip
import json
import urllib.request
import urllib.parse

URL_IMGW = 'https://meteo.imgw.pl/api/meteo/messages/v1/osmet/latest/osmet-teryt'
URL_ULDK = 'https://uldk.gugik.gov.pl/?' + urllib.parse.urlencode({
    'request': 'GetCountyByXY',
    'xy': '19.9370,50.0614,4326',  # Krakow test point, not user location
    'result': 'teryt',
})


def decode_transport(raw, content_encoding=''):
    """Unpack gzip by signature OR declared encoding; do not guess charset."""
    encoding = (content_encoding or '').lower().strip()
    if raw.startswith(b'\x1f\x8b') or 'gzip' in encoding:
        return gzip.decompress(raw)
    return raw


def download(url):
    headers = {
        'User-Agent': 'SolarRings7X-CI/1.0',
        'Accept-Encoding': 'identity',  # prefer plain content; handle gzip anyway
    }
    if url == URL_IMGW:
        headers['Accept'] = 'application/json'
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=18) as response:
        raw = response.read()
        content_encoding = response.headers.get('Content-Encoding', '')
        was_gzip = raw.startswith(b'\x1f\x8b') or 'gzip' in content_encoding.lower()
        unpacked = decode_transport(raw, content_encoding)
        print(f'INFO: response {response.status}, compressed={was_gzip}, bytes={len(raw)} -> {len(unpacked)}')
        return unpacked


def validate_imgw(payload):
    obj = json.loads(payload.decode('utf-8-sig'))
    if not (isinstance(obj, dict) and isinstance(obj.get('warnings'), dict)
            and isinstance(obj.get('teryt'), dict)):
        raise ValueError('Unexpected IMGW OSMET-Teryt schema')
    return obj


def validate_uldk(payload):
    body = payload.decode('utf-8-sig').strip().replace('\r\n', '\n')
    if not body.startswith('0\n'):
        raise ValueError('Unexpected ULDK status: '+repr(body[:50]))
    code = body.split('\n', 1)[1].strip()[:4]
    if len(code) != 4 or not code.isascii() or not code.isdigit():
        raise ValueError('Unexpected county ID: '+repr(body[:50]))
    return code


def main():
    failures = []
    try:
        obj = validate_imgw(download(URL_IMGW))
        print(f"PASS IMGW: {len(obj['warnings'])} warning records, {len(obj['teryt'])} county assignments")
    except Exception as exc:
        failures.append(f'IMGW live probe FAILED: {type(exc).__name__}: {exc}')
    try:
        code = validate_uldk(download(URL_ULDK))
        print(f'PASS ULDK: example Krakow point mapped to county TERYT {code}')
    except Exception as exc:
        failures.append(f'ULDK live probe FAILED: {type(exc).__name__}: {exc}')
    for failure in failures:
        print(failure)
    if failures:
        raise SystemExit(1)
    print('PASS: public endpoints responded; this does not verify requests on the watch.')


if __name__ == '__main__':
    main()
