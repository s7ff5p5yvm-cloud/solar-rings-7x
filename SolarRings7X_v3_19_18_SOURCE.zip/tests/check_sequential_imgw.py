#!/usr/bin/env python3
"""Offline structural regression test for 3.19.17, not a Connect IQ runtime test."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
svc=(r/'source/ImgwService.mc').read_text()
face=(r/'source/SolarRings7X.mc').read_text()
assert 'imgwCountyCacheV31916' in svc and 'imgwCountyCacheV31916' in face
assert 'function cachedCountyForLocation()' in svc
assert 'if (_county != null) { beginUnifiedImgwRequest(4); return; }' in svc
assert 'Time.now().value() - cache[3]' in svc
assert 'age > 14400' in svc
assert 'function beginCountyFeedRequest()' in svc
assert 'method(:onWarningsResponse)' in svc
cb=svc.split('function onCountyResponse(',1)[1].split('function onWarningsResponse(',1)[0]
assert 'Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 16, _stage]);' in cb
assert 'if (_stage == 9 || _stage == 10 || _stage == 11)' in cb
assert 'beginUnifiedImgwRequest(_stage);' in cb
assert 'if ((data[6] == 12 || data[6] == 16)' in face
assert 'Storage.setValue("imgwCountyCacheV31916"' in face
assert 'if (status == 16)' in face
assert 'return "IMGW " + data[0] + ": CZEKA";' in face
assert 'response[6] == 16' in face
assert 'T4 POW ' in face
assert 'T4 OK0 ' in face and 'T4 ALERT ' in face
assert 'localDateStamp()' in svc
assert 'processOfficialWarnings(payload)' in svc
print('PASS: one HTTP request per background run; GUGiK county cached; separate IMGW fetch; no false all-clear')
