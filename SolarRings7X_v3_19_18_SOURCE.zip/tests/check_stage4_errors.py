from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'source/ImgwService.mc').read_text()
f=(r/'source/SolarRings7X.mc').read_text()
assert 'var _phase;' in s
assert 'code == 10 ? _phase' in s
assert 'if (_stage == 4 || _stage == 9 || _stage == 10 || _stage == 11)' in s
assert 'beginUnifiedImgwRequest(_stage)' in s
assert 'function processOfficialWarnings(records)' in s
assert 'response[6] == 10' in f
assert 'shortStatus = "T4 E" + response[1].toString();' in f
chunk=f.split('function onBackgroundData(data)',1)[1].split('class SolarRingsFaceV3',1)[0]
assert chunk.index('Storage.setValue("imgwResultV318", data)') < chunk.index('Storage.setValue("imgwCountyCacheV31916",')
print('PASS: production full IMGW path and error reporting intact')
