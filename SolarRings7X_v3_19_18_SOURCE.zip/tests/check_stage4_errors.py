from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'source/ImgwService.mc').read_text()
f=(r/'source/SolarRings7X.mc').read_text()
assert 'var _phase;' in s
assert 'code == 10 ? _phase' in s
assert 'Storage.setValue("imgwCountyCacheV31916",' in s.split('function onCountyResponse(',1)[1].split('function onWarningsResponse(',1)[0]
assert 'makeWebRequest' not in s.split('function onCountyResponse(',1)[1].split('function onWarningsResponse(',1)[0]
assert 'function beginCountyFeedRequest()' in s
assert 'response[6] == 10' in f
assert 'shortStatus = "T4 E" + response[1].toString();' in f
assert 'if (status == 11 || status == 12 || status == 14 || status == 15)' in f
chunk=f.split('function onBackgroundData(data)',1)[1].split('class SolarRingsFaceV3',1)[0]
assert chunk.index('Storage.setValue("imgwResultV318", data)') < chunk.index('Storage.setValue("imgwCountyCacheV31916",')
print('PASS: staged IMGW exceptions exposed, county cached in background, results not lost by cache write')
