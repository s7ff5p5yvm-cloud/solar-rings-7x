#!/usr/bin/env python3
"""Static guard against forbidden GPS operations in the foreground watch face."""
from pathlib import Path
import xml.etree.ElementTree as ET
base = Path(__file__).resolve().parents[1]
face = (base/'source/SolarRings7X.mc').read_text()
field = (base/'source/FieldData.mc').read_text()
worker = (base/'source/ImgwService.mc').read_text()
manifest = ET.parse(base/'manifest.xml').getroot()
for name, code in [('face', face), ('solar', field), ('worker', worker)]:
    assert 'Position.getInfo()' not in code.replace('Position.getInfo() reliably', ''), name
    assert 'Position.enableLocationEvents(' not in code, name
assert 'var activity = Activity.getActivityInfo();' in face
assert 'activity.currentLocation.toDegrees()' in face
assert 'activity == null || activity.currentLocation == null' in face
assert 'info.currentLocation' in field
assert 'return "TEST " + stage + ": BRAK GPS";' in face
assert 'GPS? R' in face
assert 'if (diagnosticStage >= 2)' not in face # scheduler also requires enabled IMGW
assert 'diagnosticStage >= 2' in face
assert 'currentLocation' not in worker # background should reuse cached location
perm = {e.get('id') for e in manifest.iter() if e.tag.endswith('uses-permission')}
assert {'Positioning','Background','Communications','SensorHistory'} <= perm
print('PASS: watch-face-safe last-known-GPS API, GPS-null fallback, no direct Position calls')
