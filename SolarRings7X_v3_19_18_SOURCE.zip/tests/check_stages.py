#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).parent.parent
mc=(p/'source/SolarRings7X.mc').read_text()
svc=(p/'source/ImgwService.mc').read_text()
props=ET.parse(p/'resources/settings/properties.xml').getroot()
settings=ET.parse(p/'resources/settings/settings.xml').getroot()
strings=ET.parse(p/'resources/strings.xml').getroot()
assert ET.parse(p/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application').attrib['version']=='3.20.0'
assert len([e for e in props if e.attrib.get('id')=='imgwTestStageV3194'])==1
assert any(e.attrib.get('propertyKey')=='@Properties.imgwTestStageV3194' for e in settings)
assert all(any(s.attrib.get('id')=='imgwStage_'+str(i) for s in strings) for i in range(9))
assert 'if (stage == 0) { return "TEST 0: EKRAN OK"; }' in mc
assert 'srSetting("imgwTestStageV3194", 0) == 0' in mc
assert 'diagnosticStage >= 2' in mc
assert 'if (stage == 2)' in svc
assert 'Bg.exit(["", 0, 0, Time.now().value(), 0.0, 0.0, 11, _stage]);' in svc
assert 'if (Props.getValue("imgwTestStageV3194") == 3)' in svc
assert 'Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 12, _stage]);' in svc
assert 'if (stage != 3 && stage != 4 && stage != 9 && stage != 10 && stage != 11)' in svc
assert 'if (stage == 5) { beginTextProbe(); return; }' in svc
assert 'if (stage == 6) { beginJsonProbe(); return; }' in svc
assert 'if (stage == 5 || stage == 6)' in mc
assert 'if (stage == 3)' in mc
assert 'if (stage == 2)' in mc
print('PASS: isolated stage 0 UI, stage 1 GPS, stage 2 worker, stage 3 GUGiK, stage 4 IMGW, 4A raw GitHub and 4B GitHub JSON')

# Include single-package all-in-one checks in the existing v3.19.18 workflow.
import runpy
runpy.run_path(str(p/"tests/check_unified_direct.py"))
