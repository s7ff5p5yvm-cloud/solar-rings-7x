# Solar Rings 7X v3.19.17 — bezpieczne, dwuetapowe pobieranie IMGW

Wersja testowa. Test 3 (GUGiK), 4A (GitHub TXT), 4B (GitHub JSON) przeszły
na zegarku w v3.19.15. Test 4 wyłączał tarczę, dlatego zmieniono go tak,
by nie wykonywał dwóch zapytań HTTP w ramach jednego uruchomienia zadania w tle.

**Nowy test 4:** pierwsze uruchomienie zapisuje potwierdzony kod powiatu
(GUGiK), co daje `T4 POW ####`. Dopiero następne uruchomienie pobiera
mały JSON z GitHuba i sprawdza ostrzeżenia dla tego kodu.
`T4 OK0 ####` oznacza potwierdzony brak ostrzeżeń; `T4 ALERT ####` alert.
`T4 POW ####` oznacza oczekiwanie — NIE potwierdza braku ostrzeżeń.

**Instalacja:** ZIP do głównego katalogu repozytorium; BUILD.yml do
`.github/workflows/`, na głównej gałęzi. Uruchom workflow manualnie.
Repozytorium musi być publiczne, a gałąź imgw-feed aktualna.
Ustaw IMGW włączone, diagnostyka włączona, Test 4 i odświeżanie co 5 minut.
Pierwszy wynik może pojawić się po 5 minutach, pełny po kolejnym cyklu.
Jeśli tarcza ponownie się wyłącza, wróć do sprawdzonego testu 4B.

UWAGA: Lokalnych testów jednostkowych nie należy mylić z kompilacją
Monkey C w Garmin SDK ani testem na urządzeniu.

# Solar Rings 7X v3.19.15 — diagnostyka połączenia GitHub / IMGW

UWAGA: Funkcja IMGW jest nadal testowana na zegarku. Wersja 3.19.15 dodaje dwa testy
pojedynczego połączenia, bez zmiany skutecznego modułu GPS/GUGiK.

1. Po uruchomieniu GitHub Actions sprawdź, czy na gałęzi `imgw-feed` w folderze `feed/`
   istnieje `health.txt` z napisem `IMGW_FEED_OK`.
2. Na zegarku włącz IMGW + diagnostykę + interwał 5 min.
3. Wybierz `4A - GitHub: maly plik TXT`. Ta opcja nie czyta GPS i nie parsuje JSON.
   Poprawny wynik: `T4A OK RxxK`. Zostaw kilka minut, sprawdź stabilność.
4. Dopiero potem wybierz `4B - GitHub: JSON`. Pobiera `12.json` (testowy plik
   województwa małopolskiego) bez GUGiK i wykonuje tylko minimalną walidację.
   Poprawny wynik: `T4B OK RxxK`.
5. Dopiero po obu stabilnych testach można przejść do starego `4 - Pelne IMGW`
   (GPS -> GUGiK -> plik województwa -> ostrzeżenia).

Testy 4A i 4B nie potwierdzają ostrzeżeń dla aktualnego powiatu i NIE oznaczają
"braku ostrzeżeń". Jeśli tarcza zgaśnie lub błąd się powtórzy, wróć do testu 3.



Zobacz szczegóły nowego, bezpieczniejszego pobierania IMGW w `README_IMGW_V31914.md`. Poprzednie dane i ustawienia tarczy zachowano.

# Solar Rings 7X v3.19.13 — naprawa błędu porównywania tekstu w Monkey C

Na zegarku pojawiał się `T3 H30` (0x30 = ASCII `0`).
Przyczyną błędnego odrzucenia prawidłowego statusu była linia
`if (status != "0")`, ponieważ operatory `==`/`!=` w Monkey C porównują
referencje do obiektów String, nie zawartość. Teraz stosujemy
`if (!status.equals("0"))`. Zachowana jest walidacja czterocyfrowego kodu powiatu.

Po instalacji: IMGW włączone, diagnostyka włączona, Test 3 – GUGiK,
odświeżanie co 5 minut. Prawidłowy wynik: `T3 #### OK`.
Dopiero potem Test 4 — pobieranie rzeczywistych ostrzeżeń IMGW.

Pozostałe funkcje bez celowych zmian. Testy lokalne nie zastępują
kompilacji Garmin SDK ani sprawdzenia na fizycznym zegarku.

---

# Solar Rings 7X v3.19.12 – diagnostyka rzeczywistego nagłówka ULDK

W teście 3 zamiast `F5-0` pokaże `H...` z kodami znaków. Pozostałe funkcje pozostają bez celowych zmian.

# Solar Rings 7X v3.19.11 — poprawka GUGiK

Zmiana tylko w `source/ImgwService.mc`: normalizacja niewidocznych znaków
obok statusu `0` zwracanego przez ULDK i kodu powiatu. Pozostały kod
tarczy oraz ustawienia pozostały niezmienione. Dokładne testowanie w
`README_DIAGNOSTYKA_PL.md`.

# Solar Rings 7X v3.19.11

Poprawka testu sieciowego IMGW dla odpowiedzi gzip i prawidłowy numer wersji
aplikacji w manifeście. Zegarkowy kod IMGW/GUGiK pozostaje taki sam jak w
3.19.9, aby nie wprowadzać nowych zmiennych do diagnostyki.

# Aktualizacja v3.19.11

Diagnostyka statusu odpowiedzi GUGiK i jawny URL zapytania. W teście 3 szukaj T3 #### OK lub T3 F5-X. Nie włączaj testu 4 do czasu sukcesu testu 3.

# Solar Rings 7X v3.19.1 — kompletna aktualizacja

Zawiera wszystkie elementy v3.17: godzina, data, trzy kapsuly, ikony tetna,
Body Battery i minut intensywnych, dwa rozne symbole wschodu/zachodu,
pasek postepu i zielone DONE przy 100% krokow, termometr powyzej i ponizej
ustawionych progow, ostrzezenie burzowe barometryczne, kolory stanow
baterii/Body Battery/stresu, 8 konfigurowalnych pol i ostrzezenia IMGW.

## IMGW — konkretny powiat na podstawie pozycji zegarka

1. W ustawieniach Connect IQ wlacz IMGW (domyslnie wylaczone).
2. Zegarek musi udostepniac pozycje GPS. Tarcza NIE wlacza samodzielnie GPS,
   a ostatni odczyt starszy niz 6h jest odrzucany.
3. W tle (co 30 lub 60 minut) ULDK GUGiK otrzymuje wspolrzedne, odpowiada
   4-cyfrowym kodem powiatu TERYT, a IMGW zwraca liste ostrzezen.
4. Tarcza filtruje wylacznie aktywne alerty dla DOKLADNIE tego powiatu.
   Jesli nie ma pozycji/sieci/danych lub dane sa stare, ikonka znika.
5. Gdy IMGW i temperatury wywoluja dwa rozne ostrzezenia, obie ikony
   pokazywane sa niezaleznie po lewej stronie liczby temperatury.

12 rodzajow ikon + awaryjne ostrzezenie: 1 burze, 2 silny wiatr,
3 intensywne opady deszczu, 4 opady sniegu, 5 oblodzenie,
6 opady marznace/gololedz, 7 upaly, 8 silny mroz, 9 przymrozki,
10 gesta mgla, 11 zawieje/zamiecie, 12 roztopy.
Kolory stopnia: 1 zolty, 2 pomaranczowy, 3 czerwony.

## Czcionki

Usunieto z ekranu ustawien niedzialajace wybory kroju i wielkosci.
Zachowano stale, zaakceptowane wielkosci i automatyczne dopasowanie
przy dlugich wartosciach. Starsze zapisane ustawienia fontow sa ignorowane.

## Ograniczenia i zrodla

Wskaznik IMGW NIE jest systemem alarmowym. Nie gwarantuje natychmiastowego
przeslania alertu; jest zaleznym od GPS, polaczenia i danych sieciowych
uzupelnieniem oficjalnych komunikatow. Background task wymaga Garmin Connect.
Dokumentacja API: https://danepubliczne.imgw.pl/api/data/warningsmeteo
Zrodlo danych przestrzennych: Glowny Urzad Geodezji i Kartografii (GUGiK),
Usluga Lokalizacji Dzialek Katastralnych (ULDK): https://uldk.gugik.gov.pl/

Testowano statycznie kod i pliki konfiguracyjne; nie wykonano kompilacji SDK
ani testow na fizycznym zegarku. Do sprawdzenia sa zwlaszcza odpowiedz ULDK
w formacie text/plain oraz czas dzialania uslugi w tle.

## Poprawka v3.18.1 – czytelne ikony śniegu i marznących opadów
- Intensywne opady śniegu (IMGW kategoria 4): chmura i DWA PŁATKI śniegu.
- Opady marznące / gołoledź (IMGW kategoria 6): DWIE KROPLE i podwójna pozioma warstwa lodu.
- Ikony mają niezależne kształty i zachowują kolor stopnia IMGW.
- Pozostałe funkcje i ustawienia v3.18 pozostają bez zmian.

## v3.19.0: opcjonalna temperatura odczuwalna
- Nowy przelacznik w Connect IQ: "Pogoda: pokazuj takze temp. odczuwalna".
- Domyslnie **wylaczone**: opis pogody wyswietla sie tak jak poprzednio.
- Po wlaczeniu: duza liczba nadal oznacza temperature rzeczywista,
  a mniejszy wiersz pod nia pokazuje np. "ODCZ. 5°C".
- Gdy Garmin nie poda wartosci odczuwalnej, tarcza zachowa opis pogody.
- Opcja dziala tylko gdy dolne pole to "Pogoda" lub "Temperatura";
  inne wybrane dane pozostaja bez zmian.
- Dwa ostrzezenia (termometr + IMGW), ich pozycje i progi nie zmieniaja sie.
- Wartosc temperatury odczuwalnej pochodzi z Garmin Weather i wymaga
  aktualnych danych z polaczonego zegarka/telefonu.


## Poprawka v3.19.1 — typy callbacków IMGW
- Naprawiono dwa błędy kompilatora w `ImgwService.mc` przy `Comm.makeWebRequest`.
- Callbacki HTTP mają jawne typy kodu odpowiedzi, zawartości i `as Void`.
- Obsługę tablicy JSON IMGW przeniesiono do funkcji akceptującej `Lang.Object`,
  bo SDK 9.3 nie uwzględnia tablic JSON w oficjalnej sygnaturze callbacku.
- Wszystkie wcześniejsze funkcje i ustawienia v3.19 zachowane.
- Testy statyczne projektu nie zastępują kompilacji na SDK.


## Poprawka v3.19.2 – błąd po włączeniu IMGW

- IMGW: zamiast niekompatybilnej tablicy JSON z `/api/data/warningsmeteo` pobieramy oficjalny OSMET-Teryt, który zwraca obiekt JSON.
- Dane wybierane są według kodu powiatu GUGiK (TERYT) i stanu obowiązywania ostrzeżenia.
- Zdarzenia tła nie są ponownie rejestrowane z `onStart` procesu w tle; obsługa callbacku nie może przerwać renderowania tarczy.
- Wszystkie pozostałe funkcje i ustawienia v3.19.1 bez zmian.
- Ważne: test statyczny nie potwierdza jeszcze działania na urządzeniu. Jeśli tarcza nadal ulega awarii, potrzebny będzie log CIQ urządzenia.


## v3.19.3 - diagnostyka polaczenia IMGW bez kabla

Nowe ustawienie: **IMGW: pokaz status diagnostyczny**. W czasie testowania
wlacz takze IMGW i ustaw `Co 5 minut (test)`. Przy dolnym polu Pogoda lub
Temperatura, w miejscu krotkiego opisu pogody zobaczysz:

- `IMGW: BRAK GPS` – nie ma zapisanej aktualnej lokalizacji zegarka.
- `IMGW: GPS STARY` – wspolrzedne maja ponad 6 godzin.
- `IMGW: CZEKA` – czekamy na uruchomienie zadania w tle.
- `IMGW 1261: OK 0` – przyklad: udalo sie ustalic powiat 1261, IMGW zwrocilo
  poprawne dane, lecz nie ma w nim aktywnych ostrzezen.
- `IMGW 1261: ALERT` – w powiecie 1261 wykryto aktywne ostrzezenie; jego
  ikonka ma byc widoczna przy temperaturze.
- `IMGW: SIEC/API` – niepowodzenie pobierania danych z GUGiK lub IMGW.
- `IMGW: FORMAT API` – nieoczekiwany format odpowiedzi.
- `IMGW: NOWA LOK.` – pozycja zmienila sie i trzeba pobrac dane od nowa.
- `IMGW: WYGASLO` – ostatnie dane sa za stare.

Powiat 1261 jest tylko przykladem, nie oznacza Twojej lokalizacji.
Wynik `OK 0` jest waznym pozytywnym testem: nie myli pustej listy ostrzezen
z brakiem GPS/sieci. Po zakonczonym tescie wylacz diagnostyke i ustaw
odswiezanie co 30 lub 60 minut, aby zachowac opis pogody/odczuwalna i baterie.

Zabezpieczenia: kazdy wynik procesu w tle ma jawny kod statusu, starsze
niepelne dane sa odrzucane, a rysowanie ikon IMGW nie przerywa calej tarczy.

UWAGA: testy statyczne i przykladowe odpowiedzi IMGW NIE zastepuja testu
na zegarku. Duze ogolnopolskie odpowiedzi IMGW moga nadal przekroczyc limit
pamieci procesu w tle Garmin. Dlatego z powodow bezpieczenstwa nie traktuj
samej ikonki jako jedynego zrodla ostrzezen.


## Wersja 3.19.18
Nowe testy 4C i 4D: bezpośrednie GET do oficjalnego IMGW, bez pośrednictwa gałęzi imgw-feed i bez klasyfikowania ostrzeżeń. Szczegóły: README_DIAGNOSTYKA_V31918_PL.md.
