# Solar Rings 7X v3.21.9 — naprawa wyświetlania Testu 1

- Test 1 nie korzysta już z ogólnej ścieżki, która ukrywała rzeczywisty wynik pod `T1 GPS? RxxK`.
- Zamiast tego pokazuje `T1v19 ...`, gdzie v19 jednoznacznie identyfikuje kod tarczy.
- Przykłady: `T1v19 BRAK G3`, `T1v19 A3 2m`, `T1v19 P 1h`, `T1v19 K 3m`, `T1v19 O 1261`.
- Kod A3/A4 nie gwarantuje **nowego** fixa satelitarnego — oznacza źródło z Activity o określonej jakości i wiek zapisu w pamięci tarczy.
- Wersja NIE zmienia działającego pobierania ostrzeżeń i ikon IMGW ani produkcyjnego Testu 4.
- Test: włącz IMGW, wybierz 1 — Źródło lokalizacji, TERYT 0, bez podglądu ikony.

## Wgrywanie

Umieść `SolarRings7X_v3_21_9_SOURCE.zip` w głównym katalogu repozytorium GitHub, a `SolarRings7X_v3_21_9_BUILD.yml` w `.github/workflows/`, następnie uruchom nowy workflow. PRG ma nazwę `SolarRings7X_v3219.prg`.

**Uwaga:** Testy lokalne nie są kompilacją Connect IQ. Kompilację sprawdza Github Actions.
