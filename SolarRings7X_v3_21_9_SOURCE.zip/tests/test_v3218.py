from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
src=(root/'source/SolarRings7X.mc').read_text()
class CompilerRegressionV3218(unittest.TestCase):
    def test_quality_no_method_on_enum(self):
        self.assertNotIn('currentLocationAccuracy.toNumber()',src)
        self.assertIn('using Toybox.Position as Position;',src)
    def test_all_five_position_quality_constants(self):
        for k in ('QUALITY_NOT_AVAILABLE','QUALITY_LAST_KNOWN','QUALITY_POOR','QUALITY_USABLE','QUALITY_GOOD'):
            self.assertIn('Position.'+k,src)
    def test_production_view_and_gps(self):
        self.assertIn('diag = null;',src)
        self.assertIn('imgwLocationTestLine()',src)
    def test_manifest(self):
        a=ET.parse(root/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(a.attrib['version'],'3.21.9')
if __name__=='__main__': unittest.main()
