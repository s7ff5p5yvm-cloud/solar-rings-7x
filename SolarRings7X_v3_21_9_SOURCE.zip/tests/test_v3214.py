import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
p=Path(__file__).resolve().parents[1]
f=(p/'source/SolarRings7X.mc').read_text()
b=(p/'source/ImgwService.mc').read_text()
props=(p/'resources/settings/properties.xml').read_text()
settings=(p/'resources/settings/settings.xml').read_text()
strings=(p/'resources/strings.xml').read_text()
class TestV3214(unittest.TestCase):
 def test_preview_codes_and_levels(self):
  for n in range(14):
   self.assertIn(f'<listEntry value="{n}">@Strings.imgwPreview_{n}</listEntry>', settings)
   self.assertIn(f'id="imgwPreview_{n}"', strings)
  for n in (1,2,3): self.assertIn(f'imgwPreviewLevel_{n}',strings)
 def test_preview_no_gps(self):
  section=f.split('var previewKind = srSetting(',1)[1].split('var hasImgw',1)[0]
  self.assertIn('imgw = ["TEST", previewLevel, previewKind]',section)
  self.assertNotIn('captureImgwLocation(',section)
 def test_preview_label_always_visible(self):
  self.assertIn('diag = null;\n            lowerLabel = "TEST: " + previewImgwName(previewKind)',f)
 def test_real_manual_icon_without_gps(self):
  a=f.split('function activeImgwAlert(snapshot) {',1)[1].split('function imgwDiagnosticLine',1)[0]
  self.assertIn('var requirePosition = source == 0 || source == 3',a)
  self.assertIn('manual.format("%04d").equals(d[0])',a)
 def test_priority_manual_county(self):
  a=b.index('var manualTestCounty = Props.getValue(')
  self.assertLess(a,b.index('var loc = Storage.getValue("imgwLocV318")'))
  self.assertIn('beginUnifiedImgwRequest(11)',b[a:a+650])
 def test_weather_fallback_not_gps(self):
  self.assertIn('wx.observationLocationPosition',f)
  self.assertIn('wx.observationTime',f)
  self.assertIn('weatherAge < 0 || weatherAge > 7200',f)
  self.assertIn('saveImgwLocation(p[0].toFloat()',f)
  self.assertIn('if (source == 3) { imgwGpsReport(6); }',f)
  self.assertIn('(loc[3] == 3 || loc[3] == 4 || loc[3] == 5)',b)
 def test_no_silent_revalidation_of_gps(self):
  self.assertIn('imgwGpsReport(7);',f)
  self.assertIn('if (quality == 0 || quality == 1) {',f)
 def test_mark_approximation(self):
  self.assertIn('"PRZYBL"',f)
  # Source label now appears only on opt-in diagnostics, never replaces ODCZ.
 def test_fresh_alert_validation(self):
  self.assertIn('verifiedImgwResult(4, requirePosition, snapshot)',f)
  self.assertIn('var age = Time.now().value() - d[3]',f)
 def test_permissions(self):
  m=(p/'manifest.xml').read_text()
  self.assertIn('Positioning',m)
  self.assertIn('Communications',m)
  self.assertIn('version="3.21.9"',m)
 def test_full_xml(self):
  for file in (p/'resources').rglob('*.xml'):ET.parse(file)
 def test_garmin_callbacks_typed(self):
  sig='responseCode as Lang.Number, payload as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or PersistedContent.Iterator'
  for name in ('onUnifiedImgwResponse','onCountyResponse','onDirectImgwResponse'):
   self.assertIn('function '+name+'('+sig+')',b)
if __name__=='__main__':unittest.main()
