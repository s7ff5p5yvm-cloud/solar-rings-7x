from pathlib import Path
p=Path(__file__).resolve().parent
import xml.etree.ElementTree as ET
m=ET.parse(p/'manifest.xml').getroot()
app=m.find('{http://www.garmin.com/xml/connectiq}application')
assert app.attrib.get('version') == '3.21.9'
print('PASS version 3.21.9')
