# IMGW v3.19.16 — instrukcja diagnostyki

1. GitHub Actions: uruchom BUILD v3.19.16; sprawdź, czy refresh_feed oraz build są zielone.
2. Zainstaluj IQ i ustaw IMGW = ON; etap 4 = Pełny IMGW; diagnostyka = ON; 5 min.
3. Gdy brak cache: `T4 POW 1261` (przykład) oznacza wyłącznie potwierdzenie powiatu przez GUGiK.
4. Następny cykl: `T4 OK0 1261` (brak ostrzeżeń) lub `T4 ALERT 1261` (aktywny alert).
5. Błąd HTTP, zły format, przestarzały feed — nadal są pokazywane jako błędy, NIE jako brak ostrzeżeń.
6. Kod powiatu jest ustalany z ostatniej lokalizacji GPS zegarka; przykład 1261 nie jest kodem na sztywno.
7. Po zmianie lokalizacji lub wygaśnięciu cache po 4h GUGiK zostanie odpytywany ponownie.
8. Kiedy tarcza się wyłączy, przywróć test 4B i zgłoś ostatni widoczny komunikat.

Nie zmieniono pozostałych pól, ikon, ustawień i kompozycji tarczy.
