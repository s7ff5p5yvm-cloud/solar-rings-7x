"""v3.24.24 regression tests for layout, source priorities and lunar math.
Static tests are NOT a replacement for monkeyc or a real-watch trial.
"""
import datetime as dt
import math
import random
import re
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
ENGINE=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
MOON=(ROOT/'source/MoonCalendar.mc').read_text()
STORM=(ROOT/'source/StormGuard.mc').read_text()
FIELD=(ROOT/'source/FieldData.mc').read_text()
UTC=dt.timezone.utc

# Independent reference implementation of Meeus new/full moon series.
def event_epoch(k, full=True):
    T=k/1236.85
    T2=T*T; T3=T2*T; T4=T3*T
    mean=2451550.09766+29.530588861*k+0.00015437*T2-0.00000015*T3+0.00000000073*T4
    E=1-0.002516*T-0.0000074*T2
    M=2.5534+29.1053567*k-0.0000014*T2-0.00000011*T3
    Mp=201.5643+385.81693528*k+0.0107582*T2+0.00001238*T3-0.000000058*T4
    F=160.7108+390.67050284*k-0.0016118*T2-0.00000227*T3+0.000000011*T4
    Om=124.7746-1.56375588*k+0.0020672*T2+0.00000215*T3
    s=lambda x:math.sin(math.radians(x))
    c=(-.40614 if full else -.40720)*s(Mp)+(.17302 if full else .17241)*E*s(M)+(.01614 if full else .01608)*s(2*Mp)+(.01043 if full else .01039)*s(2*F)+(.00734 if full else .00739)*E*s(Mp-M)-(.00515 if full else .00514)*E*s(Mp+M)+(.00209 if full else .00208)*E*E*s(2*M)-.00111*s(Mp-2*F)-.00057*s(Mp+2*F)+.00056*E*s(2*Mp+M)-.00042*s(3*Mp)+.00042*E*s(M+2*F)+.00038*E*s(M-2*F)-.00024*E*s(2*Mp-M)-.00017*s(Om)-.00007*s(Mp+2*M)+.00004*s(2*Mp-2*F)+.00004*s(3*M)+.00003*s(Mp+M-2*F)+.00003*s(2*Mp+2*F)-.00003*s(Mp+M+2*F)+.00003*s(Mp-M+2*F)-.00002*s(Mp-M-2*F)-.00002*s(3*Mp+M)+.00002*s(4*Mp)
    c+=.000325*s(299.77+.107408*k-.009173*T2)+.000165*s(251.88+.016321*k)+.000164*s(251.83+26.651886*k)+.000126*s(349.42+36.412478*k)+.000110*s(84.66+18.206239*k)
    return (mean+c-2440587.5)*86400-75

# Compare original and one-pass StormGuard pressure/altitude logic on the
# same valid/invalid sample streams, including full 400-sample caps.
def old_pressure(samples, now, win, coverage, threshold):
    picked=[(stamp,p) for stamp,p in samples if stamp>=now-win]
    picked=[(stamp,p) for stamp,p in picked if p is not None][:400]
    if len(picked)<5:return False
    newest,pnew=picked[0]; oldest,pold=picked[-1]
    return now-newest<=900 and newest-oldest>=coverage and (pold-pnew)/100>=threshold

def new_pressures(samples, now, fast_drop, slow_drop):
    picked=[(stamp,p) for stamp,p in samples if stamp>=now-10800 and p is not None][:400]
    if not picked:return False,False
    newest,pnew=picked[0]
    short=[(stamp,p) for stamp,p in picked if stamp>=now-3600][:400]
    def good(group,coverage,threshold):
        if len(group)<5:return False
        oldest,pold=group[-1]
        return now-newest<=900 and newest-oldest>=coverage and (pold-pnew)/100>=threshold
    return good(short,3000,fast_drop),good(picked,9000,slow_drop)

class LunarAndAlerts32424(unittest.TestCase):
    def test_moon_full_dates_crosschecked_to_public_2026_calendar(self):
        # Timeanddate published UTC moments: Nov 24 14:53; Dec 24 01:28.
        for k,yy,mm,dd,hour,minute in [(332,2026,11,24,14,53),(333,2026,12,24,1,28)]:
            got=dt.datetime.fromtimestamp(event_epoch(k+.5),tz=UTC)
            expected=dt.datetime(yy,mm,dd,hour,minute,tzinfo=UTC)
            self.assertLess(abs((got-expected).total_seconds()),180)
        for fragment in ('2451550.09766d','29.530588861d',
                         '0.17302d','0.40614d','0.40614d',
                         'new Time.Moment(fullAt)','Gregorian.info',
                         'srMoonCalendarDay', '_srFullMoonDayCache = [localDay, result]'):
            self.assertIn(fragment,MOON)

    def test_day_counter_is_calendar_based_and_rolls_after_full_day(self):
        self.assertIn('if (days < 0)', MOON)
        self.assertIn('cycle + 1.5d, true', MOON)
        self.assertIn('days.toString() + "d"', MOON)
        self.assertIn('srMoonCalendarDay(fullDate) - localDay', MOON)
        # The cycle index must be an INTEGER, not a fractional lunar month.
        # Otherwise computed full moons drift with the current clock time.
        self.assertIn("Math.floor((seconds.toDouble() - 947168438d) / 2551443.0d).toNumber()", MOON)
        # Nov 23=1d, Nov 24=0d, Nov 25=29d until Dec 24.
        dates=[dt.date(2026,11,23),dt.date(2026,11,24),dt.date(2026,11,25)]
        results=[]
        fullA=dt.datetime.fromtimestamp(event_epoch(332.5),tz=UTC).date()
        fullB=dt.datetime.fromtimestamp(event_epoch(333.5),tz=UTC).date()
        for day in dates:
            results.append((fullA-day).days if day<=fullA else (fullB-day).days)
        self.assertEqual(results,[1,0,29])

    def test_moon_disk_stays_between_rules_and_no_pressure_in_lunar_panel(self):
        self.assertIn('drawLunarDisk(dc, 54, 147, 14)',FACE)
        self.assertEqual(147-14,133)
        self.assertEqual(147+14,161)
        moon=FACE.split('function drawMoonPanel(')[1].split('function topSlot(')[0]
        self.assertNotIn('_storm.warning()',moon)
        self.assertIn('dc.drawLine(127, 134, 127, 159)',moon)
        self.assertIn('weather.observationLocationName',moon)
        self.assertIn('drawSized(dc, location, 190, 135, 112, 24',moon)
        self.assertIn('drawSized(dc, moon[1], 99, 135, 42, 24',moon)
        m=re.search(r'var _srMoonExtents14 = \[([^\]]+)\];',FACE)
        self.assertIsNotNone(m)
        extents=[float(n) for n in m.group(1).split(',')]
        self.assertEqual(len(extents),29)
        for y,val in zip(range(-14,15),extents):
            self.assertAlmostEqual(val,math.sqrt(14*14-y*y),places=10)

    def test_first_pressure_then_weather_with_overflow_no_drop(self):
        alerts=FACE.split('function drawAlertCenter(')[1].split('// Battery footer')[0]
        self.assertLess(alerts.index('active.add(-1)'),alerts.index('active.add(warnings[i])'))
        self.assertIn('var centers = [45, 68, 91, 114]',alerts)
        self.assertIn('if (staticCount > 4) { staticCount = 3; }',alerts)
        self.assertIn('for (var k = 3; k < active.size(); k++)',alerts)
        self.assertIn('_alertOverflow.add(active[k])',alerts)
        self.assertIn('if (_alertOverflow == null || _alertOverflow.size() <= 1)',FACE)
        self.assertIn('dc.setClip(103, 217, 22, 26)',FACE)
        self.assertIn('(Time.now().value() / 5).toNumber()',FACE)
        self.assertIn('function allWarnings(current)',ENGINE)
        self.assertIn('warning(current);',ENGINE)
        self.assertIn('return _lastKinds;',ENGINE)
        # 4 slots have 20px glyphs and at least 3px between adjoining cells.
        centers=[45,68,91,114]
        for l,r in zip(centers,centers[1:]):
            self.assertGreaterEqual(r-l-18,4)
        self.assertGreaterEqual(133-(114+9),10)
        self.assertLess(45-9,133)

    def test_weather_bluetooth_temperature_and_old_features_still_current(self):
        for frag in ('drawWeatherAge(dc, w)', 'drawPhoneBluetooth(dc)',
                     'var remainingSteps = monitor.stepGoal - doneSteps;',
                     'srSystemStatsForFrame().charging',
                     'weather.feelsLikeTemperature',
                     'drawAlertCenter(dc, w)',
                     'drawWeatherTemperature(dc, shownTemp, 148, 227)',
                     'Weather.getCurrentConditions()'):
            self.assertIn(frag,FACE)
        self.assertIn('srSetting("stormOnV3", false)',STORM)
        self.assertIn('now - _lastCheck < 300',STORM)
        self.assertIn('new Time.Duration(10800)',STORM)
        self.assertIn('new Time.Duration(3600)', STORM.replace('stableElevation(3600','new Time.Duration(3600)') )
        self.assertIn('new Time.Duration(10800)',STORM)
        self.assertIn('var minAlt = 100000.0;',STORM)
        self.assertIn('var maxAlt = -100000.0;',STORM)
        self.assertNotIn('Comm.makeWebRequest(',FACE+FIELD+MOON+ENGINE)

    def test_one_pass_pressure_matches_old_two_window_algorithm(self):
        rng=random.Random(32424)
        now=1800000000
        for _ in range(400):
            n=rng.randrange(0,950)
            times=sorted((now-rng.randrange(0,11000) for _ in range(n)),reverse=True)
            pressure0=101300+rng.uniform(-200,200)
            slope=rng.uniform(-15,15)
            data=[(stamp, None if rng.random()<.08 else pressure0+(now-stamp)*slope/10800) for stamp in times]
            fast=rng.uniform(1,6);slow=rng.uniform(2,10)
            old=(old_pressure(data,now,3600,3000,fast),
                 old_pressure(data,now,10800,9000,slow))
            new=new_pressures(data,now,fast,slow)
            self.assertEqual(old,new)

if __name__=='__main__':unittest.main()
