"""Source-contract checks for geocode guard (not Monkey C execution).

Also exercise a separate reference specification of the intended cooldown rules.
Only Garmin SDK/on-watch tests can confirm those rules in the compiled runtime.
"""
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
GEO=(ROOT/'source/WeatherGeocode.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()

class GeoBatteryGuardContract(unittest.TestCase):
    def test_single_pending_timer_for_cross_country_travel(self):
        self.assertIn('App.Storage.setValue("srGRequest", [lat, lon]);', FACE)
        self.assertIn('if (due != null && due > 0 && now < due + 15 * 60)', FACE)
        self.assertIn('Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(delay)))', FACE)
        self.assertIn('saveNumber("srGEventDue", now + delay);', GEO)
        self.assertIn('var request = null;', GEO)
        self.assertIn('request = App.Storage.getValue("srGRequest")', GEO)

    def test_network_limit_shared_across_locations(self):
        self.assertIn('var fromLastRequest = storedNumber("srGLastTry", 0) + 30 * 60;', GEO)
        self.assertIn('if (fromLastRequest > next) { next = fromLastRequest; }', GEO)
        self.assertIn('if (now < next)', GEO)
        self.assertIn('saveNumber("srGLastTry", now);', GEO)
        self.assertIn('last + 30 * 60 - now', FACE)
        self.assertNotIn('srGFail", 0);', FACE)

    def test_exponential_backoff_with_cap(self):
        self.assertIn('var failures = storedNumber("srGFail", 0) + 1;', GEO)
        self.assertIn('if (failures > 4) { failures = 4; }', GEO)
        for line in ('var hours = 3;', 'if (failures == 2) { hours = 6; }',
                     'else if (failures == 3) { hours = 12; }',
                     'else if (failures >= 4) { hours = 24; }',
                     'saveNumber("srGNextAt", next);'):
            self.assertIn(line, GEO)
        self.assertIn('retryLater();', GEO)
        self.assertIn('saveNumber("srGFail", 0);', GEO)

    def test_missing_callbacks_have_watchdog_and_backoff(self):
        self.assertIn('saveNumber("srGInFlight", 1);', GEO)
        self.assertIn('if (storedNumber("srGInFlight", 0) == 1)', GEO)
        self.assertIn('armTimer(now + 3 * 60 * 60);', GEO)
        self.assertIn('saveNumber("srGInFlight", 0);', GEO)

    def test_stale_results_not_displayed(self):
        self.assertIn('!sameRegion(_requestedLat, _requestedLon, latest[0], latest[1])', GEO)
        self.assertIn('armTimer(now + 30 * 60);', GEO)
        self.assertIn('var requested = App.Storage.getValue("srGRequest");', FACE)
        self.assertIn('Ui.requestUpdate();', FACE)

    def test_no_foreground_http_gps_or_extra_weather_downloads(self):
        self.assertNotIn('makeWebRequest(', FACE)
        self.assertNotIn('Position.getInfo()', FACE)
        self.assertNotIn('enableLocationEvents(', FACE)
        self.assertEqual(FACE.count('Weather.getCurrentConditions()'),1)
        partial=FACE.split('function onPartialUpdate(dc)')[1].split('function onUpdate(dc)')[0]
        self.assertNotIn('registerForTemporalEvent',partial)
        self.assertNotIn('App.Storage',partial)

    def test_thermometer_and_stormguard_not_regressed(self):
        self.assertIn('if (isTemp) { temperatureMarker(dc, weather, 142, 224); }', FACE)
        center=FACE.split('function drawAlertCenter(')[1].split('function drawBattery(')[0]
        self.assertIn('if (_storm.warning()) { active.add(-1); }', center)
        self.assertLess(center.index('active.add(-1)'),center.index('active.add(warnings[i])'))
        self.assertNotIn('temperatureMarker(',center)
        self.assertIn('drawLunarDisk(dc, 54, 147, 14)', FACE)

class GeoPolicyReference(unittest.TestCase):
    @staticmethod
    def retry_hours(count):
        failures=min(4,count+1)
        return failures, (3,6,12,24)[failures-1]

    def test_failure_intervals_cap_at_24_hours(self):
        count=0
        intervals=[]
        for _ in range(12):
            count,h=self.retry_hours(count)
            intervals.append(h)
        self.assertEqual(intervals,[3,6,12,24]+[24]*8)

    def test_changing_city_cannot_bypass_network_limit(self):
        last_network_attempt=1000000
        now=last_network_attempt+11*60
        destination_changes=55
        next_allowed=max(now+5*60,last_network_attempt+30*60)
        self.assertEqual(next_allowed,last_network_attempt+30*60)
        for _ in range(destination_changes):
            self.assertLess(now,next_allowed)

    def test_failure_cooldown_priority_over_network_window(self):
        now=500000
        last_try=now-40*60
        error_cooldown_ends=now+12*3600
        eligible=max(now+5*60,last_try+30*60,error_cooldown_ends)
        self.assertEqual(eligible,error_cooldown_ends)

if __name__=='__main__':unittest.main()
