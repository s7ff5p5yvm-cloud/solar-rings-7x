from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()

class BluetoothIcon32418(unittest.TestCase):
    def test_connectivity_uses_supported_phone_state(self):
        self.assertIn('System.getDeviceSettings().phoneConnected', FACE)
        self.assertIn('var btColor = connected ? 0x00DD77 : 0xFF5555;', FACE)
        self.assertIn('if (!connected) {', FACE)
    def test_bluetooth_rune_and_crossed_disconnected_state(self):
        for line in [
            'dc.drawLine(234, 108, 234, 124);',
            'dc.drawLine(234, 108, 239, 112);',
            'dc.drawLine(239, 112, 229, 120);',
            'dc.drawLine(229, 112, 239, 120);',
            'dc.drawLine(239, 120, 234, 124);',
            'dc.drawLine(229, 124, 239, 108);',
        ]:
            self.assertIn(line, FACE)
        self.assertNotIn('dc.drawCircle(234, 116, 5);', FACE)
    def test_weather_freshness_is_separate(self):
        self.assertIn('current.observationTime.value()', FACE)
        self.assertIn('drawPhoneBluetooth(dc);', FACE)
        self.assertIn('drawSized(dc, ageLabel, 260, 104, 36, 24, ageColor, false, 16, 0);', FACE)
        self.assertIn('remainingMinutes.toString() + "m";', FACE)
    def test_existing_fields_and_steps_unchanged(self):
        self.assertIn('var remainingSteps = monitor.stepGoal - doneSteps;', FACE)
        self.assertIn('drawSized(dc, dateLabel, 197, 104, 58, 25', FACE)
        self.assertIn('drawSized(dc, dayLabel, 197, 80, 58, 23', FACE)
        self.assertIn('drawClock(dc, clock);', FACE)
    def test_current_version(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'], '3.24.29')
        self.assertIn("== '3.24.29'", (ROOT/'check_version.py').read_text())
if __name__=='__main__': unittest.main()
