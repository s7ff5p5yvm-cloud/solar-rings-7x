import re, unittest, xml.etree.ElementTree as ET
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=(P/'source/SolarRings7X.mc').read_text()
B=(P/'source/SolarRingsGarminService.mc').read_text()
C=(P/'source/SolarWeatherCodes.mc').read_text()

OFFICIAL=['CLEAR', 'PARTLY_CLOUDY', 'MOSTLY_CLOUDY', 'RAIN', 'SNOW', 'WINDY', 'THUNDERSTORMS', 'WINTRY_MIX', 'FOG', 'HAZY', 'HAIL', 'SCATTERED_SHOWERS', 'SCATTERED_THUNDERSTORMS', 'UNKNOWN_PRECIPITATION', 'LIGHT_RAIN', 'HEAVY_RAIN', 'LIGHT_SNOW', 'HEAVY_SNOW', 'LIGHT_RAIN_SNOW', 'HEAVY_RAIN_SNOW', 'CLOUDY', 'RAIN_SNOW', 'PARTLY_CLEAR', 'MOSTLY_CLEAR', 'LIGHT_SHOWERS', 'SHOWERS', 'HEAVY_SHOWERS', 'CHANCE_OF_SHOWERS', 'CHANCE_OF_THUNDERSTORMS', 'MIST', 'DUST', 'DRIZZLE', 'TORNADO', 'SMOKE', 'ICE', 'SAND', 'SQUALL', 'SANDSTORM', 'VOLCANIC_ASH', 'HAZE', 'FAIR', 'HURRICANE', 'TROPICAL_STORM', 'CHANCE_OF_SNOW', 'CHANCE_OF_RAIN_SNOW', 'CLOUDY_CHANCE_OF_RAIN', 'CLOUDY_CHANCE_OF_SNOW', 'CLOUDY_CHANCE_OF_RAIN_SNOW', 'FLURRIES', 'FREEZING_RAIN', 'SLEET', 'ICE_SNOW', 'THIN_CLOUDS', 'UNKNOWN']
class WeatherIconOnly(unittest.TestCase):
    def test_all_garmin_codes_mapped(self):
        found=set(re.findall(r'Weather.CONDITION_([A-Z_]+)',C))
        self.assertEqual(found,set(OFFICIAL))
        self.assertEqual(len(found),54)
    def test_current_weather_icon_only(self):
        self.assertIn('drawCurrentWeatherIcon(dc, w)',S)
        self.assertIn('srGarminDisplayGroup(weather.condition)',S)
        self.assertIn('Weather.getCurrentConditions()',S)
        for k in ('GarminWeatherWarnings','drawAlertCenter(','drawGarminWarningIcon(', 'onPartialUpdate(', 'drawHourlyDiagnostics(', 'Weather.getHourlyForecast(', 'readGarminForecast('):
            self.assertNotIn(k,S+B, k)
        self.assertFalse((P/'source/GarminWeatherWarnings.mc').exists())
    def test_large_distinct_icons_and_no_extra_polling(self):
        self.assertIn('var x = 80;', S)
        self.assertIn('var y = 232;', S)
        for fn in ('currentWeatherSun','currentWeatherCloud','currentWeatherRain',
                   'currentWeatherSnow','currentWeatherIce','currentWeatherFog',
                   'currentWeatherWind','currentWeatherDust','currentWeatherStorm',
                   'currentWeatherExtreme'):
            self.assertIn('function '+fn+'(', S)
        for group in range(14):
            self.assertIn('group == '+str(group), S)
        self.assertIn('code == Weather.CONDITION_FREEZING_RAIN) { return 13;', C)
        self.assertIn('code == Weather.CONDITION_ICE) { return 11;', C)
        body = S.split('function drawCurrentWeatherIcon(dc, weather) {',1)[1].split('    // Battery footer occupies',1)[0]
        for x in ('registerForTemporalEvent','makeWebRequest','getHourlyForecast',
                  'new Time.Duration','Storage.setValue'):
            self.assertNotIn(x, body)
        self.assertIn('currentWeatherCloud(dc, x, 230', body)
        self.assertIn('currentWeatherSun(dc, x, y, false)', body)
    def test_no_recurring_background(self):
        self.assertNotRegex(S+B,r'registerForTemporalEvent\(new Time.Duration\(300\)\)')
        self.assertIn('Bg.registerForTemporalEvent(now.add(new Time.Duration(',B)
        self.assertIn('Bg.deleteTemporalEvent()',B)
        self.assertIn('Bg.getLastTemporalEventTime()',B)
        self.assertIn('Bg.exit(2)',B)
        self.assertNotIn('srGarminForecastV32659',S+B)
    def test_photon_preserved(self):
        for x in ('https://photon.komoot.io/reverse','srPhotonSameRegion','srPhotonTargetV32664','srPhotonResultV32664','srPhotonScheduleIfNeeded'):
            self.assertIn(x,S+B)
        self.assertNotRegex(B,r'"(?:lang|language)"\s*=>')
        self.assertIn('"osm_tag"',B)
    def test_all_xml_and_property_ids(self):
        for f in P.rglob('*.xml'):ET.parse(f)
        settings=ET.parse(P/'resources/settings/settings.xml').getroot()
        props=ET.parse(P/'resources/settings/properties.xml').getroot()
        ids=[x.attrib['id'] for x in props]
        self.assertEqual(len(ids),len(set(ids)))
        for n in settings:
            self.assertIn(n.attrib['propertyKey'].split('.')[-1],ids)
        for id in ids:
            self.assertFalse(id.startswith('gw') and id!='gwPreviewV332')
            self.assertNotIn(id,['gwWindThresholdV332','gwIceTempV332'])
        self.assertIn('id="Positioning"',(P/'manifest.xml').read_text())
        self.assertIn('id="Communications"',(P/'manifest.xml').read_text())
    def test_settings_strings_all_defined(self):
        res=(P/'resources/settings/settings.xml').read_text()
        ids={x.attrib['id'] for x in ET.parse(P/'resources/strings.xml').getroot()}
        for ref in re.findall(r'@Strings\.([\w_]+)',res):self.assertIn(ref,ids)
    def test_version(self):self.assertIn('version="3.26.84"',(P/'manifest.xml').read_text())
    def test_no_garmin_forecast_in_any_module(self):
        for f in (P/'source').glob('*.mc'):
            self.assertNotIn('Weather.getHourlyForecast(',f.read_text())
    def test_keep_core_fields(self):
        for name in ('drawWeatherAge','drawWeatherTemperature','drawBattery','drawMoonPanel','drawClock','drawDate','updatePhotonTarget','drawCurrentWeatherIcon','nextSunEvent'):
            self.assertIn(name,S+(P/'source/FieldData.mc').read_text())
    def test_diagnostic_only_21_22(self):
        settings=ET.parse(P/'resources/settings/settings.xml').getroot()
        diag=next(n for n in settings if n.attrib.get('propertyKey')=='@Properties.gwPreviewV332')
        vals={e.attrib.get('value') for e in diag.iter('listEntry')}
        self.assertEqual(vals, {'0','21','22'})
if __name__=='__main__':unittest.main()
