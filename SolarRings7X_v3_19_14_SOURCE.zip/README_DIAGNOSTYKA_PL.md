# Solar Rings 7X v3.19.13 — naprawa błędu porównywania tekstu w Monkey C

Na zegarku pojawiał się `T3 H30` (0x30 = ASCII `0`).
Przyczyną błędnego odrzucenia prawidłowego statusu była linia
`if (status != "0")`, ponieważ operatory `==`/`!=` w Monkey C porównują
referencje do obiektów String, nie zawartość. Teraz stosujemy
`if (!status.equals("0"))`. Zachowana jest walidacja czterocyfrowego kodu powiatu.

Po instalacji: IMGW włączone, diagnostyka włączona, Test 3 – GUGiK,
odświeżanie co 5 minut. Prawidłowy wynik: `T3 #### OK`.
Dopiero potem Test 4 — pobieranie rzeczywistych ostrzeżeń IMGW.

Pozostałe funkcje bez celowych zmian. Testy lokalne nie zastępują
kompilacji Garmin SDK ani sprawdzenia na fizycznym zegarku.

---

# Solar Rings 7X v3.19.12 – precyzyjny test GUGiK

T3 F5-0 występował nadal na prawdziwym zegarku mimo normalizacji znaków w wersji 3.19.11.
Oznacza to, że sam fragment drukowalny pierwszego wiersza nie wystarcza do diagnozy.

W tej wersji gdy pierwszy wiersz odpowiedzi GUGiK jest niezgodny z oczekiwanym statusem `0`,
wyświetlamy jego rzeczywiste znaki jako kody szesnastkowe, np. `T3 H30.B`.
`30` to znak `0`; `B` to niedrukowalny znak U+000B. Zapisujemy najwyżej trzy
pierwsze znaki pierwszego wiersza, bez pozycji GPS.

Wynik `T3 #### OK` w dalszym ciągu pojawi się WYŁĄCZNIE po prawidłowym statusie
oraz czterocyfrowym kodzie powiatu. Nie używać testu 4 przed takim wynikiem.

Ustaw IMGW: Test 3, aktualizacja co 5 minut. Odczytaj `T3 H...` z zegarka.

Testy źródłowe są statyczne. Budowanie przez Garmin Connect IQ SDK
oraz działanie na zegarku pozostają do zweryfikowania na GitHubie / Garminie.
# Diagnostyka GUGiK — v3.19.11

**Problem z poprzedniej wersji:** na zegarku przy T3 pojawia się `T3 F5-0`.
W aktualnym parserze taki kod oznacza, że serwer zwrócił pierwszy wiersz
zawierający znak `0`, ale pierwszy wiersz *nie jest dokładnie równy* `0`
po usunięciu zwykłych spacji, tabulatorów i CR. **To nie potwierdza,
że przyczyną jest BOM**, ale wskazuje miejsce błędu.

**Zmiana:** sprawdzanie pierwszego wiersza znak po znaku (`toCharArray`)
i pomijanie wyłącznie znanych niewidocznych znaków formatowania (BOM U+FEFF,
NBSP U+00A0, ZWSP U+200B, WORD JOINER U+2060) oraz ASCII spacji/CR/tab.
Kod statusu nadal musi być *dokładnie* równy `0` po normalizacji.
Kod powiatu nadal musi zawierać dokładnie cztery cyfry i nie może zawierać
piątej cyfry. Dodano symulowane przypadki, w których parser ma odrzucić
status 1, -1, 00, 0error i 0;invalid. Nie zmieniono samego adresu
zapytania do GUGiK ani API IMGW.

**Test:** włącz IMGW, diagnostykę, etap 3 (GUGiK) i odświeżanie co 5 min.
Sukces = `T3 #### OK` (czterocyfrowy kod TERYT powiatu).
Jeżeli nadal wystąpi `F5-0`, potrzebny będzie dokładniejszy podgląd
surowej odpowiedzi GUGiK; nie uznawaj tego za poprawne dane.
Nie przechodź do etapu 4, dopóki etap 3 nie zwróci prawidłowego kodu.

UWAGA: testy Pythona odwzorowują logikę parsera, ale nie są testami
rzeczywistego wykonania Monkey C na fizycznym zegarku.

## Naprawa testu GitHub Actions (v3.19.11)

W workflow v3.19.9 krok "Live upstream IMGW + county geocoding check" zwracał błąd
`UnicodeDecodeError: invalid start byte 0x8b` przy próbie odczytu IMGW.
To typowy objaw nierozpakowanej odpowiedzi gzip (podpis `1f 8b`).
Teraz skrypt: żąda nieskompresowanej odpowiedzi, ale też rozpakowuje gzip
rozpoznany po nagłówku lub sygnaturze i *dopiero potem* parsuje JSON.
Dodano test offline `check_live_transport.py` na kompresję i błędne dane.

Ta zmiana naprawia test sieciowy w GitHub Actions. Kod pobierania IMGW i GUGiK
na zegarku jest pozostawiony bez zmian; `T3 F5-X` nadal wymaga osobnej
weryfikacji na urządzeniu. W `manifest.xml` poprawiono wersję aplikacji z
3.19.8 (przeoczenie w v3.19.9) na 3.19.10.

# Solar Rings 7X v3.19.11 — test odpowiedzi GUGiK

Poprzedni wynik na zegarku: **T3 F5** (odpowiedź HTTP 200, ale pierwszy wiersz ULDK nie miał statusu powodzenia `0`).

W tej wersji:
- zapytanie GetCountyByXY ma jawny adres URL zgodny z dokumentacją ULDK;
- parser toleruje spacje/CR wokół statusu, ale nigdy nie uznaje błędnego statusu za sukces;
- jeśli pierwszy wiersz jest niepoprawny, tarcza pokaże krótki fragment tego wiersza (`T3 F5-1`, `T3 F5--1`, `T3 F5-html` itp.);
- nie zmieniono pobierania GPS ani interwału IMGW.

## Test na zegarku
1. Zainstaluj nową wersję.
2. IMGW włączone, diagnostyka włączona, **Test 3 – GUGiK**, odświeżanie co 5 minut.
3. Poczekaj na wynik i odczytaj dokładny napis.
4. `T3 #### OK`: GUGiK poprawnie ustalił 4-cyfrowy kod powiatu. Dopiero wtedy test 4.
5. `T3 F5-X`: serwer zwraca status inny niż `0`. Przepisz X. Nie interpretuj tego jako braku ostrzeżeń.

`T3 F5-X` to kod diagnostyczny, nie kod powiatu. Kompilacja Garmin SDK i działanie na zegarku muszą zostać potwierdzone osobno.
# Solar Rings 7X v3.19.14 — IMGW bez ogólnopolskiego JSON na zegarku

## Dlaczego poprzednia tarcza się wyłączała?

Test 3 (ULDK/GUGiK) przeszedł (`T3 1261 OK`). Test 4 uruchamiał pobieranie ogólnopolskiej odpowiedzi IMGW, mimo że serwis Garmina ma tylko ok. 32 KB pamięci. Rozmiar i dekodowanie całego JSON mogły wywołać awarię; bez logu urządzenia nie można uznać tego za przyczynę potwierdzoną.

## Co się zmieniło

- GPS i ustalanie powiatu GUGiK pozostawiono bez zmian.
- Workflow GitHub Actions pobiera ogólnopolskie ostrzeżenia z oficjalnego serwera IMGW, sprawdza ich strukturę i tworzy **16 małych plików JSON** — po jednym na województwo.
- Dane są zapisywane do osobnej gałęzi `imgw-feed` publicznego repozytorium na GitHubie. W pliku są wyłącznie aktywne ostrzeżenia, 4-cyfrowy powiat TERYT, stopień i kod zjawiska. Brak wskazanego powiatu w **prawidłowym, świeżym pliku** oznacza brak aktywnego ostrzeżenia.
- Garmin pobiera tylko jeden mały plik dla 2-cyfrowego prefiksu województwa; **nie pobiera już ogólnopolskiego JSON**.
- Zabezpieczenia: wymagany ważny czas aktualizacji, walidacja pól, błąd zamiast fałszywego „brak ostrzeżeń” przy przeterminowanym / uszkodzonym pliku.

## Wymagania

1. **Repozytorium GitHub musi być publiczne**, aby zegarek mógł pobrać plik `raw.githubusercontent.com` bez hasła. Jeśli repo jest prywatne, test 4 będzie zgłaszał błąd HTTP (najczęściej 404) — nie będzie fałszywego OK.
2. W repozytorium: Settings → Actions → General → Workflow permissions → **Read and write permissions** (o ile polityka konta pozwala). Workflow potrzebuje uprawnienia do utworzenia i aktualizowania gałęzi `imgw-feed`.
3. Plik `SolarRings7X_v3_19_14_SOURCE.zip` w katalogu głównym gałęzi domyślnej; `SolarRings7X_v3_19_14_BUILD.yml` w `.github/workflows/`.
4. W Actions ręcznie uruchom „Build Solar Rings 7X v3.19.14 (IMGW compact feed)”. Pierwszy job powinien pokazać `PASS IMGW compact feeds ...` i utworzyć gałąź `imgw-feed`, drugi skompilować tarczę.
5. Sprawdź w repozytorium gałąź `imgw-feed` i plik `feed/12.json` dla Małopolski. Wewnątrz powinien być mały obiekt z `"v":1`, `"ts":...`, `"a":...`.
6. Zainstaluj wygenerowany plik .IQ w Connect IQ, włącz IMGW, diagnostykę, test 4 i na potrzeby testu odświeżanie co 5 minut. **Prawdziwe dane na serwerze są odświeżane co ok. 30 minut**, nawet jeżeli zegarek pyta częściej.

## Interpretacja

- `T4 OK0 1261` — **pozytywne potwierdzenie**: świeży, poprawny plik IMGW, dla Krakowa brak aktualnych ostrzeżeń.
- `T4 ALERT 1261` — świeży plik z aktywnym ostrzeżeniem przypisanym do Krakowa (kolor ikony zależy od stopnia).
- `T4 HTTP404` — najczęściej prywatne repo, brak gałęzi `imgw-feed` lub brak pliku; sprawdź publikację.
- `T4 STARE` — plik ma starszą datę niż 2 godziny albo nieprawidłową datę; nie pokazuje fałszywego „OK 0”.
- `T4 FORMAT` — plik JSON ma zły format; nie jest traktowany jako brak ostrzeżeń.

## Ważne ograniczenia

- Testy lokalne obejmują parser danych i walidację pliku; nie oznaczają przebudowania w Garmin SDK ani gwarancji działania na fizycznym urządzeniu. Obie te rzeczy weryfikujesz w GitHub Actions / na zegarku.
- GitHub może opóźnić harmonogram lub wyłączyć planowane zadania w nieaktywnych repozytoriach; zegarek w takim przypadku zgłosi przeterminowanie, a nie brak ostrzeżeń.
- Aktualna lokalizacja GPS trafia wyłącznie do GUGiK w celu ustalenia powiatu. Zegarek pobiera plik z GitHub na poziomie województwa (GitHub zna wtedy adres IP i dwucyfrowy prefiks województwa).
- Jeśli repozytorium ma pozostać prywatne, zamiast raw.githubusercontent.com trzeba uruchomić publiczną usługę publikującą te małe pliki.
