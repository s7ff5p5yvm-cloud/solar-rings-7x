#!/usr/bin/env python3
"""Solar Rings 7X v3.21.2 offline regression suite.

Static/code-flow checks on Monkey C plus Python reference-model tests. They
cannot prove a Garmin device runtime or memory budget is stable.
"""
import unittest
from pathlib import Path
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
import re

ROOT = Path(__file__).resolve().parents[1]
SVC = (ROOT/'source/ImgwService.mc').read_text(encoding='utf-8')
FACE = (ROOT/'source/SolarRings7X.mc').read_text(encoding='utf-8')
SETTINGS = ET.parse(ROOT/'resources/settings/settings.xml').getroot()
PROPS = ET.parse(ROOT/'resources/settings/properties.xml').getroot()
STRINGS = ET.parse(ROOT/'resources/strings.xml').getroot()
MANIFEST = ET.parse(ROOT/'manifest.xml').getroot()

# Small, independent reference implementation of the expected API behavior.
# This is not the Monkey C runtime; used to detect accidental semantic changes.
KIND = {
    'burza':1,'silny wiatr':2,'intensywny deszcz':3,
    'intensywne opady sniegu':4,'oblodzenie':5,
    'opady marznace':6,'upal':7,'mroz':8,
    'przymrozki':9,'gęsta mgła':10, 'zawieje i zamiecie':11,
    'roztopy':12,
}

def classify(name):
    v=name.lower()
    if 'burz' in v: return 1
    if 'zawiej' in v or 'zamie' in v: return 11
    if 'wiatr' in v or 'sztorm' in v: return 2
    if 'marzn' in v or 'gołoled' in v or 'gololed' in v: return 6
    if 'oblodz' in v: return 5
    if 'śnieg' in v or 'snieg' in v or 'śnież' in v: return 4
    if 'deszcz' in v or 'opad' in v: return 3
    if 'przymroz' in v: return 9
    if 'roztop' in v: return 12
    if 'upa' in v: return 7
    if 'mróz' in v or 'mroz' in v: return 8
    if 'mgł' in v or 'mgl' in v: return 10
    return 13

def warning(teryt='1261', name='Oblodzenie', severity='2',
            since='2026-11-13 10:00:00', until='2026-11-14 10:00:00'):
    return {'teryt':[teryt], 'nazwa_zdarzenia':name, 'stopien':severity,
            'obowiazuje_od': since,'obowiazuje_do':until}

def analyze(records, county='1261', now='2026-11-13 20:00:00'):
    if not (len(county)==4 and county.isdigit()): raise ValueError('county')
    if not isinstance(records,list) or len(records)>200: raise ValueError('root')
    best=(0,0)
    for rec in records:
        if not isinstance(rec,dict): raise ValueError('record')
        ids=rec.get('teryt'); since=rec.get('obowiazuje_od'); until=rec.get('obowiazuje_do')
        name=rec.get('nazwa_zdarzenia'); severity=rec.get('stopien')
        if not isinstance(ids,list) or len(ids)>500 or not all(isinstance(i,str) and len(i)==4 for i in ids): raise ValueError('teryt')
        if any(not isinstance(x,str) for x in [since,until,name,severity]): raise ValueError('types')
        if len(since)<19 or len(until)<19: raise ValueError('dates')
        try: level=int(severity)
        except ValueError: raise ValueError('severity')
        if level<1 or level>3: raise ValueError('severity')
        if county in ids and since[:19] <= now <= until[:19]:
            kind=classify(name)
            if level>best[0] or (level==best[0] and kind<best[1]): best=(level,kind)
    return best

class TestSource(unittest.TestCase):
    def test_01_version(self):
        app=MANIFEST.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.21.2')
    def test_02_devices(self):
        x=(ROOT/'manifest.xml').read_text()
        self.assertIn('fenix7xpro',x)
    def test_03_background_annotation(self):
        self.assertIn('(:background)\nclass ImgwServiceV318',SVC)
    def test_04_stage_alias(self):
        self.assertIn('_stage = stage == 4 ? 11 : stage;',SVC)
    def test_05_same_full_parser(self):
        self.assertIn('beginUnifiedImgwRequest(_stage);',SVC)
        self.assertIn('processOfficialWarnings(payload);',SVC)
    def test_06_sequential_requests(self):
        c=SVC.split('function onCountyResponse(',1)[1]
        self.assertIn('beginUnifiedImgwRequest(_stage)',c)
        self.assertNotIn('smallFeedUrl(',SVC)
        self.assertEqual(SVC.count('https://danepubliczne.imgw.pl/api/data/warningsmeteo'),2)
    def test_07_no_github_relay(self):
        self.assertNotIn('raw.githubusercontent.com',SVC)
        self.assertNotIn('imgwCountyCacheV31916',SVC)
    def test_08_payload_must_be_array(self):
        self.assertIn('if (!(payload instanceof Lang.Array))',SVC)
        self.assertIn('function onUnifiedImgwResponse(responseCode as Lang.Number, payload as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or PersistedContent.Iterator) as Void',SVC)
    def test_09_typed_callbacks_match_sdk(self):
        required = 'responseCode as Lang.Number, payload as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or PersistedContent.Iterator'
        for name in ('onCountyResponse','onUnifiedImgwResponse','onDirectImgwResponse'):
            self.assertIn('function '+name+'('+required+') as Void', SVC)
        self.assertIn('using Toybox.PersistedContent as PersistedContent;', SVC)
        self.assertNotIn('function onUnifiedImgwResponse(responseCode, payload)', SVC)

    def test_10_bounded_response_processing(self):
        self.assertIn('payload.size() > 200',SVC)
        self.assertIn('ids.size() > 500',SVC)
    def test_11_no_false_success_on_schema_error(self):
        self.assertIn('if (!(record instanceof Lang.Dictionary)) { stop(9); return; }',SVC)
        self.assertIn('if (lvl == null || lvl < 1 || lvl > 3) { stop(9); return; }',SVC)
    def test_12_implicit_zero_only_after_complete_scan(self):
        a=SVC.index('function processOfficialWarnings(')
        b=SVC.index('function onTemporalEvent(',a)
        p=SVC[a:b]
        self.assertLess(p.index('for (var j = 0; j < count; j++)'),p.index('var code = bestLevel > 0 ? 1 : 2;'))
    def test_13_foreground_one_result_read_per_weather_draw(self):
        a=FACE.index('function drawWeather('); b=FACE.index('function onUpdate(',a)
        self.assertEqual(FACE[a:b].count('Storage.getValue("imgwResultV318")'),1)
    def test_14_no_result_read_inside_diagnostic(self):
        a=FACE.index('function imgwDiagnosticLine('); b=FACE.index('function drawWeather(',a)
        self.assertNotIn('Storage.getValue("imgwResultV318")',FACE[a:b])
    def test_15_no_result_read_inside_validator(self):
        a=FACE.index('function verifiedImgwResult('); b=FACE.index('function activeImgwAlert(',a)
        self.assertNotIn('Storage.getValue("imgwResultV318")',FACE[a:b])
    def test_16_background_result_has_8_slots(self):
        self.assertIn('code, _stage]);',SVC)
        self.assertIn('data.size() >= 8',FACE)
    def test_17_production_requires_location(self):
        self.assertIn('imgwValidationProblem(stage, true, snapshot)',FACE)
        self.assertIn('observedAge > 21600',FACE)
        self.assertIn('Math.abs(d[4] - loc[0]) > 0.002',FACE)
    def test_18_foreground_icons_opt_in(self):
        self.assertIn('!srSetting("imgwIconsV3203", false)',FACE)
        self.assertIn('srSetting("imgwDiagnosticsV3193", false)',FACE)
    def test_19_weather_renderer_guard(self):
        self.assertIn('try {\n            drawWeather(dc, monitor, w);',FACE)
        self.assertIn('IMGW UI ERR',FACE)
    def test_20_no_github_stages_in_settings(self):
        x=(ROOT/'resources/settings/settings.xml').read_text()
        self.assertNotIn('<listEntry value="5">@Strings.imgwStage_5</listEntry>',x)
        self.assertNotIn('<listEntry value="6">@Strings.imgwStage_6</listEntry>',x)
    def test_21_original_settings_still_present(self):
        ids={i.attrib['id'] for i in PROPS}
        for k in ['slotTop1V3','slotRing1V3','moonPanelV38','showFeelsLikeV319',
                  'imgwOnV317','imgwTestStageV3194','imgwIconsV3203','imgwDiagnosticsV3193']:
            self.assertIn(k,ids)
    def test_22_consistent_monitor_fields(self):
        self.assertIn('drawBattery(dc, monitor, w)',FACE)
        self.assertIn('drawMoonPanel(dc)',FACE)
    def test_23_unseen_warning_not_false_all_clear(self):
        self.assertIn('d[6] != 1 && d[6] != 2', FACE)
    def test_24_gugik_text_equals(self):
        self.assertIn('status.equals("0")',SVC)
    def test_25_no_cached_county_in_foreground(self):
        self.assertNotIn('imgwCountyCacheV31916',FACE)
    def test_26_no_live_network_test_dependency(self):
        self.assertNotIn('requests.get(',SVC)


class TestLocationAndValidationModel(unittest.TestCase):
    # These tests model the release policy independently of Monkey C. Their
    # role is regression prevention, not proof of behavior on hardware.
    def validate(self, result, loc, now=100000):
        if result is None or len(result)<8: return 1
        if result[7]!=11: return 2
        if not isinstance(result[3],int): return 3
        age=now-result[3]
        if age<0 or age>7200: return 4
        if result[6] not in (1,2): return 5
        if not isinstance(result[0],str) or len(result[0])!=4: return 6
        if loc is None or len(loc)<3: return 7
        seen=now-loc[2]
        if seen<0 or seen>21600: return 8
        if abs(result[4]-loc[0])>0.002 or abs(result[5]-loc[1])>0.002: return 9
        if result[6]==1 and not (1<=result[1]<=3 and 1<=result[2]<=13): return 10
        return 0
    def setUp(self):
        self.result=['1261',0,0,99900,50.06,19.94,2,11]
        self.loc=[50.06,19.94,99950]
    def test_01_valid_all_clear(self): self.assertEqual(self.validate(self.result,self.loc),0)
    def test_02_wrong_stage(self):
        self.result[7]=9; self.assertEqual(self.validate(self.result,self.loc),2)
    def test_03_result_expired(self):
        self.result[3]=92000; self.assertEqual(self.validate(self.result,self.loc),4)
    def test_04_no_false_all_clear_when_no_gps(self):
        self.assertEqual(self.validate(self.result,None),7)
    def test_05_observed_location_expired(self):
        self.loc[2]=76000; self.assertEqual(self.validate(self.result,self.loc),8)
    def test_06_location_change(self):
        self.loc[0]+=0.01; self.assertEqual(self.validate(self.result,self.loc),9)
    def test_07_small_jitter(self):
        self.loc[0]+=0.001; self.assertEqual(self.validate(self.result,self.loc),0)
    def test_08_active_alert(self):
        self.result[6]=1; self.result[1]=2; self.result[2]=5
        self.assertEqual(self.validate(self.result,self.loc),0)
    def test_09_invalid_alert(self):
        self.result[6]=1; self.result[1]=5; self.result[2]=5
        self.assertEqual(self.validate(self.result,self.loc),10)
    def test_10_null_not_refreshed(self):
        face=FACE[FACE.index('function captureImgwLocation('):FACE.index('function imgwValidationProblem(')]
        self.assertIn('activity.currentLocation == null) { return; }',face)
        self.assertIn('now - last[2] >= 900',face)
    def test_11_reason_codes_visible(self):
        self.assertIn('return prefix + ": D" + reason.toString();',FACE)
        self.assertIn('shortStatus = "T4 " + diag.substring(',FACE)
        self.assertIn('prefix + ": PONOW"',FACE)
    def test_12_typed_background_location(self):
        self.assertIn('!(loc[2] instanceof Lang.Number)',SVC)
    def test_13_same_full_backend(self):
        self.assertIn('_stage = stage == 4 ? 11 : stage;',SVC)
        self.assertIn('beginUnifiedImgwRequest(_stage);',SVC)

class TestWarningModel(unittest.TestCase):
    def test_empty(self): self.assertEqual(analyze([]),(0,0))
    def test_wrong_county(self): self.assertEqual(analyze([warning('1261')],county='1205'),(0,0))
    def test_active_ice(self): self.assertEqual(analyze([warning()]),(2,5))
    def test_active_thunder(self): self.assertEqual(analyze([warning(name='Burze',severity='3')]),(3,1))
    def test_highest_severity(self):
        self.assertEqual(analyze([warning(name='Burze',severity='1'),warning(name='Silny wiatr',severity='3')]),(3,2))
    def test_expired(self): self.assertEqual(analyze([warning(until='2026-11-13 10:01:00')]),(0,0))
    def test_not_yet_active(self): self.assertEqual(analyze([warning(since='2026-11-13 23:00:00')]),(0,0))
    def test_snow_vs_freezing_rain(self): self.assertNotEqual(classify('Intensywne opady śniegu'),classify('Opady marznące'))
    def test_frost(self): self.assertEqual(classify('Przymrozki'),9)
    def test_fog(self): self.assertEqual(classify('Gęsta mgła'),10)
    def test_bad_payload_fails_closed(self):
        for p in [None,{},'oops',[None],[{'teryt':'1261'}],[warning(severity='6')], [warning(until='x')]]:
            with self.subTest(p=p), self.assertRaises(ValueError): analyze(p)
    def test_many_counties(self):
        r=warning('1205',name='Silny wiatr',severity='1'); r['teryt']=['1205','1261','1206']
        self.assertEqual(analyze([r]),(1,2))
    def test_repeat_cycles_no_model_state_leak(self):
        # 100 independent successful query/parse cycles on alternating counties.
        r=warning('1261',name='Oblodzenie',severity='2')
        for i in range(100):
            self.assertEqual(analyze([r],county='1261' if i%2==0 else '1205'), (2,5) if i%2==0 else (0,0))

if __name__=='__main__': unittest.main(verbosity=2)
