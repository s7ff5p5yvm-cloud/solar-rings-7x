"""Static checks for compact measured clock, date and unchanged hazards."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT / 'source/SolarRings7X.mc').read_text()

class HeroClockTests(unittest.TestCase):
    def test_clock_uses_measured_widths_instead_of_fixed_centers(self):
        clock = FACE.split('function drawClock(dc, clock) {')[1].split('// Mini digits',1)[0]
        for required in ('var slotH = 60;', 'var gap = 3;', 'var maxGroupW = 146;',
                         'var requested = 94;', 'dc.getTextDimensions("88", probe)',
                         'dc.getTextDimensions(hourText, font)',
                         'dc.getTextDimensions(minuteText, font)',
                         'dc.getTextDimensions(":", font)',
                         'var colonX = left + hourDim[0] + gap',
                         'var minuteX = left + hourDim[0] + gap + colonDim[0] + gap',
                         '_clockLayoutCache = layout;'):
            self.assertIn(required, clock)
        for legacy in ('dc.drawText(59, yy, font, hourText',
                       'dc.drawText(98, yy, font, ":"',
                       'dc.drawText(138, yy, font, minuteText'):
            self.assertNotIn(legacy, clock)

    def test_clock_has_three_pass_weight_without_allocating_fonts(self):
        clock = FACE.split('function drawClock(dc, clock) {')[1].split('// Mini digits',1)[0]
        for label,center in (('hourText','3'),('minuteText','5')):
            self.assertIn(f'dc.drawText(layout[{center}] - 1,', clock)
            self.assertIn(f'dc.drawText(layout[{center}],', clock)
            self.assertIn(f'dc.drawText(layout[{center}] + 1,', clock)
        self.assertIn('Gfx.getVectorFont({:face => "RobotoCondensedBold"', FACE)

    def test_date_is_big_and_integrated(self):
        date = FACE.split('function drawDate(dc, dayLabel, dateLabel) {')[1].split('// Connection status',1)[0]
        self.assertIn('dayLabel, 170, 100, 24, 29',date)
        self.assertIn('dateLabel, 225, 97, 82, 34',date)
        self.assertNotIn('dateLabel.substring(', date)
        self.assertIn('desiredPixels("fontDateV31", 39, 4)',date)

    def test_no_lane_overlap_and_layout_geometry(self):
        clock = FACE.split('function drawClock(dc, clock) {')[1].split('// Mini digits',1)[0]
        self.assertIn('var maxGroupW = 146;', clock)
        self.assertIn('var left = 9 + ((148 - groupW) / 2).toNumber();',clock)
        # Worst-case width <=146, centered in clock lane x9..157.
        for width in (50, 90, 120, 146):
            left = 9+(148-width)//2
            self.assertGreaterEqual(left-1, 9)
            self.assertLessEqual(left+width+1,158)
        self.assertIn('drawSized(dc, ageLabel, 235, 75, 56, 20',FACE)
        self.assertIn('rule(dc, 70);',FACE)
        self.assertIn('rule(dc, 135);',FACE)
        self.assertIn('var centers = [68, 91, 114];',FACE)

    def test_moon_lane_and_city_remain_fitted(self):
        moon = FACE.split('function drawMoonPanel(dc, weather) {')[1].split('function topSlot(',1)[0]
        self.assertIn('drawLunarDisk(dc, 52, 150, 12)',moon)
        self.assertIn('drawSized(dc, location, 188, 136, 126, 25',moon)

    def test_weather_warnings_unmodified(self):
        src=(ROOT/'source/SolarOpenWarnings.mc').read_bytes()
        previous=Path('/mnt/data/SolarRings7X_v3_26_27_LAYOUT_FINAL_SOURCE/source/SolarOpenWarnings.mc')
        if previous.exists():
            self.assertEqual(src,previous.read_bytes())
        self.assertIn('rule(dc, 215);',FACE)
        self.assertIn('rule(dc, 250);',FACE)

if __name__ == '__main__': unittest.main()
