import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
ENGINE=(ROOT/'source/GarminWeatherWarnings.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
PROPS=ET.parse(ROOT/'resources/settings/properties.xml').getroot()
SETTINGS=ET.parse(ROOT/'resources/settings/settings.xml').getroot()
STRINGS=ET.parse(ROOT/'resources/strings.xml').getroot()

class GarminWeatherRules(unittest.TestCase):
    def test_settings_are_one_to_one_and_resolve(self):
        ids=[x.attrib['id'] for x in PROPS]
        self.assertEqual(len(ids),len(set(ids)))
        ids_string=[x.attrib['id'] for x in STRINGS]
        self.assertEqual(len(ids_string),len(set(ids_string)))
        keys=[x.attrib['propertyKey'].split('.')[-1] for x in SETTINGS]
        self.assertEqual(len(keys),len(set(keys)))
        self.assertTrue(set(keys)<=set(ids))
        for setting in SETTINGS:
            self.assertIn(setting.attrib['title'].split('.')[-1],ids_string)
            for option in setting.iter('listEntry'):
                self.assertIn(option.text.split('.')[-1],ids_string)

    def test_master_switch_and_interval(self):
        for item in ('gwOnV324','gwIntervalV324','gwForecastV324','gwHorizonV324','gwPreviewV324'):
            self.assertIn('"'+item+'"',ENGINE)
        self.assertIn('now - _lastCheck >= interval * 60',ENGINE)
        self.assertIn('Weather.getHourlyForecast()',ENGINE)
        self.assertIn('h.forecastTime.value() - now',ENGINE)

    def test_distinct_thresholds_and_switches(self):
        for key in ['Wind','Storm','Rain','Snow','Freeze','Fog','Ice','Hail','Uv']:
            self.assertIn('gw'+key+'OnV324',ENGINE)
        for key in ['gwWindV324','gwStormChanceV324','gwRainChanceV324',
                    'gwSnowChanceV324','gwFreezeChanceV324','gwFogMetersV324',
                    'gwIceTempV324','gwIceChanceV324','gwHailChanceV324',
                    'gwUvV324']:
            self.assertIn(key,ENGINE)

    def test_icon_priority_and_distinct_symbols(self):
        for i in range(1,10):
            self.assertIn('kind == %d'%i,FACE)
        for i in (1,2,3,4,5,6,7,8,9):
            self.assertIn('k == %d'%i,ENGINE)
        self.assertIn('priority(items[j]) > priority(items[i])',ENGINE)
        self.assertIn('addAlert(k, ',ENGINE)
        self.assertIn('mergeAlerts(matched, classify(',ENGINE)

    def test_fixed_independent_slots_and_feels_like(self):
        self.assertIn('temperatureMarker(dc, weather, warning != 0 ? 124 : 144, 227)', FACE)
        self.assertIn('drawGarminWarningIcon(dc, 144, 227, warning)', FACE)
        self.assertIn('drawSized(dc, d[1], tempX, 215, tempWidth, 22,', FACE)
        self.assertIn('showFeelsLikeV319',FACE)
        self.assertIn('weather.feelsLikeTemperature',FACE)
        self.assertIn('drawSized(dc, lowerLabel, 170, 234, 105, 16, lowerColor, false,',FACE)
        self.assertIn('Weather.getCurrentConditions()',FACE)

    def test_settings_changes_clear_cached_warning(self):
        self.assertIn('function reset() {',ENGINE)
        self.assertIn('_lastCheck = 0;',ENGINE)
        self.assertIn('_lastKinds = [];', ENGINE)
        self.assertIn('resetWeatherWarningCache()',FACE)
        self.assertIn('_face.resetWeatherWarningCache()',FACE)

    def test_heavy_precipitation_filters_exist(self):
        for key in ('gwRainHeavyV324','gwSnowHeavyV324'):
            self.assertIn(key,ENGINE)
            self.assertIn(key,[p.attrib['id'] for p in PROPS])
        self.assertIn('Weather.CONDITION_HEAVY_RAIN',ENGINE)
        self.assertIn('Weather.CONDITION_HEAVY_SNOW',ENGINE)

    def test_chosen_default_thresholds_and_heavy_filters(self):
        values = {p.attrib['id']: p.text for p in PROPS}
        self.assertEqual(values['gwRainChanceV324'], '60')
        self.assertEqual(values['gwSnowChanceV324'], '60')
        self.assertEqual(values['gwStormChanceV324'], '50')
        self.assertEqual(values['gwFreezeChanceV324'], '40')
        self.assertEqual(values['gwWindV324'], '10')
        self.assertEqual(values['gwRainHeavyV324'], 'true')
        self.assertEqual(values['gwSnowHeavyV324'], 'true')
        self.assertEqual(values['gwOnV324'], 'false')
        values_by_key = {e.attrib['propertyKey'].split('.')[-1]:
                         [v.attrib['value'] for v in e.iter('listEntry')]
                         for e in SETTINGS}
        for key in ('gwStormChanceV324', 'gwRainChanceV324',
                    'gwSnowChanceV324', 'gwFreezeChanceV324'):
            self.assertEqual(values_by_key[key],
                             ['30', '40', '50', '60', '70', '80', '90'])

    def test_chance_of_storm_requires_hourly_forecast_not_claimed_observation(self):
        self.assertIn('stormOnlyChance = c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS', ENGINE)
        self.assertIn('(!isForecast && !stormOnlyChance)', ENGINE)
        self.assertIn('(isForecast && chance != null &&', ENGINE)
        self.assertIn('p >= srSetting("gwStormChanceV324", 50)', ENGINE)
        self.assertIn('c == Weather.CONDITION_HEAVY_SHOWERS', ENGINE)
        self.assertIn('c == Weather.CONDITION_HEAVY_SNOW', ENGINE)

    def test_multiple_alerts_rotate_every_five_seconds(self):
        self.assertIn('function rotatingWarning()', ENGINE)
        self.assertIn('(Time.now().value() / 5).toNumber()', ENGINE)
        self.assertIn('return _lastKinds[phase % count]', ENGINE)
        self.assertIn('function mergeAlerts(items, other, isForecast)', ENGINE)
        self.assertIn('if (baseKind(items[i]) == kind)', ENGINE)
        self.assertIn('return orderAlerts(matched)', ENGINE)
        self.assertIn('_lastKinds = [4, 17]', ENGINE)
        self.assertIn('function onPartialUpdate(dc)', FACE)
        self.assertIn('dc.setClip(134, 216, 20, 22)', FACE)
        self.assertIn('dc.clearClip()', FACE)
        self.assertIn('_lastDrawnWeatherWarning = nextKind', FACE)
        self.assertIn('_weatherWarningVisible = false;', FACE)

    def test_no_network_gps_or_background_in_new_engine(self):
        for bad in ('Communications','Position.getInfo','registerForTemporalEvent',
                    'getServiceDelegate','Storage.setValue','makeWebRequest'):
            self.assertNotIn(bad,ENGINE)
        self.assertIn('secondsOld <= 2700',ENGINE)
        self.assertIn('if (dt <= -3600 || dt > horizon * 3600)',ENGINE)
        self.assertIn('count > 8',ENGINE)

    def test_bounds_and_data_types_for_settings(self):
        data={x.attrib['id']:x for x in PROPS}
        opts={e.attrib['propertyKey'].split('.')[-1]:[x.attrib['value'] for x in e.iter('listEntry')] for e in SETTINGS}
        for k in ('gwIntervalV324','gwHorizonV324','gwWindV324','gwFogMetersV324'):
            self.assertIn(data[k].text,opts[k])
        for key in data:
            if key.startswith('gw') and key.endswith('OnV324'):
                self.assertEqual(data[key].attrib['type'],'boolean')

if __name__=='__main__': unittest.main()
