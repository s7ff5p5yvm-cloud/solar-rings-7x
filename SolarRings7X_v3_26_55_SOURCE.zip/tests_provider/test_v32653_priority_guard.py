"""Source contracts for Priority Guard v3.26.55.
Does not compile Monkey C or prove physical-device memory behavior.
"""
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[1]
N=(R/'source/SolarOpenNetwork.mc').read_text()
U=(R/'source/SolarRings7X.mc').read_text()
D=(R/'source/SolarOpenData.mc').read_text()
class PriorityGuardV32654(unittest.TestCase):
    def test_essential_timing(self):
        self.assertIn('return _interval <= 15 ? 10 * 60', N)
        self.assertIn('return _interval <= 15 ? 10 * 60',N)
        self.assertIn('_alertMode == 2 ? 60 * 60 :',N)
        self.assertIn('_alertMode == 2 ? 90 * 60 : 75 * 60',N)
    def test_critical_overdue_priority(self):
        self.assertIn('var wantC = nextC <= _now;',N)
        self.assertIn('var wantF = nextF <= _now;',N)
        self.assertIn('if ((wantC || wantF) && !reserveAux)',N)
        self.assertIn('ageC <= 16 * 60 && ageF <= 16 * 60',N)
        self.assertLess(N.index('if ((wantC || wantF) && !reserveAux)'),
                        N.index('if (cityDue && Sys.getDeviceSettings().phoneConnected)'))
    def test_single_http_per_service(self):
        self.assertNotIn('method(:onSecondReceive)',N)
        self.assertIn('Bg.exit(["OWM", changed ? 1 : 0]);',N)
    def test_two_repeated_15m_memory_faults_lock_optional(self):
        self.assertIn('function shortLocked()',N)
        self.assertIn('return num(faults) && faults >= 2;',N)
        self.assertIn('if (!_shortEnabled || shortLocked())',N)
        self.assertIn('15M OCHRONA (2 BLEDY)',U)
        self.assertIn('srOShortFaultV32652", 0',D)  # settings toggle unlock
    def test_settings_schema_and_photon_unchanged(self):
        import hashlib
        props=R/'resources/settings/properties.xml'
        self.assertEqual(hashlib.sha256(props.read_bytes()).hexdigest(),
                         'e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63')
        self.assertIn('https://photon.komoot.io/reverse',N)
        self.assertIn('function nightWindow()',N)
    def test_forecast_both_sources_and_hysteresis(self):
        self.assertIn('firstCalm >= hourly[2]',N)
        self.assertIn('if (shortReady())',N)
        self.assertIn('srOwmHourlyWarningsSnapshot()',
                      (R/'source/SolarOpenWarnings.mc').read_text())
        self.assertIn('srOwmShortWarningsSnapshot()',
                      (R/'source/SolarOpenWarnings.mc').read_text())
