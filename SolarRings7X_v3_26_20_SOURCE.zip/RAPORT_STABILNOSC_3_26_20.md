# Solar Rings 3.26.20 — odbudowa stabilnego wariantu

**Baza:** źródła 3.26.13, nie 3.26.19.

## Dlaczego
- 3.26.17: logi potwierdziły Out of Memory i Unexpected Type.
- 3.26.18: nowy log potwierdził Unexpected Type w odczycie ustawień.
- 3.26.19: blokada ekranu "ODSWIEZANIE USTAWIEN" bez limitu.

## Co poprawiono
- Zdarzenie zmiany ustawień nie przebudowuje pogodowych obiektów, nie wywołuje `srOwmProviderChanged` ani nie resetuje całych cache.
- Przy następnym normalnym odświeżeniu synchronizacja konfiguracji następuje raz, bez ekranu pośredniego.
- Zmiana OWM/Garmin przebudowuje tylko właściwy moduł ostrzeżeń.
- Przychodzące dane pogodowe unieważniają tylko cache pogody.
- Klucz diagnostyczny `gwPreviewV332` ma sprawdzany typ.
- Domyślny OWM: interwał 5 minut (wybudzenia, nie 5-minutowa aktualizacja każdego źródła), analiza alertów 5 minut, 3 h prognozy, AQI włączone.
- Bez ruszania identyfikatora aplikacji, typów i kluczy Settings.

## Ograniczenia / uczciwe zastrzeżenie
- OWM One Call 4.0 ma prognozę minutową, ale nie włączono pełnej 60-elementowej odpowiedzi 1min: bez dowodu, że mieści się w ograniczonej pamięci zadania tła, byłoby to ryzykowne. Prognoza 15min obejmuje 3 h; przy błędzie używany jest fallback 1h.
- 15-minutowa prognoza i 1-godzinna pozostają w trybie fallback, a nie są pobierane obie bez przerwy. To świadomy wybór w celu ochrony pamięci i limitu jednej operacji na wybudzenie.
- OWM 4.0 dostarcza identyfikatory urzędowych alertów, ale wersja bazowa nie pobiera pełnego ich opisu — nie należy deklarować urzędowych ostrzeżeń jako aktywnych.
- OWM AQI korzysta z osobnego endpointu air_pollution (skala 1–5) i pobiera dane około raz na 60 minut.
- Brak kompilacji Monkey C i testu na urządzeniu w tym środowisku. Testy Python sprawdzają kontrakty źródeł, nie rzeczywistą stabilność.
- Jeśli w telefonie zapisano poprzednio wartości ustawień, wartości domyślne nie muszą ich nadpisać; w Connect IQ należy ustawić ręcznie odświeżanie 5, analizę 5 i horyzont 3.

## Plan testu na Fenix 7X Pro Solar
1. Po buildzie instalacja bez resetowania całego Garmina.
2. Włączenie temperatury odczuwalnej; zapis i powrót tarczy.
3. Wyłączenie pierścienia; zapis, kontrola, czy nie pojawia się IQ! i nie znika API key.
4. Garmin Weather <-> OWM; pomiar czasu aktualizacji i TEST 16/20.
5. Co najmniej 30–60 minut normalnej pracy; nowe CIQ_LOG.YML i CIQ_LOG.BAK.
6. Testy kontrolowane ikon 1–14 i próg AQI, a następnie test rzeczywistych zdarzeń.
