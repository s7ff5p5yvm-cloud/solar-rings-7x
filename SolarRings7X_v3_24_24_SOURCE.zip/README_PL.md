# Solar Rings 7X v3.24.24 — Księżyc + lokalizacja + centrum ostrzeżeń

## Nowy układ
- Dolna lewa część to centrum ostrzeżeń (maks. 4 ikony widoczne jednocześnie).
- Jeżeli StormGuard wykrywa spadek ciśnienia, jego żółta błyskawica jest pierwsza. Bez takiego ostrzeżenia pierwsze miejsce zajmuje kolejne aktywne ostrzeżenie.
- Pozostałe ostrzeżenia Garmin Weather zachowują priorytety i kolory (czerwony = bieżące warunki, turkusowy = prognoza). Alerty temperatury również pozostają aktywne.
- Przy 5 lub więcej jednoczesnych ostrzeżeniach pierwsze trzy są stałe, a czwarte miejsce rotuje pozostałe co 5 sekund, aby żadna kategoria nie została ukryta. Przy maksymalnie 4 ikonach nie ma rotacji ani rysowania częściowego.
- Usunięta zostaje dolna dekoracyjna ikonka aktualnego zachmurzenia. Temperatura, odczuwalna, Bluetooth, aktualność pogody, kapsuły, bateria i jej ładowanie pozostają bez zmian.
- W środkowym pasie: kontrastowy większy Księżyc 28 px, liczba dni do następnej pełni (np. `8d`, `0d`, następnego dnia `29d`), pionowy separator i nazwa źródła obserwacji Garmin Weather (np. `KRAKÓW` albo `BALICE`).
- Lokalizacja pokazuje **źródło danych Garmin Weather**, które może być inne niż miasto pobytu. Brak danych = `--`; bardzo długa nazwa zmniejsza czcionkę. Nie wymaga GPS ani zapytań internetowych tarczy.
- Ustawienie starej etykiety `I KWADRA` zostało ukryte, ponieważ zastąpił je licznik. Właściwość jest zachowana dla zgodności zapisanych ustawień. `moonFontV38` reguluje wielkość nazwy lokalizacji.

## Zasilanie i dokładność
- Księżyc i odliczanie wykorzystują offline przybliżenie astronomiczne Meeusa (nowie i pełnie, poprawki periodyczne); wyliczenia są buforowane na dzień lokalny, brak dodatkowych połączeń. Jest to prognoza dat, nie dokładna efemeryda naukowa.
- StormGuard zachowuje 5-minutowy interwał, progi i analizę pełnego zakresu wysokości. Obie tendencje ciśnienia (1h i 3h) korzystają ze wspólnego odczytu trzygodzinnej historii.
- `onPartialUpdate()` pozostaje w kodzie ze względu na rzadki przypadek >4 alertów. Nie rysuje nic przy mniejszej liczbie ostrzeżeń, ale system Garmin może nadal wywoływać callback co sekundę. Zysk energetyczny wymaga pomiaru.

## Instalacja
1. Wgraj `SolarRings7X_v3_24_24_SOURCE.zip` do katalogu głównego repozytorium GitHub.
2. Zamień aktywny workflow w `.github/workflows/` na plik `SolarRings7X_v3_24_24_BUILD.yml` z kompletnej paczki.
3. Uruchom **Build Solar Rings 7X - Weather Sources v3.24.24**.
4. Pobierz artefakt `SolarRings7X_weather_v32424` i zainstaluj `SolarRings7X_v32424.prg`.
5. Sprawdź zegarek: data/godzina, Księżyc i miasto, alarm testowy 13 w ustawieniach oraz alert ciśnienia, temperaturę, kroki, ładowanie i Bluetooth.

**Ważne:** testy Python to kontrole statyczne i matematyczne, a nie kompilacja Garmin SDK. Ze względu na zmianę układu i algorytmu ciśnienia ta wersja wymaga sprawdzenia kompilacji w GitHub Actions i testu sprzętowego; do tego czasu zachowaj sprawdzoną v3.24.23. Wynik pomiaru baterii nie jest z góry zagwarantowany.
