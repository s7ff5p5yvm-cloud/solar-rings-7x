import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
CODE = (ROOT / 'source' / 'SolarRings7X.mc').read_text()

class ChargingBattery32419(unittest.TestCase):
    def test_garmin_supported_status(self):
        self.assertIn('srSystemStatsForFrame().charging;', CODE)
        self.assertIn('catch (e) { charging = false; }', CODE)
    def test_charging_only_footer_battery(self):
        footer = CODE.split('function drawBattery(dc, monitor, weather)')[1].split('function outerProgressRing')[0]
        self.assertIn('if (id == 17 && charging)', footer)
        self.assertIn('chargingBatteryIcon(dc, 117, 261, Gfx.COLOR_GREEN)', footer)
        self.assertIn('drawIcon(dc, 117, 261, id, footerColor)', footer)
        self.assertIn('drawSized(dc, d[1], 165, 251, 60, 20', footer)
    def test_charger_bolt_inside_original_battery_outline(self):
        battery = CODE.split('function batteryIcon(')[1].split('function chargingBatteryIcon(')[0]
        charger = CODE.split('function chargingBatteryIcon(')[1].split('function bodyBatteryIcon(')[0]
        for geometry in ['dc.drawRectangle(x - 9, y - 6, 17, 12);', 'dc.fillRectangle(x + 8, y - 2, 3, 4);']:
            self.assertIn(geometry, battery)
            self.assertIn(geometry, charger)
        self.assertIn('dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);', charger)
        self.assertEqual(charger.count('dc.drawLine('), 3)
    def test_old_battery_in_other_fields_unchanged(self):
        self.assertIn('else if (id == 17) { batteryIcon(dc, x, y, color); }', CODE)
    def test_charging_does_not_touch_weather_or_bluetooth(self):
        self.assertIn('current.observationTime.value()', CODE)
        self.assertIn('System.getDeviceSettings().phoneConnected', CODE)
        self.assertIn('var remainingSteps = monitor.stepGoal - doneSteps;', CODE)
    def test_version(self):
        m=ET.parse(ROOT/'manifest.xml').getroot()
        app=m.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'], '3.24.24')
        self.assertIn("== '3.24.24'", (ROOT/'check_version.py').read_text())

if __name__ == '__main__': unittest.main()
