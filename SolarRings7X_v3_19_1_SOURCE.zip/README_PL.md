# Solar Rings 7X v3.19.1 — kompletna aktualizacja

Zawiera wszystkie elementy v3.17: godzina, data, trzy kapsuly, ikony tetna,
Body Battery i minut intensywnych, dwa rozne symbole wschodu/zachodu,
pasek postepu i zielone DONE przy 100% krokow, termometr powyzej i ponizej
ustawionych progow, ostrzezenie burzowe barometryczne, kolory stanow
baterii/Body Battery/stresu, 8 konfigurowalnych pol i ostrzezenia IMGW.

## IMGW — konkretny powiat na podstawie pozycji zegarka

1. W ustawieniach Connect IQ wlacz IMGW (domyslnie wylaczone).
2. Zegarek musi udostepniac pozycje GPS. Tarcza NIE wlacza samodzielnie GPS,
   a ostatni odczyt starszy niz 6h jest odrzucany.
3. W tle (co 30 lub 60 minut) ULDK GUGiK otrzymuje wspolrzedne, odpowiada
   4-cyfrowym kodem powiatu TERYT, a IMGW zwraca liste ostrzezen.
4. Tarcza filtruje wylacznie aktywne alerty dla DOKLADNIE tego powiatu.
   Jesli nie ma pozycji/sieci/danych lub dane sa stare, ikonka znika.
5. Gdy IMGW i temperatury wywoluja dwa rozne ostrzezenia, obie ikony
   pokazywane sa niezaleznie po lewej stronie liczby temperatury.

12 rodzajow ikon + awaryjne ostrzezenie: 1 burze, 2 silny wiatr,
3 intensywne opady deszczu, 4 opady sniegu, 5 oblodzenie,
6 opady marznace/gololedz, 7 upaly, 8 silny mroz, 9 przymrozki,
10 gesta mgla, 11 zawieje/zamiecie, 12 roztopy.
Kolory stopnia: 1 zolty, 2 pomaranczowy, 3 czerwony.

## Czcionki

Usunieto z ekranu ustawien niedzialajace wybory kroju i wielkosci.
Zachowano stale, zaakceptowane wielkosci i automatyczne dopasowanie
przy dlugich wartosciach. Starsze zapisane ustawienia fontow sa ignorowane.

## Ograniczenia i zrodla

Wskaznik IMGW NIE jest systemem alarmowym. Nie gwarantuje natychmiastowego
przeslania alertu; jest zaleznym od GPS, polaczenia i danych sieciowych
uzupelnieniem oficjalnych komunikatow. Background task wymaga Garmin Connect.
Dokumentacja API: https://danepubliczne.imgw.pl/api/data/warningsmeteo
Zrodlo danych przestrzennych: Glowny Urzad Geodezji i Kartografii (GUGiK),
Usluga Lokalizacji Dzialek Katastralnych (ULDK): https://uldk.gugik.gov.pl/

Testowano statycznie kod i pliki konfiguracyjne; nie wykonano kompilacji SDK
ani testow na fizycznym zegarku. Do sprawdzenia sa zwlaszcza odpowiedz ULDK
w formacie text/plain oraz czas dzialania uslugi w tle.

## Poprawka v3.18.1 – czytelne ikony śniegu i marznących opadów
- Intensywne opady śniegu (IMGW kategoria 4): chmura i DWA PŁATKI śniegu.
- Opady marznące / gołoledź (IMGW kategoria 6): DWIE KROPLE i podwójna pozioma warstwa lodu.
- Ikony mają niezależne kształty i zachowują kolor stopnia IMGW.
- Pozostałe funkcje i ustawienia v3.18 pozostają bez zmian.

## v3.19.0: opcjonalna temperatura odczuwalna
- Nowy przelacznik w Connect IQ: "Pogoda: pokazuj takze temp. odczuwalna".
- Domyslnie **wylaczone**: opis pogody wyswietla sie tak jak poprzednio.
- Po wlaczeniu: duza liczba nadal oznacza temperature rzeczywista,
  a mniejszy wiersz pod nia pokazuje np. "ODCZ. 5°C".
- Gdy Garmin nie poda wartosci odczuwalnej, tarcza zachowa opis pogody.
- Opcja dziala tylko gdy dolne pole to "Pogoda" lub "Temperatura";
  inne wybrane dane pozostaja bez zmian.
- Dwa ostrzezenia (termometr + IMGW), ich pozycje i progi nie zmieniaja sie.
- Wartosc temperatury odczuwalnej pochodzi z Garmin Weather i wymaga
  aktualnych danych z polaczonego zegarka/telefonu.


## Poprawka v3.19.1 — typy callbacków IMGW
- Naprawiono dwa błędy kompilatora w `ImgwService.mc` przy `Comm.makeWebRequest`.
- Callbacki HTTP mają jawne typy kodu odpowiedzi, zawartości i `as Void`.
- Obsługę tablicy JSON IMGW przeniesiono do funkcji akceptującej `Lang.Object`,
  bo SDK 9.3 nie uwzględnia tablic JSON w oficjalnej sygnaturze callbacku.
- Wszystkie wcześniejsze funkcje i ustawienia v3.19 zachowane.
- Testy statyczne projektu nie zastępują kompilacji na SDK.
