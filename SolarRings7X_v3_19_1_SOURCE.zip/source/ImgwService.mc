using Toybox.System as Sys;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Application.Storage as Storage;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Application.Properties as Props;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as PersistedContent;

// IMGW beta: county TERYT from GUGiK ULDK (two HTTPS requests per refresh).
// Background service cannot enable GPS. The face stores a recent GPS fix.
// Privacy: coordinates are sent to GUGiK for geocoding; IMGW receives no coords.
(:background)
class ImgwServiceV318 extends Sys.ServiceDelegate {
    var _county;
    var _lat;
    var _lon;

    function initialize() {
        ServiceDelegate.initialize();
        _county = null;
        _lat = 0.0;
        _lon = 0.0;
    }

    // Missing or stale location/network => no warning, not a false all-clear.
    function stop() {
        Bg.exit(["", 0, 0, Time.now().value(), _lat, _lon]);
    }

    function onTemporalEvent() {
        try {
            if (Props.getValue("imgwOnV317") != true) { stop(); return; }
            var loc = Storage.getValue("imgwLocV318");
            if (loc == null || !(loc instanceof Lang.Array) || loc.size() < 3) { stop(); return; }
            var age = Time.now().value() - loc[2];
            if (age < 0 || age > 21600) { stop(); return; } // max 6-hour-old GPS fix
            _lat = loc[0].toFloat();
            _lon = loc[1].toFloat();
            if (_lat < 49.0 || _lat > 55.1 || _lon < 14.0 || _lon > 24.3) { stop(); return; }
            // Official ULDK. WKT EPSG:4326 order is longitude,latitude.
            var coords = _lon.format("%.5f") + "," + _lat.format("%.5f") + ",4326";
            Comm.makeWebRequest("https://uldk.gugik.gov.pl/",
                {"request" => "GetCountyByXY", "xy" => coords, "result" => "teryt"},
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN },
                method(:onCountyResponse));
        } catch (e) { stop(); }
    }

    // Official ULDK returns plain text: status "0" followed by 4-digit WWPP TERYT.
    function parseCounty(raw) {
        if (raw == null || !(raw instanceof Lang.String)) { return null; }
        var newline = raw.find("\n");
        if (newline == null || newline < 1 || raw.substring(0, 1) != "0") { return null; }
        var part = raw.substring(newline + 1, raw.length());
        if (part.length() < 4) { return null; }
        var code = part.substring(0, 4);
        for (var i = 0; i < 4; i++) {
            if ("0123456789".find(code.substring(i, i + 1)) == null) { return null; }
        }
        return code;
    }

    function onCountyResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        try {
            if (responseCode != 200) { stop(); return; }
            _county = parseCounty(payload);
            if (_county == null) { stop(); return; }
            Comm.makeWebRequest("https://danepubliczne.imgw.pl/api/data/warningsmeteo", null,
                { :method => Comm.HTTP_REQUEST_METHOD_GET,
                  :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON },
                method(:onWarningsResponse));
        } catch (e) { stop(); }
    }

    function dateOrdinal(t) {
        if (t == null || !(t instanceof Lang.String) || t.length() < 16) { return -1; }
        try {
            var y = t.substring(0, 4).toNumber();
            var m = t.substring(5, 7).toNumber();
            var d = t.substring(8, 10).toNumber();
            var h = t.substring(11, 13).toNumber();
            var min = t.substring(14, 16).toNumber();
            return (((y * 13 + m) * 32 + d) * 24 + h) * 60 + min;
        } catch (e) { }
        return -1;
    }

    // IMGW's published timestamps use Poland local time.
    function localOrdinal() {
        var d = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        return (((d.year * 13 + d.month) * 32 + d.day) * 24 + d.hour) * 60 + d.min;
    }

    // 1 storm, 2 wind, 3 rain, 4 snow, 5 ice, 6 freezing rain,
    // 7 heat, 8 cold, 9 ground frost, 10 fog, 11 snowdrift, 12 thaw,
    // 13 unknown. Categories intentionally independent of warning severity.
    function phenomenon(n) {
        if (n == null) { return 13; }
        var t = n.toString();
        if (t.find("burz") != null || t.find("Burz") != null) { return 1; }
        if (t.find("Zawieje") != null || t.find("zawieje") != null ||
            t.find("zamiecie") != null || t.find("Zamiecie") != null) { return 11; }
        if (t.find("wiatr") != null || t.find("Wiatr") != null ||
            t.find("sztorm") != null || t.find("Sztorm") != null) { return 2; }
        if (t.find("marzn") != null || t.find("Marzn") != null ||
            t.find("marzną") != null || t.find("Marzną") != null ||
            t.find("Gołoled") != null || t.find("gołoled") != null) { return 6; }
        if (t.find("Oblodzen") != null || t.find("oblodzen") != null) { return 5; }
        if (t.find("śnieg") != null || t.find("śniegu") != null ||
            t.find("Śnieg") != null || t.find("śnież") != null) { return 4; }
        if (t.find("deszcz") != null || t.find("Deszcz") != null ||
            t.find("opad") != null || t.find("Opad") != null) { return 3; }
        if (t.find("Przymrozk") != null || t.find("przymrozk") != null) { return 9; }
        if (t.find("Roztop") != null || t.find("roztop") != null) { return 12; }
        if (t.find("Upa") != null || t.find("upa") != null) { return 7; }
        if (t.find("mróz") != null || t.find("Mroz") != null ||
            t.find("mroz") != null) { return 8; }
        if (t.find("mgł") != null || t.find("Mgł") != null ||
            t.find("mgl") != null) { return 10; }
        return 13;
    }

    // The callback's exact signature is required by makeWebRequest().
    // SDK 9.3 may return JSON top-level arrays even though its callback
    // ContentType typedef omits Array. Handle them in an Object-typed helper
    // so an optimizer cannot fold away the array branch as unreachable.
    function onWarningsResponse(responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null) as Void {
        if (responseCode != 200 || payload == null) { stop(); return; }
        try { processWarnings(payload); }
        catch (e) { stop(); }
    }

    function processWarnings(body as Lang.Object) as Void {
        try {
            if (!(body instanceof Lang.Array)) { stop(); return; }
            var bestLevel = 0;
            var bestType = 0;
            var now = localOrdinal();
            for (var i = 0; i < body.size(); i++) {
                var item = body[i];
                if (item == null || !(item instanceof Lang.Dictionary)) { continue; }
                var start = dateOrdinal(item["obowiazuje_od"]);
                var end = dateOrdinal(item["obowiazuje_do"]);
                if (start < 0 || end < 0 || now < start || now > end) { continue; }
                var codes = item["teryt"];
                if (codes == null || !(codes instanceof Lang.Array)) { continue; }
                var match = false;
                for (var j = 0; j < codes.size(); j++) {
                    if (codes[j] != null && codes[j].toString() == _county) {
                        match = true; break;
                    }
                }
                if (!match) { continue; }
                var level = 0;
                try { level = item["stopien"].toNumber(); } catch (e) { }
                if (level < 1 || level > 3) { continue; }
                var kind = phenomenon(item["nazwa_zdarzenia"]);
                if (level > bestLevel || (level == bestLevel &&
                    (bestType == 0 || kind < bestType))) {
                    bestLevel = level;
                    bestType = kind;
                }
            }
            Bg.exit([_county, bestLevel, bestType, Time.now().value(), _lat, _lon]);
        } catch (e) { stop(); }
    }
}
