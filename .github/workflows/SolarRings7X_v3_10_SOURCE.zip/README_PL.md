# Solar Rings 7X v3.10 — 3 kapsuly i ostrzezenie burzowe

Wersja dla Garmin Fenix 7X Pro Solar (MIP 280x280). Zachowano identyfikator aplikacji i wszystkie wczesniejsze ustawienia.

Zmiany: trzy kapsuly (lewa i prawa z ikonami, srodkowa z krokami i paskiem realizacji celu); godzina i data wieksze; gora przesunieta nieco w lewo; burzowa blyskawica TYLKO po wykryciu trendu, obok dodatkowego ksiezyca po lewej; 2 progi cisnieniowe: opcjonalny 1h oraz 3h; zachowany filtr wysokosci.

Domyslnie ostrzezenie burzowe jest WYLACZONE (wlacz w Connect IQ). Po wlaczeniu aktywne sa oba okna: 2 hPa / 1h i 4 hPa / 3h. Mozna wylaczyc szybki tryb. Uwaga: wskazanie to trend barometryczny, NIE gwarantowana prognoza burzy; filtr wysokosci oparty na czujniku barometrycznym nie odroznia niezawodnie wchodzenia po schodach od zmian pogody.

Budowanie: wrzuc archiwum SolarRings7X_v3_10_SOURCE.zip w katalog glowny repozytorium i podmien .github/workflows/build-v3.yml zawartoscia SolarRings7X_v3_10_BUILD.yml. Uruchom Actions. Plik IQ wyslij do istniejacej bety w Connect IQ przez uprawnionego dewelopera.

Testy statyczne NIE zastepuja kompilacji w Garmin SDK lub testu na zegarku.
