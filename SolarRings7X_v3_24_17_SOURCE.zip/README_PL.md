# Solar Rings 7X v3.24.11 — ikony ostrzeżeń

Nowe ikony: silny wiatr — podmuchy; intensywny deszcz — chmura i paski; intensywny śnieg — chmura i kropki; burza — chmura i piorun; opady marznące — okrąg i paski; mgła — chmura i poziome linie; oblodzenie — śnieżynka; grad — okrąg i kropki; UV — słońce.

Przesunięto ikonę ostrzeżenia z x=120 na x=123; poprawiono również obszar odświeżania. Termometr, progi i silnik Garmin Weather bez zmian.

W ustawieniach Connect IQ pozycja „Podgląd ikon / legenda (TEST)” opisuje symbole słownie. Garmin Connect IQ nie gwarantuje wyświetlania dowolnych grafik w ustawieniach, więc pełna graficzna legenda znajduje się w osobnym pliku PNG. Wybranie pozycji testowej włącza test, dlatego po sprawdzeniu wróć do „Wyłączony”.

Brak kompilacji na SDK Garmin w tym środowisku — uruchom workflow GitHub Actions i sprawdź na zegarku.

---

# Solar Rings 7X v3.24.11 — ikony ostrzeżeń

Nowe ikony: silny wiatr — podmuchy; intensywny deszcz — chmura i paski; intensywny śnieg — chmura i kropki; burza — chmura i piorun; opady marznące — okrąg i paski; mgła — chmura i poziome linie; oblodzenie — śnieżynka; grad — okrąg i kropki; UV — słońce.

Przesunięto ikonę ostrzeżenia z x=120 na x=123; poprawiono również obszar odświeżania. Termometr, progi i silnik Garmin Weather bez zmian.

W ustawieniach Connect IQ pozycja „Podgląd ikon / legenda (TEST)” opisuje symbole słownie. Garmin Connect IQ nie gwarantuje wyświetlania dowolnych grafik w ustawieniach, więc pełna graficzna legenda znajduje się w osobnym pliku PNG. Wybranie pozycji testowej włącza test, dlatego po sprawdzeniu wróć do „Wyłączony”.

Brak kompilacji na SDK Garmin w tym środowisku — uruchom workflow GitHub Actions i sprawdź na zegarku.

---

# Solar Rings 7X v3.24.9 — szersze pole temperatury

Zmiana względem v3.24.8 dotyczy wyłącznie pola z liczbą temperatury w dolnym prawym panelu. Przy jednym lub dwóch markerach ma **80 zamiast 74 pikseli** szerokości, środek x=187; granice x=147..227. W najciaśniejszym układzie ostrzeżenie jest na x=120, termometr na x=140 (obrys kończy się około x=144), więc między termometrem a polem tekstu pozostają 3 piksele. Pionowy separator pozostaje na x=109.

Rozmiar żądanej czcionki nie zmienia się: istniejąca funkcja `drawSized` mierzy rzeczywistą szerokość napisu i zmniejsza go tylko wtedy, gdy nie mieści się w przydzielonym polu. Bez emulatora lub zegarka nie można zagwarantować, że `-12°C` zawsze będzie pokazane tą samą wielkością co `7°C`, szczególnie przy innych czcionkach lub większym ustawionym rozmiarze.

**Bez zmian:** kolejność (ostrzeżenie → termometr → temperatura), wszystkie alerty i ich progi, źródła aktualne/prognozowane, kolory, rotacja, pole odczuwalnej, IMGW wyłączone, testy oraz identyfikator aplikacji. Potwierdzenie wyglądu wymaga kompilacji SDK i sprawdzenia na Garminie.

---

# Solar Rings 7X v3.24.9 — ostrzeżenie po lewej, termometr bliżej temperatury

**Jedyna zmiana funkcjonalna względem v3.24.7:** zamiana kolejności dwóch małych ikonek w dolnym wierszu. Teraz **ostrzeżenie pogodowe** jest po lewej, możliwie blisko pionowego separatora, a **termometr** znajduje się po jego prawej stronie, bliżej samej temperatury.

Nowa geometria dolnego wiersza przy aktywnych markerach:
- ostrzeżenie pogodowe: x=120,
- termometr: x=140 (lub x=136, gdy jest sam),
- temperatura: środek x=186, szerokość 74 px,
- opis / odczuwalna: środek x=166.

**Bez zmian:** wszystkie progi, rotacja co 5 s, czerwone/błękitne ostrzeżenia, prognoza 1/2/3h, testy podglądowe, termometr poniżej / powyżej ustawionych progów oraz identyfikator aplikacji.

---


**Jedyna zmiana funkcjonalna względem v3.24.6:** ikonka ostrzeżenia pogodowego została przesunięta bardziej w lewo, a razem z nią lekko skorygowany został cały duet markerów i pozycja temperatury. Celem jest luźniejszy wizualnie układ i większy zapas po prawej stronie przy temperaturze.

Nowa geometria dolnego wiersza przy aktywnych markerach:
- termometr: x=116 (lub x=136, gdy jest sam),
- ostrzeżenie pogodowe: x=136,
- temperatura: środek x=188, szerokość 70 px,
- opis / odczuwalna: środek x=168.

**Bez zmian:** wszystkie progi, rotacja co 5 s, czerwone/błękitne ostrzeżenia, prognoza 1/2/3h, testy podglądowe, termometr poniżej / powyżej ustawionych progów oraz identyfikator aplikacji.

---


**Jedyna zmiana funkcjonalna względem v3.24.5:** dolny blok z ostrzeżeniami pogodowymi, termometrem i temperaturą został przesunięty bardziej w lewo. Dzięki temu po prawej stronie jest większy zapas miejsca dla wartości typu `20°C`, `30°C` oraz `-12°C`, także gdy jednocześnie widać termometr i ikonę ostrzeżenia pogodowego.

Nowa geometria dolnego wiersza przy aktywnych markerach:
- termometr: x=124 (lub x=144, gdy jest sam),
- ostrzeżenie pogodowe: x=144,
- temperatura: środek x=190, szerokość 68 px,
- opis / odczuwalna: środek x=170.

**Bez zmian:** wszystkie progi, rotacja co 5 s, czerwone/błękitne ostrzeżenia, prognoza 1/2/3h, testy podglądowe, termometr poniżej / powyżej ustawionych progów oraz identyfikator aplikacji.

---


**Jedyna zmiana funkcjonalna względem v3.24.4:** poprawa szerokości i położenia pola temperatury w dolnym panelu. Przy widocznych ikonach termometru i/lub ostrzeżenia tekst temperatury jest wyśrodkowany w x=162..230 (zamiast niebezpiecznego położenia x=211 z szerokością 90), a jego rozmiar automatycznie dopasowuje się do szerokości. Dzięki temu tekst, np. 20°C, 30°C czy -20°C, nie powinien wystawać poza ekran. Opis pogody / odczuwalna pozostał wyśrodkowany na x=174, także gdy pojawią się ostrzeżenia, zamiast przeskakiwać zbyt daleko w prawo.

**Bez zmian:** włączane termometry poniżej 0°C i powyżej 30°C (wartości konfigurowalne w Connect IQ), osobna ikona ostrzeżeń, jej kolory czerwony/błękitny według źródła, rotacja co 5 s tam, gdzie Garmin pozwala na partial update, dane bieżące i prognoza 1/2/3h, progowe prawdopodobieństwa i filtry intensywności, testy 1–13, pozostałe pola oraz ustawienia. Identyfikator aplikacji i klucze konfiguracji są zachowane.

**Kontrola:** Testy Python i XML w paczce potwierdzają ograniczenie szerokości pola, zachowanie progów i ikon. To nie jest jeszcze dowód kompilacji Garmin SDK ani poprawnego wyświetlenia na fizycznym zegarku; należy skompilować i sprawdzić.

---

# Solar Rings 7X v3.24.9 — poprawione tryby testowe i alerty pogodowe

Kompletny projekt Monkey C na Garmin fēnix 7X Pro Solar (również wariant bez Wi-Fi).
Zbudowany na bazie v3.24.4; ten sam identyfikator aplikacji i istniejące
klucze ustawień (`...V324`), żeby zachować personalizację tarczy.

## Trzy kluczowe sytuacje — dokładne zasady

1. **Zjawisko w ostatnich warunkach bieżących:** CZERWONA ikona (0xFF0000).
   Dane z `Weather.getCurrentConditions()`. Używane tylko wtedy, gdy Garmin
   poda `observationTime` i obserwacja ma nie więcej niż 45 minut. To nie
   jest czujnik wykrywający zagrożenie w czasie rzeczywistym: to najnowsza
   obserwacja dostarczona przez Garmin.
2. **Zjawisko w prognozie godzinowej:** JASKRAWOBŁĘKITNA / CYJANOWA ikona
   (0x00FFFF). Dane z `Weather.getHourlyForecast()`, po sprawdzeniu
   `forecastTime` i progów. Pod uwagę brana jest bieżąca godzina prognozy
   oraz najbliższe 1, 2 lub 3 godziny w przyszłość według ustawień. Każda
   pozycja jest prognozą także wtedy, gdy dotyczy bieżącej godziny.
3. **To samo zjawisko jest teraz i w prognozie:** dokładnie JEDNA ikona,
   CZERWONA. Jeśli zniknie z aktualnych warunków, ale pozostanie w godzinowej
   prognozie, stanie się BŁĘKITNA przy następnej analizie danych.

**Różne zjawiska** (np. teraz silny wiatr, prognozowana burza) są w jednym
miejscu obok temperatury i zmieniają się co 5 s. W każdym wyświetleniu
zachowują własny kolor. Gdy jest tylko jedno zjawisko, ikonka jest stała.
Drugi, niezależny termometr zimna / gorąca pozostaje obok temperatury i nie
zmienia się podczas rotacji. Temperatura i „ODCZ.” zawsze bazują na
`Weather.getCurrentConditions()`, nie na prognozie.

Wysoki priorytet (np. burza) wpływa na kolejność rotacji, nie ukrywa innych
rodzajów ostrzeżeń. Ten sam rodzaj ostrzeżenia nie jest powielany dla różnych
godzin prognozy. Rodzaj zagrożenia rozpoznaje się po kształcie ikonki;
wszystkie zagrożenia bieżące mają ten sam czerwony kolor, prognozowane —
błękitny. To lokalne wskaźniki z danych Garmin Weather, nie oficjalne alerty.

## Co Garmin udostępnia — bez domysłów

Oficjalne Connect IQ API w urządzeniach fēnix 7X Pro zawiera:
- `Weather.getCurrentConditions()` → ostatnie zapisane warunki, także
  temperaturę, odczuwalną, wiatr, widoczność i czas obserwacji (pola mogą być `null`).
- `Weather.getHourlyForecast()` → tablicę prognoz godzinowych, każda z
  `forecastTime`, `condition`, `precipitationChance` (0–100%), `windSpeed`,
  `temperature`, `uvIndex` (dowolne pole może być `null`).

WAŻNE: `precipitationChance` to **ogólna szansa opadu**, nie wyliczona szansa
konkretnej burzy, gradu czy ulewy. Intensywność opadu jest oceniana wg
kategorii Garmin `CONDITION_HEAVY_RAIN`, `CONDITION_HEAVY_SHOWERS`,
`CONDITION_HEAVY_SNOW` itd.; brak danych o mm/h. W prognozie nie ma osobnej
widoczności, dlatego mgła przyszła wykrywana jest wyłącznie z kategorii.
Gołoledź jest ryzykiem szacowanym z warunków, nie czujnikiem śliskości jezdni.
Kategoria „szansa na burzę” w bieżących warunkach nie jest uznawana za
trwającą burzę — do błękitnego ostrzeżenia potrzebna jest osobna prognoza.

Garmin nie udostępnia czasu *wydania* całej prognozy godzinowej, więc nie
możemy udowodnić, jak świeża jest pobrana prognoza. Jeżeli `getHourlyForecast()`
zwróci `null`, tarcza nie generuje ostrzeżeń prognozowanych. Garmin może mieć
wybraną inną lokalizację pogody niż aktualna pozycja GPS.

## Jak przetestować na zegarku bez burzy

1. Wybierz dolne pole jako „POGODA”, „TEMP” lub „ODCZUW”. **Do testowania nie musisz włączać głównego przełącznika Garmin Weather.**
2. Otwórz „Podgląd ostrzeżeń (tylko TEST)”.
3. **TEST 10:** czerwona burza teraz + błękitny wiatr w prognozie.
   Rotacja powinna następować co 5 sekund.
4. **TEST 11:** burza teraz i w prognozie → jedna czerwona burza, bez rotacji.
5. **TEST 12:** wyłącznie prognoza burzy → jedna błękitna burza.
6. **TEST 13:** dwie czerwone i jedna błękitna ikona, rotacja co 5 s.
7. Zmień „Podgląd” na **Wyłączony** — odtąd działa analiza prawdziwej pogody.

W trybie obniżonego poboru energii 5-sekundowa zmiana jest realizowana przez
`WatchFace.onPartialUpdate()` rysujące tylko komórkę 20×22 px. Gdy Garmin
ograniczy odświeżanie ze względu na budżet energii, rotacja nastąpi dopiero
podczas najbliższego normalnego odrysowania (np. po minucie lub po geście).
Dlatego odstęp 5 s jest celem, a nie bezwzględną gwarancją w trybie oszczędnym.

## Domyślne progi i opcje

Włącznik główny ostrzeżeń: wyłączony po pierwszej instalacji.
Ponowna analiza zapisanych danych co 15 min (możliwe 5/15/30/60 min).
Prognoza: włączona, horyzont 1 h (możliwe 1/2/3 h).

- Intensywny deszcz: prognoza 60%, filtr intensywności włączony.
- Intensywny śnieg: prognoza 60%, filtr intensywności włączony.
- Burza: prognoza min. 50% ogólnej szansy opadów.
- Wiatr: 10 m/s (36 km/h), wg wartości liczbowej teraz lub w prognozie.
- Deszcz marznący: prognoza 40%.
- Grad: prognoza 40%.
- Mgła: aktualna widoczność do 500 m albo kategoria „mgła” w prognozie.
- Ryzyko oblodzenia: kategoria / temperatura i opady, zależnie od źródła.
- UV: wyłączone domyślnie.

Przełączniki i progi poszczególnych alertów są oddzielne i konfigurowalne.

## Kompilacja przez GitHub Actions

1. Umieść `SolarRings7X_v3_24_4_SOURCE.zip` w katalogu głównym repozytorium.
2. Umieść `SolarRings7X_v3_24_4_BUILD.yml` w `.github/workflows/`.
3. Uruchom workflow **Build Solar Rings 7X - Weather Sources v3.24.9**.
4. Pobierz artefakt `SolarRings7X_weather_v3244` i zainstaluj `.prg`
   dla `fenix7xpro`. Potrzebny jest dotychczasowy sekret
   `CONNECTIQ_DEVELOPER_KEY_BASE64` (ten sam klucz deweloperski).
5. Sprawdź podgląd testowy, później wybierz „Wyłączony”. Aby otrzymywać prawdziwe ostrzeżenia, włącz główny przełącznik Garmin Weather.

W paczce są testy lokalne i kontrola XML. Zweryfikowano 33 testy oraz
zgodność struktur. **Nie wykonywano kompilacji Monkey C w Garmin SDK ani
nie testowano prawdziwych danych na zegarku**: pierwszy build i test na
urządzeniu powinien potwierdzić zgodność, ram oraz zachowanie 5 s.

Źródła API: https://developer.garmin.com/connect-iq/api-docs/Toybox/Weather.html
https://developer.garmin.com/connect-iq/api-docs/Toybox/Weather/HourlyForecast.html
https://developer.garmin.com/connect-iq/api-docs/Toybox/Weather/CurrentConditions.html
https://developer.garmin.com/connect-iq/api-docs/Toybox/WatchUi/WatchFace.html

## Poprawka v3.24.9 (problem: test „Silny wiatr” bez ikonki)

- W v3.24.3 kod sprawdzał `gwOnV324` przed `gwPreviewV324`.
  Gdy rzeczywiste alerty były wyłączone, **każdy test milczał**.
- Od v3.24.9 testy 1–13 sprawdzane są **przed** przełącznikiem głównym.
  Działają bez danych pogodowych i bez przekroczenia progów.
- Testowa ikonka jest rysowana obok wartości w dolnym polu `POGODA`
  (ID 16), `TEMP` (ID 18) lub `ODCZUW` (ID 19).
  Jeśli w dolnym polu jest inny wskaźnik (np. wiatr lub tętno),
  nie ma obok niego ikonki ostrzeżenia — zgodnie z układem tarczy.
- Przez cały czas zachowano wcześniejsze klucze ustawień V324,
  identyfikator tarczy oraz kolory (czerwony / cyjanowy), duplikaty
  i rotację w trybie `onPartialUpdate`.
- Testy są statyczne, nie zastępują kompilacji Garmin SDK ani uruchomienia
  na prawdziwym zegarku. Jeśli tryb demonstracyjny nadal nie pojawi się
  przy wybranej dolnej temperaturze, trzeba sprawdzić logi zegarka lub
  sposób instalacji nowej wersji.
## v3.24.11 — wyrównanie temperatur
Górna temperatura jest wyrównana od lewej w chronionym obszarze X=148–227 przy ikonach. Szerokość tekstu mierzona na zegarku; dłuższe wartości rosną w prawo. Wiersz odczuwalnej podąża za środkiem górnej temperatury z ograniczeniem pozycji 166–174, aby zachować margines ekranu. Ikony i progi ostrzeżeń bez zmian.


## v3.24.17
Ikona zegara i odstęp od licznika wieku pogody. Od 60 minut czas ma format np. `1h30m`. Wersja synchronizowana w manifeście, testach i GitHub Actions.
