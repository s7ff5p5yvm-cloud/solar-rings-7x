from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT / "source/SolarRings7X.mc").read_text()
class WeatherAge32417(unittest.TestCase):
    def test_date_and_clock(self):
        self.assertIn('drawSized(dc, dateLabel, 197, 104, 58, 25', FACE)
        self.assertIn('drawSized(dc, dayLabel, 197, 80, 58, 23', FACE)
        self.assertIn('var cx = 97;', FACE)
        self.assertIn('var slotW = 164;', FACE)
    def test_icon_and_separation(self):
        self.assertIn('dc.drawCircle(234, 116, 5)', FACE)
        self.assertIn('dc.drawLine(234, 116, 234, 113)', FACE)
        self.assertIn('drawSized(dc, ageLabel, 260, 104, 36, 24', FACE)
    def test_minutes_hours(self):
        self.assertIn('ageLabel = "1h";', FACE)
        self.assertIn('remainingMinutes.toString() + "m"', FACE)
        self.assertIn('current.observationTime.value()', FACE)
        self.assertIn('drawWeatherAge(dc, w);', FACE)
    def test_version(self):
        for p in [ROOT/'manifest.xml',ROOT/'check_version.py',ROOT/'tests/test_final_no_imgw.py',ROOT/'tests/test_warning_sources.py']:
            self.assertIn('3.24.17',p.read_text())
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.24.17')
if __name__ == '__main__': unittest.main()
