# Solar Rings 7X v3.24.25 — lokalizacja pogodowa + termometr

Wersja oparta na **v3.24.24**. Bez zmian w progach ostrzeżeń, StormGuard,
rotacji ikon, dacie pełni, paskach, Bluetooth, czujnikach i ładowaniu.

## Zmiany

- Ikona termometru jest wyłącznie **obok temperatury**: x=142, y=224.
  Neutralna przy zwykłej temperaturze, niebieska poniżej ustawionego progu
  zimna, pomarańczowa ponad progiem gorąca. Zachowuje ustawienia progów.
  Nie zajmuje żadnego miejsca w lewym centrum alertów.
- Lewy alert-center: tylko **StormGuard na pierwszej pozycji** (jeśli aktywny)
  i ikony ostrzeżeń Garmin Weather, z dotychczasową logiką priorytetu i rotacji
  jedynie przy więcej niż czterech aktywnych ostrzeżeniach.
- W panelu Księżyca nowa lokalizacja jest odczytywana z
  `Weather.getCurrentConditions().observationLocationPosition.toDegrees()`.
  Tarcza wyszukuje najbliższy punkt spośród **115 statycznych nazw miast**
  w lokalnej tabeli. Maksymalny promień dopasowania: około 30 km.
  Gdy brak dopasowania, wyświetla współrzędne (np. `50.10,19.90`).
  Gdy Garmin nie udostępni także współrzędnych ani nazwy: `BRAK LOK.`.
  Opcjonalne `observationLocationName` nadal wspierane jako rezerwowe źródło.
- **Uwaga:** to przybliżona nazwa pobliskiego miasta wyliczona z współrzędnych
  udostępnianych przez Garmin Weather, **nie oficjalna nazwa stacji**.
  Garmin może zwrócić `null` także w `observationLocationPosition`; tarcza nie
  uruchamia GPS, nie pobiera danych z sieci i nie udaje nazwy miasta.

## Energooszczędność

- Brak dodatkowych żądań internetowych, geokodowania i uruchamiania GPS.
- Wykorzystanie aktualnie buforowanego obiektu Garmin Weather.
- Wynik wyszukiwania miasta jest zapamiętany, dopóki współrzędne nie zmienią się
  o ok. 0,01 stopnia (około 1 km); rysowana jest tylko tekstowa etykieta.
- Wszystkie istniejące bufory/opt. v3.24.24 zostały zachowane.

## GitHub Actions

1. Wgraj `SolarRings7X_v3_24_25_SOURCE.zip` do **głównego katalogu** repo.
2. Zastąp aktywny workflow `.github/workflows/*.yml` dostarczonym
   `SolarRings7X_v3_24_25_BUILD.yml` (usuń stare konkurencyjne workflow).
3. Uruchom `Build Solar Rings 7X - Weather Sources v3.24.25`.
4. Pobierz `SolarRings7X_weather_v32425` i zainstaluj `SolarRings7X_v32425.prg`.

## Zakres testów

W lokalnym Pythonie: regresja i statyczne kontrole źródeł oraz XML.
**Brak kompilacji Garmin Monkey C SDK / testu na realnym zegarku**.
Po wgraniu sprawdź temperaturę (w szczególności -12°C), 4 ikony ostrzeżeń,
napis z miastem i to, czy brak współrzędnych nie wyłącza tarczy.
Zachowaj v3.24.24 na wypadek problemów.
