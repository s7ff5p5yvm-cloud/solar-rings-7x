"""v3.24.25 weather-position city and temperature-lane regression checks.
These are static tests, not a Garmin SDK compile or device simulation.
"""
import unittest, re
from pathlib import Path
R=Path(__file__).resolve().parents[1]
F=(R/'source/SolarRings7X.mc').read_text()
C=(R/'source/WeatherCity.mc').read_text()

class WeatherCityAndTemperature32425(unittest.TestCase):
    def test_weather_coordinates_and_offline_battery_optimization(self):
        moon=F.split('function drawMoonPanel(')[1].split('function topSlot(')[0]
        self.assertIn('weather.observationLocationPosition.toDegrees()',moon)
        self.assertIn('srWeatherCityFromDegrees(latitude, longitude)',moon)
        self.assertIn('_locationCache[0] == keyLat',moon)
        self.assertIn('BRAK LOK.',moon)
        self.assertIn('weather.observationLocationName',moon)
        self.assertNotIn('Activity.getActivityInfo()',moon)
        self.assertIn('"KRAKÓW", 50.0647d, 19.9450d',C)
        self.assertIn('"ZAKOPANE", 49.2992d, 19.9496d',C)
        self.assertIn('"WARSZAWA", 52.2297d, 21.0122d',C)
        self.assertIn('900.0d',C)
        self.assertNotIn('makeWebRequest',C)
        self.assertNotIn('enableLocationEvents',C)
        self.assertNotIn('getCurrentConditions',C)
        self.assertNotIn('getCurrentLocation',C)

    def test_thermometer_always_beside_the_temperature(self):
        weather=F.split('function drawWeather(dc, monitor, weather)')[1].split('function drawAlertGlyph(')[0]
        self.assertIn('if (isTemp) { temperatureMarker(dc, weather, 142, 224); }',weather)
        marker=F.split('function temperatureMarker(')[1].split('function warningCloud(')[0]
        self.assertIn('warningThermometer(dc, x, y, color);',marker)
        self.assertIn('temp > hot',marker)
        self.assertIn('temp < cold',marker)
        self.assertEqual(142-4,138)
        self.assertGreaterEqual(138-133,5)
        self.assertLess(142+4,148)
        self.assertLessEqual(224+9,233)
        self.assertIn('drawWeatherTemperature(dc, shownTemp, 148, 227)',weather)

    def test_alert_center_never_contains_temperature(self):
        center=F.split('function drawAlertCenter(')[1].split('// Battery footer')[0]
        self.assertIn('_storm.warning()',center)
        self.assertIn('_weatherWarnings.allWarnings(weather)',center)
        self.assertLess(center.index('active.add(-1)'),center.index('active.add(warnings[i])'))
        self.assertNotIn('active.add(-2)',center)
        self.assertNotIn('active.add(-3)',center)
        self.assertNotIn('temperatureMarker(',center)
        glyph=F.split('function drawAlertGlyph(')[1].split('function drawAlertCenter(')[0]
        self.assertNotIn('tag == -2',glyph)
        self.assertNotIn('tag == -3',glyph)
        self.assertIn('drawGarminWarningIcon(dc, x, 228, tag)',glyph)

    def test_moon_bluetooth_charging_stormguard_and_warning_rotation_preserved(self):
        for x in ('drawLunarDisk(dc, 54, 147, 14)',
                  'srMoonDayInfo()', 'drawPhoneBluetooth(dc)',
                  'srSystemStatsForFrame().charging',
                  'var remainingSteps = monitor.stepGoal - doneSteps;',
                  'Time.now().value() / 5', 'function onPartialUpdate(dc)'):
            self.assertIn(x,F)
        storm=(R/'source/StormGuard.mc').read_text()
        self.assertIn('now - _lastCheck < 300',storm)
        self.assertEqual(storm.count('History.getPressureHistory('),1)

if __name__ == '__main__': unittest.main()
