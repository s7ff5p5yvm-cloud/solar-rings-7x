#!/usr/bin/env python3
from pathlib import Path
source=(Path(__file__).resolve().parents[1]/'source/ImgwService.mc').read_text()
face=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
assert 'statusChars[j].toNumber().format("%X")' in source
assert '_httpStatus = hexHeader;' in source
assert 'if (!status.equals("0")) {' in source
assert 'reason.find("H") == 0' in face
assert 'Bg.exit([_county, 0, 0, Time.now().value(), _lat, _lon, 12])' in source
# reference model of diagnostic, not a Garmin runtime test
for h, expected in [('0\v','H30.B'),('0\x00','H30.0'),('0\u2028','H30.2028'),('00','H30.30')]:
    raw='H'+'.'.join(format(ord(ch),'X') for ch in h[:3]); assert raw==expected,(h,raw,expected)
print('PASS: unexpected ULDK status exposes leading codepoints as hex; no false OK')
