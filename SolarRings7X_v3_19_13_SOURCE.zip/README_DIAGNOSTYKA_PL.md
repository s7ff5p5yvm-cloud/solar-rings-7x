# Solar Rings 7X v3.19.13 — naprawa błędu porównywania tekstu w Monkey C

Na zegarku pojawiał się `T3 H30` (0x30 = ASCII `0`).
Przyczyną błędnego odrzucenia prawidłowego statusu była linia
`if (status != "0")`, ponieważ operatory `==`/`!=` w Monkey C porównują
referencje do obiektów String, nie zawartość. Teraz stosujemy
`if (!status.equals("0"))`. Zachowana jest walidacja czterocyfrowego kodu powiatu.

Po instalacji: IMGW włączone, diagnostyka włączona, Test 3 – GUGiK,
odświeżanie co 5 minut. Prawidłowy wynik: `T3 #### OK`.
Dopiero potem Test 4 — pobieranie rzeczywistych ostrzeżeń IMGW.

Pozostałe funkcje bez celowych zmian. Testy lokalne nie zastępują
kompilacji Garmin SDK ani sprawdzenia na fizycznym zegarku.

---

# Solar Rings 7X v3.19.12 – precyzyjny test GUGiK

T3 F5-0 występował nadal na prawdziwym zegarku mimo normalizacji znaków w wersji 3.19.11.
Oznacza to, że sam fragment drukowalny pierwszego wiersza nie wystarcza do diagnozy.

W tej wersji gdy pierwszy wiersz odpowiedzi GUGiK jest niezgodny z oczekiwanym statusem `0`,
wyświetlamy jego rzeczywiste znaki jako kody szesnastkowe, np. `T3 H30.B`.
`30` to znak `0`; `B` to niedrukowalny znak U+000B. Zapisujemy najwyżej trzy
pierwsze znaki pierwszego wiersza, bez pozycji GPS.

Wynik `T3 #### OK` w dalszym ciągu pojawi się WYŁĄCZNIE po prawidłowym statusie
oraz czterocyfrowym kodzie powiatu. Nie używać testu 4 przed takim wynikiem.

Ustaw IMGW: Test 3, aktualizacja co 5 minut. Odczytaj `T3 H...` z zegarka.

Testy źródłowe są statyczne. Budowanie przez Garmin Connect IQ SDK
oraz działanie na zegarku pozostają do zweryfikowania na GitHubie / Garminie.
# Diagnostyka GUGiK — v3.19.11

**Problem z poprzedniej wersji:** na zegarku przy T3 pojawia się `T3 F5-0`.
W aktualnym parserze taki kod oznacza, że serwer zwrócił pierwszy wiersz
zawierający znak `0`, ale pierwszy wiersz *nie jest dokładnie równy* `0`
po usunięciu zwykłych spacji, tabulatorów i CR. **To nie potwierdza,
że przyczyną jest BOM**, ale wskazuje miejsce błędu.

**Zmiana:** sprawdzanie pierwszego wiersza znak po znaku (`toCharArray`)
i pomijanie wyłącznie znanych niewidocznych znaków formatowania (BOM U+FEFF,
NBSP U+00A0, ZWSP U+200B, WORD JOINER U+2060) oraz ASCII spacji/CR/tab.
Kod statusu nadal musi być *dokładnie* równy `0` po normalizacji.
Kod powiatu nadal musi zawierać dokładnie cztery cyfry i nie może zawierać
piątej cyfry. Dodano symulowane przypadki, w których parser ma odrzucić
status 1, -1, 00, 0error i 0;invalid. Nie zmieniono samego adresu
zapytania do GUGiK ani API IMGW.

**Test:** włącz IMGW, diagnostykę, etap 3 (GUGiK) i odświeżanie co 5 min.
Sukces = `T3 #### OK` (czterocyfrowy kod TERYT powiatu).
Jeżeli nadal wystąpi `F5-0`, potrzebny będzie dokładniejszy podgląd
surowej odpowiedzi GUGiK; nie uznawaj tego za poprawne dane.
Nie przechodź do etapu 4, dopóki etap 3 nie zwróci prawidłowego kodu.

UWAGA: testy Pythona odwzorowują logikę parsera, ale nie są testami
rzeczywistego wykonania Monkey C na fizycznym zegarku.

## Naprawa testu GitHub Actions (v3.19.11)

W workflow v3.19.9 krok "Live upstream IMGW + county geocoding check" zwracał błąd
`UnicodeDecodeError: invalid start byte 0x8b` przy próbie odczytu IMGW.
To typowy objaw nierozpakowanej odpowiedzi gzip (podpis `1f 8b`).
Teraz skrypt: żąda nieskompresowanej odpowiedzi, ale też rozpakowuje gzip
rozpoznany po nagłówku lub sygnaturze i *dopiero potem* parsuje JSON.
Dodano test offline `check_live_transport.py` na kompresję i błędne dane.

Ta zmiana naprawia test sieciowy w GitHub Actions. Kod pobierania IMGW i GUGiK
na zegarku jest pozostawiony bez zmian; `T3 F5-X` nadal wymaga osobnej
weryfikacji na urządzeniu. W `manifest.xml` poprawiono wersję aplikacji z
3.19.8 (przeoczenie w v3.19.9) na 3.19.10.

# Solar Rings 7X v3.19.11 — test odpowiedzi GUGiK

Poprzedni wynik na zegarku: **T3 F5** (odpowiedź HTTP 200, ale pierwszy wiersz ULDK nie miał statusu powodzenia `0`).

W tej wersji:
- zapytanie GetCountyByXY ma jawny adres URL zgodny z dokumentacją ULDK;
- parser toleruje spacje/CR wokół statusu, ale nigdy nie uznaje błędnego statusu za sukces;
- jeśli pierwszy wiersz jest niepoprawny, tarcza pokaże krótki fragment tego wiersza (`T3 F5-1`, `T3 F5--1`, `T3 F5-html` itp.);
- nie zmieniono pobierania GPS ani interwału IMGW.

## Test na zegarku
1. Zainstaluj nową wersję.
2. IMGW włączone, diagnostyka włączona, **Test 3 – GUGiK**, odświeżanie co 5 minut.
3. Poczekaj na wynik i odczytaj dokładny napis.
4. `T3 #### OK`: GUGiK poprawnie ustalił 4-cyfrowy kod powiatu. Dopiero wtedy test 4.
5. `T3 F5-X`: serwer zwraca status inny niż `0`. Przepisz X. Nie interpretuj tego jako braku ostrzeżeń.

`T3 F5-X` to kod diagnostyczny, nie kod powiatu. Kompilacja Garmin SDK i działanie na zegarku muszą zostać potwierdzone osobno.
