#!/usr/bin/env python3
"""Contract tests for a sample of the official IMGW OSMET-Teryt API.

These verify the upstream data shape and the expected user-visible outcomes;
they are not an execution of the Monkey C code on a Fenix device.
"""
from datetime import datetime
from pathlib import Path
import json

# Compact, faithful sample of the real OSMET-Teryt response observed 2026-11-13.
SAMPLE = {
    'warnings': {
        'Sk20261112115330694': {
            'PhenomenonName': 'Opady śniegu', 'Level': '1',
            'ValidFrom': '2026-11-13 04:00', 'ValidTo': '2026-11-13 12:00',
        },
        'Sk20261112115329929': {
            'PhenomenonName': 'Intensywne opady deszczu', 'Level': '2',
            'ValidFrom': '2026-11-12 22:00', 'ValidTo': '2026-11-13 13:00',
        },
        'Sk20261112103859097': {
            'PhenomenonName': 'Silny wiatr', 'Level': '1',
            'ValidFrom': '2026-11-13 01:00', 'ValidTo': '2026-11-14 06:00',
        },
    },
    'teryt': {
        '1211': ['Sk20261112115330694'],
        '1801': ['Sk20261112115329929', 'Sk20261112115330694'],
        '3205': ['Sk20261112103859097'],
    },
}

def parse_county(value):
    """Mirror the expected ULDK 0+newline+WWPP response contract."""
    if not isinstance(value, str) or not value.startswith('0\n'):
        return None
    code = value.split('\n', 1)[1][:4]
    return code if len(code) == 4 and code.isascii() and code.isdigit() else None


def classify(name):
    lowered = name.casefold()
    if 'burz' in lowered:
        return 1
    if 'wiatr' in lowered:
        return 2
    if 'marzn' in lowered or 'marzną' in lowered or 'gołoled' in lowered:
        return 6
    if 'śnieg' in lowered or 'śnież' in lowered:
        return 4
    if 'deszcz' in lowered or 'opad' in lowered:
        return 3
    return 13


def evaluate(data, county, now):
    assert isinstance(data['warnings'], dict) and isinstance(data['teryt'], dict)
    levels = []
    for warning_id in data['teryt'].get(county, [])[:25]:
        entry = data['warnings'].get(warning_id)
        if not isinstance(entry, dict):
            continue
        start = datetime.strptime(entry['ValidFrom'], '%Y-%m-%d %H:%M')
        end = datetime.strptime(entry['ValidTo'], '%Y-%m-%d %H:%M')
        level = int(entry['Level'])
        if start <= now <= end and 1 <= level <= 3:
            levels.append((level, classify(entry['PhenomenonName'])))
    if not levels:
        return 2, 0, 0  # Verified: no current warnings
    level, phenomenon = max(levels, key=lambda pair: (pair[0], -pair[1]))
    return 1, level, phenomenon


def main():
    now = datetime(2026, 11, 13, 11, 0)
    assert parse_county('0\n1211') == '1211'
    assert parse_county('0\n1261\n') == '1261'
    assert parse_county('1\n1261') is None
    assert parse_county('0\n12AA') is None
    assert evaluate(SAMPLE, '1211', now) == (1, 1, 4)  # Snow alert
    assert evaluate(SAMPLE, '1801', now) == (1, 2, 3)  # Rain over snow
    assert evaluate(SAMPLE, '3205', now) == (1, 1, 2)  # Wind alert
    assert evaluate(SAMPLE, '1261', now) == (2, 0, 0)  # No alerts, valid API
    assert evaluate(SAMPLE, '1211', datetime(2026, 11, 15, 11, 0)) == (2, 0, 0)  # Expired
    assert classify('Opady marznące') == 6
    assert classify('Opady śniegu') == 4
    # Verify actual Monkey C contains the required code contracts.
    root = Path(__file__).resolve().parents[1]
    service = (root/'source/ImgwService.mc').read_text()
    face = (root/'source/SolarRings7X.mc').read_text()
    for fragment in ('if (ids != null && ids instanceof Lang.Array)',
                     'var warning = warnings[ids[i].toString()]',
                     'if (start < 0 || end < 0) { stop(9); return; }',
                     'bestLevel > 0 ? 1 : 2',
                     'stop(3)', 'stop(6)', 'stop(8)', 'stop(9)'):
        assert fragment in service, fragment
    for fragment in ('IMGW: BRAK GPS', 'TEST 2: CZEKA', 'IMGW: SIEC/API',
                     'IMGW: FORMAT API', 'IMGW: WYGASLO', ': ALERT', ': OK 0'):
        assert fragment in face, fragment
    print('PASS: sample IMGW 2026-11-13; powiat, active/expired/no-warning, level, snow vs freezing rain and UI status')

if __name__ == '__main__':
    main()
