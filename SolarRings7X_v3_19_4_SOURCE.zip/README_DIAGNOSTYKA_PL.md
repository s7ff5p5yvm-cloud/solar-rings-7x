# Solar Rings 7X v3.19.4 — wersja diagnostyczna bez kabla USB

Problem: tarcza Garmin znika po wlaczeniu IMGW. Status `IMGW: CZEKA`
znaczy jedynie, ze dane jeszcze nie przyszly. **Nie** potwierdza, ze lacznosc
z serwerem zadzialala. Nie przedstawiamy zalozonej przyczyny jako potwierdzonej.

## Test w pieciu etapach (nie musisz miec kabla ani logu)

Zainstaluj ZIP + workflow z tej samej wersji. W Connect IQ ustaw:
- IMGW = wlaczone
- IMGW: pokaz status diagnostyczny = wlaczone
- IMGW: odswiezanie = 5 minut (test)
- Dolne pole = Pogoda albo Temperatura
- IMGW: etap testowania = 0 (poczatkowo)

0. `0 - Ekran (bez GPS i internetu)`: status `TEST 0: EKRAN OK`. Nie
   wlacza GPS ani zadania w tle. Poczekaj, czy tarcza pozostaje na ekranie.
1. `1 - GPS zegarka`: status `TEST 1: GPS OK`, `BRAK GPS` lub `GPS STARY`.
   Brak GPS nie powoduje bledu. Nadal bez zadania w tle.
2. `2 - Zadanie w tle (bez internetu)`: po uruchomieniu zadania powinno byc
   `TEST 2: TLO OK`; wczesniej `TEST 2: CZEKA`. Zadanie nic nie pobiera.
3. `3 - GPS i GUGiK (bez IMGW)`: po uruchomieniu zadania `GUGIK 1261: OK`
   (1261 to jedynie przyklad) oznacza wyznaczenie rzeczywistego kodu powiatu.
4. `4 - Pelne IMGW na zywo`: status `IMGW XXXX: OK 0` lub
   `IMGW XXXX: ALERT` oznacza potwierdzona odpowiedz obu serwerow;
   w razie bledu `IMGW: SIEC/API` lub `IMGW: FORMAT API`.

Zmiana etapu = zmiana ustawienia w Connect IQ. Przełączaj **jeden etap na raz**.
Jezeli tarcza znika, zanotuj numer etapu i czy zdazyl sie pojawic status.
Jesli otrzymasz `CZEKA`, daj urzadzeniu czas na wyzwolenie zadania w tle.
Garmin nie gwarantuje natychmiastowego uruchomienia po zmianie ustawien.

## Uwaga

Ta wersja jest przeznaczona do ustalenia miejsca awarii. W etapach 0-3
**nie ma dzialajacych ostrzezen IMGW**. Nie uzywaj ich jako zrodla
informacji o zagrozeniach pogodowych. W etapie 4 dzialanie zalezy od
odpowiedzi serwerow, lacznosci z telefonem i limitow pamieci.

Nie wykonano kompilacji w Garmin SDK ani testu na fizycznym zegarku w tym
srodowisku. Testy kodu lokalnie sprawdzaja spojnosc etapow, XML i logike
przykladowych odpowiedzi; nie dowodza, ze Garmin skompiluje urzadzeniowy PRG.
