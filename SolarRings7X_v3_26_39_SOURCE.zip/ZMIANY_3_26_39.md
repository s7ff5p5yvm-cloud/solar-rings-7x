# Solar Rings 7X v3.26.39 – testowy hotfix 3.26.38

Baza: 3.26.37 (nienaruszona), z trzema dostawcami dodanymi w testowej 3.26.38.

## Naprawa GitHub Actions
- SOURCE.zip i BUILD.yml są generowane razem; workflow zapisuje SHA-256
  rzeczywiście dołączonego ZIP i sprawdza wersję manifestu.
- Stary hash 3.26.38 był nieprawidłowy, co uniemożliwiało nawet rozpakowanie źródeł.

## Photon — co wykryto w kodzie i poprawiono
- OWM mógł odkładać Photon w każdym cyklu, gdy aktualna pogoda była do pobrania.
  Po pierwszym uzyskanym CURRENT nazwa dostaje własny cykl, bez drugiego żądania w tym samym przebudzeniu.
- Próba Photon w OWM była podejmowana przed sprawdzeniem łączności z telefonem,
  a niepowodzenie mogło powodować 3-godzinną blokadę bez kodu diagnostycznego.
- Zapytanie reverse korzysta z radius=5 km oraz co najwyżej 3 wyników
  z tagiem `place`. To zwiększa szanse na nazwę osady, której punkt OSM leży dalej niż domyślny mały promień.
- Czas retry: pierwsze niepowodzenie 10 minut, kolejne 20/30 minut;
  HTTP 429: 60 minut. Sukces jest buforowany dla danej lokalizacji.
- Garmin Weather i OWM/Meteo zapisują liczbowy stan ostatniego zapytania:
  [UTC, dostawca 0/1/2, etap, kod HTTP, przyczyna] pod kluczem srGDiagV32639.
- TEST 21 pokazuje etap, kod HTTP, przyczynę, wiek ostatniej próby,
  termin następnej próby oraz czy zapisano rozpoznaną nazwę.
- W OWM jednorazowa migracja zeruje historyczną karę 3–24 h z poprzednich wersji.
- Diagnostyka nie przechowuje współrzędnych, kluczy API ani treści HTTP.

**Uwaga:** bez logów diagnostycznych z urządzenia nie można ustalić,
który z możliwych powodów faktycznie wystąpił w konkretnym miejscu.
Testy źródeł nie są symulacją pełnego Garmin SDK ani testem na zegarku.
