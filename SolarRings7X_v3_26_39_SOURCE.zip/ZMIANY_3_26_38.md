# Solar Rings 7X v3.26.38 — eksperymentalny trzeci dostawca Open-Meteo

## Podstawa
Dokładna kopia stabilnej v3.26.37. Garmin Weather i OWM zachowują obecne pobieranie, wygląd, ostrzeżenia, baterię (ułamek %) i wspólny Photon. Open-Meteo to trzeci, opcjonalny wybór; v3.26.37 pozostaje paczką do powrotu.

## Open-Meteo
- Endpoint prognozy `https://api.open-meteo.com/v1/forecast` (automatyczny model `best_match`, bez klucza), AQI `https://air-quality-api.open-meteo.com/v1/air-quality` (European AQI przybliżony do istniejących 5 kategorii). Współrzędne jak w OWM, bez uruchamiania GPS. Photon nadal rozpoznaje nazwę dla współrzędnych.
- Ten sam wybrany profil 5/15/30/60 min i budżet jednego zapytania HTTP na wybudzenie zadania, co OWM. Przy profilu 5 min teraz i prognoza docelowo co ~10 min, a prognoza 15-min ma 12 rekordów. Pełny nowy model nie powstaje co 5 minut; to interwał zapytań tarczy.
- Minimalna odpowiedź: current + sunrise/sunset; prognoza `minutely_15` (tylko weather_code/rain/snowfall, do 12 kroków) i pomocnicze `hourly` (temperatura, wiatr, porywy, widzialność, UV, prawdopodobieństwo); daily; osobno opcjonalnie AQI. W razie błędu 15-min przejście na godzinową, a nie crash. Brak danych pozostaje brakiem danych.
- 28 opublikowanych kodów WMO oraz 97 jako dodatkowy kod defensywny: tabela OPEN_METEO_WMO_MATRIX.csv. Kod 299 jest wyłącznie prywatnym znacznikiem WMO 96/99 (burza z gradem), **nigdy** identyfikatorem OWM. Ostrzeżenia i ikony korzystają ze stabilnego silnika OWM po konwersji.
- Test 15 pokazuje raw WMO i wewnętrzne ID; testy 16–20 pokazują statusy i snapshoty dla aktywnego źródła. Identyfikatory WMO w diagnostyce są dostępne tylko dla trybu Open-Meteo.
- Stan danych chroniony `srOLastModeV326`: po przełączeniu OWM ↔ Open-Meteo nie wyświetla się poprzedni dostawca. Migracja Open-Meteo jest opóźniona do zadania BG i nie uruchamia serii zapisów podczas rysowania / zapisu ustawień.

## Ograniczenia i testy
To wariant **do testu**, nie „stabilny”. Testy Python sprawdzają strukturę źródeł i model zachowania. Brak kompilacji Monkey C SDK i testu na Fenix 7X Pro; testy źródeł **nie** dowodzą braku błędów pamięci i kompatybilności na zegarku. Jeśli nie działa, powrócić do v3.26.37 bez ingerencji w jej pliki.
