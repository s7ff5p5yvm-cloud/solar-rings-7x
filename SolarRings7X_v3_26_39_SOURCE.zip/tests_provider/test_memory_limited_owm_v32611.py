"""Solar Rings v3.26.13: static contracts for reducing JSON response size.
These tests cannot replace Monkey C SDK build or a live API call.
"""
from pathlib import Path
import unittest
P=Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
D=(P/'source/SolarOpenData.mc').read_text()
class RequestMemoryLimits(unittest.TestCase):
    def test_timeline_small_response_requested_at_server(self):
        self.assertIn('q["cnt"] = "12";',N)
        self.assertIn('q["cnt"] = "2";',N)
        self.assertIn('q["cnt"] = value("srOHourlyTinyV32611") == 1 ? "2" : "4";',N)
        self.assertLess(N.index('q["cnt"] = "12";'), N.index('Comm.makeWebRequest(route, q'))
    def test_oom_retry_once_with_two_rows(self):
        self.assertIn('kindIs("forecast") && !_shortRequest && code == -403',N)
        self.assertIn('write("srOHourlyTinyV32611", 1);',N)
        self.assertIn('write("srONextFV326", _now + 10 * 60);',N)
        self.assertIn('pause = 6 * 3600;',N)
    def test_new_version_resets_schedule_once(self):
        self.assertIn('diagVersion != 32612',D)
        self.assertIn('if (mode != 0 && resetDiag)',D)
        self.assertIn('srOwmWrite("srONextCV326", 0)',D)
        self.assertIn('srOwmWrite("srONextFV326", 0)',D)
        self.assertIn('srOwmWrite("srOHourlyTinyV32611", 0)',D)
    def test_no_new_network_calls_or_api_key_in_diagnostics(self):
        self.assertEqual(N.count('Comm.makeWebRequest('),2)
        self.assertNotIn('diagWrite("srOKey',N)
    def test_endpoints_still_include_current_and_both_timelines(self):
        for route in ('onecall/current','timeline/15min','timeline/1h'):
            self.assertIn(route,N)
if __name__ == '__main__': unittest.main()
