"""Regression contracts for Photon scheduling + diagnostics. Source-level checks only."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
P=Path(__file__).resolve().parents[1]
N=(P/'source/SolarOpenNetwork.mc').read_text()
G=(P/'source/WeatherGeocode.mc').read_text()
F=(P/'source/SolarRings7X.mc').read_text()
S=(P/'resources/settings/settings.xml').read_text()
R=(P/'resources/strings.xml').read_text()

class Photon39Tests(unittest.TestCase):
 def test_separate_status_screen(self):
  self.assertIn('value="21">@Strings.gw_diag_21',S)
  self.assertIn('srGDiagV32639',F)
  self.assertIn('diagMode >= 16 && diagMode <= 21',F)
  self.assertIn('TEST 21: Photon',R)
 def test_limited_requests_per_wake(self):
  self.assertEqual(N.count('Comm.makeWebRequest('),2)
  self.assertIn('if (cityLookupDue())',N)
  self.assertIn('value("srOCurrV326") != null',N)
  self.assertIn('startCityLookup();\n                return;',N)
  self.assertIn('if (!Sys.getDeviceSettings().phoneConnected)',N)
 def test_avoid_3hour_lockout_and_reset_legacy_state(self):
  self.assertNotIn('write("srGNextAt", _now + 3 * 3600)',N)
  self.assertIn('if (value("srGPolicyV32639") != 1)',N)
  self.assertIn('cityRetry(code, reason)',N)
  self.assertIn('failures <= 1 ? 10 * 60',N)
  self.assertIn('http == 429',N)
  self.assertIn('var minutes = failures == 1 ? 10',G)
 def test_radius_response_safety(self):
  for s in [N,G]:
   self.assertIn('"radius" => "5"',s)
   self.assertIn('"osm_tag" => "place"',s)
   self.assertIn('"limit" => "3"',s)
   self.assertIn('instanceof Lang.Dictionary',s)
   self.assertIn('instanceof Lang.String',s)
 def test_compact_no_user_geodata_in_logs(self):
  self.assertIn('[_now, _meteo ? 2 : 1, stage, http, reason]',N)
  self.assertIn('[Time.now().value(), 0, stage, http, reason]',G)
  self.assertNotIn('diagWrite("srGDiagV32639", _loc)',N)
  self.assertNotIn('App.Storage.setValue("srGDiagV32639", _requestedLat)',G)
 def test_old_stable_ui_kept(self):
  self.assertIn('var top = 171;',F)
  self.assertIn('dc.drawRoundedRectangle(left, top, width, 39, 18);',F)
  self.assertIn('function srBatteryPercentText', (P/'source/FieldData.mc').read_text())

if __name__ == '__main__': unittest.main()
