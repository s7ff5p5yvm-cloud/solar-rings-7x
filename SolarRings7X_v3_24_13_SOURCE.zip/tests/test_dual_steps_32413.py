import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'source/SolarRings7X.mc').read_text()
class DualSteps(unittest.TestCase):
    def test_existing_modes_retained(self):
        xml=(ROOT/'resources/settings/settings.xml').read_text()
        for n in (0,1,2):
            self.assertIn(f'<listEntry value="{n}">@Strings.capsuleStepsMode_{n}</listEntry>',xml)
        self.assertIn('if (isCenter && srSetting("capsuleStepsModeV39", 0) == 1',SRC)
        self.assertIn('capsuleTrack(dc, left, top, width, d[2], col, stepsReached, showDone);',SRC)
    def test_dual_mode_is_separate(self):
        self.assertIn('srSetting("capsuleStepsModeV39", 0) == 2',SRC)
        self.assertIn('var remainingSteps = monitor.stepGoal - doneSteps;',SRC)
        self.assertIn('if (remainingSteps < 0) { remainingSteps = 0; }',SRC)
        segment=SRC.split('// Optional dual-line steps display')[1].split('var valueW = width - 35;')[0]
        self.assertEqual(segment.count('drawSized(dc,'),2)
        self.assertIn('return;',segment)
        self.assertNotIn('capsuleTrack(dc',segment)
    def test_xml_and_default(self):
        for f in ROOT.rglob('*.xml'): ET.parse(f)
        self.assertIn('<property id="capsuleStepsModeV39" type="number">0</property>',(ROOT/'resources/settings/properties.xml').read_text())
if __name__=='__main__': unittest.main()
