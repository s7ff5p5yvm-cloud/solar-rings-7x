# Solar Rings 7X v3.19.5 - test RAM bez kabla

Po niepowodzeniu wszystkich etapow w wersji 3.19.4 podejrzewamy
przeciazenie pamieci renderera albo uruchomienie wspolnego kodu przy zmianie
ustawien, NIE tylko pobieranie danych IMGW.

Co zmieniono: krotki komunikat testowy wyswietlany natywna czcionka bitmapowa,
bez dodatkowego tworzenia czcionek wektorowych; limit obiektow pamieci cache
czcionek = 20; awaryjne przejscie na natywne czcionki przy <18 KB RAM; mniej operacji na persistent Storage w testach 0/1.

W dolnym podpisie zobaczysz `T0 OK RnnK` albo `T1 OK RnnK`,
gdzie RnnK to przyblizona wolna pamiec aplikacji (KiB) przed
wyrenderowaniem tekstu diagnostycznego.

Ustawienia: IMGW wlaczone, status diagnostyczny wlaczony,
dolne pole Pogoda/Temperatura, etap 0. Zaobserwuj liczbe RnnK
i czy tarcza znika. Jesli etap 0 wywali tarcze, etap 2/3/4
nie ma sensu testowac na tym PRG. Przypadek etapu 0 nigdy
nie dotyka GPS ani HTTP (jedynie wspolne ustawienia aplikacji).

UWAGA: ten test nie dowodzi, ze IMGW dziala. Bez testu na fizycznym
Garminie nie ma potwierdzenia runtime. Obecne odpowiedzi etapow 2-4
sa diagnostyka, nie oficjalne ostrzezenia.
