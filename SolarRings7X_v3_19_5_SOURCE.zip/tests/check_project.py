#!/usr/bin/env python3
"""v3.19.5 static regression tests, not a Garmin SDK compile."""
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
mc=(r/'source/SolarRings7X.mc').read_text()
svc=(r/'source/ImgwService.mc').read_text()
config=(r/'source/Config.mc').read_text()
props=ET.parse(r/'resources/settings/properties.xml').getroot()
settings=ET.parse(r/'resources/settings/settings.xml').getroot()
strings=ET.parse(r/'resources/strings.xml').getroot()
manifest=ET.parse(r/'manifest.xml').getroot()
app=manifest.find('{http://www.garmin.com/xml/connectiq}application')
assert app.attrib['id']=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
assert app.attrib['version']=='3.19.5'
ids={e.attrib['id'] for e in props}
keys={e.attrib['propertyKey'].split('.')[-1] for e in settings}
assert len(keys)==len(list(settings))
assert all(k in ids for k in keys)
labels={e.attrib['id'] for e in strings}
for e in settings:
    assert e.attrib['title'].split('.')[-1] in labels
    for option in e.findall('.//listEntry'):
        assert option.text.split('.')[-1] in labels
assert len(list(settings)) == 35, len(list(settings))
assert len(ids) == 52, len(ids)
assert all(not (k.startswith('size') or k.startswith('font') or k=='moonFontV38') for k in keys)
assert 'imgwModeV317' not in keys and 'imgwVoivV317' not in keys
assert {'imgwOnV317','imgwMinutesV317','imgwDiagnosticsV3193','imgwTestStageV3194','stepDoneV314','tempAlertsV312','showFeelsLikeV319'} <= keys
assert 'if (key == "fontClockV31"' in config
assert 'ImgwServiceV318()' in mc
assert 'captureImgwLocation();' in mc
assert 'Position.getInfo()' in mc
assert 'fix.when.value()' in mc
assert 'approximateImgwWoj(' not in mc
assert 'imgwAutoWojV317' not in svc
assert 'GetCountyByXY' in svc
assert 'HTTP_RESPONSE_CONTENT_TYPE_TEXT_PLAIN' in svc
assert '"xy" => coords' in svc
assert '"teryt"' in svc and 'var ids = countyMap[_county];' in svc
assert 'https://meteo.imgw.pl/api/meteo/messages/v1/osmet/latest/osmet-teryt' in svc
assert 'warning["ValidFrom"]' in svc and 'warning["ValidTo"]' in svc
assert 'if (hasImgw && hasThermometer)' in mc
assert 'var showDone = stepsReached && srSetting("stepDoneV314", true);' in mc
assert 'dc.drawCircle(cx, cy, 5);' in mc
assert 'stormBolt(dc, 46, 147)' in mc
assert 'var slotW = 164;' in mc
assert 'function temperatureMarker' in mc
assert 'function bodyBatteryIcon' in mc
assert 'function intensityTimerIcon' in mc
assert 'function heart' in mc
assert 'function imgwAlert(dc, x, y, category, level)' in mc
for n in range(1,13):
    assert f'category == {n}' in mc, n
# Visual code separation: snow = cloud + flakes, freezing rain = drops + ice.
snow = mc.split('category == 4) { // Heavy snowfall: cloud + two snowflakes')[1].split('} else if (category == 5)')[0]
freeze = mc.split('category == 6) { // Freezing rain: two drops + ice sheet')[1].split('} else if (category == 8)')[0]
assert 'dc.fillCircle' in snow and 'dc.fillRectangle' in snow
assert snow.count('dc.drawLine') >= 4
assert 'dc.fillCircle' not in freeze and 'dc.drawLine' in freeze
assert 'x - 8, y + 4, x + 8, y + 4' in freeze
assert snow != freeze
for n in range(1,14):
    assert f'return {n};' in svc, n
for threshold in (0,1,2,3):
    assert threshold in [0,1,2,3]
perms={e.attrib['id'] for e in app.find('{http://www.garmin.com/xml/connectiq}permissions')}
assert {'Background','Communications','Positioning','SensorHistory'} <= perms
print('PASS: v3.19.5; optional feels-like, 35 phone settings, weather alarms and prior features')

# Opt-in feels-like, null-safe and preserves existing weather condition by default.
props_by_id={e.attrib['id']:e for e in props}
assert props_by_id['showFeelsLikeV319'].attrib['type']=='boolean'
assert (props_by_id['showFeelsLikeV319'].text or '').strip()=='false'
assert 'var lowerLabel = id == 16 ? conditionText(weather) : d[0];' in mc
assert 'if (isTemp && srSetting("showFeelsLikeV319", false)' in mc
assert 'weather.feelsLikeTemperature != null' in mc
assert '"ODCZ. " + weather.feelsLikeTemperature.format("%.0f") + "°C"' in mc
assert mc.count('drawSized(dc, lowerLabel, 174, 234, 105, 16,') == 1
assert 'if (hasThermometer) { temperatureMarker' in mc
assert 'if (hasImgw)' in mc
print('PASS: feels-like displays alongside main temperature; condition label retained if disabled/unavailable')

# Regression for SDK 9.3 compiler error "Invalid Method(... Any, Any)".
cb_type = 'responseCode as Lang.Number, payload as Lang.Dictionary or Lang.String or Lang.ByteArray or PersistedContent.Iterator or Null'
assert 'function onCountyResponse(' + cb_type + ') as Void' in svc
assert 'function onWarningsResponse(' + cb_type + ') as Void' in svc
assert 'function processWarnings(body as Lang.Object) as Void' in svc
assert 'if (!(body instanceof Lang.Dictionary))' in svc
assert 'var warning = warnings[ids[i].toString()];' in svc
assert 'function onCountyResponse(responseCode, payload)' not in svc
assert 'function onWarningsResponse(responseCode, payload)' not in svc
print('PASS: typed HTTP callbacks and IMGW JSON object handler')

# v3.19.5 runtime safety and official IMGW object response checks
assert 'var warnings = body["warnings"];' in svc
assert 'var countyMap = body["teryt"];' in svc
assert 'var ids = countyMap[_county];' in svc
assert 'bestLevel > 0 ? 1 : 2' in svc
assert 'function imgwDiagnosticLine()' in mc
assert 'var diag = isTemp ? imgwDiagnosticLine() : null;' in mc
assert 'warning["PhenomenonName"]' in svc
assert 'warning["Level"]' in svc
assert 'function getInitialView()' in mc and 'updateImgwScheduler();' in mc
assert 'function onStart(state)' in mc and 'AppBase.onStart(state);' in mc
assert 'function onBackgroundData(data)' in mc and 'try { Ui.requestUpdate(); } catch (e) { }' in mc
print('PASS: official OSMET object format; background scheduling guarded; data validation added')

# Ensure onStart() does not schedule recursively in the worker process.
app_start = mc.split('function onStart(state) {', 1)[1].split('function onSettingsChanged()', 1)[0]
assert 'updateImgwScheduler();' not in app_start
assert 'function getInitialView()' in mc and 'updateImgwScheduler();' in mc.split('function getInitialView()', 1)[1].split('function getServiceDelegate()',1)[0]
assert 'https://danepubliczne.imgw.pl/api/data/warningsmeteo", null,' not in svc
print('PASS: no recursive IMGW registration in background; official object endpoint selected')
