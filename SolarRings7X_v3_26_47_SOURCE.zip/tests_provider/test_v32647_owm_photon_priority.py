"""v3.26.47 workflow regression checks. Source checks + bounded scheduling model."""
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
NET=(ROOT/'source/SolarOpenNetwork.mc').read_text()
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
SSET=(ROOT/'resources/settings/settings.xml').read_text()
GEO=(ROOT/'source/WeatherGeocode.mc').read_text()

class OwmPhotonPriority47(unittest.TestCase):
    def test_essential_diagnostic_only(self):
        setting=next(el for el in ET.fromstring(SSET).findall('setting')
                     if el.get('propertyKey')=='@Properties.gwPreviewV332')
        self.assertEqual([int(x.get('value')) for x in setting.find('settingConfig')],[0,15,21])
        self.assertIn('function drawPhotonDiag(dc)',FACE)
        self.assertNotIn('function drawOpenDiagPage(',FACE)
        panel=FACE.split('function drawPhotonDiag(dc)')[1].split('function onUpdate(dc)')[0]
        self.assertNotIn('Comm.makeWebRequest(',panel)
        self.assertNotIn('srOwmForecastSnapshot()',panel)
        self.assertNotIn('srOwmVisibleCurrent()',panel)
        self.assertNotIn('var lines = []',panel)
    def test_weather_queue_order_and_only_when_idle(self):
        start=NET.index('if (nextF <= _now) { _kind = "forecast"; }')
        c=NET.index('else if (nextC <= _now) { _kind = "current"; }',start)
        d=NET.index('else if (nextD <= _now) { _kind = "daily"; }',c)
        a=NET.index('nextA <= _now) { _kind = "air"; }',d)
        city=NET.index('if (kindIs("") && cityLookupDue())',a)
        self.assertTrue(start<c<d<a<city)
        self.assertEqual(NET.count('Comm.makeWebRequest('),2)
    def test_hourly_bootstrap_even_if_15min_enabled(self):
        self.assertIn('if (!haveHourly && !haveShort) { return "srOHoursV326"; }',NET)
        self.assertIn('return "srOShortV3264";',NET)
        self.assertIn('srOShortPausedV3264',NET)
    def test_location_poll_and_retry_fast(self):
        self.assertIn('now - _lastOpenLocationPoll >= 5 * 60',FACE)
        self.assertIn('if (code == 429) { minutes = 60; }',NET)
        retry=NET.split('function cityRetry(code)')[1].split('function startCityLookup')[0]
        self.assertNotIn('24 * 3600',retry)
        self.assertIn('15 * 60',NET)
        self.assertIn('srGTraceV32647',NET)
        self.assertIn('srGTraceV32647',GEO)
    def test_scheduler_model_owm_first_idle_photon_eventually(self):
        # Model 5-minute wake, OWM 10-minute freshness and daily/AQI calls.
        next_at={'forecast':0,'current':0,'daily':0,'air':0,'photon':0}
        durations={'forecast':10,'current':15,'daily':720,'air':60,'photon':180}
        seen=[]
        for now in range(0,180,5):
            due=[p for p in ('forecast','current','daily','air') if next_at[p]<=now]
            if due: k=due[0]
            elif next_at['photon']<=now: k='photon'
            else: continue
            seen.append((now,k))
            next_at[k]=now+durations[k]
        self.assertEqual([x[1] for x in seen[:4]],['forecast','current','forecast','daily'])
        self.assertIn('photon',[x[1] for x in seen])
        self.assertLessEqual(next(t for t,p in seen if p=='photon'),60)
    def test_storage_schema_and_app_id_unchanged(self):
        from hashlib import sha256
        # Stable v3.26.46 properties hash, independent of local parent folders.
        expected='e15261174dcc2f3a47afe32df624683e8bf4eb34dc8c76f31968ac102125db63'
        self.assertEqual(sha256((ROOT/'resources/settings/properties.xml').read_bytes()).hexdigest(),expected)
        app=ET.parse(ROOT/'manifest.xml').getroot()[0]
        self.assertEqual(app.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')

if __name__=='__main__': unittest.main()
