import unittest
from pathlib import Path
import xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent.parent
class PositioningRegression(unittest.TestCase):
    def test_garmin_weather_position_permission_present(self):
        root=ET.parse(P/'manifest.xml').getroot()
        iq='{http://www.garmin.com/xml/connectiq}'
        names=[x.get('id') for x in root.findall('.//'+iq+'uses-permission')]
        self.assertIn('Positioning',names)
        self.assertEqual(1,names.count('Positioning'))
    def test_location_display_has_weather_position_fallback(self):
        s=(P/'source/SolarRings7X.mc').read_text()
        self.assertIn('weather.observationLocationName',s)
        self.assertIn('weather.observationLocationPosition.toDegrees()',s)
        self.assertIn('srWeatherCityFromDegrees(',s)
    def test_sunrise_sunset_location_fallback(self):
        s=(P/'source/FieldData.mc').read_text()
        self.assertIn('w.observationLocationPosition',s)
        self.assertIn('info.currentLocation',s)
        self.assertIn('Weather.getSunrise(location, now)',s)
        self.assertIn('Weather.getSunset(location, now)',s)
    def test_5min_weather_and_color_untouched(self):
        s=(P/'source/SolarRings7X.mc').read_text()
        self.assertIn('new Time.Duration(300)',s)
        self.assertIn('color = 0x00FFFF;',s)
        self.assertIn('hasForecastUnderline = true;',s)
    def test_no_owm_photon_or_http(self):
        allsrc='\n'.join(p.read_text() for p in (P/'source').glob('*.mc'))
        for x in ['makeWebRequest(', 'WeatherGuard(', 'srOwmProviderChanged(']:
            self.assertNotIn(x,allsrc)
if __name__ == '__main__': unittest.main()
