#!/usr/bin/env python3
"""Offline reference model for ULDK status parsing; not a Garmin SDK test."""
from pathlib import Path

ALLOWED = ' \t\r\ufeff\u00a0\u200b\u2060'

def parse(raw):
    if raw is None: return None,'1'
    if not isinstance(raw,str): return None,'2'
    if len(raw)<2: return None,'3'
    if '\n' not in raw: return None,'4'
    head, rest = raw.split('\n',1)
    status=''.join(ch for ch in head if ch not in ALLOWED)
    if status!='0':
        preview=''.join(c for c in status if c in '0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')[:4]
        return None, 'F5-'+(preview or '?')
    rest=rest.lstrip(ALLOWED + '\n')
    if len(rest)<4: return None,'6'
    code=rest[:4]
    if not code.isascii() or not code.isdigit() or (len(rest)>4 and rest[4].isdigit()):
        return None,'7'
    return code,'0'

cases=[
  ('0\n1261',('1261','0')),
  ('0\r\n1261\r\n',('1261','0')),
  (' 0 \r\n  1261',('1261','0')),
  ('\ufeff0\n1261',('1261','0')),
  ('0\ufeff\n1261',('1261','0')),
  ('\u00a00\u00a0\r\n1261',('1261','0')),
  ('0\u200b\n1261',('1261','0')),
  ('0\u2060\n\ufeff1261',('1261','0')),
  ('1\nerror',(None,'F5-1')),
  ('-1\nerror',(None,'F5--1')),
  ('00\n1261',(None,'F5-00')),
  ('0error\n1261',(None,'F5-0err')),
  ('0;invalid\n1261',(None,'F5-0inv')),
  ('<html>\nmessage',(None,'F5-html')),
  ('0\n12612',(None,'7')),
  ('0\n126x',(None,'7')),
  ('0\n12',(None,'6')),
  (None,(None,'1')),
  ('',(None,'3')),
  ('garbled',(None,'4')),
  ({},(None,'2')),
]
for raw, expected in cases:
    got=parse(raw)
    assert got == expected,(repr(raw),got,expected)

svc=(Path(__file__).resolve().parents[1]/'source/ImgwService.mc').read_text(encoding='utf-8')
assert 'var statusChars = header.toCharArray();' in svc
assert 'statusChars[h].toNumber()' in svc
for cp in ('0xFEFF','0x00A0','0x200B','0x2060'):
    assert cp in svc
assert 'if (status != "0") {' in svc
assert 'statusChars[j].toNumber().format("%X")' in svc
assert '_httpStatus = hexHeader;' in svc
assert 'if (pos + 4 > raw.length())' in svc
assert 'if (responseCode != 200)' in svc
assert 'Comm.makeWebRequest(url, null,' in svc
print('PASS: 21 ULDK response cases including BOM, Unicode separators and nonzero server statuses')
