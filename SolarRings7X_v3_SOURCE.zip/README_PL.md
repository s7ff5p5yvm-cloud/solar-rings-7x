# Solar Rings 7X — wersja 3.0.0 (3 pierścienie, 3 pola)

Odtworzony układ tarczy: godzina i data, trzy pola konfigurowalne,
trzy duże pierścienie, dolne dane pogody i baterii. Wszystkie osiem
slotów jest konfigurowalne z Connect IQ, jeśli aplikacja jest
zainstalowana **przez Connect IQ Store jako beta**, a nie ręcznie jako `.PRG`.

Domyślnie górne pola: wschód / faza Księżyca / zachód; pierścienie:
tętno / kroki / Body Battery; dół: pogoda / bateria.

Progress: tylko tam, gdzie istnieje sensowny cel, np. kroki i minuty
intensywne. Tętno nie ma ustalonego celu — pierścień jest neutralny.

Burza: wskaźnik opcjonalny (domyślnie wyłączony), wymaga co najmniej
2,5 godz. historii ciśnienia i wysokości oraz braku znaczącego ruchu
wysokościowego. Jest to jedynie orientacyjny wskaźnik trendu ciśnienia,
a nie gwarantowane ostrzeżenie meteorologiczne.

Wersja 3 nie jest jeszcze skompilowana na rzeczywistym Garmin SDK ani
przetestowana na zegarku. Przy pierwszej kompilacji sprawdź logi Actions.

## Wdrożenie

1. Rozpakuj pełny ZIP lub wgraj `SolarRings7X_v3_UPDATE.zip` do repozytorium.
2. Utwórz workflow `.github/workflows/apply-solar-rings-v3.yml` z osobnego pliku.
3. Actions → Apply Solar Rings v3 → Run workflow.
4. Actions → Build Garmin Solar Rings 7X → Run workflow. Nowa wersja musi
   zostać zatwierdzona jako `.IQ` w istniejącej aplikacji beta.
5. Zainstaluj aktualizację przez Connect IQ na iPhonie, a potem szukaj
   ustawień w sekcji **Moje tarcze / My Watch Faces** aplikacji Connect IQ.

Uwaga: skopiowanie `.PRG` przez USB do folderu GARMIN/APPS nie zapewnia
mechanizmu ustawień mobilnych Connect IQ.
