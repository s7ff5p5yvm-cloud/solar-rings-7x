#!/usr/bin/env python3
"""Quick static validation before actual Garmin SDK compilation."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
settings=ET.parse(root/'resources/settings/settings.xml').getroot()
properties=ET.parse(root/'resources/settings/properties.xml').getroot()
strings=ET.parse(root/'resources/strings.xml').getroot()
manifest=ET.parse(root/'manifest.xml').getroot()
p={x.get('id') for x in properties.findall('property')}
s={x.get('id') for x in strings.findall('string')}
assert len(p)==14 and len(s)==len(set(s))
assert len(settings.findall('setting'))==len(p)==14
for item in settings.findall('setting'):
    assert item.get('propertyKey','').startswith('@Properties.')
    assert item.get('propertyKey').split('.')[-1] in p
    assert item.get('title','').split('.')[-1] in s
    config=item.find('settingConfig')
    assert config is not None
    for entry in config.findall('listEntry'):
        assert entry.text.startswith('@Strings.') and entry.text.split('.')[-1] in s
app=list(manifest)[0]
assert app.get('version')=='3.0.0' and app.get('id')=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
face=(root/'source/SolarRings7X.mc').read_text()
assert face.count('topSlot(dc,') == 4 # definition + 3 calls
assert face.count('ring(dc,') == 4 # definition + 3 calls
assert 'stormBolt(dc, 251, 132)' in face
# Ring circle x=55,140,225 r=37; center y=174 -> top 137, bottom 211
# Main top rule=124, bottom rule=217 -> at least 6px clear vertical margins
for a,b in [(55,140),(140,225)]: assert b-a > 2*37
assert 174-37>124 and 174+37<217
print('STATIC CHECKS PASSED: 8 slots, 3 rings, 3 top, 14 phone options, no overlap in reserved circles')
