using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;

class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    function getInitialView() { return [new SolarRingsFaceV3()]; }
    function onSettingsChanged() { Ui.requestUpdate(); }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
    }

    // Choose only fonts that fit the measured bounding box on the *actual*
    // device. This avoids assuming that FONT_TINY has a fixed pixel height.
    function fit(dc, label, cx, top, maxWidth, maxHeight, white, large) {
        if (label == null) { return; }
        var str = label.toString();
        if (str.length() == 0) { return; }
        var digitsOnly = true;
        for (var q = 0; q < str.length(); q++) {
            var ch = str.substring(q, q + 1);
            if ("0123456789:".find(ch) == null) { digitsOnly = false; }
        }
        var fonts = large && digitsOnly
            ? [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM, Gfx.FONT_NUMBER_MILD,
               Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY]
            : [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
        var chosen = Gfx.FONT_XTINY;
        var w = 0;
        var h = 0;
        for (var i = 0; i < fonts.size(); i++) {
            var dims = dc.getTextDimensions(str, fonts[i]);
            if (dims[0] <= maxWidth && dims[1] <= maxHeight) {
                chosen = fonts[i]; w = dims[0]; h = dims[1];
                break;
            }
        }
        if (w == 0) {
            chosen = Gfx.FONT_XTINY;
            // Do not silently cut a five-digit step value.
            if (!(digitsOnly && str.length() <= 5)) {
                while (str.length() > 0 && dc.getTextWidthInPixels(str, chosen) > maxWidth) {
                    str = str.substring(0, str.length() - 1);
                }
            }
            if (str.length() == 0) { return; }
            h = dc.getFontHeight(chosen);
            if (h > maxHeight) { h = maxHeight; }
        }
        dc.setColor(white, Gfx.COLOR_TRANSPARENT);
        dc.drawText(cx, top + (maxHeight - h) / 2, chosen, str, Gfx.TEXT_JUSTIFY_CENTER);
    }

    function rule(dc, y) {
        dc.setColor(0x555555, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(30, y, 250, y);
    }

    function sunIcon(dc, x, y, settingSun) {
        dc.setColor(settingSun ? Gfx.COLOR_YELLOW : Gfx.COLOR_ORANGE,
                    Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 5, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 9, y, x + 9, y);
        dc.drawLine(x, y - 9, x, y - 6);
        dc.setPenWidth(1);
    }

    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 2, 4);
        dc.fillCircle(x + 4, y - 2, 4);
        dc.fillRectangle(x - 5, y, 10, 4);
        dc.drawLine(x - 7, y + 2, x, y + 9);
        dc.drawLine(x, y + 9, x + 7, y + 2);
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, 7);
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x + 4, y - 2, 7);
    }

    function cloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 7, y + 2, 5);
        dc.fillCircle(x, y - 2, 7);
        dc.fillCircle(x + 8, y + 2, 5);
        dc.fillRectangle(x - 11, y + 2, 23, 6);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3 || id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { stopwatch(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }

    function topSlot(dc, x, id, monitor, weather) {
        if (id == 0) { return; }
        var data = readField(id, monitor, weather);
        drawIcon(dc, x, 82, id, 0x00AAFF);
        fit(dc, data[1], x, 92, 75, 25, Gfx.COLOR_WHITE, false);
    }

    function ring(dc, x, id, colorCode, monitor, weather) {
        if (id == 0) { return; }
        var data = readField(id, monitor, weather);
        var y = 174;
        var rad = 37;
        var col = srColor(colorCode);
        dc.setPenWidth(5);
        dc.setColor(0x555555, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, rad);
        var ratio = data[2];
        if (ratio == null) {
            // Thin colored outline: this metric has no meaningful goal.
            dc.setPenWidth(2);
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            dc.drawCircle(x, y, rad);
            dc.setPenWidth(5);
        } else {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, rad);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end = end + 360; }
                dc.drawArc(x, y, rad, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
        drawIcon(dc, x, 156, id, col);
        fit(dc, data[1], x, 171, 67, 29, Gfx.COLOR_WHITE, true);
    }

    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 54, 234, id, 0x00AAFF);
        fit(dc, d[1], 118, 219, 76, 28, Gfx.COLOR_WHITE, true);
        if (id == 16) {
            fit(dc, conditionText(weather), 197, 222, 94, 24,
                Gfx.COLOR_LT_GRAY, false);
        } else {
            fit(dc, d[0], 197, 222, 94, 24, Gfx.COLOR_LT_GRAY, false);
        }
    }

    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 109, 263, id, Gfx.COLOR_GREEN);
        fit(dc, d[1], 159, 252, 63, 25, Gfx.COLOR_WHITE, false);
    }

    function onUpdate(dc) {
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var now = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND","PN","WT","SR","CZ","PT","SB"];
        var months = ["STY","LUT","MAR","KWI","MAJ","CZE","LIP","SIE","WRZ","PAZ","LIS","GRU"];

        fit(dc, twoDigits(now.hour) + ":" + twoDigits(now.min), 111, 10,
            158, 56, Gfx.COLOR_WHITE, true);
        fit(dc, days[date.day_of_week - 1], 219, 20, 50, 23,
            Gfx.COLOR_WHITE, false);
        fit(dc, date.day.toString() + " " + months[date.month - 1], 219, 42,
            70, 20, Gfx.COLOR_LT_GRAY, false);
        rule(dc, 68);

        var info = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }
        topSlot(dc, 57, srSetting("slotTop1V3", 14), info, w);
        topSlot(dc, 140, srSetting("slotTop2V3", 34), info, w);
        topSlot(dc, 223, srSetting("slotTop3V3", 15), info, w);
        rule(dc, 124);
        ring(dc, 55, srSetting("slotRing1V3", 1), srSetting("colorRing1V3", 0), info, w);
        ring(dc, 140, srSetting("slotRing2V3", 2), srSetting("colorRing2V3", 2), info, w);
        ring(dc, 225, srSetting("slotRing3V3", 3), srSetting("colorRing3V3", 6), info, w);
        rule(dc, 217);
        drawWeather(dc, info, w);
        drawBattery(dc, info, w);
        if (_storm.warning()) { stormBolt(dc, 251, 132); }
    }
}
