# Solar Rings 7X v3.21.7

## Poprawka widoku produkcyjnego IMGW

W wersji 3.21.7 Test 4 pełnego IMGW jest **zawsze trybem produkcyjnym**. W dolnym polu pod temperaturą nie pojawiają się napisy techniczne o ręcznym/ostatnim powiecie, braku alertu ani błędach lokalizacji. Wyświetlana jest temperatura odczuwalna (jeśli dostępna i włączona) lub opis pogody. Aktywne ostrzeżenie nadal może być wyświetlane jako ikona. Zmiana nie wpływa na pobieranie ostrzeżeń, automatyczny/ręczny TERYT ani próg mrozu.

Diagnostyka nadal działa: **Test 1** — źródło lokalizacji GPS/Weather/cache; **Test 11** — diagnostyka przetwarzania IMGW. W obu przypadkach należy włączyć ustawienie „IMGW: pokaż status diagnostyczny”. Podgląd ikon TEST jest celowo podpisany „TEST” niezależnie od diagnostyki.

Uwaga: jeśli Garmin nie podaje temperatury odczuwalnej, tarcza może pokazać opis pogody; ta poprawka nie wytwarza brakujących danych. Poprawka nie zmienia fizycznej dostępności GPS w Connect IQ. Jeżeli urządzenie nadal wyświetla komunikat techniczny w Teście 4, należy upewnić się, że zainstalowano nowy skompilowany plik **3.21.7**, a Connect IQ zastosowało ustawienia.

## Instalacja

Wgraj `SolarRings7X_v3_21_7_SOURCE.zip` do głównego katalogu GitHuba i `SolarRings7X_v3_21_7_BUILD.yml` do `.github/workflows/`; uruchom workflow, zainstaluj wynikowy `.iq`.

## Test produkcyjny

IMGW: włączone, Test 4, TERYT 0, podgląd ikon 0, ikony włączone, diagnostyka wyłączona lub włączona — w obu przypadkach brak komunikatu technicznego w dolnym wierszu. Włącz „Pogoda: pokazuj także temperaturę odczuwalną”.

Nie ma tu kompilacji na fizycznym Fenixie; lokalne testy Python/XML służą jako kontrola regresji.
