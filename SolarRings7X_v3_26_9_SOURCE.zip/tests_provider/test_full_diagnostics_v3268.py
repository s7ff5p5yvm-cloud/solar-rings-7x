"""Safety and integration checks for v3.26.8 (static Monkey C contracts).

These are NOT execution in Garmin SDK or a real HTTP response from a watch.
"""
from pathlib import Path
import unittest
from xml.etree import ElementTree as ET

R=Path(__file__).resolve().parents[1]
NW=(R/'source/SolarOpenNetwork.mc').read_text()
OD=(R/'source/SolarOpenData.mc').read_text()
UI=(R/'source/SolarRings7X.mc').read_text()
GE=(R/'source/WeatherGeocode.mc').read_text()
STR=(R/'resources/strings.xml').read_text()
SET=ET.parse(R/'resources/settings/settings.xml').getroot()

class FullOpenWeatherDiagnostics3268(unittest.TestCase):
    def test_version_and_existing_app_identity(self):
        m=ET.parse(R/'manifest.xml').getroot().find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(m.get('version'),'3.26.9')
        self.assertEqual(m.get('id'),'D1F8E1A4B7FC45BD91E8F0A0959041BF')
    def test_one_forecast_request_and_no_foreground_network(self):
        self.assertEqual(NW.count('Comm.makeWebRequest('),1)
        self.assertNotIn('Comm.makeWebRequest(',UI)
        for route in ['onecall/current','onecall/timeline/15min','onecall/timeline/1h','onecall/timeline/1day','2.5/air_pollution']:
            self.assertIn(route,NW)
    def test_each_endpoint_has_independent_diagnostics(self):
        for key in ['srODNowV3268','srODForecastV3268','srODDailyV3268',
                    'srODAirV3268','srODSystemV3268']:
            self.assertIn(key,NW)
            self.assertIn(key,UI)
        self.assertIn('srODHistoryV3268',NW)
        self.assertIn('old.size() > 5',NW)
        self.assertIn('history.add([stamp, p, code, _diagStep])',NW)
    def test_json_schema_details_are_logged_without_payloads(self):
        for bit in [1,2,4,8,16,32,64,128,256]:
            self.assertIn('_diagMask += '+str(bit)+';',NW)
        self.assertIn('data["data"]',NW)
        self.assertIn('data["list"]',NW)
        self.assertIn('num(row["dt"])',NW)
        self.assertIn('num(row["temp"])',NW)
        self.assertIn('firstId(row)',NW)
        self.assertNotIn('diagWrite("srODHistoryV3268", data)',NW)
        self.assertNotIn('diagWrite("srODHistoryV3268", _key)',NW)
        self.assertNotIn('diagWrite(endpointKey(p), data)',NW)
        self.assertIn('var history = []',NW)
    def test_debug_logs_never_block_weather(self):
        snippet=NW.split('function diagWrite(key, v)')[1].split('function coords(v)')[0]
        self.assertNotIn('_unsafe = true',snippet)
        self.assertIn('catch (e) { }',snippet)
        self.assertIn('diagWrite("srODiagV3266"',NW)
        self.assertIn('write("srOCurrV326", snapshot)',NW)
    def test_error_classes_disambiguated(self):
        for c in ['-151','-202','-203','-204','-205','-206','-208','-209','-210',
                  '-211','-212','-213','-216','-220','-221','-222']:
            self.assertIn(c,NW)
        self.assertIn('if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }',NW)
        self.assertIn('if (code != 200) { fail(code); return; }',NW)
        self.assertIn('if (!dictionary(data)) { fail(-151); return; }',NW)
    def test_four_selectable_diagnostic_screens(self):
        root={x.get('propertyKey'):x for x in SET}
        view=root['@Properties.gwPreviewV332'].find('settingConfig')
        v={int(x.get('value')) for x in view}
        for i in [15,16,17,18,19]:
            self.assertIn(i,v)
        self.assertIn('drawOpenDiagPage(dc, diagMode)',UI)
        self.assertIn('diagMode >= 16 && diagMode <= 20',UI)
        for i in range(16,20):self.assertIn(f'gw_diag_{i}',STR)
        self.assertNotIn('Position.enableLocationEvents(',UI)
    def test_diagnostic_history_reset_when_upgrading(self):
        self.assertIn('diagVersion != 3269',OD)
        self.assertIn('srODVersionV3269',OD)
        self.assertIn('modeChanged || keyChanged',OD)
        self.assertIn('srODWakeV3268',OD)
    def test_location_and_garmin_fallback_unaltered(self):
        self.assertIn('srOwmUpdateLocation(locationMetadata)',UI)
        self.assertIn('srOwmVisibleCurrent()',UI)
        self.assertIn('Weather.getCurrentConditions()',UI)
        self.assertIn('if (provider == 1)',GE)
        self.assertIn('new SolarOpenNetwork()',GE)
    def test_15min_fallback_remains(self):
        self.assertIn('srOShortPausedV3264',NW)
        self.assertIn('srOHoursV326',NW)
        self.assertIn('srOShortAttemptV3264',NW)
        self.assertIn('_shortRequest &&',NW)

if __name__=='__main__': unittest.main()
