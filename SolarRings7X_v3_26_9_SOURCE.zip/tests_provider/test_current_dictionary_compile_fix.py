"""Regression against Monkey C Null inference in current OWM 4.0 data."""
from pathlib import Path
import unittest
SRC = (Path(__file__).resolve().parents[1]/"source"/"SolarOpenNetwork.mc").read_text()

def current_entry(rows):
    if not isinstance(rows,list) or len(rows)!=1 or not isinstance(rows[0],dict):
        return None
    return rows[0]

class TestCurrentDictionaryCompileFix(unittest.TestCase):
    def test_dictionary_checked_before_cast(self):
        assert SRC.count('var d = currentRows[0] as Lang.Dictionary;') == 1
        block=SRC[SRC.index('var currentRows = data["data"]'):SRC.index('} else if (_kind == "forecast")')]
        assert 'var d = null;' not in block
        assert 'dictionary(currentRows[0])' in block
        assert block.index('dictionary(currentRows[0])') < block.index('var d = currentRows[0] as Lang.Dictionary;') < block.index('num(d["dt"])')
    def test_only_one_dictionary_row_is_selected(self):
        for bad in (None, [], [None], [{} , {}], ['hello'], {'data':[]}, 12, 'text'):
            self.assertIsNone(current_entry(bad))
        self.assertEqual(current_entry([{'dt':123,'temp':12}]), {'dt':123,'temp':12})
    def test_current_snapshot_field_order_unchanged(self):
        expected='_loc[0], _loc[1], _now, d["dt"].toNumber(),\n                            d["temp"], optionalNumber(d,"feels_like")'
        self.assertIn(expected, SRC)
if __name__ == "__main__": unittest.main()
