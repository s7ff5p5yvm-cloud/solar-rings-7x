using Toybox.Application as App;
using Toybox.Background as Bg;
using Toybox.Communications as Comm;
using Toybox.Lang as Lang;
using Toybox.PersistedContent as Persisted;
using Toybox.System as Sys;
using Toybox.Time as Time;

// One request per background wake-up. Optional 15-minute OWM 4.0
// forecast replaces (does not supplement) the 1h forecast call. Since OWM
// may deliver up to 50 JSON rows in one response, parsing can exceed watch
// background RAM before trimming. On failure, pause 15min and use 1h fallback.
// Only up to 12 valid short-range rows are saved, never full API JSON.
(:background)
class SolarOpenNetwork {
    var _kind;
    var _loc;
    var _now;
    var _interval;
    var _key;
    var _unsafe;
    var _shortEnabled;
    var _shortRequest;
    // Compact diagnostic counters; no keys, URLs, coordinates or raw JSON.
    var _diagStep;
    var _diagMask;
    var _diagRows;
    var _diagAccepted;
    var _diagAge;

    function initialize() {
        _kind = "";
        _loc = null;
        _now = 0;
        _interval = 30;
        _key = "";
        _unsafe = false;
        _shortEnabled = true;
        _shortRequest = false;
        _diagStep = 0;
        _diagMask = 0;
        _diagRows = 0;
        _diagAccepted = 0;
        _diagAge = 0;
    }
    function setting(key, fallback) {
        try {
            var v = App.Properties.getValue(key);
            if (v != null) { return v; }
        } catch (e) { }
        return fallback;
    }
    function num(v) {
        return v != null && (v instanceof Lang.Number || v instanceof Lang.Long ||
                             v instanceof Lang.Float || v instanceof Lang.Double);
    }
    function value(key) {
        try { return App.Storage.getValue(key); } catch (e) { return null; }
    }
    function write(key, v) {
        try {
            if (App.Storage.getValue(key) != v) { App.Storage.setValue(key, v); }
            return true;
        } catch (e) { _unsafe = true; return false; }
    }
    // Logging is best-effort. Failures of diagnostic storage MUST NOT mark
    // the entire meteorological update unsafe or stop normal weather writes.
    function diagWrite(key, v) {
        try { App.Storage.setValue(key, v); } catch (e) { }
    }
    function coords(v) {
        return v != null && v instanceof Lang.Array && v.size() >= 2 &&
            num(v[0]) && num(v[1]) && v[0] >= -90 && v[0] <= 90 &&
            v[1] >= -180 && v[1] <= 180;
    }
    function same(a, b) {
        return coords(a) && coords(b) &&
            a[0] > b[0] - 0.025d && a[0] < b[0] + 0.025d &&
            a[1] > b[1] - 0.035d && a[1] < b[1] + 0.035d;
    }
    function deadline(key, snapshot, duration) {
        var d = value(key);
        if (!num(d) || d < 0 || d > _now + 48 * 3600) { d = 0; }
        var s = value(snapshot);
        if (same(s, _loc) && s.size() >= 3 && num(s[2]) &&
            s[2] <= _now && _now - s[2] <= 10800 &&
            s[2] + duration > d) { d = s[2] + duration; }
        return d;
    }
    function forecastStorageKey() {
        var paused = value("srOShortPausedV3264");
        if (_shortEnabled && (!num(paused) || paused <= _now)) {
            return "srOShortV3264";
        }
        return "srOHoursV326";
    }
    function schedule() {
        var now = Time.now().value();
        var earliest = deadline("srONextCV326", "srOCurrV326", _interval * 60);
        var f = deadline("srONextFV326", forecastStorageKey(), _interval * 120);
        if (earliest == 0 || f < earliest) { earliest = f; }
        var daily = deadline("srONextDV326", "srODayV326", 12 * 3600);
        if (earliest == 0 || daily < earliest) { earliest = daily; }
        if (setting("srOwmAirV326", false)) {
            var a = deadline("srONextAV326", "srOAirV326", 3600);
            if (earliest == 0 || a < earliest) { earliest = a; }
        }
        var seconds = earliest - now;
        if (seconds < 300) { seconds = 300; }
        if (seconds > 6 * 3600) { seconds = 6 * 3600; }
        if (_unsafe) { seconds = 6 * 3600; }
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(seconds)));
        } catch (e) { _diagStep = 90; status(-222); }
    }
    // Endpoint index: 0=position, 1=current, 2=forecast, 3=daily, 4=AQI.
    // Diagnostic result uses HTTP code or a small local negative code.
    // Durable pipeline breadcrumbs: [epoch, gate, endpoint, currentWaitSec, forecastWaitSec].
    // Each gate is a concrete stage, not a guessed HTTP or GPS error.
    // Bounded numeric-only record, no token, URL, response text or coordinates.
    function gate(stage) {
        var now = Time.now().value();
        var c = value("srONextCV326");
        var f = value("srONextFV326");
        var cw = -1;
        var fw = -1;
        if (num(c)) { cw = c.toNumber() - now; }
        if (num(f)) { fw = f.toNumber() - now; }
        diagWrite("srODGateV3269", [now, stage, phase(), cw, fw]);
    }
    function runSafely() {
        try { start(); }
        catch (e) {
            // If anything fails before makeWebRequest or before its normal
            // error handler, retain a visible breadcrumb and retry safely.
            _diagStep = 91;
            gate(90);
            status(-230);
            try {
                Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(10 * 60)));
            } catch (e2) { }
            Bg.exit(["OWM", 0]);
        }
    }
    function phase() {
        if (_kind == "current") { return 1; }
        if (_kind == "forecast") { return 2; }
        if (_kind == "daily") { return 3; }
        if (_kind == "air") { return 4; }
        return 0;
    }
    function endpointKey(p) {
        if (p == 1) { return "srODNowV3268"; }
        if (p == 2) { return "srODForecastV3268"; }
        if (p == 3) { return "srODDailyV3268"; }
        if (p == 4) { return "srODAirV3268"; }
        return "srODSystemV3268";
    }
    function status(code) {
        // Format of per-endpoint snapshot: [time, endpoint, stage, result,
        // structural flags, response records, accepted records, ageSec, 15m].
        // The legacy 3-field status remains readable by the old TEST 15.
        var p = phase();
        // Background can be killed/restarted during an async request. If
        // transient _kind is unavailable, use the last safely stored phase.
        if (p == 0 && code != 0) {
            var selected = value("srODGateV3269");
            if (selected instanceof Lang.Array && selected.size() == 5 &&
                num(selected[0]) && num(selected[2]) &&
                selected[0] <= Time.now().value() + 300 &&
                Time.now().value() - selected[0] <= 1800 &&
                selected[2] >= 1 && selected[2] <= 4) {
                p = selected[2];
            }
        }
        if (p == 0 && code != 0) {
            var ctx = value("srOReqCtxV3267");
            var tm = Time.now().value();
            if (ctx instanceof Lang.Array && ctx.size() == 6 &&
                num(ctx[0]) && num(ctx[1]) &&
                ctx[0] <= tm + 300 && tm - ctx[0] <= 1800 &&
                ctx[1] >= 1 && ctx[1] <= 4) { p = ctx[1]; }
        }
        var stamp = Time.now().value();
        diagWrite("srODiagV3266", [stamp, p, code]);
        diagWrite(endpointKey(p), [stamp, p, _diagStep, code, _diagMask,
                               _diagRows, _diagAccepted, _diagAge,
                               _shortRequest ? 1 : 0]);
        // Keep the last six terminal outcomes. Each entry is four integers.
        // Never retain the API token, request URL, location or response body.
        if (code != 100 && code != 0) {
            var old = value("srODHistoryV3268");
            var history = [];
            if (old instanceof Lang.Array) {
                var first = old.size() > 5 ? old.size() - 5 : 0;
                for (var i = first; i < old.size(); i++) {
                    if (old[i] instanceof Lang.Array && old[i].size() == 4) {
                        history.add(old[i]);
                    }
                }
            }
            history.add([stamp, p, code, _diagStep]);
            diagWrite("srODHistoryV3268", history);
        }
    }
    // A compact structural fingerprint, independent from the parser result.
    // Flags: 1=dict 2=array 4=nonempty 8=first record dict,
    // 16=dt 32=temp 64=weather ID 128=timezone 256=air.main.
    function inspectResponse(data) {
        _diagMask = 0;
        _diagRows = 0;
        _diagAccepted = 0;
        _diagAge = 0;
        if (!dictionary(data)) { return; }
        _diagMask += 1;
        if (num(data["timezone_offset"])) { _diagMask += 128; }
        var rows = _kind == "air" ? data["list"] : data["data"];
        if (!(rows instanceof Lang.Array)) { return; }
        _diagMask += 2;
        _diagRows = rows.size();
        if (_diagRows < 1) { return; }
        _diagMask += 4;
        var row = rows[0];
        if (!dictionary(row)) { return; }
        _diagMask += 8;
        if (num(row["dt"])) {
            _diagMask += 16;
            _diagAge = _now - row["dt"].toNumber();
        }
        if (num(row["temp"]) || dictionary(row["temp"])) {
            _diagMask += 32;
        }
        if (firstId(row) != null) { _diagMask += 64; }
        if (dictionary(row["main"])) { _diagMask += 256; }
    }
    // An HTTP callback can arrive after a background-service state change.
    // Restore only the bounded request metadata, never the API key or JSON.
    function restoreRequestContext() {
        var r = value("srOReqCtxV3267");
        var t = Time.now().value();
        if (!(r instanceof Lang.Array) || r.size() != 6 ||
            !num(r[0]) || !num(r[1]) || !num(r[2]) || !num(r[3]) ||
            !num(r[4]) || !num(r[5]) || r[0] > t + 300 ||
            t - r[0] > 1800 || r[1] < 1 || r[1] > 4) { return false; }
        var pos = [r[2], r[3], r[0]];
        if (!coords(pos)) { return false; }
        _kind = r[1] == 1 ? "current" : r[1] == 2 ? "forecast" :
                r[1] == 3 ? "daily" : "air";
        _now = r[0];
        _loc = pos;
        _interval = r[4];
        _shortRequest = r[5] == 1;
        return true;
    }
    function finish(changed) {
        schedule();
        Bg.exit(["OWM", changed ? 1 : 0]);
    }
    function fail(code) {
        if (_diagStep < 20) { _diagStep = 12; }
        status(code);
        if (_shortRequest) { write("srOShortAttemptV3264", 0); }
        // A 15min endpoint failure must not disable the basic hourly alerts.
        // HTTP 401/403/429 are key/rate-limit problems; retrying the same
        // credentials against 1h would be wasteful. -403 is Garmin's network
        // out-of-memory error, NOT HTTP 403; fall back without a retry loop.
        if (_kind == "forecast" && _shortRequest &&
            code != 401 && code != 403 && code != 429) {
            write("srOShortPausedV3264", _now + 24 * 3600);
            write("srONextFV326", _now + 10 * 60);
            finish(false);
            return;
        }
        var pause = 60 * 60;
        if (code == 401 || code == 403 || code == 429 || code == -403) {
            pause = 6 * 3600;
        }
        if (_kind == "current") { write("srONextCV326", _now + pause); }
        if (_kind == "forecast") { write("srONextFV326", _now + pause); }
        if (_kind == "daily") { write("srONextDV326", _now + pause); }
        if (_kind == "air") { write("srONextAV326", _now + pause); }
        finish(false);
    }
    function start() {
        _now = Time.now().value();
        _diagStep = 10; // Background service actually woke.
        diagWrite("srODWakeV3268", _now);
        gate(10);
        if (setting("srProviderV326", 0) != 1) {
            gate(11);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        _key = setting("srOpenKeyV326", "");
        _loc = value("srOLocV326");
        if (!(_key instanceof Lang.String) || _key.length() < 8) {
            gate(12); status(-11);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        // Use the last location seen on the face, even when a Garmin
        // weather observation is older than 3h. Never request data using
        // coordinates absent or not seen by the face for over 48h.
        if (!coords(_loc) || _loc.size() < 3 || !num(_loc[2]) ||
            _loc[2] > _now + 300 || _now - _loc[2] > 48 * 3600) {
            gate(13); status(-10);
            try { Bg.deleteTemporalEvent(); } catch (e) { }
            Bg.exit(null); return;
        }
        _interval = setting("srOwmMinutesV326", 30);
        if (_interval != 15 && _interval != 30 && _interval != 60) {
            _interval = 30;
        }
        _shortEnabled = setting("srOwm15MinV3264", true) == true;
        var previousStatus = value("srODiagV3266");
        if (previousStatus instanceof Lang.Array && previousStatus.size() == 3 &&
            num(previousStatus[0]) && previousStatus[2] == 100 &&
            previousStatus[0] < _now - 8 * 60) {
            _diagStep = 90;
            status(-17);
            _diagStep = 10;
        }
        // Previous high-resolution call may have killed the background task
        // before any callback (e.g. JSON OOM). A stuck attempt triggers a
        // one-day circuit breaker instead of retrying the oversized payload.
        var orphaned = value("srOShortAttemptV3264");
        if (num(orphaned) && orphaned > 0 &&
            orphaned <= _now - 5 * 60 && orphaned >= _now - 24 * 3600) {
            write("srOShortPausedV3264", _now + 24 * 3600);
            write("srONextFV326", 0);
        }
        if (num(orphaned) && orphaned > 0) {
            write("srOShortAttemptV3264", 0);
        }
        var nextC = deadline("srONextCV326", "srOCurrV326", _interval * 60);
        var nextF = deadline("srONextFV326", forecastStorageKey(), _interval * 120);
        var nextD = deadline("srONextDV326", "srODayV326", 12 * 3600);
        var nextA = deadline("srONextAV326", "srOAirV326", 3600);
        if (nextC <= _now) { _kind = "current"; }
        else if (nextF <= _now) { _kind = "forecast"; }
        else if (nextD <= _now) { _kind = "daily"; }
        else if (setting("srOwmAirV326", false) && nextA <= _now) { _kind = "air"; }
        if (_kind == "") { gate(14); finish(false); return; }
        gate(16); // Which endpoint was actually selected?
        if (!Sys.getDeviceSettings().phoneConnected) {
            gate(15); fail(-12); return;
        }
        var route = "";
        if (_kind == "current") { route = "https://api.openweathermap.org/data/4.0/onecall/current"; }
        else if (_kind == "forecast") {
            _shortRequest = forecastStorageKey() == "srOShortV3264";
            if (_shortRequest) {
                route = "https://api.openweathermap.org/data/4.0/onecall/timeline/15min";
            } else {
                route = "https://api.openweathermap.org/data/4.0/onecall/timeline/1h";
            }
        }
        else if (_kind == "daily") { route = "https://api.openweathermap.org/data/4.0/onecall/timeline/1day"; }
        else { route = "https://api.openweathermap.org/data/2.5/air_pollution"; }
        var q = {
            "lat" => _loc[0].format("%.4f"),
            "lon" => _loc[1].format("%.4f"),
            "appid" => _key
        };
        if (_kind != "air") {
            q["units"] = "metric";
            q["lang"] = "pl";
        }
        // Protect against a missing callback or a killed background process.
        // A conservative deadline is persisted BEFORE the request, and a
        // one-shot 15-min watchdog is armed. Successful callback replaces the
        // watchdog with the normal schedule, without an extra persistent
        // write when the deadline remains the same.
        var nextKey = "srONextCV326";
        var nextEpoch = _now + _interval * 60;
        if (_kind == "forecast") {
            nextKey = "srONextFV326";
            nextEpoch = _now + _interval * 120;
        } else if (_kind == "daily") {
            nextKey = "srONextDV326";
            nextEpoch = _now + 12 * 3600;
        } else if (_kind == "air") {
            nextKey = "srONextAV326";
            nextEpoch = _now + 3600;
        }
        if (!write(nextKey, nextEpoch)) { status(-16); finish(false); return; }
        if (_shortRequest && !write("srOShortAttemptV3264", _now)) {
            finish(false); return;
        }
        // Persist just the request phase and location for callback recovery.
        if (!write("srOReqCtxV3267", [_now, phase(), _loc[0], _loc[1],
                                     _interval, _shortRequest ? 1 : 0])) {
            status(-154); finish(false); return;
        }
        gate(17); // Request context persisted.
        _diagStep = 20; // Request queued for Connect IQ.
        status(100);
        try {
            Bg.registerForTemporalEvent(Time.now().add(new Time.Duration(15 * 60)));
        } catch (e) { fail(-221); return; }
        try {
            // The gate is persisted before the asynchronous network call.
            gate(18);
            Comm.makeWebRequest(route, q, {
                :method => Comm.HTTP_REQUEST_METHOD_GET,
                :responseType => Comm.HTTP_RESPONSE_CONTENT_TYPE_JSON
            }, method(:onReceive));
        } catch (e) { fail(-220); }
    }
    function dictionary(v) { return v != null && v instanceof Lang.Dictionary; }
    function firstId(d) {
        if (!dictionary(d)) { return null; }
        var list = d["weather"];
        if (!(list instanceof Lang.Array) || list.size() < 1 ||
            !dictionary(list[0])) { return null; }
        var id = list[0]["id"];
        return num(id) ? id.toNumber() : null;
    }
    function nestedRate(d, key) {
        var r = d[key];
        if (!dictionary(r)) { return null; }
        var amount = r["1h"];
        return num(amount) ? amount : null;
    }
    function pct(d) {
        var p = d["pop"];
        if (p == null) { return null; }
        // Invalid but present is NOT the same thing as absent: -1 sentinel.
        // View model turns this sentinel into --, warning rule fails closed.
        if (!num(p) || p < 0 || p > 1) { return -1; }
        return (p * 100).toNumber();
    }
    function optionalNumber(d, k) {
        var v = d[k];
        return num(v) ? v : null;
    }
    function onReceive(code as Lang.Number,
            data as Null or Lang.ByteArray or Lang.Dictionary or Lang.String or Persisted.Iterator) as Void {
        _diagStep = 25; // Callback invoked, regardless of HTTP code.
        // Also restore context on a normal callback: storage is authoritative
        // for endpoint and the 15-minute variant after a background restart.
        if (_kind == "") { restoreRequestContext(); }
        gate(19);
        if (_kind == "" && !restoreRequestContext()) {
            status(-19); Bg.exit(["OWM", 0]); return;
        }
        if (code != 200) { fail(code); return; }
        _diagStep = 30;
        try { inspectResponse(data); }
        catch (e) { fail(-216); return; }
        if (!dictionary(data)) { fail(-151); return; }
        // Keep the attempt marker until the entire response is validated and
        // successfully saved. If background dies DURING JSON processing, the
        // watchdog must still notice the orphan and switch to hourly.
        // Location may have changed while HTTP was pending; never save
        // a response from the previous city as the new city's weather.
        if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }
        var ok = false;
        var reason = -214; // Explicit unknown branch; no generic FORMAT -152.
        try {
            if (_kind == "current") {
                // One Call 4.0 current uses {"data":[{...}]} (one item),
                // not the older 2.5/3.0 nested current Dictionary.
                var currentRows = data["data"];
                // Do not initialise 'd' with null: Monkey C infers Null and
                // rejects d["dt"] / d["temp"] even after dictionary(d).
                // Cast only an explicitly validated Dictionary, and keep all
                // indexed reads inside that guard (no additional allocations).
                if (!(currentRows instanceof Lang.Array)) { reason = -202; }
                else if (currentRows.size() == 0) { reason = -203; }
                else if (!dictionary(currentRows[0])) { reason = -204; }
                // V4 current normally returns one row. Do not reject a valid
                // first row solely because a future API response adds rows.
                if (currentRows instanceof Lang.Array && currentRows.size() > 0 &&
                    dictionary(currentRows[0])) {
                    var d = currentRows[0] as Lang.Dictionary;
                    if (!num(d["dt"])) { reason = -205; }
                    else if (!num(d["temp"])) { reason = -206; }
                    else if (d["dt"] > _now + 300 || _now - d["dt"] > 5400) {
                        reason = -153;
                    }
                    if (dictionary(d) && num(d["dt"]) && num(d["temp"]) &&
                        d["dt"] <= _now + 300 && _now - d["dt"] <= 5400) {
                        var snapshot = [
                            _loc[0], _loc[1], _now, d["dt"].toNumber(),
                            d["temp"], optionalNumber(d,"feels_like"),
                            optionalNumber(d,"wind_speed"), optionalNumber(d,"humidity"),
                            optionalNumber(d,"uvi"), optionalNumber(d,"visibility"),
                            optionalNumber(d,"clouds"), firstId(d),
                            optionalNumber(d,"pressure"), optionalNumber(d,"sunrise"),
                            optionalNumber(d,"sunset"), optionalNumber(d,"wind_gust"), pct(d),
                            nestedRate(d,"rain"), nestedRate(d,"snow")
                        ];
                        reason = -154;
                        _diagStep = 60;
                        ok = write("srOCurrV326", snapshot);
                        if (ok) { _diagAccepted = 1; }
                        if (ok) { write("srONextCV326", _now + _interval * 60); }
                    } // Missing values and stale time are reported separately.
                }
            } else if (_kind == "forecast") {
                // Both timelines use {data:[{dt,weather,pop,...}]}. The
                // high-resolution endpoint may send 50 records; bound both
                // iteration and STORAGE to the upcoming 3h (12 x 15min).
                // WARNING: this does not shrink the HTTP/JSON response itself.
                var records = data["data"];
                if (!(records instanceof Lang.Array)) { reason = -202; }
                else if (records.size() == 0) { reason = -203; }
                if (records instanceof Lang.Array && records.size() > 0) {
                    var mini = [];
                    var count = records.size();
                    if (count > 50) { count = 50; }
                    var horizonSeconds = _shortRequest ? 3 * 3600 : 5 * 3600;
                    var maxRows = _shortRequest ? 12 : 5;
                    var previous = 0;
                    for (var i = 0; i < count; i++) {
                        var h = records[i];
                        if (!dictionary(h) || !num(h["dt"])) { continue; }
                        var t = h["dt"].toNumber();
                        if (t <= _now || t > _now + horizonSeconds ||
                            t <= previous) { continue; }
                        // Forecast format shared with the old 1h engine.
                        mini.add([t, firstId(h), optionalNumber(h,"wind_speed"),
                            optionalNumber(h,"temp"), optionalNumber(h,"uvi"),
                            pct(h), nestedRate(h,"rain"), nestedRate(h,"snow"),
                            optionalNumber(h,"visibility"), optionalNumber(h,"wind_gust")]);
                        previous = t;
                        if (mini.size() >= maxRows) { break; }
                    }
                    // Never overwrite a good forecast with zero valid rows.
                    // At least one mapped record is required for the new
                    // endpoint; otherwise automatically switch back to 1h.
                    var valid = mini.size() > 0;
                    if (valid && _shortRequest) {
                        var recognized = false;
                        for (var z = 0; z < mini.size(); z++) {
                            if (mini[z][1] != null) { recognized = true; break; }
                        }
                        valid = recognized;
                    }
                    if (!valid) {
                        reason = mini.size() > 0 ? -209 : -208;
                    } else { _diagAccepted = mini.size(); }
                    if (valid) {
                        var saveKey = _shortRequest ? "srOShortV3264" : "srOHoursV326";
                        reason = -154;
                        _diagStep = 60;
                        ok = write(saveKey, [_loc[0], _loc[1], _now, mini]);
                        if (ok) { write("srONextFV326", _now + _interval * 120); }
                    }
                }
            } else if (_kind == "daily") {
                var days = data["data"];
                var tz = data["timezone_offset"];
                if (!(days instanceof Lang.Array)) { reason = -202; }
                else if (!num(tz)) { reason = -211; }
                else if (days.size() == 0) { reason = -203; }
                if (days instanceof Lang.Array && num(tz)) {
                    var currentDay = ((_now + tz) / 86400).toNumber();
                    var day = null;
                    for (var k = 0; k < days.size() && k < 10; k++) {
                        var item = days[k];
                        if (!dictionary(item) || !num(item["dt"]) ||
                            !dictionary(item["temp"])) { continue; }
                        var dayId = ((item["dt"] + tz) / 86400).toNumber();
                        if (dayId != currentDay) { continue; }
                        var temps = item["temp"];
                        if (num(temps["min"]) && num(temps["max"])) {
                            day = [_loc[0],_loc[1],_now,dayId,temps["min"],temps["max"],tz];
                        }
                        break;
                    }
                    if (day == null) { reason = -210; }
                    if (day != null) {
                        reason = -154;
                        _diagStep = 60;
                        ok = write("srODayV326", day);
                        if (ok) { _diagAccepted = 1; }
                        if (ok) { write("srONextDV326", _now + 12 * 3600); }
                    }
                }
            } else if (_kind == "air") {
                var air = data["list"];
                if (!(air instanceof Lang.Array)) { reason = -202; }
                else if (air.size() == 0) { reason = -203; }
                else if (!dictionary(air[0])) { reason = -204; }
                else if (!dictionary(air[0]["main"])) { reason = -212; }
                if (air instanceof Lang.Array && air.size() > 0 &&
                    dictionary(air[0]) && dictionary(air[0]["main"])) {
                    var a = air[0]["main"]["aqi"];
                    var t2 = air[0]["dt"];
                    if (num(a) && a >= 1 && a <= 5 && num(t2) &&
                        t2 <= _now + 300 && _now - t2 <= 7200) {
                        reason = -154;
                        _diagStep = 60;
                        ok = write("srOAirV326", [_loc[0],_loc[1],_now,t2.toNumber(),a.toNumber()]);
                        if (ok) { _diagAccepted = 1; }
                        if (ok) { write("srONextAV326", _now + 3600); }
                    }
                }
            }
        } catch (e) { ok = false; reason = -155; }
        if (_unsafe) { reason = -154; }
        if (!ok || _unsafe) { fail(reason); return; }
        if (_shortRequest && !write("srOShortAttemptV3264", 0)) {
            fail(-16); return;
        }
        _diagStep = 70;
        gate(21);
        status(200);
        finish(true);
    }
}
