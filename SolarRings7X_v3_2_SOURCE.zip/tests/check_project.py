#!/usr/bin/env python3
"""Offline checks for v3.2 metadata, phone configuration and layout contracts.
This cannot replace real Garmin SDK compilation and a physical watch test.
"""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
props = ET.parse(ROOT / 'resources/settings/properties.xml').getroot()
settings = ET.parse(ROOT / 'resources/settings/settings.xml').getroot()
strings = ET.parse(ROOT / 'resources/strings.xml').getroot()
manifest = ET.parse(ROOT / 'manifest.xml').getroot()

pmap = {p.get('id'): p for p in props.findall('property')}
smap = {s.get('id') for s in strings.findall('string')}
slist = settings.findall('setting')
assert len(pmap) == 21 and len(slist) == 21
assert len(smap) == len(strings.findall('string'))
assert len({s.get('propertyKey') for s in slist}) == 21
for s in slist:
    key = s.get('propertyKey', '').replace('@Properties.', '')
    title = s.get('title','').replace('@Strings.', '')
    assert key in pmap, key
    assert title in smap, title
    cfg = s.find('settingConfig')
    assert cfg is not None and cfg.get('type') in ('list', 'boolean')
    for ent in cfg.findall('listEntry'):
        assert ent.text.replace('@Strings.', '') in smap
app = list(manifest)[0]
assert app.get('version') == '3.2.0'
assert app.get('id') == 'D1F8E1A4B7FC45BD91E8F0A0959041BF'
assert {'fenix7xpro', 'fenix7xpronowifi'} == {
    p.get('id') for p in app[0].findall('{http://www.garmin.com/xml/connectiq}product')
}
face = (ROOT / 'source/SolarRings7X.mc').read_text()
field = (ROOT / 'source/FieldData.mc').read_text()
config = (ROOT / 'source/Config.mc').read_text()
assert face.count('topSlot(dc,') == 4  # 1 function + 3 calls
assert face.count('ring(dc,') == 4     # 1 function + 3 calls
assert 'outerProgressRing(dc, monitor, w, clock)' in face
assert 'onSettingsChanged()' in face and 'Ui.requestUpdate()' in face
assert 'Props.getValue(key)' in config
for setting_key in ('fontClockV31','fontDateV31','fontWeatherV31','outerRingV31',
                    'slotTop1V3','slotRing2V3','slotFooterV3','stormOnV3'):
    assert setting_key in pmap and setting_key in (face + config + (ROOT / 'source/StormGuard.mc').read_text())

# Scale = 0,1,2 is capped to different font families. The actual size may
# still be reduced if a long number cannot fit on the real Garmin font atlas.
assert 'if (scale <= 0)' in face and 'else if (scale == 1)' in face
assert 'Gfx.FONT_NUMBER_HOT' in face and 'Gfx.FONT_NUMBER_MILD' in face
assert 'Gfx.FONT_SMALL' in face and 'Gfx.FONT_TINY' in face
assert 'dc.setClip(left, top, width, height)' in face
assert 'dc.clearClip()' in face
# HR must NEVER fall back to a valid 3-minute-old historical sample.
hr_code = field.split('function recentHeartRate() {', 1)[1].split('\nfunction sunClock', 1)[0]
assert 'Activity.getActivityInfo()' in hr_code
assert 'currentHeartRate' in hr_code
assert 'getHeartRateHistory' not in hr_code
assert 'return null;' in hr_code

# Hard reserved zones: all row segments have a gap in Y, and header time/date
# text bounding boxes do not overlap at any Y even for wide fonts.
sections = [
    ('header', 12, 70),
    ('top', 77, 123),
    ('rings', 135, 195),
    ('weather', 204, 246),
    ('footer', 249, 266),
]
for (name0, a, b),(name1, c, d) in zip(sections, sections[1:]):
    assert b < c, (name0,name1)
clock_box=(100-146/2,100+146/2)
date_box=(201-52/2,201+52/2)
assert clock_box[1] < date_box[0]

ring_y, ring_r = 165, 30
assert 125 < ring_y-ring_r < ring_y+ring_r < 202
for cx in (57,140,223):
    assert 15 <= cx-ring_r and cx+ring_r <= 265
for x in (78,171,115,155):
    assert 40 <= x <= 240
assert 'weatherSymbol(dc, 78, 222, weather)' in face
assert 'drawIcon(dc, 115, 256, id, Gfx.COLOR_GREEN)' in face
assert 'var radius = 132;' in face
assert 'stormBolt(dc, 246, 129)' in face

# New field 35 is a selectable value for all eight data slots, without
# changing existing property IDs or saved user preferences.
assert 'data_35' in smap
for entry in slist:
    key = entry.get('propertyKey', '')
    if key.startswith('@Properties.slot'):
        options = [e.get('value') for e in entry.find('settingConfig').findall('listEntry')]
        assert len(options) == 36 and options == [str(i) for i in range(36)], key
assert 'if (id == 35)' in field and 'if (id == 35)' in face
assert 'Weather.getSunrise(location, now)' in field
assert 'Weather.getSunset(location, now)' in field
assert 'Weather.getSunrise(location, tomorrow)' in field
assert 'now.add(new Time.Duration(86400))' in field
assert 'rise.value() > now.value()' in field
assert 'set.value() > now.value()' in field
assert 'Gregorian.info(selected, Time.FORMAT_SHORT)' in field

# Pure decision-model scenarios for the nearest-event rule.
def choose_next(now, sunrise, sunset, tomorrow_sunrise):
    today = [(when, event) for when, event in ((sunrise, 'WSCHOD'),(sunset, 'ZACHOD')) if when is not None and when > now]
    if today: return min(today)[1]
    return 'WSCHOD' if tomorrow_sunrise is not None and tomorrow_sunrise > now else None
assert choose_next(5*60, 6*60+46, 16*60+1, 24*60+6*60+47) == 'WSCHOD'
assert choose_next(12*60, 6*60+46, 16*60+1, 24*60+6*60+47) == 'ZACHOD'
assert choose_next(17*60, 6*60+46, 16*60+1, 24*60+6*60+47) == 'WSCHOD'
assert choose_next(12*60, None, None, None) is None

print('PASS: metadata, 21 mobile settings, nearest sunrise/sunset, three rings, font settings, current HR and layout boxes')
