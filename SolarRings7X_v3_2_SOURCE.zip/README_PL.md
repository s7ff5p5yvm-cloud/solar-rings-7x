# Solar Rings 7X — wersja beta 3.2.0

Poprawka działającej wersji 3.1, na Garmin Fenix 7X Pro Solar (280 × 280, MIP).

- Naprawiono rozmieszczenie daty, pogody i baterii względem opcjonalnego zewnętrznego pierścienia.
- Zwiększono miejsce na godzinę i uporządkowano trzy mniejsze pierścienie.
- Wielkość godziny: mała / średnia / duża ma teraz odrębne zestawy czcionek.
- Data i pogoda mają większe, niezależne obszary oraz dynamiczny dobór rozmiaru napisu.
- Tętno bierze dane z `Toybox.Activity.getActivityInfo().currentHeartRate` i nie pokazuje danych historycznych jako bieżących. Przy braku odczytu jest `--`.
- Wszystkie ustawienia w Connect IQ z v3.1 zachowane, identyfikator aplikacji niezmieniony.

**Weryfikacja**: sprawdzone XML, położenia elementów w modelu 280×280 i analiza kodu. Wymagane testy Garmin SDK i rzeczywisty test na zegarku. Kompilacja nie jest gwarantowana bez uruchomienia GitHub Actions.

## Instalacja
1. Dodaj jeden ZIP `SolarRings7X_v3_2_SOURCE.zip` do głównego katalogu GitHuba.
2. Zaktualizuj `.github/workflows/build-v3.yml` z pliku `SolarRings7X_v3_2_BUILD.yml`.
3. Uruchom `Actions → Build Solar Rings 7X v3.2 (3 rings)`.
4. Jeśli test i eksport będą zielone, uprawniony właściciel konta deweloperskiego aktualizuje istniejącą betę przez `Upload New Version`; zainstaluj aktualizację przez Connect IQ.
5. Zmień w iPhonie ustawienie zegara między małym i dużym, naciśnij `Zapisz` i zsynchronizuj zegarek.

## Test tętna
Najpierw sprawdź wskazanie na nadgarstku. Następnie po zdjęciu zegarka włącz ponownie tarczę / odczekaj do kolejnego odświeżenia. Gdy Garmin zgłosi brak aktywnego tętna, tarcza ma pokazać `--`, a nie ostatnią historyczną liczbę. Nie jest to urządzenie medyczne.

## Nowe pole: Wschod / zachod - automatycznie
W Connect IQ wybierz **Wschod / zachod - automatycznie** w dowolnym polu, np. "Gora - srodek". Do wschodu pokazuje najblizszy wschod, miedzy wschodem a zachodem pokazuje zachod, po zachodzie nastepny wschod (z dnia kolejnego). Ikona zmienia sie wraz z typem zdarzenia. Obliczanie korzysta z bieżącej daty i lokalizacji pogody/GPS udostępnianej przez zegarek i przelicza się przy odświeżeniu. Brak pozycji lub niedostepnosc danych Garmina oznacza `--:--` zamiast wymyslonej godziny. Osobne opcje wschodu i zachodu pozostaja do wyboru.
