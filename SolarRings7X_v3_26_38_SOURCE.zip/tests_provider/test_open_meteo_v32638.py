"""Source/contract regression for the optional Open-Meteo provider.

These tests do NOT compile Monkey C or prove runtime heap headroom.
They check that the stable Garmin/OWM paths remain intact and that all
WMO codes and network/diagnostic contracts of v3.26.38 are represented.
"""
from pathlib import Path
import csv
import hashlib
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'source'

def file(relative):
    return (ROOT / relative).read_text(encoding='utf-8')

def function(source, name):
    pat = re.search(r'\bfunction\s+' + re.escape(name) + r'\s*\(', source)
    if not pat:
        raise AssertionError(f'Missing function {name}')
    following = source[pat.start():]
    depth = 0
    left = following.find('{')
    if left < 0: raise AssertionError('Missing brace for ' + name)
    # Monkey C is C-like; braces in comments and strings are irrelevant for
    # the known methods below, where no embedded braces appear.
    for i in range(left, len(following)):
        if following[i] == '{': depth += 1
        elif following[i] == '}':
            depth -= 1
            if depth == 0: return following[:i + 1]
    raise AssertionError('Unbalanced ' + name)

class OpenMeteoSourceContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.net = file('source/SolarOpenNetwork.mc')
        cls.data = file('source/SolarOpenData.mc')
        cls.face = file('source/SolarRings7X.mc')
        cls.warn = file('source/SolarOpenWarnings.mc')
        cls.geo = file('source/WeatherGeocode.mc')
        with (ROOT / 'OPEN_METEO_WMO_MATRIX.csv').open(encoding='utf-8') as f:
            cls.rows = list(csv.DictReader(f))

    def test_base_visual_geometry_unchanged(self):
        # SHA256 of the original 3.26.37 files (portable in GitHub CI).
        # Catch any accidental changes to time, battery, moon, captions,
        # progress capsules, Garmin warning logic or OWM icon mapping.
        stable_sha256 = {
            'FieldData.mc': '2391caa6249cebda033ccc37f766fd0cfa3877e23f6ec62c278dfa625a13a443',
            'WeatherCity.mc': '41e3c46fea97c5a8fedade097ab49ffdf55d72b15f87475cf9eeb6784714a51e',
            'MoonCalendar.mc': '13a3ea607f48ad1abd0a2166d8d2c10500d859eec86a3c7620bd4f98d0a4fed3',
            'SolarWeatherCodes.mc': 'af61deb3fb460a2eef6d55c86910e57e4c80fe4e163e16bdad7efa69dc1df23e',
            'GarminWeatherWarnings.mc': 'f937252eafeca85c431d996b1e43927294d68f07449298501cd070ca34383823',
        }
        for name, expected in stable_sha256.items():
            with self.subTest(name=name):
                got = hashlib.sha256((SRC/name).read_bytes()).hexdigest()
                self.assertEqual(got, expected)

    def test_version(self):
        self.assertIn('version="3.26.38"', file('manifest.xml'))
        self.assertIn("== '3.26.38'", file('check_version.py'))

    def test_settings_has_three_providers(self):
        settings = file('resources/settings/settings.xml')
        for mode in ('0','1','2'):
            with self.subTest(mode=mode):
                self.assertRegex(settings, rf'<listEntry value="{mode}">')
        self.assertIn('sr_source_meteo', file('resources/strings.xml'))

    def test_provider_routes_and_modes(self):
        self.assertIn('return (mode == 1 || mode == 2) ? mode : 0;', self.data)
        self.assertIn('return srProviderMode() == 2;', self.data)
        self.assertIn('if (srUseMeteo()) { return true; }', self.data)
        self.assertIn('"https://api.open-meteo.com/v1/forecast"', self.net)
        self.assertIn('"https://air-quality-api.open-meteo.com/v1/air-quality"', self.net)
        self.assertIn('"https://api.openweathermap.org/data/4.0/onecall/current"', self.net)

    def test_service_activation_only_valid_external_modes(self):
        self.assertEqual(self.geo.count('if (provider == 1 || provider == 2)'), 3)
        self.assertNotIn('if (provider != 0)', self.geo)
        self.assertEqual(self.geo.count('provider = srProviderMode();'), 3)

    def test_isolation_prevents_stale_other_provider_data(self):
        for getter in ('srOwmCurrentSnapshot', 'srOwmForecastSnapshot', 'srOwmDailySnapshot',
                       'srOwmForecastStepSeconds'):
            with self.subTest(getter=getter):
                self.assertIn('srOwmRead("srOLastModeV326") != srProviderMode()', function(self.data,getter))
        self.assertIn('srOwmProviderChanged();', function(self.net,'start'))
        self.assertIn('selected != 2', function(self.net,'onReceive'))
        self.assertIn('selected != 1', function(self.net,'onReceive'))

    def test_switching_settings_defers_storage_migration(self):
        changed = function(self.face, 'refreshChangedSettings')
        self.assertIn('mode == 2 || oldMode == 2', changed)
        self.assertIn('Bg.registerForTemporalEvent', changed)
        self.assertNotIn('srOwmProviderChanged();', changed.split('if (mode != oldMode && (mode == 2 || oldMode == 2))')[1].split('} else if')[0])
        self.assertIn('if (!srUseMeteo()) { srOwmProviderChanged(); }', function(self.face,'getInitialView'))

    def test_only_bounded_weather_requests(self):
        start = function(self.net,'start')
        self.assertIn('"forecast_minutely_15"] = "12"',start)
        self.assertIn('"forecast_hours"] = "4"',start)
        self.assertIn('"forecast_hours"] = "5"',start)
        self.assertIn('"forecast_days"] = "1"',start)
        self.assertIn('"weather_code,rain,snowfall"',start)
        self.assertIn('"timeformat" => "unixtime"',start)
        self.assertEqual(self.net.count('Comm.makeWebRequest('), 2, 'Exactly 1 weather call or 1 Photon call per wake')
        self.assertIn('if (!kindIs("current") && cityLookupDue())', start)
        self.assertIn('startCityLookup();\n            return;', start)

    def test_request_context_and_callback_mode(self):
        self.assertIn('if (_meteo) { context.add(2); }', function(self.net, 'start'))
        self.assertIn('r.size() != 6 && r.size() != 7', function(self.net,'restoreRequestContext'))
        self.assertIn('r.size() == 7 && r[6] == 2', function(self.net,'restoreRequestContext'))
        self.assertIn('receiveMeteo(data); return;', function(self.net,'onReceive'))

    def test_all_wmo_codes_present_in_dispatch(self):
        known = {0,1,2,3,45,48,51,53,55,56,57,61,63,65,66,67,71,73,75,
                 77,80,81,82,85,86,95,96,99}
        mapped = {int(row['wmo_code']):int(row['internal_weather_id']) for row in self.rows}
        self.assertEqual(set(mapped),known | {97})
        code = function(self.net,'meteoId')
        for number in known | {97}:
            with self.subTest(wmo=number):
                self.assertRegex(code,rf'\bwmo\s*==\s*{number}\b')
        self.assertIn('if (wmo == 96 || wmo == 99) { return 299; }', code)
        self.assertIn('return null;',code)

    def test_wmo_mapping_ids_match_published_matrix(self):
        body = function(self.net, 'meteoId')
        found = {}
        for cond, code in re.findall(r'if\s*\(([^)]*)\)\s*\{\s*return\s+(\d+)\s*;',body):
            for number in re.findall(r'wmo\s*==\s*(\d+)',cond):
                k = int(number)
                self.assertNotIn(k,found, f'Duplicate WMO {k}')
                found[k] = int(code)
        expected = {int(row['wmo_code']):int(row['internal_weather_id']) for row in self.rows}
        self.assertEqual(found, expected)

    def test_meteo_hail_not_mislabeled_owm(self):
        self.assertEqual({r['wmo_code'] for r in self.rows if r['internal_weather_id']=='299'}, {'96','99'})
        self.assertIn('srUseMeteo() && id == 299',self.data)
        self.assertIn('srUseMeteo() && code == 299',self.warn)
        self.assertIn('code == 299',self.warn)

    def test_warning_thresholds_stay_user_configurable(self):
        for setting in ('gwRainChanceV332','gwSnowChanceV332','gwWindV332','srOwmGustV3263',
                        'gwFogMetersV332','gwUvV332','gwRainHeavyV332','gwSnowHeavyV332',
                        'gwHailOnV332','gwFreezeOnV332'):
            with self.subTest(setting=setting):
                self.assertIn(setting,self.warn)

    def test_snow_and_rain_use_correct_15m_units(self):
        self.assertIn('r * 4', function(self.net,'meteoQuarterRain'))
        self.assertIn('r * 40', function(self.net,'meteoQuarterSnow'))
        self.assertIn('r * 10', function(self.net,'meteoSnowHour'))
        self.assertIn('stamp < times[j] + 3600', function(self.net,'meteoHourlyAt'))

    def test_diagnostic_includes_raw_code(self):
        self.assertIn('srMRawNowV32638',self.net)
        self.assertIn('srMRawForecastV32638',self.net)
        self.assertIn('"TEST 15: METEO 15M"',self.face)
        self.assertIn('"WMO " + wmo[1].toString()',self.face)
        self.assertIn('"METEO: BRAK DANYCH"',self.face)

    def test_empty_or_invalid_response_is_rejected(self):
        parse = function(self.net,'receiveMeteo')
        self.assertIn('if (!dictionary(data)) { fail(-301); return; }',parse)
        self.assertIn('if (!same(_loc, value("srOLocV326"))) { fail(-213); return; }',parse)
        self.assertIn('if (!ok || _unsafe) { fail(reason); return; }',parse)
        self.assertIn('if (recognized)',parse)

    def test_xml_all_valid(self):
        for xml_file in ROOT.rglob('*.xml'):
            with self.subTest(file=str(xml_file.relative_to(ROOT))):
                ET.parse(xml_file)

if __name__ == '__main__': unittest.main()
