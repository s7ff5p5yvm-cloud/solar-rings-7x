#!/usr/bin/env python3
from pathlib import Path
from math import sqrt
import re, xml.etree.ElementTree as ET
base=Path(__file__).resolve().parents[1]
code=(base/'source/SolarRings7X.mc').read_text()
fields=(base/'source/FieldData.mc').read_text()
ns='{http://www.garmin.com/xml/connectiq}'
root=ET.parse(base/'manifest.xml').getroot()
app=root.find(ns+'application')
assert app.get('version')=='3.8.0'
assert app.get('id')=='D1F8E1A4B7FC45BD91E8F0A0959041BF'
props=ET.parse(base/'resources/settings/properties.xml').getroot()
settings=ET.parse(base/'resources/settings/settings.xml').getroot()
strings=ET.parse(base/'resources/strings.xml').getroot()
pids={x.get('id') for x in props}
sids={x.get('id') for x in strings}
assert len(pids)==len(settings)==35
for setting in settings:
    assert setting.get('propertyKey').split('.')[-1] in pids
    assert setting.get('title').split('.')[-1] in sids
    for entry in setting.findall('.//listEntry'):
        assert entry.text.split('.')[-1] in sids
for token in ('drawMoonPanel(dc);','drawLunarDisk(dc, 73, 147, 12);',
              'moonPhaseCompactLabel()', 'moonPhaseExtendedLabel()',
              'moonPanelV38','moonLabelV38','moonFontV38','drawClock(dc, clock)',
              'drawDate(dc, days[date.day_of_week - 1]',
              'srSetting("slotRing2V3", 2)', 'weatherSymbol(dc, 74, 229, weather)'):
    assert token in code or token in fields,token
assert 'Activity.getActivityInfo()' in fields
assert 'return [isRise,' in fields
# Explicit geometry on the native 280px MIP canvas.
areas={
 'top':(44,27,236,75), 'time':(25,79,181,126),
 'date':(184,79,259,129), 'moon':(59,133,250,160),
 'rings':(35,166,245,213), 'weather':(55,216,228,247),
 'footer':(101,252,190,269)
}
for k,(x1,y1,x2,y2) in areas.items():
    assert 0<=x1<x2<280 and 0<=y1<y2<280,(k,(x1,y1,x2,y2))
for a,b in [('top','time'),('time','moon'),('date','moon'),('moon','rings'),('rings','weather'),('weather','footer')]:
    assert areas[a][3]<areas[b][1],(a,b)
assert areas['time'][2] < areas['date'][0]
# Moon disk + vertical separator + text stay within the dedicated row.
assert 73-12>=areas['moon'][0] and 73+12<96
assert 96<176-72 and 176+72<=areas['moon'][2]
for center in (69,140,211):
    assert 35<=center-33 and center+33<=245
# Outer rim is 3px thick; keep key data visually inside circular content area.
for x,y in ((74,229),(174,238),(117,261),(158,260),(73,147)):
    assert (x-140)**2+(y-140)**2 < 130**2,(x,y)
print('PASS: v3.8 assets, 35 mobile settings, moon phase layout, preserved Garmin HR, day ring and data fields')
