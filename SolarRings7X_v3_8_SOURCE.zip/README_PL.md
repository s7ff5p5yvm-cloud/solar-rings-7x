# Solar Rings 7X v3.8.0 — dodatkowy Księżyc

Wersja oparta na działającej tarczy v3.7 (Fenix 7X Pro Solar 280×280 MIP).

## Układ
- Trzy pola u góry: wschód, faza Księżyca, zachód (konfigurowalne z iPhone’a).
- Duża godzina i data po prawej stronie.
- NOWY poziomy pasek fazy Księżyca między godziną i trzema owalami: dynamicznie oświetlany dysk, opis zmieniany wraz z fazą. Krótki tekst jest ustawieniem domyślnym, żeby pozostał czytelny na 280 px.
- Trzy owale: tętno, kroki, Body Battery (każdy zmieniany na dowolne dane).
- Pogoda z dynamiczną ikoną, temperatura i opis, bateria w stopce.
- Konfigurowalny postęp na obwodzie, niezależny wskaźnik gwałtownego spadku ciśnienia.

## Nowe ustawienia Connect IQ
- Dodatkowe pole fazy Księżyca: Wł./Wył.
- Opis fazy: Krótki / Dłuższy (automatycznie dopasowywany).
- Rozmiar opisu Księżyca: Dziedzicz / XS / S / M / L / XL.

Zachowano 32 istniejące klucze ustawień, łącznie 35. Zachowano AppID do aktualizacji istniejącej bety.

## Uwaga o precyzji
Faza jest przybliżeniem według miesiąca synodycznego, a nie dokładną efemerydą astronomiczną. Ostrzeżenie burzowe jest wyłącznie wskaźnikiem trendu ciśnienia, nie prognozą gwarantującą bezpieczeństwo.

## Instalacja
1. Wrzuć `SolarRings7X_v3_8_SOURCE.zip` do głównego katalogu GitHub.
2. Zastąp `.github/workflows/build-v3.yml` dostarczonym `SolarRings7X_v3_8_BUILD.yml`.
3. Uruchom Actions → `Build Solar Rings 7X v3.8 (3 rings + moon)`.
4. Po poprawnej kompilacji pobierz `.IQ` z Artifacts; aktualizacja bety wymaga konta uprawnionego dewelopera Garmin. Nie udostępniaj nikomu prywatnego klucza.

## Weryfikacja
Lokalne kontrole XML, powiązań ustawień i geometrii 280×280. Nie zastępują sprawdzenia w Garmin SDK i na zegarku.
