#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'source/SolarRings7X.mc').read_text()
assert 'getSystemStats().freeMemory' in s
assert 'Gfx.FONT_XTINY, shortStatus' in s
assert '_fontCacheCount < 20' in s
assert 'if (System.getSystemStats().freeMemory < 18000)' in s
assert 'if (_lowMemory)' in s
assert 'Bg.getTemporalEventRegisteredTime() != null' in s
assert 'srSetting("imgwTestStageV3194", 0) == 0' in s
print('PASS: v3.19.6 memory indicator, bounded font cache and stage-0 isolation')
