# Solar Rings 7X v3.19.6 – naprawa odczytu GPS w tarczy

Wyniki testu na Garmin Fenix 7X Pro Solar: etap 0 stabilny, etap 1 powodował wyłączenie tarczy.

Znaleziono przyczynę w kodzie: bezpośrednie wywołanie Position.getInfo() z tarczy.
Tarcze Connect IQ nie mogą samodzielnie włączać GPS, a bezpośrednie API Position
na różnych urządzeniach/firmware może powodować problemy.

Poprawka:
- w module IMGW lokalizacja z Activity.getActivityInfo().currentLocation (ostatnia pozycja GPS zegarka),
- ten sam bezpieczny mechanizm dla wschodu/zachodu słońca,
- brak GPS -> komunikat T1 GPS? RnnK zamiast wyłączenia tarczy,
- wynik T1 OK RnnK, jeśli pozycja zegarka jest dostępna,
- pamięć RAM i grafika pozostają tak jak w v3.19.5,
- zachowano uprawnienie Positioning (potrzebne dla currentLocation).

Test:
1. Najpierw test 1 – GPS. Poczekaj 2–3 minuty i sprawdź stabilność.
2. Jeśli pokazuje GPS? bez awarii, uruchom na chwilę zwykłą aktywność GPS na otwartym powietrzu,
   po uzyskaniu pozycji wróć do tarczy i sprawdź test 1 ponownie.
3. Dopiero gdy stabilnie działa test 1, przejdź do testu 2 – TŁO.
4. Potem 3 – GUGiK i 4 – IMGW. Na tych etapach sprawdzamy też statusy API.

Uwaga: currentLocation nie jest GPS-em uruchamianym na żądanie, tylko ostatnią
lokalizacją uzyskaną przez zegarek. Gdy jest niedostępna, tarcza nie wyświetla
fałszywej informacji, że IMGW działa. Nie korzysta z lokalizacji stacji pogodowej.

Testy źródłowe nie zastępują kompilacji SDK ani testu na zegarku.
