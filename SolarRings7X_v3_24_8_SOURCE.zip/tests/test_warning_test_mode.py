"""Regression contract: manual preview must bypass the real alert master switch."""
import unittest
from pathlib import Path

R=Path(__file__).resolve().parents[1]
ENGINE=(R/'source/GarminWeatherWarnings.mc').read_text()
FACE=(R/'source/SolarRings7X.mc').read_text()

class WarningPreviewRegression(unittest.TestCase):
    def test_preview_precedes_master_switch(self):
        self.assertLess(ENGINE.index('var preview = srSetting("gwPreviewV324", 0);'),
                        ENGINE.index('if (!srSetting("gwOnV324", false))'))
        for n in (10,11,12,13):
            self.assertLess(ENGINE.index(f'if (preview == {n})'),
                            ENGINE.index('if (!srSetting("gwOnV324", false))'))

    def test_test_wind_does_not_require_live_weather_or_thresholds(self):
        block=ENGINE.split('if (preview > 0 && preview <= 9)',1)[1].split('if (preview == 10)',1)[0]
        self.assertIn('_lastKinds = [preview]',block)
        self.assertIn('return rotatingWarning()',block)
        self.assertNotIn('evaluate(',block)
        self.assertNotIn('gwWindV324',block)

    def test_markers_appear_on_all_temperature_fields(self):
        self.assertIn('var isTemp = (id == 16 || id == 18 || id == 19);',FACE)
        self.assertIn('if (isTemp) {',FACE)
        self.assertIn('_weatherWarnings.warning(weather)', FACE)

    def test_real_alert_off_clears_cache_if_no_preview(self):
        off=ENGINE.split('if (!srSetting("gwOnV324", false))',1)[1].split('var now =',1)[0]
        self.assertIn('reset();', off)
        self.assertIn('return 0;',off)

if __name__ == '__main__': unittest.main()
