"""Geometry regression checks for the Fenix 7X Pro 280x280 round screen."""
from pathlib import Path
import math
import unittest
P=Path(__file__).resolve().parents[1]/"source"/"CompassScreen.mc"
SRC=P.read_text(encoding="utf-8")

class UIGeometry(unittest.TestCase):
    def test_help_is_paged(self):
        self.assertIn("_helpPage = (_helpPage + direction + 3) % 3",SRC)
        self.assertIn('"UP/DOWN: STRONA "',SRC)
        self.assertIn('var y=78+j*35;',SRC)
    def test_guidance_has_two_separate_rows_without_footer(self):
        self.assertIn('_navBandText(dc,cx,h-99,36,192,firstLine',SRC)
        self.assertIn('_navBandText(dc,cx,h-61,32,148,secondLine',SRC)
        self.assertNotIn('_source+" / "+_speedName()',SRC)
        self.assertIn('dc.fillRoundedRectangle(cx-100, h-99, 200, 36, 10)',SRC)
        self.assertIn('dc.fillRoundedRectangle(cx-84, h-61, 168, 32, 10)',SRC)
        self.assertNotIn('h-85,G.FONT_MEDIUM',SRC)
        self.assertNotIn('h-55,G.FONT_MEDIUM',SRC)
        self.assertIn('"PRAWO " : "LEWO "',SRC)
        self.assertIn('"NA KIERUNKU"',SRC)
    def test_safe_chord_near_lower_edge(self):
        # For a 280px circular display, the worst case is each band's lower edge.
        bands=[(181,217,192),(219,251,148)]
        for top,bottom,text_width in bands:
            self.assertLessEqual(text_width,2*math.sqrt(140**2-(bottom-140)**2)-12,
                                 f'band {top}..{bottom} clips circular safe area')
        self.assertLessEqual(168, 2*math.sqrt(140**2-(251-140)**2)-2)
    def test_cardinal_labels_do_not_overlap_dashboard(self):
        self.assertIn('if (letterY < h-107)',SRC)
    def test_menu_footer_avoids_circular_clipping(self):
        self.assertIn('G.FONT_XTINY,G.FONT_XTINY,142,footer',SRC)
        self.assertIn('G.FONT_XTINY,G.FONT_XTINY,142,_toast',SRC)
    def test_saved_bearings_keep_target_and_confirmation(self):
        self.assertIn('"ZAPISZ DO SLOTU"',SRC)
        self.assertIn('"START: NADPISZ"',SRC)
        self.assertIn('"CEL: "+CompassMath.text(_display(_target),_mils)',SRC)
    def test_navigator_turbo_remains_80ms(self):
        self.assertIn('return _speedMode == 2 ? 80 : 100;',SRC)
    def test_current_version(self):
        self.assertIn('version="1.3.4"',(P.parents[1]/"manifest.xml").read_text())
if __name__ == "__main__": unittest.main()
