# Solar Rings 7X v3.6 – czcionki i czytelność

Docelowe urządzenia: Garmin Fenix 7X Pro Solar MIP (280x280), w tym wersja bez Wi-Fi.
Wersja: 3.6.0. Zachowany ID istniejącej aplikacji Connect IQ i wszystkie wcześniejsze klucze ustawień.

## Co się zmieniło
- Trzy pierścienie mają promień 27 px zamiast 30 px i zostały przesunięte 3 px do góry.
- Ikona pogody (chmura, słońce, deszcz itd.) znajduje się 4 px niżej; linia oddzielająca ringi i pogodę została podniesiona.
- Godzina, data, pola wschodu i zachodu, wartości pierścieni, temperatura i opis pogody korzystają teraz w pierwszej kolejności ze skalowalnej czcionki Garmin (Graphics.getVectorFont).
- Nowe ustawienie „Krój czcionki”: Roboto Condensed Bold / Regular, Exo SemiBold, Bionic dla cyfr, Garmin standardowy.
- Nowe ustawienie „Dodatkowe powiększenie tekstu”: 0 / +2 / +4 / +6 px.
- Istniejące ustawienia Mały/Średni/Duży nadal działają niezależnie dla godziny, daty, pól górnych, wartości pierścieni i pogody.
- Dopasowanie napisów bazuje na rzeczywistych rozmiarach glyphów. Długie liczby (np. kroki 12500) są pomniejszane tylko w razie potrzeby, bez obcinania.
- Jeśli wektorowy krój nie jest dostępny na urządzeniu, kod używa systemowej czcionki rastrowej jako bezpiecznego zamiennika.

Nie zmieniono: źródła tętna, konfiguracji danych pól, wskaźnika burzowego, zegarów słonecznych, geometrii pierścienia zewnętrznego ani ID aplikacji.

## Instalacja przez GitHub Actions
1. Prześlij ZIP `SolarRings7X_v3_6_SOURCE.zip` do korzenia istniejącego repozytorium `solar-rings-7x`.
2. W pliku `.github/workflows/build-v3.yml` zamień kod na zawartość `SolarRings7X_v3_6_BUILD.yml`.
3. Uruchom `Actions -> Build Solar Rings 7X v3.6 (3 rings) -> Run workflow`.
4. W artefakcie `SolarRings7X-v36-build` sprawdź rezultat kompilacji, pobierz `.iq`.
5. Zaktualizuj istniejącą aplikację beta Connect IQ i zainstaluj aktualizację z iPhone'a (nie przez skopiowanie `.prg`).

## Test działania
- Otwórz ustawienia Solar Rings 7X w Connect IQ i wybierz `Krój czcionki = Roboto Condensed Bold` oraz `Dodatkowe powiększenie tekstu = +2 px`.
- Zapisz i zsynchronizuj zegarek. Porównaj z +6 px oraz rozmiarem godziny Mały / Duży.
- Sprawdź 5-cyfrowe kroki i czy pogoda nie nachodzi na zewnętrzny pierścień.
- Na Garminie może pojawić się opóźnienie odświeżenia całej tarczy. Jeśli zmiana czcionki nie zadziała, sprawdź wersję 3.6.0 i instalację poprzez Connect IQ.

## Weryfikacja
Projekt przechodzi lokalne testy statyczne struktury XML, obecności ustawień, geometrii i kodu fontów. Kompilacja Garmin SDK oraz prawdziwy wygląd nie zostały zweryfikowane lokalnie i wymagają sprawdzenia w GitHub Actions oraz na zegarku.

## Ważne
Nie udostępniaj pliku prywatnego klucza podpisywania Garmin. Nie ma go w tej paczce. Nie rozprowadzamy również plików czcionek – korzystamy ze skalowalnych czcionek wbudowanych w urządzenie.
