using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;

class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    function getInitialView() { return [new SolarRingsFaceV3()]; }
    function onSettingsChanged() { Ui.requestUpdate(); }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;
    var _fontCache;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
        _fontCache = {};
    }

    // Select genuinely different font sizes for SMALL / NORMAL / LARGE.
    // Always fit the selected font to a reserved box; never draw outside it.
    // IMPORTANT: using a single dynamic largest-fit list made small and
    // large look identical in v3.1. This implementation uses distinct caps.
    // 3.5: native Garmin text throughout. Earlier versions drew clock and
    // ring numbers one bitmap rectangle at a time and sometimes showed NO
    // values on the real MIP screen. One Dc.drawText per value avoids it.
    // This renderer NEVER changes the clip region and always has a fallback.
    function fitScaled(dc, value, x, top, width, height, color, numeric, scale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        var numberOnly = numeric;
        if (numberOnly) {
            for (var i = 0; i < str.length(); i++) {
                var c = str.substring(i, i + 1);
                if ("0123456789:".find(c) == null) {
                    numberOnly = false;
                    break;
                }
            }
        }
        var fonts;
        if (numberOnly) {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_LARGE, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }
        var chosen = Gfx.FONT_XTINY;
        var textH = dc.getFontHeight(chosen);
        for (var j = 0; j < fonts.size(); j++) {
            var dim = dc.getTextDimensions(str, fonts[j]);
            if (dim[0] <= width && dim[1] <= height) {
                chosen = fonts[j];
                textH = dim[1];
                break;
            }
        }
        // No pixel rectangles and NO setClip(): every field is visible.
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        var yy = top + ((height - textH) / 2).toNumber();
        dc.drawText(x, yy, chosen, str, Gfx.TEXT_JUSTIFY_CENTER);
    }

    // NEW v3.6: scalable fonts available on Fenix 7X Pro (Connect IQ 4.2.2+).
    // RobotoCondensedBold is an installed system face, NOT a bundled font file.
    // The optional style and increase settings affect every visible data field.
    function desiredPixels(settingKey, normalSize, increment) {
        var level = srSetting(settingKey, 2);
        if (level < 0) { level = 0; }
        if (level > 2) { level = 2; }
        return normalSize + (level - 1) * increment +
               (srSetting("fontExtraV36", 1) * 2);
    }

    function vectorFontFor(pixels, digits) {
        var style = srSetting("fontFaceV36", 0);
        if (style == 4) { return null; } // Garmin native-only fallback
        var face = "RobotoCondensedBold";
        if (style == 1) { face = "RobotoCondensedRegular"; }
        else if (style == 2) { face = "ExoSemiBold"; }
        else if (style == 3 && digits) { face = "BionicBold"; }
        var key = face + ":" + pixels.toString();
        var cached = _fontCache[key];
        if (cached != null) { return cached; }
        var found = null;
        try { found = Gfx.getVectorFont({:face => face, :size => pixels}); }
        catch (e) { }
        if (found != null) { _fontCache[key] = found; }
        return found;
    }

    function drawSized(dc, value, x, top, width, height, color, digits, sizePixels, fallbackScale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        // Fit the *measured* glyphs into the allotted section.
        // For long values reduce font size rather than truncating steps.
        var smallest = sizePixels - 12;
        if (smallest < 12) { smallest = 12; }
        for (var px = sizePixels; px >= smallest; px -= 2) {
            var font = vectorFontFor(px, digits);
            if (font == null) { break; }
            try {
                var dim = dc.getTextDimensions(str, font);
                if (dim[0] <= width && dim[1] <= height) {
                    dc.setColor(color, Gfx.COLOR_TRANSPARENT);
                    var yy = top + ((height - dim[1]) / 2).toNumber();
                    dc.drawText(x, yy, font, str, Gfx.TEXT_JUSTIFY_CENTER);
                    return;
                }
            } catch (e) {
                // If Garmin rejects a glyph, try the native bitmap fallback.
                break;
            }
        }
        // Never leave a field blank if a face is unsupported.
        fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale);
    }

    function fit(dc, value, x, top, width, height, color, numeric) {
        fitScaled(dc, value, x, top, width, height, color, numeric, 1);
    }


    // Truly visible large clock. Font sizes are measured on the actual device,
    // so changing small/medium/large in the iPhone app changes the candidate
    // set and still fits the reserved 145 x 53 px area.
    function drawClock(dc, clock) {
        var value = twoDigits(clock.hour) + ":" + twoDigits(clock.min);
        drawSized(dc, value, 106, 88, 152, 51, Gfx.COLOR_WHITE, true,
                  desiredPixels("fontClockV31", 42, 6),
                  srSetting("fontClockV31", 2));
    }





    // Small raster digits remain ONLY for sunrise/sunset (the last good
    // version displayed those correctly). The main clock and all ring
    // values use native drawText instead.
    function miniGlyph(ch) {
        if (ch == "0") { return ["111","101","101","101","101","101","111"]; }
        if (ch == "1") { return ["010","110","010","010","010","010","111"]; }
        if (ch == "2") { return ["111","001","001","111","100","100","111"]; }
        if (ch == "3") { return ["111","001","001","111","001","001","111"]; }
        if (ch == "4") { return ["101","101","101","111","001","001","001"]; }
        if (ch == "5") { return ["111","100","100","111","001","001","111"]; }
        if (ch == "6") { return ["111","100","100","111","101","101","111"]; }
        if (ch == "7") { return ["111","001","001","010","010","010","010"]; }
        if (ch == "8") { return ["111","101","101","111","101","101","111"]; }
        if (ch == "9") { return ["111","101","101","111","001","001","111"]; }
        if (ch == ":") { return ["0","1","1","0","1","1","0"]; }
        return ["000","000","000","000","000","000","000"];
    }

    // Fixed-width 3x7 glyphs. All writes are confined to the intended
    // region; use only filled rectangles so this works without font assets.
    function drawPixelDigits(dc, value, centerX, top, pixel, color) {
        if (value == null || value.length() == 0) { return; }
        var units = 0;
        for (var i = 0; i < value.length(); i++) {
            var g = miniGlyph(value.substring(i, i + 1));
            units += g[0].length() + 1;
        }
        units -= 1;
        var x = (centerX - (units * pixel) / 2).toNumber();
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        for (var k = 0; k < value.length(); k++) {
            var glyph = miniGlyph(value.substring(k, k + 1));
            for (var row = 0; row < 7; row++) {
                var bits = glyph[row];
                for (var col = 0; col < bits.length(); col++) {
                    if (bits.substring(col, col + 1) == "1") {
                        dc.fillRectangle(x + col * pixel, top + row * pixel,
                                         pixel, pixel);
                    }
                }
            }
            x += (glyph[0].length() + 1) * pixel;
        }
    }

    function onlyDigits(str) {
        if (str == null || str.length() == 0) { return false; }
        for (var i = 0; i < str.length(); i++) {
            if ("0123456789".find(str.substring(i, i + 1)) == null) {
                return false;
            }
        }
        return true;
    }
    // Sunrise and sunset times use a larger measured Garmin font.
    function drawTopClock(dc, value, center) {
        var pref = srSetting("fontTopV31", 2);
        drawSized(dc, value, center, 48, 65, 29, Gfx.COLOR_WHITE, true,
                  desiredPixels("fontTopV31", 19, 3), pref);
    }

    // Date is on the right of the clock; the two lines are individually
    // fitted to 72px. No clips which can hide the clock or ring values.
    function drawDate(dc, dayLabel, dateLabel) {
        var settingSize = srSetting("fontDateV31", 2);
        drawSized(dc, dayLabel, 223, 87, 65, 25,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontDateV31", 22, 3), settingSize);
        drawSized(dc, dateLabel, 223, 112, 73, 25,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontDateV31", 20, 3), settingSize);
    }

    // Native 1px separators, including the two vertical ones requested
    // between the sunrise / moon / sunset fields.
    function rule(dc, y) {
        dc.setColor(0x666666, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        if (y == 250) {
            dc.drawLine(102, y, 191, y);
        } else {
            dc.drawLine(27, y, 253, y);
        }
    }

    function topDividers(dc) {
        dc.setColor(0x888888, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(113, 25, 113, 75);
        dc.drawLine(167, 25, 167, 75);
    }

    function weatherDivider(dc) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(112, 209, 112, 247);
    }

    function sunIcon(dc, x, y, settingSun) {
        dc.setColor(settingSun ? Gfx.COLOR_YELLOW : Gfx.COLOR_ORANGE,
                    Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 5, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 9, y, x + 9, y);
        dc.drawLine(x, y - 9, x, y - 6);
        dc.setPenWidth(1);
    }

    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 2, 4);
        dc.fillCircle(x + 4, y - 2, 4);
        dc.fillRectangle(x - 5, y, 10, 4);
        dc.drawLine(x - 7, y + 2, x, y + 9);
        dc.drawLine(x, y + 9, x + 7, y + 2);
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, 7);
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x + 4, y - 2, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // independent pressure-warning bolt, they describe present weather.
    function weatherSymbol(dc, x, y, weather) {
        if (weather == null || weather.condition == null) {
            // Missing weather: neutral outline, no invented condition.
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.drawLine(x, y - 4, x, y + 1);
            dc.drawCircle(x, y + 5, 1);
            dc.setPenWidth(1);
            return;
        }
        var c = weather.condition;
        // Pure sunshine.
        if (c == Weather.CONDITION_CLEAR || c == Weather.CONDITION_FAIR ||
            c == Weather.CONDITION_MOSTLY_CLEAR) {
            dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y - 2, 10);
            dc.drawLine(x, y - 19, x, y - 15);
            dc.drawLine(x, y + 11, x, y + 16);
            dc.drawLine(x - 18, y - 2, x - 14, y - 2);
            dc.drawLine(x + 14, y - 2, x + 18, y - 2);
            dc.drawLine(x - 13, y - 15, x - 10, y - 12);
            dc.drawLine(x + 10, y + 8, x + 13, y + 11);
            dc.drawLine(x + 12, y - 15, x + 9, y - 12);
            dc.drawLine(x - 9, y + 8, x - 12, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Cloud with some sun.
        if (c == Weather.CONDITION_PARTLY_CLOUDY ||
            c == Weather.CONDITION_PARTLY_CLEAR ||
            c == Weather.CONDITION_THIN_CLOUDS) {
            cloud(dc, x, y);
            return;
        }
        // Cloud and precipitation.
        if (c == Weather.CONDITION_RAIN || c == Weather.CONDITION_LIGHT_RAIN ||
            c == Weather.CONDITION_HEAVY_RAIN || c == Weather.CONDITION_DRIZZLE ||
            c == Weather.CONDITION_SCATTERED_SHOWERS || c == Weather.CONDITION_SHOWERS ||
            c == Weather.CONDITION_LIGHT_SHOWERS || c == Weather.CONDITION_HEAVY_SHOWERS ||
            c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN ||
            c == Weather.CONDITION_UNKNOWN_PRECIPITATION) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(0x00AAFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 12, x - 13, y + 18);
            dc.drawLine(x, y + 12, x - 3, y + 18);
            dc.drawLine(x + 10, y + 12, x + 7, y + 18);
            dc.setPenWidth(1);
            return;
        }
        // Snow / wintry conditions.
        if (c == Weather.CONDITION_SNOW || c == Weather.CONDITION_LIGHT_SNOW ||
            c == Weather.CONDITION_HEAVY_SNOW || c == Weather.CONDITION_FLURRIES ||
            c == Weather.CONDITION_CHANCE_OF_SNOW || c == Weather.CONDITION_WINTRY_MIX ||
            c == Weather.CONDITION_RAIN_SNOW || c == Weather.CONDITION_ICE_SNOW ||
            c == Weather.CONDITION_LIGHT_RAIN_SNOW || c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
            c == Weather.CONDITION_FREEZING_RAIN || c == Weather.CONDITION_SLEET ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 11, x - 10, y + 19);
            dc.drawLine(x - 14, y + 15, x - 6, y + 15);
            dc.drawLine(x + 7, y + 11, x + 7, y + 19);
            dc.drawLine(x + 3, y + 15, x + 11, y + 15);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_THUNDERSTORMS ||
            c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
            c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS ||
            c == Weather.CONDITION_TROPICAL_STORM) {
            simpleCloud(dc, x, y - 6);
            stormBolt(dc, x + 2, y + 13);
            return;
        }
        if (c == Weather.CONDITION_FOG || c == Weather.CONDITION_MIST ||
            c == Weather.CONDITION_HAZY || c == Weather.CONDITION_HAZE) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 20, y - 9, x + 16, y - 9);
            dc.drawLine(x - 16, y - 2, x + 20, y - 2);
            dc.drawLine(x - 20, y + 5, x + 15, y + 5);
            dc.drawLine(x - 13, y + 12, x + 20, y + 12);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_WINDY || c == Weather.CONDITION_SQUALL) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 22, y - 5, x + 12, y - 5);
            dc.drawLine(x - 12, y + 3, x + 19, y + 3);
            dc.drawLine(x - 19, y + 11, x + 10, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Overcast / unclassified present weather.
        simpleCloud(dc, x, y);
    }

    function simpleCloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 11, y + 2, 8);
        dc.fillCircle(x + 1, y - 4, 11);
        dc.fillCircle(x + 14, y + 3, 8);
        dc.fillRectangle(x - 17, y + 3, 38, 9);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 35) {
            var currentWeather = null;
            try { currentWeather = Weather.getCurrentConditions(); } catch (e) { }
            var event = nextSunEvent(currentWeather);
            if (event != null) { sunIcon(dc, x, y, event[0]); }
            else { genericIcon(dc, x, y, Gfx.COLOR_LT_GRAY); }
        }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3 || id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { stopwatch(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }

    function topSlot(dc, x, id, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        if (id == 35) {
            var nextEvent = nextSunEvent(weather);
            if (nextEvent != null) { sunIcon(dc, x, 37, nextEvent[0]); }
            else { genericIcon(dc, x, 37, Gfx.COLOR_LT_GRAY); }
        } else {
            drawIcon(dc, x, 37, id, 0x00CCFF);
        }
        var v = d[1];
        // The top row is a dedicated 68px slot, with a 1px separator.
        if (id == 14 || id == 15 || id == 35) {
            drawTopClock(dc, v, x);
        } else {
            drawSized(dc, v, x, 51, 62, 25, Gfx.COLOR_WHITE,
                      false, desiredPixels("fontTopV31", 18, 3),
                      srSetting("fontTopV31", 2));
        }
    }

    

    // Three 54px diameter rings at Y=173, with extra spacing below. Icons in the
    // upper half and native text values in the lower half. All digits appear
    // on the watch even when data = 12345 or when Body Battery is missing.
    function ring(dc, x, id, colorCode, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var y = 173;
        var radius = 27;
        var col = srColor(colorCode);
        dc.setPenWidth(4);
        dc.setColor(0x414141, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        var ratio = d[2];
        dc.setColor(col, Gfx.COLOR_TRANSPARENT);
        if (ratio == null) {
            dc.drawCircle(x, y, radius);
        } else {
            var p = ratio.toFloat();
            if (p < 0.0) { p = 0.0; }
            if (p > 1.0) { p = 1.0; }
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (359.0 * p).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
        drawIcon(dc, x, 161, id, col);
        var v = d[1];
        // Preserve full five-digit steps; if larger, use compact presentation.
        if (id == 2 && v.length() > 5 && monitor.steps != null) {
            v = compact(monitor.steps);
        }
        drawSized(dc, v, x, 177, 48, 22, Gfx.COLOR_WHITE,
                  onlyDigits(v), desiredPixels("fontRingV31", 19, 3),
                  srSetting("fontRingV31", 2));
    }

    

    // Dedicated 43px weather area. Same visual composition as the reference:
    // pictogram LEFT, large temperature RIGHT, short condition BELOW.
    // Weather zone Y=207..249, deliberately independent from the rings
    // and footer. The icon changes with the actual Garmin weather condition.
    // Weather is composed like the reference: large dynamic icon LEFT,
    // divider, large temperature RIGHT, condition directly underneath.
    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var sz = srSetting("fontWeatherV31", 2);
        if (id == 16) {
            weatherSymbol(dc, 70, 229, weather);
            drawSized(dc, d[1], 173, 207, 116, 28,
                      Gfx.COLOR_WHITE, false,
                      desiredPixels("fontWeatherV31", 23, 3), sz);
            drawSized(dc, conditionText(weather), 169, 228, 112, 21,
                      Gfx.COLOR_WHITE, false,
                      desiredPixels("fontWeatherV31", 17, 2), sz);
        } else {
            drawIcon(dc, 70, 229, id, 0x00CCFF);
            drawSized(dc, d[1], 173, 207, 116, 28,
                      Gfx.COLOR_WHITE, false,
                      desiredPixels("fontWeatherV31", 23, 3), sz);
            drawSized(dc, d[0], 169, 228, 112, 21,
                      Gfx.COLOR_LT_GRAY, false,
                      desiredPixels("fontWeatherV31", 17, 2), sz);
        }
    }

    // Battery footer resides inside the circle at Y=251..267 and cannot
    // touch the outer progress ring. All contents stay in a 76px box.
    // Battery is separate from the outer ring and weather description.
    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 120, 260, id, Gfx.COLOR_GREEN);
        drawSized(dc, d[1], 155, 250, 49, 17,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontWeatherV31", 17, 2),
                  srSetting("fontWeatherV31", 2));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = readField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 131;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function onUpdate(dc) {
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var clock = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND", "PN", "WT", "SR", "CZ", "PT", "SB"];
        var months = ["STY", "LUT", "MAR", "KWI", "MAJ", "CZE",
                      "LIP", "SIE", "WRZ", "PAZ", "LIS", "GRU"];
        var monitor = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }

        // First the optional outer ring; all content is drawn over it.
        outerProgressRing(dc, monitor, w, clock);

        // Top: 3 independently configurable fields, two vertical separators.
        topSlot(dc, 77, srSetting("slotTop1V3", 14), monitor, w);
        topSlot(dc, 140, srSetting("slotTop2V3", 34), monitor, w);
        topSlot(dc, 203, srSetting("slotTop3V3", 15), monitor, w);
        topDividers(dc);
        rule(dc, 81);

        // Dedicated middle row: time and date, no shared clipping region.
        drawClock(dc, clock);
        drawDate(dc, days[date.day_of_week - 1],
                 date.day.toString() + " " + months[date.month - 1]);
        rule(dc, 142);

        // Three progress rings, native-font values guaranteed to be attempted.
        ring(dc, 69, srSetting("slotRing1V3", 1),
             srSetting("colorRing1V3", 0), monitor, w);
        ring(dc, 140, srSetting("slotRing2V3", 2),
             srSetting("colorRing2V3", 2), monitor, w);
        ring(dc, 211, srSetting("slotRing3V3", 3),
             srSetting("colorRing3V3", 6), monitor, w);
        rule(dc, 205);

        // Left weather pictogram | right temperature + conditions.
        drawWeather(dc, monitor, w);
        weatherDivider(dc);
        rule(dc, 250);
        drawBattery(dc, monitor, w);

        // Independent barometric trend indicator, disabled by default.
        if (_storm.warning()) { stormBolt(dc, 253, 175); }
    }

    
}
