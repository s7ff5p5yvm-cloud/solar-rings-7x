# Solar Rings 7X v3.24.23 — bezpieczna optymalizacja CPU

Buduj z `SolarRings7X_v3_24_23_SOURCE.zip` przy użyciu workflow `SolarRings7X_v3_24_23_BUILD.yml`.
Po GitHub Actions pobierz artefakt `SolarRings7X_weather_v32423` i zainstaluj `SolarRings7X_v32423.prg`.

## Zmiany względem v3.24.22
- Dwie stałe tablice geometrii Księżyca zamiast ponawiania 15 pierwiastków dla małej ikony. Duży Księżyc był już zoptymalizowany. Zachowano pierwiastek dla ewentualnych innych promieni.
- Buforowany jest **wyłącznie tekst** daty (`dzień miesiąca` i `miesiąc`), przy każdym odświeżeniu nadal odczytywany jest aktualny kalendarz.
- Buforowany jest **wyłącznie tekst** godziny (w obrębie aktualnej minuty), a bieżąca godzina i ustawienia czcionki są sprawdzane przy każdym odświeżeniu.
- Buforowany jest **wyłącznie wynik formatowania** wieku pogody dla tej samej liczby minut. Czas `observationTime` i stan Bluetooth nadal są odczytywane na bieżąco.
- Bez zmian w danych i ustawieniach użytkownika, progach i rotacji ostrzeżeń, rysowaniu kapsuł, baterii, czujnikach, integracji Garmin Weather, częstotliwości pełnych i częściowych odświeżeń.

## Ograniczenia
Testy Python są statyczne i matematyczne; nie potwierdzają kompilacji Monkey C ani poprawy zużycia energii. Brak Garmin SDK w środowisku autora. Wpływ na baterię prawdopodobnie niewielki i wymaga pomiaru na zegarku. Bufory zabierają dodatkową, małą ilość pamięci; w razie problemów można wrócić do sprawdzonej 3.24.22.
