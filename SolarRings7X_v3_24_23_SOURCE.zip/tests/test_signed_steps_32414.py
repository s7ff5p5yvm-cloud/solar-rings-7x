import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'source/SolarRings7X.mc').read_text()
class SignedSteps(unittest.TestCase):
    def test_signed_difference(self):
        segment=SRC.split('// Optional dual-line steps display')[1].split('var valueW = width - 35;')[0]
        self.assertIn('var remainingSteps = monitor.stepGoal - doneSteps;', segment)
        self.assertIn('var remainingText = remainingSteps.toString();', segment)
        self.assertNotIn('remainingSteps < 0', segment)
        self.assertIn('drawSized(dc, remainingText', segment)
        self.assertEqual(segment.count('drawSized(dc,'), 2)
        self.assertNotIn('capsuleTrack(dc', segment)
    def test_examples(self):
        for goal, steps, expected in [(6000,4500,1500),(6000,6000,0),(6000,6442,-442),(6000,16000,-10000)]:
            self.assertEqual(goal-steps,expected)
    def test_font_autofit(self):
        segment=SRC.split('function drawSized(')[1].split('function fit(')[0]
        self.assertIn('dc.getTextDimensions(str, font)',segment)
        self.assertIn('dim[0] <= width && dim[1] <= height',segment)
        self.assertIn('fitScaled(dc, str, x, top, width, height',segment)
if __name__=='__main__': unittest.main()
