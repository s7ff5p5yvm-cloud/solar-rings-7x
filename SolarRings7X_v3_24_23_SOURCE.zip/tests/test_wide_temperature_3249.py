"""Static geometry tests for dual icons plus negative two-digit temperatures."""
from pathlib import Path
import re, unittest, math
SRC=(Path(__file__).resolve().parents[1]/'source/SolarRings7X.mc').read_text()
class WideTemperature3249(unittest.TestCase):
    def test_left_anchored_measured_temperature(self):
        self.assertIn('var tempLeft = hasMarkers ? 148 : 147;', SRC)
        self.assertIn('var tempRight = hasMarkers ? 227 : 227;', SRC)
        self.assertIn('var actualTempCenter = drawWeatherTemperature(dc, shownTemp, tempLeft, tempRight);', SRC)
        self.assertIn('dc.getTextDimensions(str, font)', SRC)
        self.assertIn('var center = left + (chosenDim[0] / 2).toNumber();', SRC)
        self.assertGreaterEqual(148-(140+4), 3)
        self.assertEqual(227-148, 79)
        self.assertIn('var lowerCenter = actualTempCenter;', SRC)
        self.assertIn('srSetting("tempLayoutTestV32412", 0)', SRC)
        self.assertIn('shownTemp = "-35°C"', SRC)
        self.assertIn('shownTemp = "-99°C"', SRC)
        self.assertIn('lowerLabel = "ODCZ. -45°C"', SRC)
        self.assertIn('lowerLabel = "ODCZ. -99°C"', SRC)
    def test_separate_icons_and_separator(self):
        self.assertIn('dc.drawLine(109, 220, 109, 245);',SRC)
        self.assertIn('drawGarminWarningIcon(dc, 123, 227, warning)',SRC)
        self.assertIn('temperatureMarker(dc, weather, warning != 0 ? 140 : 136, 227)',SRC)
        self.assertIn('dc.setClip(113, 216, 20, 22)',SRC)
        self.assertIn('drawGarminWarningIcon(dc, 123, 227, nextKind)',SRC)
        # Warning geometry occupies x111..129, leaving 2 px to x109 separator.
        self.assertGreaterEqual((120-9)-109,2)
    def test_right_edge_inside_circular_display_at_baseline(self):
        # conservative radius 131 centered on the 280px screen
        r=131; cy=140
        # temperature's top/height are 215/22; bottom-right usable edge at y237
        edge=140+math.sqrt(r*r-(237-cy)**2)
        self.assertGreaterEqual(edge,227)
if __name__=='__main__': unittest.main()
