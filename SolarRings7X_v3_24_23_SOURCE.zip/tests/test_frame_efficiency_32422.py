"""Static regression checks for v3.24.23. Device SDK profiling still required."""
import re
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
FACE = (ROOT/'source/SolarRings7X.mc').read_text()
FIELDS = (ROOT/'source/FieldData.mc').read_text()
CONFIG = (ROOT/'source/Config.mc').read_text()
WARN = (ROOT/'source/GarminWeatherWarnings.mc').read_text()

class FrameEfficiency32422(unittest.TestCase):
    def test_stats_shared_within_frame_and_not_between_frames(self):
        self.assertEqual(FACE.count('System.getSystemStats()'), 1)
        self.assertIn('_srFrameSystemStats = stats;', FACE)
        self.assertIn('_srFrameSystemStats = null;', FACE)
        self.assertIn('srSystemStatsForFrame().charging', FACE)
        self.assertIn('srSystemStatsForFrame().battery', FIELDS)
        self.assertIn('function srSystemStatsForFrame()', FIELDS)
    def test_field_cache_generation_changes_every_full_update(self):
        self.assertIn('_frameEpoch += 1;', FACE)
        self.assertIn('entry[0] == _frameEpoch', FACE)
        self.assertIn('entry[1] = result;', FACE)
        self.assertIn('var result = readField(id, monitor, weather);', FACE)
        self.assertEqual(FACE.count('var d = frameField(id, monitor, weather);'), 4)
        self.assertIn('var field = frameField(dataId, monitor, weather);', FACE)
        self.assertNotIn('var d = readField(id, monitor, weather);', FACE)
    def test_settings_cap_covers_all_persisted_settings(self):
        all_src='\n'.join(p.read_text() for p in (ROOT/'source').glob('*.mc'))
        names=set(re.findall(r'srSetting\("([^"]+)"',all_src))
        forced=set(re.findall(r'key == "([^"]+)"',CONFIG.split('var cached =')[0]))
        self.assertLessEqual(len(names - forced), 64)
        self.assertIn('_srSettingCacheSize < 64',CONFIG)
        self.assertIn('srResetSettingsCache();', FACE)
    def test_live_data_and_notifications_preserved(self):
        for line in ('Monitor.getInfo()', 'System.getClockTime()',
                     'System.getDeviceSettings().phoneConnected',
                     'var remainingSteps = monitor.stepGoal - doneSteps;',
                     'chargingBatteryIcon(dc, 117, 261, Gfx.COLOR_GREEN)',
                     'drawWeatherAge(dc, w);', 'function onPartialUpdate(dc)'):
            self.assertIn(line, FACE)
        for line in ('Weather.getHourlyForecast()', 'rotatingWarning()',
                     'function classify(', 'function evaluate('):
            self.assertIn(line, WARN)
    def test_weather_polls_unchanged(self):
        self.assertIn('now - _cachedWeatherAt < 10', FACE)
        self.assertIn('now - _lastCheck >= interval * 60',WARN)
    def test_render_generation_is_not_reused_from_old_setting_changes(self):
        self.assertIn('_frameFieldResults = {};',FACE)
        self.assertIn('_face.resetPerformanceCaches();',FACE)

if __name__=='__main__': unittest.main()
