"""Static regression checks for performance-only changes; not an SDK emulator."""
from pathlib import Path
import unittest,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
FACE=(ROOT/'source/SolarRings7X.mc').read_text()
FIELDS=(ROOT/'source/FieldData.mc').read_text()
CONFIG=(ROOT/'source/Config.mc').read_text()
WARN=(ROOT/'source/GarminWeatherWarnings.mc').read_text()

class Optimization32422(unittest.TestCase):
    def test_version(self):
        root=ET.parse(ROOT/'manifest.xml').getroot()
        app=root.find('{http://www.garmin.com/xml/connectiq}application')
        self.assertEqual(app.attrib['version'],'3.24.23')
        self.assertIn("== '3.24.23'",(ROOT/'check_version.py').read_text())

    def test_setting_cache_explicitly_invalidated_when_gcm_changes_settings(self):
        self.assertIn('function srResetSettingsCache()',CONFIG)
        self.assertIn('if (cached != null) { return cached; }',CONFIG)
        self.assertIn('_srSettingCacheSize < 64',CONFIG)
        a=FACE.split('function onSettingsChanged()')[1].split('class SolarRingsFaceV3')[0]
        self.assertIn('srResetSettingsCache();',a)
        self.assertIn('_face.resetPerformanceCaches();',a)
        self.assertIn('_face.resetWeatherWarningCache();',a)
        self.assertIn('Ui.requestUpdate();',a)

    def test_vector_fonts_fitted_by_value_and_geometry_not_by_color(self):
        a=FACE.split('function drawSized(')[1].split('function fit(dc,')[0]
        for fragment in ['cached[0] == str','cached[1] == sizePixels',
                         'cached[2] == digits','cached[6] == width',
                         'cached[7] == height','_sizedFitCacheSize < 16',
                         'var slotKey = x * 512 + top;',
                         'var low = 10;','var high = sizePixels - 1;',
                         'fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale)']:
            self.assertIn(fragment,a)
        self.assertIn('_sizedFitCache.remove(slotKey);',a)
        self.assertNotIn('for (var px = sizePixels;',a)

    def test_slot_keys_do_not_overlap_on_280px_screen(self):
        # All valid 280 x 280 centers occupy unique numeric keys.
        self.assertEqual(len({x*512+y for x in range(280) for y in range(280)}),280*280)

    def test_clock_fit_cache_preserves_double_draw_and_original_placement(self):
        a=FACE.split('function drawClock(')[1].split('// Mini digits')[0]
        for fragment in ('_clockFitCache','clockCached[0] == value',
                         'clockCached[1] == requested','var cx = 97;',
                         'var slotW = 164;','var slotH = 52;',
                         'dc.drawText(cx + 1, yy, chosenFont, value, Gfx.TEXT_JUSTIFY_CENTER)'):
            self.assertIn(fragment,a)

    def test_temperature_binary_search_preserves_original_left_alignment(self):
        a=FACE.split('function drawWeatherTemperature(')[1].split('function drawWeather(',1)[0]
        for fragment in ('_tempFitCache','var requested = vectorFontFor(pixels, false);',
                         'var high = pixels - 1;','var low = 10;',
                         'dc.getTextDimensions(str, probe)',
                         'var center = left + (chosenDim[0] / 2).toNumber();',
                         'var center2 = left + (dim2[0] / 2).toNumber();',
                         'drawSized(dc, str, left + width / 2, 215, width, 22,'):
            self.assertIn(fragment,a)
        self.assertNotIn('for (var px = pixels; px >= 10; px -= 1)',a)

    def test_temperature_search_equivalent_to_previous_linear_search(self):
        for requested in range(10,67):
            for best in range(9,requested+1):
                expected=next((p for p in range(requested,9,-1) if p<=best),None)
                chosen=requested if requested<=best else None
                if chosen is None:
                    lo,hi=10,requested-1
                    while lo<=hi:
                        mid=(lo+hi)//2
                        if mid<=best: chosen=mid;lo=mid+1
                        else:hi=mid-1
                self.assertEqual(chosen,expected)

    def test_nearest_sun_event_expires_on_event_crossing(self):
        a=FIELDS.split('function nextSunEvent(')[1].split('function conditionText(')[0]
        for fragment in ('_srNextSunEvent','cached[1] == observation',
                         'nowSeconds - cached[0] < (cached[3] == null ? 30 : 120)',
                         'nowSeconds < cached[2]',
                         'selected.value()',
                         'Weather.getSunrise(location, now)',
                         'Weather.getSunset(location, now)'):
            self.assertIn(fragment,a)
        # A cached event is never valid on/after the event instant.
        def valid(now,stored,expires,observation_eq=True):
            return observation_eq and now>=stored and now-stored <120 and now<expires
        self.assertTrue(valid(100,99,101))
        self.assertFalse(valid(101,99,101))
        self.assertFalse(valid(102,99,101))
        self.assertFalse(valid(200,0,1000))

    def test_no_second_sun_lookup_in_top_icon(self):
        a=FACE.split('function topSlot(')[1].split('function capsuleTrack(')[0]
        self.assertIn('if (d[1] != "--:--")',a)
        self.assertNotIn('nextSunEvent(weather)',a)
        self.assertIn('nextSunEvent(getCachedConditions())', FACE)

    def test_weather_fetched_once_per_ten_seconds_without_network_requests(self):
        a=FACE.split('function getCachedConditions()')[1].split('function resetWeatherWarningCache()')[0]
        self.assertIn('now - _cachedWeatherAt < 10',a)
        self.assertEqual(FACE.count('Weather.getCurrentConditions()'),1)
        self.assertIn('var w = getCachedConditions();',FACE)
        self.assertNotIn('Communications.makeWebRequest',FACE)

    def test_moon_computation_reuses_current_minute(self):
        self.assertIn('var _srMoonSample = null;',FIELDS)
        self.assertIn('_srMoonSample[0] == minute',FIELDS)
        a=FACE.split('function drawLunarDisk(')[1].split('function drawMoonPanel(')[0]
        self.assertIn('_moonCosCache[0] == minute',a)
        self.assertIn('Math.cos(2.0 * Math.PI * phase)',a)

    def test_no_movement_of_main_geometry(self):
        for s in ('drawSized(dc, dayLabel, 197, 80, 58, 23,',
                  'drawSized(dc, dateLabel, 197, 104, 58, 25,',
                  'dc.setClip(113, 216, 20, 22);',
                  'drawGarminWarningIcon(dc, 123, 227, warning)',
                  'var tempLeft = hasMarkers ? 148 : 147;',
                  'chargingBatteryIcon(dc, 117, 261, Gfx.COLOR_GREEN)'):
            self.assertIn(s,FACE)

    def test_always_current_user_data_not_cached(self):
        for frag in ('Monitor.getInfo()',
                     'System.getDeviceSettings().phoneConnected',
                     'srSystemStatsForFrame().charging',
                     'var remainingSteps = monitor.stepGoal - doneSteps;',
                     'var clock = System.getClockTime();'):
            self.assertIn(frag,FACE)
        self.assertIn('Activity.getActivityInfo()',FIELDS)
        self.assertIn('function onPartialUpdate(dc)',FACE)
        self.assertIn('Weather.getHourlyForecast()',WARN)
        self.assertIn('rotatingWarning()',WARN)

if __name__=='__main__': unittest.main()
