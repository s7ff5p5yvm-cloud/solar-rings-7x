using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;
using Toybox.Math as Math;
using Toybox.Background as Bg;
using Toybox.Application.Storage as Storage;
using Toybox.Position as Position;
using Toybox.Lang as Lang;

// App class is also available to the small IMGW background service.
(:background)
class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    // Register background events only from the foreground watch-face view.
    // AppBase.onStart() also runs inside the background worker; scheduling
    // from there can recursively restart the service on some firmware.
    function getInitialView() {
        updateImgwScheduler();
        return [new SolarRingsFaceV3()];
    }

    function getServiceDelegate() { return [new ImgwServiceV318()]; }

    function onStart(state) {
        AppBase.onStart(state);
    }

    function onSettingsChanged() {
        updateImgwScheduler();
        try { Storage.deleteValue("imgwResultV318"); } catch (e) { }
        try { Ui.requestUpdate(); } catch (e) { }
    }

    function updateImgwScheduler() {
        try {
            if (App.Properties.getValue("imgwOnV317") == true) {
                var interval = App.Properties.getValue("imgwMinutesV317");
                if (interval == null || interval < 15) { interval = 30; }
                // Re-register on settings change and startup, if supported.
                Bg.registerForTemporalEvent(new Time.Duration(interval * 60));
            } else {
                Bg.deleteTemporalEvent();
                Storage.deleteValue("imgwResultV318");
            }
        } catch (e) { }
    }

    function onBackgroundData(data) {
        try {
            if (data != null && data instanceof Lang.Array && data.size() >= 6) {
                Storage.setValue("imgwResultV318", data);
            }
        } catch (e) { }
        // Never let an IMGW callback terminate the watch-face renderer.
        try { Ui.requestUpdate(); } catch (e) { }
    }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;
    var _fontCache;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
        _fontCache = {};
    }

    // Select genuinely different font sizes for SMALL / NORMAL / LARGE.
    // Always fit the selected font to a reserved box; never draw outside it.
    // IMPORTANT: using a single dynamic largest-fit list made small and
    // large look identical in v3.1. This implementation uses distinct caps.
    // 3.5: native Garmin text throughout. Earlier versions drew clock and
    // ring numbers one bitmap rectangle at a time and sometimes showed NO
    // values on the real MIP screen. One Dc.drawText per value avoids it.
    // This renderer NEVER changes the clip region and always has a fallback.
    function fitScaled(dc, value, x, top, width, height, color, numeric, scale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        var numberOnly = numeric;
        if (numberOnly) {
            for (var i = 0; i < str.length(); i++) {
                var c = str.substring(i, i + 1);
                if ("0123456789:".find(c) == null) {
                    numberOnly = false;
                    break;
                }
            }
        }
        var fonts;
        if (numberOnly) {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_LARGE, Gfx.FONT_MEDIUM,
                         Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }
        var chosen = Gfx.FONT_XTINY;
        var textH = dc.getFontHeight(chosen);
        for (var j = 0; j < fonts.size(); j++) {
            var dim = dc.getTextDimensions(str, fonts[j]);
            if (dim[0] <= width && dim[1] <= height) {
                chosen = fonts[j];
                textH = dim[1];
                break;
            }
        }
        // No pixel rectangles and NO setClip(): every field is visible.
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        var yy = top + ((height - textH) / 2).toNumber();
        dc.drawText(x, yy, chosen, str, Gfx.TEXT_JUSTIFY_CENTER);
    }

    // NEW v3.6: scalable fonts available on Fenix 7X Pro (Connect IQ 4.2.2+).
    // RobotoCondensedBold is an installed system face, NOT a bundled font file.
    // The optional style and increase settings affect every visible data field.
    function desiredPixels(settingKey, normalSize, increment) {
        var level = srSetting(settingKey, 2);
        if (level < 0) { level = 0; }
        if (level > 2) { level = 2; }
        return normalSize + (level - 1) * increment +
               (srSetting("fontExtraV36", 1) * 2);
    }

    // v3.7: Independent field size controls, with backwards-compatible group
    // settings as defaults. -1 means inherit the existing group setting.
    // 0..4 map to XS / Small / Medium / Large / XL.
    function fieldPixels(fieldKey, groupKey, normalSize, step) {
        var chosen = srSetting(fieldKey, -1);
        if (chosen == -1) {
            var groupLevel = srSetting(groupKey, 2);
            if (groupLevel < 0) { groupLevel = 0; }
            if (groupLevel > 2) { groupLevel = 2; }
            chosen = groupLevel * 2;
        }
        if (chosen < 0) { chosen = 0; }
        if (chosen > 4) { chosen = 4; }
        return normalSize + (chosen - 2) * step +
               (srSetting("fontExtraV36", 1) * 2);
    }

    function fieldScale(fieldKey, groupKey) {
        var level = srSetting(fieldKey, -1);
        if (level < 0) { return srSetting(groupKey, 2); }
        if (level <= 1) { return 0; }
        if (level == 2) { return 1; }
        return 2;
    }

    function vectorFontFor(pixels, digits) {
        var style = srSetting("fontFaceV36", 0);
        if (style == 4) { return null; } // Garmin native-only fallback
        var face = "RobotoCondensedBold";
        if (style == 1) { face = "RobotoCondensedRegular"; }
        else if (style == 2) { face = "ExoSemiBold"; }
        else if (style == 3 && digits) { face = "BionicBold"; }
        var key = face + ":" + pixels.toString();
        var cached = _fontCache[key];
        if (cached != null) { return cached; }
        var found = null;
        try { found = Gfx.getVectorFont({:face => face, :size => pixels}); }
        catch (e) { }
        if (found != null) { _fontCache[key] = found; }
        return found;
    }

    function drawSized(dc, value, x, top, width, height, color, digits, sizePixels, fallbackScale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }
        // Fit the *measured* glyphs into the allotted section.
        // For long values reduce font size rather than truncating steps.
        var smallest = 10;
        for (var px = sizePixels; px >= smallest; px -= 1) {
            var font = vectorFontFor(px, digits);
            if (font == null) { break; }
            try {
                var dim = dc.getTextDimensions(str, font);
                if (dim[0] <= width && dim[1] <= height) {
                    dc.setColor(color, Gfx.COLOR_TRANSPARENT);
                    var yy = top + ((height - dim[1]) / 2).toNumber();
                    dc.drawText(x, yy, font, str, Gfx.TEXT_JUSTIFY_CENTER);
                    return;
                }
            } catch (e) {
                // If Garmin rejects a glyph, try the native bitmap fallback.
                break;
            }
        }
        // Never leave a field blank if a face is unsupported.
        fitScaled(dc, str, x, top, width, height, color, digits, fallbackScale);
    }

    function fit(dc, value, x, top, width, height, color, numeric) {
        fitScaled(dc, value, x, top, width, height, color, numeric, 1);
    }


    // Truly visible large clock. Font sizes are measured on the actual device,
    // so changing small/medium/large in the iPhone app changes the candidate
    // set and still fits the reserved 145 x 53 px area.
    // v3.12: wider 164px bold clock, still separate from the unchanged date.
    // Distinct target sizes (small/medium/large) avoid prior settings collapsing
    // to one size. Actual glyph bounds are measured before drawing.
    function drawClock(dc, clock) {
        var value = twoDigits(clock.hour) + ":" + twoDigits(clock.min);
        var pref = srSetting("fontClockV31", 2);
        var requested = 62;
        if (pref <= 0) { requested = 46; }
        else if (pref == 1) { requested = 54; }
        requested += srSetting("fontExtraV36", 1) * 2;
        // Horizontal position is deliberately separated from the date box.
        // 77..129 is the full vertical band between the rules at 76 and 130.
        var cx = 97;
        var top = 77;
        var slotW = 164;
        var slotH = 52;
        for (var px = requested; px >= 32; px--) {
            var boldFont = null;
            try {
                var clockFontKey = "CLOCKB:" + px.toString();
                boldFont = _fontCache[clockFontKey];
                if (boldFont == null) {
                    boldFont = Gfx.getVectorFont({:face => "RobotoCondensedBold", :size => px});
                    if (boldFont != null) { _fontCache[clockFontKey] = boldFont; }
                }
                if (boldFont != null) {
                    var dim = dc.getTextDimensions(value, boldFont);
                    if (dim[0] + 3 <= slotW && dim[1] <= slotH) {
                        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
                        var yy = top + ((slotH - dim[1]) / 2).toNumber();
                        dc.drawText(cx, yy, boldFont, value, Gfx.TEXT_JUSTIFY_CENTER);
                        // One pixel of additional weight for high contrast MIP.
                        dc.drawText(cx + 1, yy, boldFont, value, Gfx.TEXT_JUSTIFY_CENTER);
                        return;
                    }
                }
            } catch (e) { break; }
        }
        // Fallback on devices that cannot render the vector typeface.
        drawSized(dc, value, cx, top, slotW, slotH, Gfx.COLOR_WHITE, true,
                  requested, pref);
    }

    // Mini digits for compact times and symbols are kept below.

    function miniGlyph(ch) {
        if (ch == "0") { return ["111","101","101","101","101","101","111"]; }
        if (ch == "1") { return ["010","110","010","010","010","010","111"]; }
        if (ch == "2") { return ["111","001","001","111","100","100","111"]; }
        if (ch == "3") { return ["111","001","001","111","001","001","111"]; }
        if (ch == "4") { return ["101","101","101","111","001","001","001"]; }
        if (ch == "5") { return ["111","100","100","111","001","001","111"]; }
        if (ch == "6") { return ["111","100","100","111","101","101","111"]; }
        if (ch == "7") { return ["111","001","001","010","010","010","010"]; }
        if (ch == "8") { return ["111","101","101","111","101","101","111"]; }
        if (ch == "9") { return ["111","101","101","111","001","001","111"]; }
        if (ch == ":") { return ["0","1","1","0","1","1","0"]; }
        return ["000","000","000","000","000","000","000"];
    }

    // Fixed-width 3x7 glyphs. All writes are confined to the intended
    // region; use only filled rectangles so this works without font assets.
    function drawPixelDigits(dc, value, centerX, top, pixel, color) {
        if (value == null || value.length() == 0) { return; }
        var units = 0;
        for (var i = 0; i < value.length(); i++) {
            var g = miniGlyph(value.substring(i, i + 1));
            units += g[0].length() + 1;
        }
        units -= 1;
        var x = (centerX - (units * pixel) / 2).toNumber();
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        for (var k = 0; k < value.length(); k++) {
            var glyph = miniGlyph(value.substring(k, k + 1));
            for (var row = 0; row < 7; row++) {
                var bits = glyph[row];
                for (var col = 0; col < bits.length(); col++) {
                    if (bits.substring(col, col + 1) == "1") {
                        dc.fillRectangle(x + col * pixel, top + row * pixel,
                                         pixel, pixel);
                    }
                }
            }
            x += (glyph[0].length() + 1) * pixel;
        }
    }

    function onlyDigits(str) {
        if (str == null || str.length() == 0) { return false; }
        for (var i = 0; i < str.length(); i++) {
            if ("0123456789".find(str.substring(i, i + 1)) == null) {
                return false;
            }
        }
        return true;
    }
    // Sunrise and sunset times use a larger measured Garmin font.
    function drawTopClock(dc, value, center, sizeKey, slotWidth) {
        drawSized(dc, value, center, 50, slotWidth, 23,
                  Gfx.COLOR_WHITE, true,
                  fieldPixels(sizeKey, "fontTopV31", 21, 2),
                  fieldScale(sizeKey, "fontTopV31"));
    }

    // Date is on the right of the clock; the two lines are individually
    // fitted to 72px. No clips which can hide the clock or ring values.
    function drawDate(dc, dayLabel, dateLabel) {
        var settingSize = srSetting("fontDateV31", 2);
        drawSized(dc, dayLabel, 219, 80, 65, 23,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontDateV31", 27, 3), settingSize);
        drawSized(dc, dateLabel, 219, 104, 77, 25,
                  Gfx.COLOR_WHITE, false,
                  desiredPixels("fontDateV31", 24, 3), settingSize);
    }

    // Native 1px separators, including the two vertical ones requested
    // between the sunrise / moon / sunset fields.
    function rule(dc, y) {
        dc.setColor(0x696969, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        if (y == 250) {
            dc.drawLine(100, y, 190, y);
        } else if (y == 163) {
            // Short separator leaves the moon symbol and the outer rim clear.
            dc.drawLine(99, y, 242, y);
        } else {
            dc.drawLine(28, y, 252, y);
        }
    }

    function topDividers(dc) {
        dc.setColor(0x888888, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(107, 29, 107, 70);
        dc.drawLine(163, 29, 163, 70);
    }

    function weatherDivider(dc) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(109, 220, 109, 245);
    }

    // Different shapes for sunrise and sunset, not just different colors.
    // Both icons fit within x-12..x+15, y-9..y+8 on the 280px face.
    // Sunrise: arrow UP. Sunset: arrow DOWN.
    function sunIcon(dc, x, y, isRise) {
        dc.setColor(isRise ? 0xFFE8A0 : 0xFF7799, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 2, y + 6, 6, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 12, y + 7, x + 9, y + 7);
        dc.setPenWidth(1);
        dc.drawLine(x - 2, y - 4, x - 2, y - 6);
        dc.drawLine(x - 10, y, x - 8, y + 1);
        dc.drawLine(x + 5, y, x + 7, y + 1);
        // The arrow is separate from the sun, so its direction is obvious.
        dc.setPenWidth(2);
        dc.drawLine(x + 13, y - 8, x + 13, y + 1);
        if (isRise) {
            dc.drawLine(x + 10, y - 5, x + 13, y - 8);
            dc.drawLine(x + 13, y - 8, x + 16, y - 5);
        } else {
            dc.drawLine(x + 10, y - 2, x + 13, y + 1);
            dc.drawLine(x + 13, y + 1, x + 16, y - 2);
        }
        dc.setPenWidth(1);
    }

    // Solid, symmetrical heart similar to the clear heart from Garmin Connect.
    // Pixel-width fill makes it readable even at the MIP capsule's icon size.
    // Extents x-8..x+8, y-8..y+8.
    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 4, 4);
        dc.fillCircle(x + 4, y - 4, 4);
        dc.fillRectangle(x - 8, y - 4, 16, 4);
        for (var row = 0; row <= 8; row++) {
            var halfWidth = 8 - row;
            dc.drawLine(x - halfWidth, y + row, x + halfWidth, y + row);
        }
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    // Garmin Connect inspired Body Battery pictogram. Three segmented energy
    // arcs and one central circular node; vector geometry, no external assets.
    // Bounds x +/-10, y +/-10: safe even in the 64px side capsules.
    function bodyBatteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 10, Gfx.ARC_CLOCKWISE, 35, 142);
        dc.drawArc(x, y, 10, Gfx.ARC_CLOCKWISE, 158, 252);
        dc.drawArc(x, y, 10, Gfx.ARC_CLOCKWISE, 269, 342);
        dc.setPenWidth(1);
        dc.drawCircle(x, y - 2, 3);
        dc.fillCircle(x, y - 2, 2);
        dc.setPenWidth(2);
        dc.drawLine(x, y + 2, x, y + 7);
        dc.drawLine(x - 4, y + 2, x, y + 5);
        dc.drawLine(x + 4, y + 2, x, y + 5);
        dc.setPenWidth(1);
    }

    // Intensywne minuty: a fast stopwatch with three speed lines, clearly
    // distinct from the simple top-row stopwatch icon.
    // Bounds x-14..x+10, y-11..y+10.
    function intensityTimerIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x + 1, y + 1, 8);
        dc.drawLine(x + 1, y - 8, x + 1, y - 11);
        dc.drawLine(x - 2, y - 11, x + 4, y - 11);
        dc.drawLine(x + 1, y + 1, x + 4, y + 4);
        dc.drawLine(x + 1, y + 1, x + 1, y - 3);
        dc.drawLine(x - 14, y - 4, x - 9, y - 4);
        dc.drawLine(x - 14, y, x - 10, y);
        dc.drawLine(x - 14, y + 4, x - 9, y + 4);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        drawLunarDisk(dc, x, y, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // independent pressure-warning bolt, they describe present weather.
    function weatherSymbol(dc, x, y, weather) {
        if (weather == null || weather.condition == null) {
            // Missing weather: neutral outline, no invented condition.
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.drawLine(x, y - 4, x, y + 1);
            dc.drawCircle(x, y + 5, 1);
            dc.setPenWidth(1);
            return;
        }
        var c = weather.condition;
        // Pure sunshine.
        if (c == Weather.CONDITION_CLEAR || c == Weather.CONDITION_FAIR ||
            c == Weather.CONDITION_MOSTLY_CLEAR) {
            dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y - 2, 10);
            dc.drawLine(x, y - 19, x, y - 15);
            dc.drawLine(x, y + 11, x, y + 16);
            dc.drawLine(x - 18, y - 2, x - 14, y - 2);
            dc.drawLine(x + 14, y - 2, x + 18, y - 2);
            dc.drawLine(x - 13, y - 15, x - 10, y - 12);
            dc.drawLine(x + 10, y + 8, x + 13, y + 11);
            dc.drawLine(x + 12, y - 15, x + 9, y - 12);
            dc.drawLine(x - 9, y + 8, x - 12, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Cloud with some sun.
        if (c == Weather.CONDITION_PARTLY_CLOUDY ||
            c == Weather.CONDITION_PARTLY_CLEAR ||
            c == Weather.CONDITION_THIN_CLOUDS) {
            cloud(dc, x, y);
            return;
        }
        // Cloud and precipitation.
        if (c == Weather.CONDITION_RAIN || c == Weather.CONDITION_LIGHT_RAIN ||
            c == Weather.CONDITION_HEAVY_RAIN || c == Weather.CONDITION_DRIZZLE ||
            c == Weather.CONDITION_SCATTERED_SHOWERS || c == Weather.CONDITION_SHOWERS ||
            c == Weather.CONDITION_LIGHT_SHOWERS || c == Weather.CONDITION_HEAVY_SHOWERS ||
            c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN ||
            c == Weather.CONDITION_UNKNOWN_PRECIPITATION) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(0x00AAFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 12, x - 13, y + 18);
            dc.drawLine(x, y + 12, x - 3, y + 18);
            dc.drawLine(x + 10, y + 12, x + 7, y + 18);
            dc.setPenWidth(1);
            return;
        }
        // Snow / wintry conditions.
        if (c == Weather.CONDITION_SNOW || c == Weather.CONDITION_LIGHT_SNOW ||
            c == Weather.CONDITION_HEAVY_SNOW || c == Weather.CONDITION_FLURRIES ||
            c == Weather.CONDITION_CHANCE_OF_SNOW || c == Weather.CONDITION_WINTRY_MIX ||
            c == Weather.CONDITION_RAIN_SNOW || c == Weather.CONDITION_ICE_SNOW ||
            c == Weather.CONDITION_LIGHT_RAIN_SNOW || c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
            c == Weather.CONDITION_FREEZING_RAIN || c == Weather.CONDITION_SLEET ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 11, x - 10, y + 19);
            dc.drawLine(x - 14, y + 15, x - 6, y + 15);
            dc.drawLine(x + 7, y + 11, x + 7, y + 19);
            dc.drawLine(x + 3, y + 15, x + 11, y + 15);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_THUNDERSTORMS ||
            c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
            c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS ||
            c == Weather.CONDITION_TROPICAL_STORM) {
            simpleCloud(dc, x, y - 6);
            stormBolt(dc, x + 2, y + 13);
            return;
        }
        if (c == Weather.CONDITION_FOG || c == Weather.CONDITION_MIST ||
            c == Weather.CONDITION_HAZY || c == Weather.CONDITION_HAZE) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 20, y - 9, x + 16, y - 9);
            dc.drawLine(x - 16, y - 2, x + 20, y - 2);
            dc.drawLine(x - 20, y + 5, x + 15, y + 5);
            dc.drawLine(x - 13, y + 12, x + 20, y + 12);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_WINDY || c == Weather.CONDITION_SQUALL) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 22, y - 5, x + 12, y - 5);
            dc.drawLine(x - 12, y + 3, x + 19, y + 3);
            dc.drawLine(x - 19, y + 11, x + 10, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Overcast / unclassified present weather.
        simpleCloud(dc, x, y);
    }

    function simpleCloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 11, y + 2, 8);
        dc.fillCircle(x + 1, y - 4, 11);
        dc.fillCircle(x + 14, y + 3, 8);
        dc.fillRectangle(x - 17, y + 3, 38, 9);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    // Only the existing pictogram changes color when an optional threshold is
    // crossed. This adds no icons/lines and preserves the approved geometry.
    // d[2] is a 0..1 ratio, not a percent; null means no dependable data.
    function statusIconColor(id, ratio, normalColor) {
        if (!srSetting("statusColorsV315", true) || ratio == null) {
            return normalColor;
        }
        var percent = ratio.toFloat() * 100.0;
        if (id == 17) {
            if (percent <= srSetting("batteryCriticalV315", 10)) { return Gfx.COLOR_RED; }
            if (percent <= srSetting("batteryLowV315", 20)) { return Gfx.COLOR_YELLOW; }
        }
        if (id == 3 && percent <= srSetting("bodyLowV315", 20)) {
            return Gfx.COLOR_ORANGE;
        }
        if (id == 10 && percent >= srSetting("stressHighV315", 80)) {
            return Gfx.COLOR_ORANGE;
        }
        return normalColor;
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 35) {
            var currentWeather = null;
            try { currentWeather = Weather.getCurrentConditions(); } catch (e) { }
            var event = nextSunEvent(currentWeather);
            if (event != null) { sunIcon(dc, x, y, event[0]); }
            else { genericIcon(dc, x, y, Gfx.COLOR_LT_GRAY); }
        }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3) { bodyBatteryIcon(dc, x, y, color); }
        else if (id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { intensityTimerIcon(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }


    // Lunar phase illustration: illuminated fraction changes as the synodic
    // cycle progresses. It is intentionally simple for low-color MIP displays.
    function drawLunarDisk(dc, x, y, r) {
        var phase = moonFraction();
        if (phase < 0.0) { phase += 1.0; }
        dc.setColor(0x303044, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, r);
        dc.setColor(0xEEEEFF, Gfx.COLOR_TRANSPARENT);
        var cosPhase = Math.cos(2.0 * Math.PI * phase);
        for (var row = -r; row <= r; row++) {
            var extent = Math.sqrt((r * r - row * row).toFloat());
            var leftEdge = x - extent.toNumber();
            var rightEdge = x + extent.toNumber();
            if (phase < 0.5) {
                var startX = x + (extent * cosPhase).toNumber();
                if (startX <= rightEdge) {
                    dc.drawLine(startX, y + row, rightEdge, y + row);
                }
            } else {
                var endX = x - (extent * cosPhase).toNumber();
                if (leftEdge <= endX) {
                    dc.drawLine(leftEdge, y + row, endX, y + row);
                }
            }
        }
        dc.setColor(0x9999BB, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawCircle(x, y, r);
    }

    // Independent, optional lunar panel with its own mobile font control.
    // Short labels are deliberately preferred to unreadably small long names.
    function drawMoonPanel(dc) {
        if (!srSetting("moonPanelV38", true)) { return; }
        // Warning appears ONLY after a qualified pressure trend.
        // Dedicated left gutter ensures it cannot collide with lunar graphic.
        if (_storm.warning()) { stormBolt(dc, 46, 147); }
        drawLunarDisk(dc, 76, 147, 12);
        dc.setColor(0x999999, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(101, 135, 101, 158);
        var mode = srSetting("moonLabelV38", 0);
        var value = mode == 0 ? moonPhaseCompactLabel() : moonPhaseExtendedLabel();
        drawSized(dc, value, 182, 135, 136, 24,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("moonFontV38", "fontWeatherV31", 19, 2),
                  fieldScale("moonFontV38", "fontWeatherV31"));
    }

    function topSlot(dc, x, id, sizeKey, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        if (id == 35) {
            var event = nextSunEvent(weather);
            if (event != null) { sunIcon(dc, x, 36, event[0]); }
            else { genericIcon(dc, x, 36, Gfx.COLOR_LT_GRAY); }
        } else {
            drawIcon(dc, x, 36, id, 0x00CCFF);
        }
        var v = d[1];
        var boxWidth = x == 134 ? 45 : 66;
        if (id == 14 || id == 15 || id == 35) {
            drawTopClock(dc, v, x, sizeKey, boxWidth);
        } else {
            drawSized(dc, v, x, 49, boxWidth, 24,
                      Gfx.COLOR_WHITE, false,
                      fieldPixels(sizeKey, "fontTopV31", 19, 2),
                      fieldScale(sizeKey, "fontTopV31"));
        }
    }

    // v3.12: Three capsules with independent safe lanes for icon, number and
    // progress. Works for any selectable metric with or without a ratio.
    // Border y=167..211; icon center y=182; text y=171..191;
    // progress track y=196..199. The separator is below at y=215.
    function capsuleTrack(dc, left, top, width, ratio, color, stepsReached, showDone) {
        if (ratio == null) { return; }
        var p = ratio.toFloat();
        if (p < 0.0) { p = 0.0; }
        if (p > 1.0) { p = 1.0; }
        var bx = left + 10;
        // Raised a little and made thicker for better visibility.
        var by = top + 29;
        var barH = 4;
        var barWidth = width - 20;
        // At 100% steps the check has its OWN 12px lane at track's right;
        // no check mark is ever painted on top of a filled progress bar.
        if (showDone) { barWidth -= 12; }
        dc.setColor(0x283144, Gfx.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(bx, by, barWidth, barH, 2);
        var fill = (p * barWidth.toFloat()).toNumber();
        if (fill >= 2) {
            dc.setColor(stepsReached ? Gfx.COLOR_GREEN : color, Gfx.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(bx, by, fill, barH, 2);
        }
        if (showDone) {
            // An outlined green DONE circle occupies x=right-20..right-10.
            // Text is in y=171..191; this icon is in y=193..203.
            dc.setColor(Gfx.COLOR_GREEN, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(1);
            var cx = left + width - 15;
            var cy = by + 2;
            dc.drawCircle(cx, cy, 5);
            dc.drawLine(cx - 3, cy, cx - 1, cy + 2);
            dc.drawLine(cx - 1, cy + 2, cx + 3, cy - 2);
        }
    }

    function capsule(dc, left, width, id, colorCode, sizeKey, monitor, weather, isCenter) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var col = srColor(colorCode);
        var top = 167;
        dc.setPenWidth(3);
        dc.setColor(col, Gfx.COLOR_TRANSPARENT);
        dc.drawRoundedRectangle(left, top, width, 44, 19);
        dc.setPenWidth(1);
        // Icon occupies x=left+6..+28, number starts at x=left+30.
        // Lowest icon point at y=192, below top border and above track.
        var iconX = left + 17;
        // Alert only recolors the existing icon; capsule border stays themed.
        drawIcon(dc, iconX, 182, id, statusIconColor(id, d[2], col));
        var value = d[1];
        var stepsReached = false;
        if (id == 2) {
            if (monitor.steps != null && monitor.stepGoal != null &&
                monitor.stepGoal > 0 && monitor.steps >= monitor.stepGoal) {
                stepsReached = true;
            }
            if (monitor.steps != null) {
                var steps = monitor.steps;
                if (isCenter && srSetting("capsuleStepsModeV39", 0) == 1 &&
                    monitor.stepGoal != null && monitor.stepGoal > 0) {
                    steps = monitor.stepGoal - steps;
                    if (steps < 0) { steps = 0; }
                }
                value = steps < 1000000 ? steps.toString() : compact(steps);
            }
        }
        var valueW = width - 35;
        var valueCenter = left + 30 + (valueW / 2).toNumber();
        drawSized(dc, value, valueCenter, 171, valueW, 20,
                  Gfx.COLOR_WHITE, onlyDigits(value),
                  fieldPixels(sizeKey, "fontRingV31", isCenter ? 23 : 21, 2),
                  fieldScale(sizeKey, "fontRingV31"));
        var showDone = stepsReached && srSetting("stepDoneV314", true);
        capsuleTrack(dc, left, top, width, d[2], col, stepsReached, showDone);
    }

    // A single thermometer glyph for both temperature warnings. The narrow
    // 14x17px icon fits between the weather divider and temperature text on
    // the 280x280 MIP display, without touching the captions underneath.
    // The entire symbol changes color rather than adding extra UI elements.
    function warningThermometer(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        // Outline, mercury column and filled round bulb.
        // Bounds x-4..x+4, y-8..y+9.
        dc.drawRoundedRectangle(x - 3, y - 8, 6, 13, 2);
        dc.fillRectangle(x - 1, y - 5, 2, 10);
        dc.fillCircle(x, y + 5, 4);
        dc.setPenWidth(1);
    }

    // Displays ONLY when weather temperature crosses a configured threshold.
    // We deliberately reuse v3.12 property IDs so current iPhone settings and
    // saved threshold preferences stay compatible across updates.
    function temperatureMarker(dc, w, x, y) {
        if (!srSetting("tempAlertsV312", true) || w == null ||
            w.temperature == null) { return; }
        var temp = w.temperature;
        var hot = srSetting("tempHotV312", 30);
        var cold = srSetting("tempColdV312", 0);
        if (temp > hot) {
            // Orange/red tone: over the hot threshold (e.g. >30C).
            warningThermometer(dc, x, y, Gfx.COLOR_ORANGE);
        } else if (temp < cold) {
            // Bright cold blue: below the cold threshold (e.g. <0C).
            warningThermometer(dc, x, y, 0x00CCFF);
        }
    }

    // Polish IMGW weather warning: a symbol per phenomenon and official
    // severity color. Local simplified vector icons are drawn in Monkey C.
    // Event categories: 1 storm, 2 wind, 3 rain, 4 snow, 5 ice,
    //                   6 heat, 7 fog, 8 cold, 9 other.
    function imgwAlert(dc, x, y, category, level) {
        var color = Gfx.COLOR_YELLOW;
        if (level == 2) { color = Gfx.COLOR_ORANGE; }
        else if (level >= 3) { color = Gfx.COLOR_RED; }
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        if (category == 1) { // Thunderstorm
            dc.drawLine(x + 2, y - 8, x - 3, y + 1);
            dc.drawLine(x - 3, y + 1, x + 2, y + 1);
            dc.drawLine(x + 2, y + 1, x - 2, y + 8);
        } else if (category == 2) { // Wind
            dc.drawLine(x - 7, y - 4, x + 4, y - 4);
            dc.drawArc(x + 3, y - 7, 3, Gfx.ARC_CLOCKWISE, 180, 360);
            dc.drawLine(x - 8, y + 1, x + 7, y + 1);
            dc.drawLine(x - 6, y + 6, x + 3, y + 6);
        } else if (category == 3) { // Heavy rain
            dc.drawArc(x - 1, y - 3, 6, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
            dc.drawLine(x - 7, y - 2, x + 6, y - 2);
            dc.drawLine(x - 5, y + 1, x - 7, y + 6);
            dc.drawLine(x, y + 1, x - 2, y + 6);
            dc.drawLine(x + 5, y + 1, x + 3, y + 6);
        } else if (category == 4) { // Heavy snowfall: cloud + two snowflakes
            // Cloud silhouette occupies y-9..y, snowflakes y+2..y+7.
            // Deliberately different from freezing-rain drops over icy ground.
            dc.fillCircle(x - 4, y - 4, 3);
            dc.fillCircle(x + 1, y - 5, 4);
            dc.fillCircle(x + 5, y - 3, 3);
            dc.fillRectangle(x - 7, y - 4, 14, 4);
            dc.setPenWidth(1);
            dc.drawLine(x - 4, y + 2, x - 4, y + 7);
            dc.drawLine(x - 6, y + 4, x - 2, y + 4);
            dc.drawLine(x + 4, y + 2, x + 4, y + 7);
            dc.drawLine(x + 2, y + 4, x + 6, y + 4);
            dc.setPenWidth(2);
        } else if (category == 5) { // Ice
            dc.drawLine(x - 7, y, x + 7, y);
            dc.drawLine(x, y - 7, x, y + 7);
            dc.drawCircle(x, y, 3);
        } else if (category == 7) { // Heat
            dc.drawCircle(x, y, 4);
            dc.drawLine(x, y - 8, x, y - 6);
            dc.drawLine(x, y + 6, x, y + 8);
            dc.drawLine(x - 8, y, x - 6, y);
            dc.drawLine(x + 6, y, x + 8, y);
        } else if (category == 10) { // Fog
            dc.drawLine(x - 7, y - 5, x + 7, y - 5);
            dc.drawLine(x - 8, y, x + 5, y);
            dc.drawLine(x - 5, y + 5, x + 8, y + 5);
        } else if (category == 6) { // Freezing rain: two drops + ice sheet
            // Strong triangular drops; double horizontal line = frozen surface.
            // No snowflake and no cloud: unmistakable at just 18x18 pixels.
            dc.drawLine(x - 4, y - 8, x - 7, y - 2);
            dc.drawLine(x - 7, y - 2, x - 1, y - 2);
            dc.drawLine(x - 1, y - 2, x - 4, y - 8);
            dc.drawLine(x + 4, y - 8, x + 1, y - 2);
            dc.drawLine(x + 1, y - 2, x + 7, y - 2);
            dc.drawLine(x + 7, y - 2, x + 4, y - 8);
            dc.setPenWidth(1);
            dc.drawLine(x - 8, y + 4, x + 8, y + 4);
            dc.drawLine(x - 6, y + 7, x + 6, y + 7);
            dc.setPenWidth(2);
        } else if (category == 8) { // Strong frost: thermometer outline
            dc.drawRoundedRectangle(x - 3, y - 7, 6, 11, 2);
            dc.fillCircle(x, y + 5, 4);
            dc.drawLine(x - 1, y - 3, x - 1, y + 4);
        } else if (category == 9) { // Ground frost: short grass and ice
            dc.drawLine(x - 7, y + 6, x + 7, y + 6);
            dc.drawLine(x - 3, y + 6, x - 5, y - 3);
            dc.drawLine(x + 3, y + 6, x + 5, y - 3);
            dc.drawLine(x - 6, y - 6, x + 6, y + 1);
        } else if (category == 11) { // Snowdrift / blizzard
            dc.drawLine(x - 8, y - 5, x + 6, y - 5);
            dc.drawLine(x - 7, y, x + 8, y);
            dc.drawLine(x - 5, y + 5, x + 6, y + 5);
            dc.fillCircle(x - 2, y - 7, 1);
            dc.fillCircle(x + 5, y + 3, 1);
        } else if (category == 12) { // Thaw: melting ice droplet
            dc.drawLine(x - 7, y - 4, x + 7, y - 4);
            dc.drawLine(x, y - 8, x, y);
            dc.drawCircle(x, y + 4, 4);
        } else { // Unknown alert: triangle + exclamation
            dc.drawLine(x, y - 7, x + 7, y + 6);
            dc.drawLine(x + 7, y + 6, x - 7, y + 6);
            dc.drawLine(x - 7, y + 6, x, y - 7);
            dc.drawLine(x, y - 2, x, y + 2);
            dc.fillCircle(x, y + 4, 1);
        }
        dc.setPenWidth(1);
    }

    // The watch face cannot turn on GPS. Read a recent *watch GPS fix* only.
    // Store it for the IMGW background network worker. Never use Garmin weather
    // observation station coordinates as though they were the user's location.
    function captureImgwLocation() {
        if (!srSetting("imgwOnV317", false)) { return; }
        try {
            var fix = Position.getInfo();
            if (fix == null || fix.position == null || fix.when == null ||
                fix.accuracy == Position.QUALITY_NOT_AVAILABLE) { return; }
            var now = Time.now().value();
            var then = fix.when.value();
            if (then > now || now - then > 21600) { return; }
            var latLon = fix.position.toDegrees();
            if (latLon == null || latLon.size() < 2) { return; }
            var lat = latLon[0].toFloat();
            var lon = latLon[1].toFloat();
            if (lat < 49.0 || lat > 55.1 || lon < 14.0 || lon > 24.3) { return; }
            var last = Storage.getValue("imgwLocV318");
            if (last == null || last.size() < 3 || last[2] != then ||
                Math.abs(last[0] - lat) > 0.002 ||
                Math.abs(last[1] - lon) > 0.002) {
                Storage.setValue("imgwLocV318", [lat, lon, then]);
            }
        } catch (e) { }
    }

    // A cached result expires after 2h, or immediately when watch GPS shows
    // the wearer moved more than approximately 1km from its lookup point.
    function activeImgwAlert() {
        if (!srSetting("imgwOnV317", false)) { return null; }
        try {
            var data = Storage.getValue("imgwResultV318");
            var loc = Storage.getValue("imgwLocV318");
            if (data == null || data.size() < 6 || loc == null || loc.size() < 3) { return null; }
            if (data[0] == null || data[0].toString().length() != 4 ||
                data[1] <= 0 || data[2] <= 0) { return null; }
            var age = Time.now().value() - data[3];
            var fixAge = Time.now().value() - loc[2];
            if (age < 0 || age > 7200 || fixAge < 0 || fixAge > 21600) { return null; }
            if (Math.abs(data[4] - loc[0]) > 0.01 ||
                Math.abs(data[5] - loc[1]) > 0.01) { return null; }
            return data;
        } catch (e) { }
        return null;
    }

    // Dedicated 43px weather area. Same visual composition as the reference:
    // pictogram LEFT, large temperature RIGHT, short condition BELOW.
    // Weather zone Y=207..249, deliberately independent from the rings
    // and footer. The icon changes with the actual Garmin weather condition.
    // Weather is composed like the reference: large dynamic icon LEFT,
    // divider, large temperature RIGHT, condition directly underneath.
    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var isTemp = (id == 16 || id == 18);
        var hasThermometer = false;
        if (isTemp && srSetting("tempAlertsV312", true) && weather != null &&
            weather.temperature != null) {
            var hot = srSetting("tempHotV312", 30);
            var cold = srSetting("tempColdV312", 0);
            hasThermometer = weather.temperature > hot || weather.temperature < cold;
        }
        var imgw = activeImgwAlert();
        var hasImgw = (imgw != null) && isTemp;
        if (id == 16) {
            weatherSymbol(dc, 74, 235, weather);
        } else {
            drawIcon(dc, 74, 235, id, 0x00CCFF);
        }
        // Two independent warning slots to the left of the actual temperature.
        // Both appear simultaneously; numeric field always stays to their right.
        if (hasThermometer) { temperatureMarker(dc, weather, 124, 224); }
        if (hasImgw) {
            imgwAlert(dc, hasThermometer ? 144 : 124, 224, imgw[2], imgw[1]);
        }
        var textX = 174;
        var textWidth = 105;
        if (hasImgw && hasThermometer) {
            textX = 198;
            textWidth = 78;
        } else if (hasImgw || hasThermometer) {
            textX = 183;
            textWidth = 91;
        }
        drawSized(dc, d[1], textX, 215, textWidth, 22,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("sizeWeatherValueV37", "fontWeatherV31", 27, 2),
                  fieldScale("sizeWeatherValueV37", "fontWeatherV31"));
        // Optional second temperature in the existing label lane, without
        // shrinking the main number or colliding with two warning icons.
        // When off, the original weather description is unchanged.
        var lowerLabel = id == 16 ? conditionText(weather) : d[0];
        var lowerColor = id == 16 ? Gfx.COLOR_WHITE : Gfx.COLOR_LT_GRAY;
        if (isTemp && srSetting("showFeelsLikeV319", false) && weather != null &&
            weather.feelsLikeTemperature != null) {
            lowerLabel = "ODCZ. " + weather.feelsLikeTemperature.format("%.0f") + "°C";
            lowerColor = Gfx.COLOR_WHITE;
        }
        drawSized(dc, lowerLabel, 174, 234, 105, 16,
                  lowerColor, false,
                  fieldPixels("sizeWeatherLabelV37", "fontWeatherV31", 17, 2),
                  fieldScale("sizeWeatherLabelV37", "fontWeatherV31"));
    }

    // Battery footer resides inside the circle at Y=251..267 and cannot
    // touch the outer progress ring. All contents stay in a 76px box.
    // Battery is separate from the outer ring and weather description.
    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 117, 261, id,
                 statusIconColor(id, d[2], Gfx.COLOR_GREEN));
        drawSized(dc, d[1], 165, 251, 60, 20,
                  Gfx.COLOR_WHITE, false,
                  fieldPixels("sizeFooterV37", "fontWeatherV31", 22, 2),
                  fieldScale("sizeFooterV37", "fontWeatherV31"));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = readField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 131;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function onUpdate(dc) {
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var clock = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND", "PN", "WT", "SR", "CZ", "PT", "SB"];
        var months = ["STY", "LUT", "MAR", "KWI", "MAJ", "CZE",
                      "LIP", "SIE", "WRZ", "PAZ", "LIS", "GRU"];
        var monitor = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }
        captureImgwLocation();

        outerProgressRing(dc, monitor, w, clock);
        topSlot(dc, 73, srSetting("slotTop1V3", 14), "sizeTopLeftV37", monitor, w);
        topSlot(dc, 134, srSetting("slotTop2V3", 34), "sizeTopMidV37", monitor, w);
        topSlot(dc, 195, srSetting("slotTop3V3", 15), "sizeTopRightV37", monitor, w);
        topDividers(dc);
        rule(dc, 76);

        drawClock(dc, clock);
        drawDate(dc, days[date.day_of_week - 1],
                 date.day.toString() + " " + months[date.month - 1]);
        rule(dc, 130);

        drawMoonPanel(dc);
        rule(dc, 163);

        capsule(dc, 32, 64, srSetting("slotRing1V3", 1),
                srSetting("colorRing1V3", 0), "sizeRingLeftV37", monitor, w, false);
        capsule(dc, 99, 83, srSetting("slotRing2V3", 2),
                srSetting("colorRing2V3", 2), "sizeRingMidV37", monitor, w, true);
        capsule(dc, 185, 64, srSetting("slotRing3V3", 3),
                srSetting("colorRing3V3", 6), "sizeRingRightV37", monitor, w, false);
        rule(dc, 215);

        drawWeather(dc, monitor, w);
        weatherDivider(dc);
        rule(dc, 250);
        drawBattery(dc, monitor, w);

        if (!srSetting("moonPanelV38", true) && _storm.warning()) { stormBolt(dc, 46, 147); }
    }

    
}
