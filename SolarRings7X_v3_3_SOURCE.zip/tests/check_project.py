#!/usr/bin/env python3
"""Offline structural and layout guards for Solar Rings 7X v3.3.

These checks cannot substitute Garmin SDK compilation or a physical watch test.
"""
import xml.etree.ElementTree as ET
from pathlib import Path
import re

P = Path(__file__).resolve().parent.parent
S = (P / "source/SolarRings7X.mc").read_text()
F = (P / "source/FieldData.mc").read_text()
CFG = (P / "source/Config.mc").read_text()
M = ET.parse(P / "manifest.xml").getroot()
app = M.find('{http://www.garmin.com/xml/connectiq}application')
assert app is not None and app.get("version") == "3.3.0"
assert app.get('id') == 'D1F8E1A4B7FC45BD91E8F0A0959041BF'
settings = ET.parse(P / 'resources/settings/settings.xml').getroot()
properties = ET.parse(P / 'resources/settings/properties.xml').getroot()
strings = ET.parse(P / 'resources/strings.xml').getroot()
props = {p.attrib['id']: p.text for p in properties.findall('property')}
strs = {t.attrib['id'] for t in strings.findall('string')}
assert len(props) == len(settings.findall('setting')) == 21
assert len(strs) == len(strings.findall('string'))
for x in settings.findall('setting'):
    key = x.attrib['propertyKey'].split('.')[-1]
    label = x.attrib['title'].split('.')[-1]
    assert key in props and label in strs, key
    config = x.find('settingConfig')
    assert config is not None
    for entry in config.findall('listEntry'):
        assert entry.text.split('.')[-1] in strs
for slot in ['slotTop1V3','slotTop2V3','slotTop3V3','slotRing1V3','slotRing2V3','slotRing3V3','slotLowerV3','slotFooterV3']:
    keys = [e.attrib.get('value') for x in settings.findall('setting')
            if x.attrib['propertyKey'] == '@Properties.' + slot
            for e in x.find('settingConfig').findall('listEntry')]
    assert keys == list(map(str,range(36))), slot

assert 'onSettingsChanged()' in S and 'Ui.requestUpdate()' in S
assert 'Props.getValue(key)' in CFG
assert 'Activity.getActivityInfo()' in F and 'activity.currentHeartRate' in F
assert 'Weather.getSunrise' in F and 'Weather.getSunset' in F
assert 'function stormBolt(' in S

# New order: solar -> hour/date -> rings -> weather -> battery.
p = S.index('function onUpdate(dc)')
on_update = S[p:]
markers=['topSlot(dc, 72', 'drawClock(dc, clock)', 'ring(dc, 61', 'drawWeather(dc, monitor, w)', 'drawBattery(dc, monitor, w)']
indices=[on_update.index(marker) for marker in markers]
assert indices == sorted(indices)
assert on_update.count('topSlot(dc, ') == 3
assert on_update.count('ring(dc, ') == 3
assert 'rule(dc, 89)' in on_update and 'rule(dc, 143)' in on_update
assert 'rule(dc, 207)' in on_update and 'rule(dc, 246)' in on_update

# Adjacent source layout zones are disjoint at all times.
zones = {'upper':(27,84),'clock':(94,140),'rings':(145,202),'weather':(208,245),'footer':(248,268)}
last = -1
for name,(start,end) in zones.items():
    assert last < start <= end < 280,name
    last=end
# Top slots are narrow and close but do not overlap in their 72px bounding boxes.
centers=(72,140,208)
# Boxes can touch by 4px, but actual rendering is confined to 72px
# and long Moon-phase labels fit into their own centered reserved area.
assert centers[1]-centers[0] == centers[2]-centers[1] == 68
assert centers[0] - 36 >= 36 and centers[2] + 36 <= 244
for size in (2,3,4):
    assert size * 18 <= 72  # actual mini clock width, including HH:MM
# Hour and date areas are side-by-side with a positive gap.
for size in (4,5,6):
    assert size * 27 <= 162  # 5 digit numeric HH:MM pixels
    assert 98 - (size*27)/2 >= 16
    assert 98 + (size*27)/2 < 218 - 70/2
assert all(f'pixel = {i}' in S for i in (4,5,6))
assert 'function drawClock(dc, clock)' in S
assert 'function drawDate(dc, dayLabel, dateLabel)' in S
assert 'if (sz == 1) { font = Gfx.FONT_TINY; }' in S
assert 'function drawTopClock(dc, value, center)' in S
# Confirm clock glyph patterns are rectangular and seven rows tall.
glyph_bodies = re.findall(r'if \(ch == "[0-9:]"\) \{ return \[(.*?)\]; \}',S)
assert len(glyph_bodies)==22
for g in glyph_bodies:
    rows=re.findall(r'"([01]+)"',g)
    assert len(rows)==7
    assert all(len(r)==len(rows[0]) for r in rows)
for cx in (61,140,219):
    assert cx-28>14 and cx+28<266
assert 143 < 174-28 and 174+28 < 207
assert 'var y = 174;' in S and 'var radius = 28;' in S
assert 'weatherSymbol(dc, 75, 224, weather)' in S
assert 'stormBolt(dc, 255, 172)' in S
assert 'srSetting("fontClockV31", 2)' in S
assert 'srSetting("fontDateV31", 2)' in S
# Check balanced braces after removing comment/string literals (lightweight lexical guard).
text=re.sub(r'//[^\n]*','',S)
text=re.sub(r'"(?:\\.|[^"\\])*"','""',text)
assert text.count('{')==text.count('}'),(text.count('{'),text.count('}'))
print('PASS: v3.3 XML, 21 iPhone settings, three top slots, bigger 3-scale clock, date, rings and weather geometry')
