using Toybox.Application as App;
using Toybox.WatchUi as Ui;
using Toybox.Graphics as Gfx;
using Toybox.System as System;
using Toybox.Time as Time;
using Toybox.Time.Gregorian as Gregorian;
using Toybox.Weather as Weather;
using Toybox.ActivityMonitor as Monitor;

class SolarRings7XApp extends App.AppBase {
    function initialize() { AppBase.initialize(); }
    function getInitialView() { return [new SolarRingsFaceV3()]; }
    function onSettingsChanged() { Ui.requestUpdate(); }
}

class SolarRingsFaceV3 extends Ui.WatchFace {
    var _storm;

    function initialize() {
        WatchFace.initialize();
        _storm = new StormGuard();
    }

    // Select genuinely different font sizes for SMALL / NORMAL / LARGE.
    // Always fit the selected font to a reserved box; never draw outside it.
    // IMPORTANT: using a single dynamic largest-fit list made small and
    // large look identical in v3.1. This implementation uses distinct caps.
    function fitScaled(dc, value, x, top, width, height, color, numeric, scale) {
        if (value == null || width <= 0 || height <= 0) { return; }
        var str = value.toString();
        if (str.length() == 0) { return; }

        var isNumber = numeric;
        if (numeric) {
            for (var i = 0; i < str.length(); i++) {
                var character = str.substring(i, i + 1);
                if ("0123456789:".find(character) == null) {
                    isNumber = false;
                    break;
                }
            }
        }
        var fonts;
        if (isNumber) {
            if (scale <= 0) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_NUMBER_HOT, Gfx.FONT_NUMBER_MEDIUM,
                         Gfx.FONT_NUMBER_MILD, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        } else {
            if (scale <= 0) {
                fonts = [Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else if (scale == 1) {
                fonts = [Gfx.FONT_SMALL, Gfx.FONT_TINY, Gfx.FONT_XTINY];
            } else {
                fonts = [Gfx.FONT_MEDIUM, Gfx.FONT_SMALL,
                         Gfx.FONT_TINY, Gfx.FONT_XTINY];
            }
        }

        var font = null;
        var glyphH = 0;
        for (var n = 0; n < fonts.size(); n++) {
            var dimensions = dc.getTextDimensions(str, fonts[n]);
            if (dimensions[0] <= width && dimensions[1] <= height) {
                font = fonts[n];
                glyphH = dimensions[1];
                break;
            }
        }
        if (font == null) {
            font = Gfx.FONT_XTINY;
            glyphH = dc.getFontHeight(font);
            // Never truncate digits such as 12345 / 25000.
            if (!isNumber) {
                while (str.length() > 1 &&
                       dc.getTextWidthInPixels(str, font) > width) {
                    str = str.substring(0, str.length() - 1);
                }
            }
        }
        // Prevent Garmin's native font bearings from spilling into adjacent
        // sections even when a model has unusually large font metrics.
        var left = (x - width / 2).toNumber();
        dc.setClip(left, top, width, height);
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.drawText(x, top + ((height - glyphH) / 2).toNumber(),
                    font, str, Gfx.TEXT_JUSTIFY_CENTER);
        dc.clearClip();
    }

    function fit(dc, value, x, top, width, height, color, numeric) {
        fitScaled(dc, value, x, top, width, height, color, numeric, 1);
    }


    // Explicit pixel-clock size is independent of Garmin's native-font fallback.
    // Four digits plus colon are always exactly 27 logical columns wide.
    // SMALL=4px, NORMAL=5px, LARGE=6px; unlike v3.2 they cannot collapse
    // to the same font size when the SDK's text metrics differ.
    function clockGlyph(ch) {
        if (ch == "0") { return ["01110","10001","10011","10101","11001","10001","01110"]; }
        if (ch == "1") { return ["00100","01100","00100","00100","00100","00100","01110"]; }
        if (ch == "2") { return ["01110","10001","00001","00010","00100","01000","11111"]; }
        if (ch == "3") { return ["11110","00001","00001","01110","00001","00001","11110"]; }
        if (ch == "4") { return ["00010","00110","01010","10010","11111","00010","00010"]; }
        if (ch == "5") { return ["11111","10000","10000","11110","00001","00001","11110"]; }
        if (ch == "6") { return ["01110","10000","10000","11110","10001","10001","01110"]; }
        if (ch == "7") { return ["11111","00001","00010","00100","01000","01000","01000"]; }
        if (ch == "8") { return ["01110","10001","10001","01110","10001","10001","01110"]; }
        if (ch == "9") { return ["01110","10001","10001","01111","00001","00001","01110"]; }
        if (ch == ":") { return ["00","11","11","00","11","11","00"]; }
        return ["00000","00000","00000","00000","00000","00000","00000"];
    }

    function drawClock(dc, clock) {
        var choice = srSetting("fontClockV31", 2);
        var pixel = 6;
        if (choice <= 0) { pixel = 4; }
        else if (choice == 1) { pixel = 5; }
        var value = twoDigits(clock.hour) + ":" + twoDigits(clock.min);
        var x = (98 - (27 * pixel) / 2).toNumber();
        var y = (95 + (42 - 7 * pixel) / 2).toNumber();
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        for (var k = 0; k < value.length(); k++) {
            var glyph = clockGlyph(value.substring(k, k + 1));
            var glyphWidth = glyph[0].length();
            for (var gy = 0; gy < glyph.size(); gy++) {
                var line = glyph[gy];
                for (var gx = 0; gx < line.length(); gx++) {
                    if (line.substring(gx, gx + 1) == "1") {
                        dc.fillRectangle(x + gx * pixel, y + gy * pixel,
                                         pixel, pixel);
                    }
                }
            }
            x += (glyphWidth + 1) * pixel;
        }
    }

    // Narrow 3x7 font guarantees that sunrise and sunset HH:MM remain
    // legible in three closely spaced 72px slots (no tiny-font fallback).
    function miniGlyph(ch) {
        if (ch == "0") { return ["111","101","101","101","101","101","111"]; }
        if (ch == "1") { return ["010","110","010","010","010","010","111"]; }
        if (ch == "2") { return ["111","001","001","111","100","100","111"]; }
        if (ch == "3") { return ["111","001","001","111","001","001","111"]; }
        if (ch == "4") { return ["101","101","101","111","001","001","001"]; }
        if (ch == "5") { return ["111","100","100","111","001","001","111"]; }
        if (ch == "6") { return ["111","100","100","111","101","101","111"]; }
        if (ch == "7") { return ["111","001","001","010","010","010","010"]; }
        if (ch == "8") { return ["111","101","101","111","101","101","111"]; }
        if (ch == "9") { return ["111","101","101","111","001","001","111"]; }
        if (ch == ":") { return ["0","1","1","0","1","1","0"]; }
        return ["000","000","000","000","000","000","000"];
    }

    function drawTopClock(dc, value, center) {
        var selected = srSetting("fontTopV31", 2);
        var size = 4;
        if (selected <= 0) { size = 2; }
        else if (selected == 1) { size = 3; }
        var x = (center - 18 * size / 2).toNumber();
        var y = (55 + (29 - 7 * size) / 2).toNumber();
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        for (var i = 0; i < value.length(); i++) {
            var rows = miniGlyph(value.substring(i, i + 1));
            var gw = rows[0].length();
            for (var ry = 0; ry < rows.size(); ry++) {
                for (var rx = 0; rx < rows[ry].length(); rx++) {
                    if (rows[ry].substring(rx, rx + 1) == "1") {
                        dc.fillRectangle(x + rx * size, y + ry * size,
                                         size, size);
                    }
                }
            }
            x += (gw + 1) * size;
        }
    }

    // Date uses three explicit, different native font sizes.
    // The two lines are inside a clip with a 3px vertical gutter.
    function drawDate(dc, dayLabel, dateLabel) {
        var sz = srSetting("fontDateV31", 2);
        var font = Gfx.FONT_XTINY;
        if (sz == 1) { font = Gfx.FONT_TINY; }
        else if (sz >= 2) { font = Gfx.FONT_SMALL; }
        dc.setClip(182, 94, 72, 47);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.drawText(218, 95, font, dayLabel, Gfx.TEXT_JUSTIFY_CENTER);
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        // For long date strings, choose shorter but unambiguous layout.
        if (dc.getTextWidthInPixels(dateLabel, font) > 72) {
            var blank = dateLabel.find(" ");
            if (blank != null) {
                dateLabel = dateLabel.substring(0, blank) +
                            dateLabel.substring(blank + 1);
            }
        }
        dc.drawText(218, 118, font, dateLabel, Gfx.TEXT_JUSTIFY_CENTER);
        dc.clearClip();
    }

    function rule(dc, y) {
        dc.setColor(0x555555, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawLine(30, y, 250, y);
    }

    function sunIcon(dc, x, y, settingSun) {
        dc.setColor(settingSun ? Gfx.COLOR_YELLOW : Gfx.COLOR_ORANGE,
                    Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x, y, 5, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 9, y, x + 9, y);
        dc.drawLine(x, y - 9, x, y - 6);
        dc.setPenWidth(1);
    }

    function heart(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 4, y - 2, 4);
        dc.fillCircle(x + 4, y - 2, 4);
        dc.fillRectangle(x - 5, y, 10, 4);
        dc.drawLine(x - 7, y + 2, x, y + 9);
        dc.drawLine(x, y + 9, x + 7, y + 2);
    }

    function footprints(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 5, y - 4, 3);
        dc.fillRectangle(x - 8, y, 5, 8);
        dc.fillCircle(x + 5, y - 2, 3);
        dc.fillRectangle(x + 3, y + 2, 5, 8);
    }

    function batteryIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawRectangle(x - 9, y - 6, 17, 12);
        dc.fillRectangle(x + 8, y - 2, 3, 4);
        dc.fillRectangle(x - 6, y - 3, 9, 6);
        dc.setPenWidth(1);
    }

    function stopwatch(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y + 2, 8);
        dc.drawLine(x, y - 7, x, y - 11);
        dc.drawLine(x - 3, y - 11, x + 3, y - 11);
        dc.drawLine(x, y + 2, x + 4, y - 2);
        dc.setPenWidth(1);
    }

    function moon(dc, x, y) {
        dc.setColor(0xAAAAAA, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x, y, 7);
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x + 4, y - 2, 7);
    }

    function cloud(dc, x, y) {
        // More pronounced partly-cloudy icon, drawn without external fonts.
        dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawArc(x - 10, y - 7, 8, Gfx.ARC_COUNTER_CLOCKWISE, 0, 180);
        dc.drawLine(x - 10, y - 18, x - 10, y - 16);
        dc.drawLine(x - 21, y - 8, x - 19, y - 8);
        dc.setPenWidth(1);
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 6, y + 2, 6);
        dc.fillCircle(x + 3, y - 1, 9);
        dc.fillCircle(x + 13, y + 3, 6);
        dc.fillRectangle(x - 12, y + 3, 30, 7);
    }

    

    // Weather symbols follow the Garmin cached condition. Unlike the
    // independent pressure-warning bolt, they describe present weather.
    function weatherSymbol(dc, x, y, weather) {
        if (weather == null || weather.condition == null) {
            // Missing weather: neutral outline, no invented condition.
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y, 8);
            dc.drawLine(x, y - 4, x, y + 1);
            dc.drawCircle(x, y + 5, 1);
            dc.setPenWidth(1);
            return;
        }
        var c = weather.condition;
        // Pure sunshine.
        if (c == Weather.CONDITION_CLEAR || c == Weather.CONDITION_FAIR ||
            c == Weather.CONDITION_MOSTLY_CLEAR) {
            dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawCircle(x, y - 2, 10);
            dc.drawLine(x, y - 19, x, y - 15);
            dc.drawLine(x, y + 11, x, y + 16);
            dc.drawLine(x - 18, y - 2, x - 14, y - 2);
            dc.drawLine(x + 14, y - 2, x + 18, y - 2);
            dc.drawLine(x - 13, y - 15, x - 10, y - 12);
            dc.drawLine(x + 10, y + 8, x + 13, y + 11);
            dc.drawLine(x + 12, y - 15, x + 9, y - 12);
            dc.drawLine(x - 9, y + 8, x - 12, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Cloud with some sun.
        if (c == Weather.CONDITION_PARTLY_CLOUDY ||
            c == Weather.CONDITION_PARTLY_CLEAR ||
            c == Weather.CONDITION_THIN_CLOUDS) {
            cloud(dc, x, y);
            return;
        }
        // Cloud and precipitation.
        if (c == Weather.CONDITION_RAIN || c == Weather.CONDITION_LIGHT_RAIN ||
            c == Weather.CONDITION_HEAVY_RAIN || c == Weather.CONDITION_DRIZZLE ||
            c == Weather.CONDITION_SCATTERED_SHOWERS || c == Weather.CONDITION_SHOWERS ||
            c == Weather.CONDITION_LIGHT_SHOWERS || c == Weather.CONDITION_HEAVY_SHOWERS ||
            c == Weather.CONDITION_CHANCE_OF_SHOWERS ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN ||
            c == Weather.CONDITION_UNKNOWN_PRECIPITATION) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(0x00AAFF, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 12, x - 13, y + 18);
            dc.drawLine(x, y + 12, x - 3, y + 18);
            dc.drawLine(x + 10, y + 12, x + 7, y + 18);
            dc.setPenWidth(1);
            return;
        }
        // Snow / wintry conditions.
        if (c == Weather.CONDITION_SNOW || c == Weather.CONDITION_LIGHT_SNOW ||
            c == Weather.CONDITION_HEAVY_SNOW || c == Weather.CONDITION_FLURRIES ||
            c == Weather.CONDITION_CHANCE_OF_SNOW || c == Weather.CONDITION_WINTRY_MIX ||
            c == Weather.CONDITION_RAIN_SNOW || c == Weather.CONDITION_ICE_SNOW ||
            c == Weather.CONDITION_LIGHT_RAIN_SNOW || c == Weather.CONDITION_HEAVY_RAIN_SNOW ||
            c == Weather.CONDITION_FREEZING_RAIN || c == Weather.CONDITION_SLEET ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_SNOW ||
            c == Weather.CONDITION_CLOUDY_CHANCE_OF_RAIN_SNOW) {
            simpleCloud(dc, x, y - 5);
            dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 10, y + 11, x - 10, y + 19);
            dc.drawLine(x - 14, y + 15, x - 6, y + 15);
            dc.drawLine(x + 7, y + 11, x + 7, y + 19);
            dc.drawLine(x + 3, y + 15, x + 11, y + 15);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_THUNDERSTORMS ||
            c == Weather.CONDITION_SCATTERED_THUNDERSTORMS ||
            c == Weather.CONDITION_CHANCE_OF_THUNDERSTORMS ||
            c == Weather.CONDITION_TROPICAL_STORM) {
            simpleCloud(dc, x, y - 6);
            stormBolt(dc, x + 2, y + 13);
            return;
        }
        if (c == Weather.CONDITION_FOG || c == Weather.CONDITION_MIST ||
            c == Weather.CONDITION_HAZY || c == Weather.CONDITION_HAZE) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 20, y - 9, x + 16, y - 9);
            dc.drawLine(x - 16, y - 2, x + 20, y - 2);
            dc.drawLine(x - 20, y + 5, x + 15, y + 5);
            dc.drawLine(x - 13, y + 12, x + 20, y + 12);
            dc.setPenWidth(1);
            return;
        }
        if (c == Weather.CONDITION_WINDY || c == Weather.CONDITION_SQUALL) {
            dc.setColor(Gfx.COLOR_LT_GRAY, Gfx.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            dc.drawLine(x - 22, y - 5, x + 12, y - 5);
            dc.drawLine(x - 12, y + 3, x + 19, y + 3);
            dc.drawLine(x - 19, y + 11, x + 10, y + 11);
            dc.setPenWidth(1);
            return;
        }
        // Overcast / unclassified present weather.
        simpleCloud(dc, x, y);
    }

    function simpleCloud(dc, x, y) {
        dc.setColor(Gfx.COLOR_WHITE, Gfx.COLOR_TRANSPARENT);
        dc.fillCircle(x - 11, y + 2, 8);
        dc.fillCircle(x + 1, y - 4, 11);
        dc.fillCircle(x + 14, y + 3, 8);
        dc.fillRectangle(x - 17, y + 3, 38, 9);
    }

    function genericIcon(dc, x, y, color) {
        dc.setColor(color, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(2);
        dc.drawCircle(x, y, 5);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.setPenWidth(1);
    }

    function drawIcon(dc, x, y, id, color) {
        if (id == 0) { return; }
        if (id == 14 || id == 15) { sunIcon(dc, x, y, id == 14); }
        else if (id == 34) { moon(dc, x, y); }
        else if (id == 35) {
            var currentWeather = null;
            try { currentWeather = Weather.getCurrentConditions(); } catch (e) { }
            var event = nextSunEvent(currentWeather);
            if (event != null) { sunIcon(dc, x, y, event[0]); }
            else { genericIcon(dc, x, y, Gfx.COLOR_LT_GRAY); }
        }
        else if (id == 1) { heart(dc, x, y, color); }
        else if (id == 2) { footprints(dc, x, y, color); }
        else if (id == 3 || id == 17) { batteryIcon(dc, x, y, color); }
        else if (id == 4 || id == 5) { stopwatch(dc, x, y, color); }
        else if (id == 16 || id == 18) { cloud(dc, x, y); }
        else { genericIcon(dc, x, y, color); }
    }

    function stormBolt(dc, x, y) {
        dc.setColor(Gfx.COLOR_YELLOW, Gfx.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        dc.drawLine(x + 3, y - 8, x - 3, y);
        dc.drawLine(x - 3, y, x + 3, y);
        dc.drawLine(x + 3, y, x - 2, y + 8);
        dc.setPenWidth(1);
    }

    function topSlot(dc, x, id, monitor, weather) {
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        if (id == 35) {
            var nextEvent = nextSunEvent(weather);
            if (nextEvent != null) {
                sunIcon(dc, x, 37, nextEvent[0]);
            } else {
                genericIcon(dc, x, 37, Gfx.COLOR_LT_GRAY);
            }
        } else {
            drawIcon(dc, x, 37, id, 0x00AAFF);
        }
        // Large numeric HH:MM keeps its own exact pixel size; other data
        // (including the Moon phase) are fitted to the 72px slot.
        var value = d[1];
        if ((id == 14 || id == 15 || id == 35) &&
            value.length() == 5 && value.substring(2, 3) == ":" &&
            value.substring(0, 1) != "-") {
            drawTopClock(dc, value, x);
        } else {
            fitScaled(dc, value, x, 55, 72, 29, Gfx.COLOR_WHITE,
                      false, srSetting("fontTopV31", 2));
        }
    }

    

    function ring(dc, x, id, colorCode, monitor, weather) {
        if (id == 0) { return; }
        var data = readField(id, monitor, weather);
        var y = 174;
        var radius = 28; // smaller rings, shifted up; no overlap with weather
        var col = srColor(colorCode);
        dc.setPenWidth(5);
        dc.setColor(0x484848, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        var ratio = data[2];
        if (ratio == null) {
            dc.setPenWidth(2);
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            dc.drawCircle(x, y, radius);
        } else {
            var progress = ratio.toFloat();
            if (progress < 0) { progress = 0.0; }
            if (progress > 1) { progress = 1.0; }
            dc.setColor(col, Gfx.COLOR_TRANSPARENT);
            if (progress >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (progress > 0.004) {
                var end = 90 - (progress * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
        drawIcon(dc, x, 163, id, col);
        var displayed = data[1];
        // Keep 10 000–99 999 steps as exact values. Only 6+ digit
        // counters are abbreviated when they cannot fit in a circle.
        if (displayed.length() > 5 && id == 2) {
            var val = monitor.steps;
            if (val != null && val >= 100000) {
                displayed = compact(val);
            }
        }
        fitScaled(dc, displayed, x, 174, 62, 24, Gfx.COLOR_WHITE,
                  true, srSetting("fontRingV31", 2));
    }

    

    // Dedicated 43px weather area. Same visual composition as the reference:
    // pictogram LEFT, large temperature RIGHT, short condition BELOW.
    function drawWeather(dc, monitor, weather) {
        var id = srSetting("slotLowerV3", 16);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        var size = srSetting("fontWeatherV31", 2);
        if (id == 16) {
            weatherSymbol(dc, 75, 224, weather);
            fitScaled(dc, d[1], 174, 207, 110, 24,
                      Gfx.COLOR_WHITE, false, size);
            fitScaled(dc, conditionText(weather), 174, 229, 110, 16,
                      Gfx.COLOR_LT_GRAY, false, size);
        } else {
            drawIcon(dc, 75, 224, id, 0x00AAFF);
            fitScaled(dc, d[1], 174, 207, 110, 24,
                      Gfx.COLOR_WHITE, false, size);
            fitScaled(dc, d[0], 174, 229, 110, 16,
                      Gfx.COLOR_LT_GRAY, false, size);
        }
    }

    // Battery footer resides inside the circle at Y=251..267 and cannot
    // touch the outer progress ring. All contents stay in a 76px box.
    function drawBattery(dc, monitor, weather) {
        var id = srSetting("slotFooterV3", 17);
        if (id == 0) { return; }
        var d = readField(id, monitor, weather);
        drawIcon(dc, 116, 256, id, Gfx.COLOR_GREEN);
        fitScaled(dc, d[1], 158, 248, 60, 20,
                  Gfx.COLOR_WHITE, false, srSetting("fontWeatherV31", 2));
    }

    function outerProgressRing(dc, monitor, weather, clock) {
        var mode = srSetting("outerRingV31", 1);
        if (mode == 0) { return; }
        var ratio = null;
        if (mode == 1) {
            ratio = (clock.hour * 60.0 + clock.min) / 1440.0;
        } else {
            var dataId = 0;
            if (mode == 2) { dataId = 10; } // Stress
            if (mode == 3) { dataId = 2; }  // Steps / daily goal
            if (mode == 4) { dataId = 3; }  // Body Battery
            if (mode == 5) { dataId = 17; } // Watch battery
            if (mode == 6) { dataId = 4; }  // Weekly intensity minutes
            if (dataId != 0) {
                var field = readField(dataId, monitor, weather);
                ratio = field[2];
            }
        }
        var x = 140;
        var y = 140;
        var radius = 132;
        dc.setPenWidth(3);
        dc.setColor(0x343434, Gfx.COLOR_TRANSPARENT);
        dc.drawCircle(x, y, radius);
        if (ratio != null) {
            var p = ratio.toFloat();
            if (p < 0) { p = 0.0; }
            if (p > 1) { p = 1.0; }
            dc.setColor(srColor(srSetting("outerColorV31", 6)),
                        Gfx.COLOR_TRANSPARENT);
            if (p >= 0.999) {
                dc.drawCircle(x, y, radius);
            } else if (p > 0.004) {
                var end = 90 - (p * 359.0).toNumber();
                if (end < 0) { end += 360; }
                dc.drawArc(x, y, radius, Gfx.ARC_CLOCKWISE, 90, end);
            }
        }
        dc.setPenWidth(1);
    }

    

    function onUpdate(dc) {
        dc.setColor(Gfx.COLOR_BLACK, Gfx.COLOR_BLACK);
        dc.clear();
        var clock = System.getClockTime();
        var date = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var days = ["ND","PN","WT","SR","CZ","PT","SB"];
        var months = ["STY","LUT","MAR","KWI","MAJ","CZE","LIP","SIE","WRZ","PAZ","LIS","GRU"];
        var monitor = Monitor.getInfo();
        var w = null;
        try { w = Weather.getCurrentConditions(); } catch (e) { }

        // Outside ring first, leaving foreground text fully opaque.
        outerProgressRing(dc, monitor, w, clock);

        // 1. Three customizable solar/moon fields at the TOP.
        // Keep centers close together and clamp their texts to 72px each.
        topSlot(dc, 72, srSetting("slotTop1V3", 14), monitor, w);
        topSlot(dc, 140, srSetting("slotTop2V3", 34), monitor, w);
        topSlot(dc, 208, srSetting("slotTop3V3", 15), monitor, w);
        rule(dc, 89);

        // 2. Large clock UNDER the solar row, plus stacked date at right.
        // The pixel clock has 3 DISTINCT sizes controlled from the iPhone.
        drawClock(dc, clock);
        drawDate(dc, days[date.day_of_week - 1],
                 date.day.toString() + " " + months[date.month - 1]);
        rule(dc, 143);

        // 3. Three progress rings with icons and 5-digit step values.
        ring(dc, 61, srSetting("slotRing1V3", 1),
             srSetting("colorRing1V3", 0), monitor, w);
        ring(dc, 140, srSetting("slotRing2V3", 2),
             srSetting("colorRing2V3", 2), monitor, w);
        ring(dc, 219, srSetting("slotRing3V3", 3),
             srSetting("colorRing3V3", 6), monitor, w);
        rule(dc, 207);

        // 4. Weather is its own TWO-LINE block. Battery is separate.
        drawWeather(dc, monitor, w);
        rule(dc, 246);
        drawBattery(dc, monitor, w);
        // Independent pressure warning; shown only when guard confirms trend.
        if (_storm.warning()) { stormBolt(dc, 255, 172); }
    }

    
}
