# Solar Rings 7X v3.3 — górne pola nad godziną

**Nowy układ (Fenix 7X Pro Solar, MIP 280×280):** wschód • Księżyc • zachód na samej górze. Poniżej duża godzina z datą po prawej, trzy kółka, pogoda w dwóch wierszach i bateria.

## Kontrolki iPhone

Ustawienia dotychczasowe pozostają pod tymi samymi kluczami. **Rozmiar godziny (mały/średni/duży)** ma teraz trzy niezależne skale 4, 5 i 6 pikseli na element czcionki, co zapobiega poprzedniemu problemowi z identycznym rozmiarem. Wartość i opis pogody oraz data używają Garminowych czcionek automatycznie dopasowywanych do wydzielonej szerokości.

Górne pola mają szerokość do 72 px, więc długie teksty są skracane; czasy HH:MM mają mieścić się bez obcinania. Gdy nie ma danych o słońcu, pojawia się `--:--`. Tętno nadal korzysta z `Activity.currentHeartRate` (bez historycznej wartości), zgodnie z działającą v3.2.

## Testy i ograniczenia

Statyczne testy w `tests/check_project.py` sprawdzają strefy układu, identyfikator aplikacji, klucze ustawień i wersję. Testy statyczne nie zastępują uruchomienia na Garminie. Zewnętrzny ring i ostrzeżenie burzowe zachowują zachowanie z v3.2; ostrzeżenie ma charakter pomocniczy, nie jest prognozą ostrzegającą przed wszystkimi burzami.

## Instalacja

1. Prześlij `SolarRings7X_v3_3_SOURCE.zip` do repozytorium GitHub (do katalogu głównego).
2. Zastąp `.github/workflows/build-v3.yml` zawartością `SolarRings7X_v3_3_BUILD.yml`.
3. Actions > Build Solar Rings 7X v3.3 > Run workflow.
4. Z artefaktów pobierz plik `.IQ` i zaktualizuj **istniejącą** wersję beta przez konto deweloperskie. Instaluj przez Connect IQ, aby zachować ustawienia z telefonu.
